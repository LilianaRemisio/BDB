# bbog-dig-dt-balances-mngr-function
[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=bbog-dig-dt-balances-mngr-function&metric=alert_status&token=a0c666758c7389700f62c581d15f328ede3b2e10)](https://sonarcloud.io/summary/new_code?id=bbog-dig-dt-balances-mngr-function)

Manager tipo lambda que permite hacer la consulta de saldos de los diferentes productos.

