#!/bin/bash
set -eux
rm ~/.npmrc | true
curl -u "${ARTIFACTORY_READER_USER}:${ARTIFACTORY_READER_API_KEY}" 'https://bbogdigital.jfrog.io/bbogdigital/api/npm/auth' >> ~/.npmrc
export GITHUB_REPO_BRANCH_OAS=qa
sh ci-cd/getOASfromIaC.sh
npm install