import { RequestHeadersModel } from '../model/request-headers.model';
import { IAcctBasicInfo } from '../model/request-savings.model';
import { invokeCertificateBalanceService } from './certificate-balance.service';
import { invokeCreditCardBalanceService } from './creditcard-balance.service';
import { invokeDemandBalanceService } from './demand-balance.service';
import { invokeLoanBalanceService } from './loan-balance.service';
import { invokeSavingBalanceService } from './saving-balance.service';
import { invokeTrustBalanceService } from './trust-balance.service';
import getLogger from './utils/GetLogger';
const logBdb = getLogger('bdb:GroupBalanceService');
const TIMEOUT_IN_MILLISECONDS =15*1000;
const executeMethod= (account: IAcctBasicInfo,baseParams: RequestHeadersModel): Promise<any> => {

    return  new Promise(async (resolve, reject) => {
        let result: any;
        const rquid = baseParams['X-RqUID'];
        try {
            switch(account.acctType) {
                case 'SDA':
                    result=   invokeSavingBalanceService(account.acctId,baseParams,TIMEOUT_IN_MILLISECONDS);
                    resolve(result);
                    break;
                case 'DDA':
                    result=await  invokeDemandBalanceService(account.acctId,baseParams,TIMEOUT_IN_MILLISECONDS);
                    resolve(result);
                    break;
                case 'CCA':
                    result= await  invokeCreditCardBalanceService(account.acctId,baseParams,TIMEOUT_IN_MILLISECONDS);
                    resolve(result);
                    break;
                case 'LOC':
                    result= await invokeLoanBalanceService(account.acctId,baseParams,TIMEOUT_IN_MILLISECONDS);
                    resolve(result);
                    break;
                case 'CDA':
                    result= await invokeCertificateBalanceService(
                        account.acctId,
                        baseParams,
                        TIMEOUT_IN_MILLISECONDS,
                        account.bankInfo.branchId
                    );
                    resolve(result);
                    break;
                case 'FDA':
                    result= await invokeTrustBalanceService(account.acctId, account.acctType, account.acctSubType, account.bankInfo.branchId ,baseParams,TIMEOUT_IN_MILLISECONDS);
                    resolve(result);
                    break;
            }
        } catch(error) {
            logBdb.error(rquid, `[Failed get response for ${account.acctType}]`, JSON.stringify(error));
            resolve({});
        }
    });
};

export const invokeGroupBalanceService = async (accounts: IAcctBasicInfo[],
                                                baseParams: RequestHeadersModel): Promise<any> => {
    const balances = await Promise.all(
        accounts.map(async (account: IAcctBasicInfo) => (
            executeMethod(account, baseParams)
        ))
    );
    const rquid = baseParams['X-RqUID'];
    const responseJson = {
        balances
    };
    logBdb.debug(rquid, 'balances Formated to Struct' , JSON.stringify(responseJson));
    return responseJson;
};
