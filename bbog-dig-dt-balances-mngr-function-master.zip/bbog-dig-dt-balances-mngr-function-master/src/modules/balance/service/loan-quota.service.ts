import { getVariable } from '../../../config';
import { RequestService } from '../../core/services/request/request.service';
import { AdapterError } from '../model/adapter-error';
import { LoanQuotaHeadersModel } from '../model/loanquota-headers.model';
import { RequestHeadersModel } from '../model/request-headers.model';
import { IStructureBalanceDefinition } from '../model/structure-balance-definition';
import { generateXml,
    getResponse, parseError } from './common-service';
import getLogger from './utils/GetLogger';
import loanQuotaMapper from './utils/LoanQuotaMapper';

const logBdb = getLogger('bdb:LoanQuotaService');

export const invokeLoanQuotaService = async (baseParams: RequestHeadersModel, loanQuotaParams: LoanQuotaHeadersModel, timeout?: number): Promise<any> => {
    const rquid = baseParams['X-RqUID'];
    try {
        logBdb.debug(rquid, '[Invoke Loan Quota Service]');
        const itemsXml = addItemsXmlToRetrieveLoanQuota(loanQuotaParams);
        const requestXml = generateXml(baseParams, IStructureBalanceDefinition.LOAN_QUOTA,
            itemsXml);
        const requestService = new RequestService();
        const response = await requestService.post({
            body: requestXml,
            url: `${await getVariable('LOAN_QUOTA_ENDPOINT')}`,
            reqId: rquid,
        }, timeout);
        const xmlResponse = response.data;
        const mapperResponseBus = getResponse(IStructureBalanceDefinition.LOAN_QUOTA,
                xmlResponse as string);
        logBdb.debug(rquid,'[Successfull Loan Quota Service]');
        return loanQuotaMapper.transformResponseBusToApi(mapperResponseBus);
    } catch (error) {
        logBdb.error(rquid, '[Error in Loan Quota Service]', JSON.stringify(error));
        if(!(error instanceof AdapterError)) {
            throw parseError(error);
        } else {
            throw error;
        }
    }
};

export const addItemsXmlToRetrieveLoanQuota = (loanQuotaParams: LoanQuotaHeadersModel): string => {
    return `
    <v1:AcctBal>
    <v1:CurAmt>
       <v1:Amt>${loanQuotaParams.rate}</v1:Amt>
    </v1:CurAmt>
    <v1:CurAmt>
       <v1:Amt>${loanQuotaParams.amount}</v1:Amt>
    </v1:CurAmt>
    </v1:AcctBal>
    <v1:RefInfo>
        <v1:RefId>${loanQuotaParams.term}</v1:RefId>
    </v1:RefInfo>
    <v1:RefInfo>
        <v1:RefId>${loanQuotaParams.increase}</v1:RefId>
    </v1:RefInfo>
    <v1:RefInfo>
        <v1:RefId>${loanQuotaParams.frequency}</v1:RefId>
    </v1:RefInfo>
    <v1:RefInfo>
        <v1:RefId>${loanQuotaParams.accrualBase}</v1:RefId>
    </v1:RefInfo>
    <v1:RefInfo>
        <v1:RefId>${loanQuotaParams.accrualMethod}</v1:RefId>
    </v1:RefInfo>
    <v1:OpenDt>${loanQuotaParams.disbursementDate}</v1:OpenDt>
    <v1:DueDt>${loanQuotaParams.firstPaymentDate}</v1:DueDt>`;
};
