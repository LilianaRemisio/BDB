import { getVariable } from '../../../config';
import { RequestService } from '../../core/services/request/request.service';
import { AdapterError } from '../model/adapter-error';
import { RequestHeadersModel } from '../model/request-headers.model';
import { IStructureBalanceDefinition } from '../model/structure-balance-definition';
import { generateXml,
         getResponse, parseError } from './common-service';
import balancesMngrMapper from './utils/BalancesMngrMapper';
import getLogger from './utils/GetLogger';

const logBdb = getLogger('bdb:DemandBalanceService');

export const invokeDemandBalanceService = async (acctId: string,
                                                 baseParams: RequestHeadersModel,timeout?: number): Promise<any> => {
    const rquid = baseParams['X-RqUID'];
    try {
        logBdb.debug(rquid, '[Invoke Demand Balance Service]');
        const xmlAccounts = addDemandAccounts(acctId);
        const xmlRequest = generateXml(baseParams, IStructureBalanceDefinition.DEMAND_BALANCE, xmlAccounts);
        const requestService = new RequestService();
        const response = await requestService.post({
            body: xmlRequest,
            url: `${await getVariable('DEMAND_BALANCES_ENDPOINT')}`,
            reqId: rquid,
        },timeout);
        const xmlResponse = response.data;
        const mapperResponseBus = getResponse(IStructureBalanceDefinition.DEMAND_BALANCE,
            xmlResponse as string);
        logBdb.debug(rquid, '[Successfull Demand Balance Service]');
        return balancesMngrMapper.transformResponseBusToApi(mapperResponseBus);
    } catch (demandError) {
        logBdb.error(rquid, '[Error in Demand Balance Service]', JSON.stringify(demandError));
        if(!(demandError instanceof AdapterError)) {
          throw parseError(demandError);
        } else {
            throw demandError;
        }
    }
};

export const addDemandAccounts = (acctId: string): string => {
  return `<v11:AcctBasicInfo>
            <v1:AcctId>${acctId}</v1:AcctId>
            <v1:AcctType>DDA</v1:AcctType>
         </v11:AcctBasicInfo>`;
};
