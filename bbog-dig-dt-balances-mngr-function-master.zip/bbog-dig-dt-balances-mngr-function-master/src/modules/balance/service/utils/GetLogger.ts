import { BdBLogger, TLogLevelName } from '@npm-bbta/bbog-dig-dt-tslog-lib';
import { config } from '../../../../config';

config();

export default function getLogger(name: string): BdBLogger {
    const cloudLogs = process.env.CLOUD_LOGS !== 'false';
    const logLevel = process.env.LEVEL_LOGS as TLogLevelName;

    return new BdBLogger(cloudLogs, name, logLevel);
}
