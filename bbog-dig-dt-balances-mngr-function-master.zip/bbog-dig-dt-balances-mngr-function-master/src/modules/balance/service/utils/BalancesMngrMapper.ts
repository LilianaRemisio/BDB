import { IBalancesResponse, IGetBalancesResponse } from '../../model/response-balances.model';

export default class BalancesMngrMapper {
    public static transformResponseBusToApi(busResponse: IBalancesResponse) {
        const responseArray: any = [];
        busResponse.AccInfo.forEach((balance) => {
            responseArray.push(this.transformResponseGetBalances(balance));
        });
        return { AccInfo: responseArray };
    }
    public static transformResponseGetBalances(busResponse: IGetBalancesResponse) {
        return {
            AcctBasicInfo: busResponse.AcctBasicInfo,
            PersonInfo: busResponse.PersonInfo,
            /* tslint:disable-next-line */
            AccountStatus: busResponse.AccountStatus,
            AcctBal: busResponse.AcctBal,
            ExtAcctBal: this.getValueOrNull(busResponse.ExtAcctBal),
            OwnerInd: this.getValueOrNull(busResponse.OwnerInd),
            openDt: this.getValueOrNull(busResponse.openDt),
            RefInfo: this.getValueOrNull(busResponse.RefInfo),
            OpenDt: this.getValueOrNull(busResponse.OpenDt),
            ExpDt: this.getValueOrNull(busResponse.ExpDt),
            UpDt: Date,
            PaidDt: this.getValueOrNull(busResponse.PaidDt),
            MinPmtCurAmt: this.getValueOrNull(busResponse.MinPmtCurAmt),
            Term: this.getValueOrNull(busResponse.Term),
            Rate: this.getValueOrNull(busResponse.Rate),
            OverdraftDays: this.getValueOrNull(busResponse.OverdraftDays),
            Fee: this.getValueOrNull(busResponse.Fee),
            NextPmtCurAmt: this.getValueOrNull(busResponse.NextPmtCurAmt),
            DueDt: this.getValueOrNull(busResponse.DueDt),
            Ownership: this.getValueOrNull(busResponse.Ownership),
            FinalCurAmt: this.getValueOrNull(busResponse.FinalCurAmt)
        };
    }

    public static getValueOrNull(value: any): any {
        return value ? value : null;
    }
}
