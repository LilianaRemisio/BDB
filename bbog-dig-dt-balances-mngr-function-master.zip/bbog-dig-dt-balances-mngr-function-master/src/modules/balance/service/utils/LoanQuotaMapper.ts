import { IGetLoanQuotaResponse, ILoanQuotaResponse } from '../../model/response-balances.model';

export default class LoanQuotaMapper {
    public static transformResponseBusToApi(busResponse: ILoanQuotaResponse): IGetLoanQuotaResponse {
        const response: any = {};
        const accInfo = busResponse.AccInfo[0];
        response.InterestRate = this.getValueOrNull( accInfo.CurAmt[0].Amt );
        response.InterestAmount = this.getValueOrNull( accInfo.CurAmt[1].Amt );
        response.TotalRepmtAmt = this.getValueOrNull (accInfo.CurAmt[2].Amt );
        response.FlatAmount = this.getValueOrNull( accInfo.CurAmt[3].Amt );
        response.PaymentAmount = this.getValueOrNull( accInfo.CurAmt[4].Amt );
        response.MaturityDate = this.getValueOrNull( accInfo.EffDt );
        return response;
    }

    public static getValueOrNull(value: any): any {
        return value ? value : null;
    }
}
