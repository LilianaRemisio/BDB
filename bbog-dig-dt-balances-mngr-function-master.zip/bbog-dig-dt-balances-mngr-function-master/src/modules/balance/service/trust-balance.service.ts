import { getVariable } from '../../../config';
import { RequestService } from '../../core/services/request/request.service';
import { AdapterError } from '../model/adapter-error';
import { RequestHeadersModel } from '../model/request-headers.model';
import { IStructureBalanceDefinition } from '../model/structure-balance-definition';
import { generateXml,
    getResponse, parseError } from './common-service';
import balancesMngrMapper from './utils/BalancesMngrMapper';
import getLogger from './utils/GetLogger';

const logBdb = getLogger('bdb:TrustBalanceService');

export const invokeTrustBalanceService = async (acctId: string,
                                                acctType: string,
                                                acctSubType: string,
                                                branchId: string,
                                                baseParams: RequestHeadersModel, timeout?: number):
                                                Promise<any> => {
    const rquid = baseParams['X-RqUID'];
    try {
        logBdb.debug('[Invoke Trust Balance Service]');
        const accountsXml = addAccounts(acctId, acctType, acctSubType, branchId);
        const requestXml = generateXml(baseParams, IStructureBalanceDefinition.TRUST_BALANCE,
            accountsXml);
        const requestService = new RequestService();
        const response = await requestService.post({
            body: requestXml,
            url: `${await getVariable('TRUST_BALANCES_ENDPOINT')}`,
            reqId: rquid,
        },timeout);
        const xmlResponse = response.data;
        const mapperResponseBus = getResponse(IStructureBalanceDefinition.TRUST_BALANCE,
            xmlResponse as string);
        logBdb.debug(rquid, '[Successfull Trust Balance Service]');
        return balancesMngrMapper.transformResponseBusToApi(mapperResponseBus);
    } catch (error) {
        logBdb.error(rquid, '[Error in Trust Balance Service]', JSON.stringify(error));
        if(!(error instanceof AdapterError)) {
            throw parseError(error);
        } else {
            throw error;
        }
    }
};

export const addAccounts = (acctId: string, acctType: string, acctSubType: string, branchId: string): string => {
    return `
        <v11:AcctBasicInfo>
            <v1:AcctId>${acctId}</v1:AcctId>
            <v1:AcctType>${acctType}</v1:AcctType>
            <v1:AcctSubType>${acctSubType}</v1:AcctSubType>
            <v11:BankInfo>
              <v1:BranchId>${branchId}</v1:BranchId>
            </v11:BankInfo>
         </v11:AcctBasicInfo>`;
};
