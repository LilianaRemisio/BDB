import { getVariable } from '../../../config';
import { RequestService } from '../../core/services/request/request.service';
import { AdapterError } from '../model/adapter-error';
import { RequestHeadersModel } from '../model/request-headers.model';
import { IStructureBalanceDefinition } from '../model/structure-balance-definition';
import { generateXml,
    getResponse, parseError } from './common-service';
import dateFormat from 'dateformat';
import getLogger from './utils/GetLogger';

const logBdb = getLogger('bdb:DetailCreditService');

export const invokeCustomerProductInquiry = async (parametersDetailCredit: {},
                                                 baseParams: RequestHeadersModel,timeout?: number): Promise<any> => {
    const rquid = baseParams['X-RqUID'];
    try {
        logBdb.debug(rquid, '[Invoke Customer Product Service]');
        const xmlCredit = addCreditDetail(parametersDetailCredit);
        const xmlRequest = generateXml(baseParams, IStructureBalanceDefinition.CUSTOMER_PRODUCT, xmlCredit);
        const requestService = new RequestService();
        const response = await requestService.post({
            body: xmlRequest,
            url: `${await getVariable('CUSTOMER_PRODUCT_ENDPOINT')}`,
            reqId: rquid,
        },timeout);
        const xmlResponse = response.data;
        return getResponse(IStructureBalanceDefinition.CUSTOMER_PRODUCT,
            xmlResponse as string);
    } catch (error) {
        logBdb.error(rquid, '[Error in Customer Product Service]', JSON.stringify(error));
        if(!(error instanceof AdapterError)) {
            throw parseError(error);
        } else {
            throw error;
        }
    }
};

export const addCreditDetail = (parametersDetailCredit: any): string => {
    return `<v1:BaseEnvr>
                <v1:Desc>${parametersDetailCredit.baseEnvr}</v1:Desc>
           </v1:BaseEnvr>
           <v1:CreditDetailId>
                <v1:TrnType>${parametersDetailCredit.trnType}</v1:TrnType>
                <v1:LoanAcctId>
                <v1:AcctId>${parametersDetailCredit.acctId}</v1:AcctId>
                <v1:AcctType>${parametersDetailCredit.acctType}</v1:AcctType>
                <v1:BankInfo>
                    <v1:BranchId></v1:BranchId>
                </v1:BankInfo>
                </v1:LoanAcctId>
                <v1:BranchId></v1:BranchId>
                <v1:EffDt>${dateFormat(
        new Date(),
        'yyyy-mm-dd"T"HH:MM:ss"-05:00"')}</v1:EffDt>
            </v1:CreditDetailId>`;
};
