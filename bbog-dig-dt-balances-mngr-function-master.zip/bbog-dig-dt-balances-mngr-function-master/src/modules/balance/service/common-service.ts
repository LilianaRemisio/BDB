import dateFormat from 'dateformat';
import uuid from 'uuid';
import xml2js from 'xml2js';
import xpath from 'xml2js-xpath';
import { AdapterError } from '../model/adapter-error';
import { RequestHeadersModel } from '../model/request-headers.model';
import { IBalancesResponse ,IGetBalancesResponse } from '../model/response-balances.model';
import { IStructureProperties } from '../model/structure-properties.model';
import ValidateType from '../util/ValidateType';
import getLogger from './utils/GetLogger';

const PARSER_OPTIONS = {
  explicitArray: false,
  ignoreAttrs: true,
  tagNameProcessors: [xml2js.processors.stripPrefix],

};

const logBdb = getLogger('bdb:CommonService');

export const parseError = (
  errorResponse: any
): any => {
  const err = errorResponse && errorResponse.context ? errorResponse.context as AdapterError : undefined;
  if (err) {
    throw err;
  }
  const jsonError = AdapterError.getErrorFromMessage(
    'Error general',
    500
  );
  logBdb.debug(JSON.stringify(jsonError));
  throw jsonError;
};
export const parseBusinessError = (errorResponse: any): any => {
  const jsonErrorBussines = AdapterError.getErrorFromMessage(
    (errorResponse.Status || {}).ServerStatusDesc || 'Error de negocio',
    409
  );
  logBdb.debug(JSON.stringify(jsonErrorBussines));
  throw jsonErrorBussines;
};
export const generateXml = (
  baseParams: RequestHeadersModel,
  methodService: IStructureProperties,
  additionalItems: string
): string => {
  const rquid = baseParams['X-RqUID'];
  const custIdentType = ValidateType.transformDocumentType(baseParams['X-CustIdentType']);
  const channel = baseParams['X-NetworkOwner'] ? baseParams['X-NetworkOwner'] : validateChannel(baseParams['X-Channel']);
  const method = `${methodService.method}Request`;
  const accountsItemsIdentification = `<v11:GovIssueIdent>
              <v1:GovIssueIdentType>${
      custIdentType
  }</v1:GovIssueIdentType>
              <v1:IdentSerialNum>${
      baseParams['X-CustIdentNum']
  }</v1:IdentSerialNum>
           </v11:GovIssueIdent>`;
  const requestXML = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
  xmlns:ser="urn://bancodebogota.com/${methodService.service}/product/service/"
  xmlns:even="urn://bancodebogota.com/${methodService.service}/product/event/"
  xmlns:v1="urn://bancodebogota.com/ifx/base/v1/" xmlns:v11="urn://bancodebogota.com/ifx/lite/v1/">
  <soapenv:Header/>
  <soapenv:Body>
     <ser:${method}>
        <even:${methodService.requestName}>
           <v1:RqUID>${uuid.v4()}</v1:RqUID>
           <v1:CustId>
              <v1:CustLoginId>${baseParams['X-CustIdentNum']}</v1:CustLoginId>
           </v1:CustId>
           <v1:NetworkTrnInfo>
              <v1:NetworkOwner>${channel}</v1:NetworkOwner>
              <v1:TerminalId>${baseParams['X-TerminalId']}</v1:TerminalId>
              <v1:BankId>${baseParams['X-CompanyId']}</v1:BankId>
           </v1:NetworkTrnInfo>
           <v1:ClientDt>${dateFormat(
    new Date(),
    'yyyy-mm-dd"T"HH:MM:ss"-05:00"'
  )}</v1:ClientDt>
           ${methodService.service === 'accounts' ? accountsItemsIdentification : ''}
           ${additionalItems}
        </even:${methodService.requestName}>
     </ser:${method}>
  </soapenv:Body>
</soapenv:Envelope>
  `;
  logBdb.debug(rquid, `[Request XML] ${JSON.stringify(requestXML)}`, );
  return requestXML;
};

export const getResponse = (
  structure: IStructureProperties,
  response: string
) => {
  const method = `${structure.method}Response`;
  const parser = new xml2js.Parser(PARSER_OPTIONS);
  let resultService: any;
  try {
    parser.parseString(response, (err: any, result: any) => {
      if (!err) {
        const matches = xpath.find(result, `//${structure.responseName}`);
        if (matches.length > 0) {
          resultService = result.Envelope.Body[method][structure.responseName];
          if (!isValidResponse(resultService)) {
            logBdb.debug('[resultService - InvalidRs]', resultService);
            parseBusinessError(
                resultService,
            );
          } else {
            logBdb.debug('[resultService Success]', response);
            setInternalsArray(resultService, structure);
          }
        } else {
          resultService = false;
        }
      } else {
        throw err;
      }
    });
    if (!resultService) {
      parseError(response);
    }
    return resultService.CreditDetailRec ? resultService[structure.objectName] : {
      AccInfo: resultService[structure.objectName] as IGetBalancesResponse[]
    } as IBalancesResponse;
  } catch (error: any) {
    logBdb.error('[ERROR to getResponse]', JSON.stringify(response));
    throw error;
  }
};

const setInternalsArray = (resultService: any, structure: IStructureProperties): any => { // NOSONAR
  if (structure.objectsRequiredAsArray && structure.objectsRequiredAsArray.length > 0) {
    const attributesToArray = structure.objectsRequiredAsArray;
    const objectRoot = structure.objectName;
    const array = Array.isArray(resultService[objectRoot]) ?
      resultService[objectRoot] : new Array(resultService[objectRoot]); // NOSONAR
    resultService[objectRoot] = array;
    array.forEach((balance: any, key: any) => {
      attributesToArray.forEach((attribute: any) => {
        if (balance[attribute] && !balance[attribute].length) {
          const value = balance[attribute];
          const responseOc: any = [];
          responseOc.push(value);
          resultService[structure.objectName][key][attribute] = responseOc;
        }
      });
    });
  }
};

const isValidResponse = (result: any): any => {
  try {
    const statusCode = +result.Status?.StatusCode;
    if (typeof (result.Status) === 'undefined' || statusCode === 0) {
      return true;
    } else {
      return false;
    }
  } catch (err) {
    return true;
  }
};

const validateChannel = (channel: any): string => {
  switch (channel) {
    case 'BancaMovil':
      return 'SMP';
    case 'BancaVirtual':
      return 'PB';
    case 'BdB Empresas':
      return 'BEP001';
    default:
      return 'DIG482';
  }
};
