import { Request, Response } from 'express';
import { AdapterError } from '../model/adapter-error';
import { RequestHeadersModel } from '../model/request-headers.model';
import { ReqHeadersAdditionalCertificate } from '../model/req-headers-additional-certificate';
import { ReqHeadersAdditionalTrust } from '../model/req-headers-additional-trust';
import { IGetBalanceRq } from '../model/request-savings.model';
import { invokeCertificateBalanceService } from '../service/certificate-balance.service';
import { invokeCreditCardBalanceService } from '../service/creditcard-balance.service';
import { invokeDemandBalanceService } from '../service/demand-balance.service';
import { invokeGroupBalanceService } from '../service/group-balance.service';
import { invokeLoanBalanceService } from '../service/loan-balance.service';
import { invokeSavingBalanceService } from '../service/saving-balance.service';
import { invokeTrustBalanceService } from '../service/trust-balance.service';
import { invokeCustomerProductInquiry } from '../service/customer-product.service';
import { getVariable } from '../../../config';
import { LoanQuotaHeadersModel } from '../model/loanquota-headers.model';
import { invokeLoanQuotaService } from '../service/loan-quota.service';
import getLogger from '../service/utils/GetLogger';

const STATUS_200 = 200;
const ERROR_MESSAGE = 'An error has occurred getting balances to accounts';
const ERROR_MESSAGE_DETAIL_CREDIT = 'An error has occurred getting detail credit';
const ERROR_MESSAGE_LOAN_QUOTA = 'An error has occurred getting loan quota';
const TIMEOUT_IN_MILLISECONDS =15*1000;
const logBdb = getLogger('bdb:BalancesController');

export class BalancesController {

  public async retrieveGroupBalances(req: Request, res: Response, next: any) {
    try {
      const requestHeadersDto = new RequestHeadersModel(req);
      const accounts = req.body as IGetBalanceRq;
      const rquid = requestHeadersDto['X-RqUID'];
      logBdb.debug(rquid, 'accounts ', accounts);
      logBdb.debug(rquid, 'accounts Info', accounts.accountsInfo);
      const resp = await invokeGroupBalanceService(accounts.accountsInfo, requestHeadersDto);
      logBdb.debug(rquid, 'retrieveSavingBalance ', resp);
      return res.status(STATUS_200).json(resp);
    } catch (error: any) {
      balanceController.catchError(
        res,
        'retrieveSavingBalance',
        error,
        ERROR_MESSAGE
      );
    }
    return res;
  }

  public async retrieveSavingBalance(req: Request, res: Response, next: any) {
    try {
      const requestHeadersDto = new RequestHeadersModel(req);
      const rquid = requestHeadersDto['X-RqUID'];
      const acctId = req.params.acctId;
      const resp = await invokeSavingBalanceService(acctId, requestHeadersDto);

      logBdb.debug(rquid, 'retrieveSavingBalance:', resp);
      return res.status(STATUS_200).json(resp);
    } catch (error: any) {
      balanceController.catchError(
        res,
        'retrieveSavingBalance',
        error,
        ERROR_MESSAGE
      );
    }
    return res;
  }

  public async retrieveDemandBalance(req: Request, res: Response, next: any) {
    try {
      const requestHeadersDto = new RequestHeadersModel(req);
      const acctId = req.params.acctId;
      const resp = await invokeDemandBalanceService(acctId, requestHeadersDto);
      const rquid = requestHeadersDto['X-RqUID'];

      logBdb.debug(rquid, 'retrieveDemandBalance', resp);
      return res.status(STATUS_200).json(resp);
    } catch (error: any) {
      balanceController.catchError(
        res,
        'retrieveDemandBalance',
        error,
        ERROR_MESSAGE
      );
    }
    return res;
  }

  public async retrieveCreditCardBalance(
    req: Request,
    res: Response,
    next: any
  ) {
    try {
      const requestHeadersDto = new RequestHeadersModel(req);
      const acctId = req.params.acctId;
      const rquid = requestHeadersDto['X-RqUID'];

      const resp = await invokeCreditCardBalanceService(
        acctId,
        requestHeadersDto
      );
      logBdb.debug(rquid, 'retrieveCreditCardBalance', resp);
      return res.status(STATUS_200).json(resp);
    } catch (error: any) {
      balanceController.catchError(
        res,
        'retrieveCreditCardBalance',
        error,
        ERROR_MESSAGE
      );
    }
    return res;
  }

  public async retrieveLoanBalance(
    req: Request,
    res: Response,
    next: any
  ) {
    try {
      const requestHeadersDto = new RequestHeadersModel(req);
      const acctId = req.params.acctId;
      const rquid = requestHeadersDto['X-RqUID'];

      const resp = await invokeLoanBalanceService(
        acctId,
        requestHeadersDto
      );
      logBdb.debug(rquid, 'retrieveLoanBalance', resp);
      return res.status(STATUS_200).json(resp);
    } catch (error: any) {
      balanceController.catchError(
        res,
        'retrieveLoanBalance',
        error,
        ERROR_MESSAGE
      );
    }
    return res;
  }

  public async retrieveCertificateBalance(
      req: Request,
      res: Response,
      next: any
  ) {
    try {
      const requestHeadersDto = new ReqHeadersAdditionalCertificate(req);
      const acctId = req.params.acctId;
      const branchId = (requestHeadersDto.branchIdHeaders.BranchId);
      const rquid = requestHeadersDto.generalHeaders['X-RqUID'];

      const resp = await invokeCertificateBalanceService(
          acctId,
          requestHeadersDto.generalHeaders,
          TIMEOUT_IN_MILLISECONDS,
          branchId
      );
      logBdb.debug(rquid, 'retrieveCertificateBalance', resp);
      return res.status(STATUS_200).json(resp);
    } catch (error: any) {
      balanceController.catchError(
          res,
          'retrieveCertificateBalance',
          error,
          ERROR_MESSAGE
      );
    }
    return res;
  }

  public async retrieveTrustBalance(
      req: Request,
      res: Response,
      next: any
  ) {
    try {
      const requestHeadersDto = new ReqHeadersAdditionalTrust(req);
      const acctId = req.params.acctId;
      const branchId = (requestHeadersDto.branchIdHeaders.BranchId);
      const acctType = (requestHeadersDto.acctTypeHeaders.AcctType);
      const acctSubType = (requestHeadersDto.acctSubTypeHeaders.AcctSubType);
      const rquid = requestHeadersDto.generalHeaders['X-RqUID'];


      const resp = await invokeTrustBalanceService(
          acctId,
          acctType,
          acctSubType,
          branchId,
          requestHeadersDto.generalHeaders
      );
      logBdb.debug(rquid, 'retrieveTrustBalance ', resp);
      return res.status(STATUS_200).json(resp);
    } catch (error: any) {
      balanceController.catchError(
          res,
          'retrieveTrustBalance',
          error,
          ERROR_MESSAGE
      );
    }
    return res;
  }

  public async retrieveDetailCreditInfo(rq: Request, rs: Response) {
    try {
      const requestHeadersDto = new RequestHeadersModel(rq);
      const parametersDetailCredit = {
         acctId: rq.header('acctId') || '',
         trnType: rq.header('TrnType') || '',
         acctType: rq.header('acctType') || '',
         baseEnvr: rq.header('BaseEnvr') || ''
      };
      const rquid = requestHeadersDto['X-RqUID'];
      const timeout = Number.parseInt(`${await getVariable('TIMEOUT_SERVICE')}`, 0);
      const responseService = await invokeCustomerProductInquiry(
          parametersDetailCredit,
          requestHeadersDto,
          timeout
      );
      logBdb.debug(rquid, '[Successfull Customer Product Service]',responseService);
      return rs.status(STATUS_200).json(responseService).end();
    } catch (error: any) {
      return balanceController.catchError(
          rs,
          'retrieveDetailCreditInfo',
          error,
          ERROR_MESSAGE_DETAIL_CREDIT
      );
    }
  }

  public async retrieveLoanQuota(rq: Request, rs: Response) {
    try {
      const rquid = rq.header('X-RqUID');
      const requestHeadersDto = new RequestHeadersModel(rq);
      logBdb.debug(rquid, ' request headers', requestHeadersDto);
      const loanQuotaHeadersDto = new LoanQuotaHeadersModel(rq);
      logBdb.debug(rquid ,' info to know loan quota', loanQuotaHeadersDto);
      const responseService = await invokeLoanQuotaService(requestHeadersDto, loanQuotaHeadersDto);
      logBdb.debug('[Successfull Loan Quota Service]', responseService);
      return rs.status(STATUS_200).json(responseService).end();
    } catch (error: any) {
      return balanceController.catchError(
          rs,
          'retrieveLoanQuota',
          error,
          ERROR_MESSAGE_LOAN_QUOTA
      );
    }
  }

  private catchError(
    res: Response,
    method: string,
    error: AdapterError,
    defaultError: string
  ) {
    const errorObj = JSON.stringify(error);
    logBdb.error(`Error ${method} ${errorObj}`);
    return res.status(error.Status.StatusCode ? error.Status.StatusCode : 500 ).send(error || defaultError);
  }
}

const balanceController = new BalancesController();
export default balanceController;
