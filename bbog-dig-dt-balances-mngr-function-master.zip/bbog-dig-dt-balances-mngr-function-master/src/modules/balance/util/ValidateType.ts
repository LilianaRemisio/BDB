export default class ValidateType {
    public static transformDocumentType( identityType: any ): string {
        let convertedIdentityType = '';
        if ( identityType === 'CC' ) {
            convertedIdentityType = 'C';
        } else if ( identityType === 'NI' ) {
            convertedIdentityType = 'L';
        } else if ( identityType === 'CE' ) {
            convertedIdentityType = 'E';
        } else if ( identityType === 'NJ' ) {
            convertedIdentityType = 'N';
        } else if ( identityType === 'NE' ) {
            convertedIdentityType = 'I';
        } else if ( identityType === 'PA' ) {
            convertedIdentityType = 'P';
        } else if ( identityType === 'RC' ) {
            convertedIdentityType = 'R';
        } else if ( identityType === 'TI' ) {
            convertedIdentityType = 'T';
        } else {
            throw new Error(`Documento no expecificado: ${identityType}`);
        }
        return convertedIdentityType;
    }
}
