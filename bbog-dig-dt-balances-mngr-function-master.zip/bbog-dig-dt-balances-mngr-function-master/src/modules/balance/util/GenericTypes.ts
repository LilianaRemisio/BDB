export type StringNullable = string | null | undefined;
export type NumberNullable = number | null | undefined;
export type CustIdentType = 'CC' | 'CE' | 'LC' | 'NI' | 'OT' | 'PA' | 'RC' | 'TI' | 'NJ' | 'NE';
export type SeverityType = 'Success' | 'Info' | 'Warning' | 'Error';
