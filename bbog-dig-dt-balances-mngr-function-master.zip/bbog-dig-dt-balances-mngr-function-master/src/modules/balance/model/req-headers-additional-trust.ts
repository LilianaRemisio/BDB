import { Request } from 'express';
import { RequestHeadersModel } from './request-headers.model';
import { RequestBranchId } from './requestBranchId';
import { RequestAcctType } from './requestAcctType';
import { RequestAcctSubType } from './requestAcctSubType';

export class ReqHeadersAdditionalTrust {
    public generalHeaders: RequestHeadersModel;
    public branchIdHeaders: RequestBranchId;
    public acctTypeHeaders: RequestAcctType;
    public acctSubTypeHeaders: RequestAcctSubType;

    constructor(request: Request) {
        this.generalHeaders = new RequestHeadersModel(request);
        this.branchIdHeaders = new RequestBranchId(request);
        this.acctTypeHeaders = new RequestAcctType(request);
        this.acctSubTypeHeaders = new RequestAcctSubType(request);
    }
}
