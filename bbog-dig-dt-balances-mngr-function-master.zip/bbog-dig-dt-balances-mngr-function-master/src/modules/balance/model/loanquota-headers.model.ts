import { Request } from 'express';

type stringNullable = string | null | undefined;

export const rate = 'rate';
export const amount = 'amount';
export const term = 'term';
export const frequency = 'frequency';
export const increase = 'increase';
export const accrualBase = 'accrualBase';
export const accrualMethod = 'accrualMethod';
export const disbursementDate = 'disbursementDate';
export const firstPaymentDate = 'firstPaymentDate';

export class LoanQuotaHeadersModel {
    public 'rate': stringNullable;
    public 'amount': stringNullable;
    public 'term': stringNullable;
    public 'frequency': stringNullable;
    public 'increase': stringNullable;
    public 'accrualBase': stringNullable;
    public 'accrualMethod': stringNullable;
    public 'disbursementDate': stringNullable;
    public 'firstPaymentDate': stringNullable;

    constructor(request: Request) {
        this[rate] = request.header(rate);
        this[amount] = request.header(amount);
        this[term] = request.header(term);
        this[frequency] = request.header(frequency);
        this[increase] = request.header(increase);
        this[accrualBase] = request.header(accrualBase);
        this[accrualMethod] = request.header(accrualMethod);
        this[disbursementDate] = request.header(disbursementDate);
        this[firstPaymentDate] = request.header(firstPaymentDate);
    }
}
