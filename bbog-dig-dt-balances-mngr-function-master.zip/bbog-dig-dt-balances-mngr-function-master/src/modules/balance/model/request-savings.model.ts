
export interface IAcctBasicInfo {
    acctId: string;
    acctType: string;
    acctSubType: string;
    bankInfo: IBankInfo;
}

export interface IGetBalanceRq {
    accountsInfo: IAcctBasicInfo[];
}

export interface IBankInfo {
    branchId: string;
    refInfo: IRefInfo;
}

export interface IRefInfo {
    refType: string;
    refId: string;
}
