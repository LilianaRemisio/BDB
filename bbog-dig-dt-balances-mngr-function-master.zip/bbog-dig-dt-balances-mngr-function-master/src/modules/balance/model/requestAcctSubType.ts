import { Request } from 'express';
import { stringNullable } from './IGeneralTypes';

export class RequestAcctSubType {
    public AcctSubType: stringNullable;
    constructor(request: Request) {
        this.AcctSubType = String(request.query.acctSubType || '');
    }
}
