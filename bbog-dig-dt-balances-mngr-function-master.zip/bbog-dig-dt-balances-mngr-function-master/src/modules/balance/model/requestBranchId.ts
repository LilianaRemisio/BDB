import { Request } from 'express';
import { stringNullable } from './IGeneralTypes';

export class RequestBranchId {
    public BranchId: stringNullable;
    constructor(request: Request) {
        this.BranchId = String(request.query.branchId || '');
    }
}
