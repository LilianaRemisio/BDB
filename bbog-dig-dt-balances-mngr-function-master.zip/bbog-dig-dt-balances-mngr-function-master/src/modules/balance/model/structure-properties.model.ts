export interface IStructureProperties {
    method: string;
    requestName: string;
    responseName: string;
    objectName: string;
    objectsRequiredAsArray?: string[];
    service: string;
}
