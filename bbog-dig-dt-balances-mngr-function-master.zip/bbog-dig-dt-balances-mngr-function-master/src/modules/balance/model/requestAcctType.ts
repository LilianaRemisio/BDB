import { Request } from 'express';
import { stringNullable } from './IGeneralTypes';

export class RequestAcctType {
    public AcctType: stringNullable;
    constructor(request: Request) {
        this.AcctType = String(request.query.acctType || '');
    }
}
