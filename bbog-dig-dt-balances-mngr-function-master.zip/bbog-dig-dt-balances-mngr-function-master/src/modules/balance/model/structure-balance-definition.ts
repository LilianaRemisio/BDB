import { IStructureProperties } from './structure-properties.model';

const ACCOUNTS_SERVICE = 'accounts';
export class IStructureBalanceDefinition {
  public static SAVING_BALANCE: IStructureProperties = {
    method: 'getSavingsBalances',
    objectName: 'SDABalRec',
    objectsRequiredAsArray: [
      'ExtAcctBal'
    ],
    requestName: 'SDABalInqRq',
    responseName: 'SDABalInqRs',
    service: ACCOUNTS_SERVICE
  };
  public static DEMAND_BALANCE: IStructureProperties  = {
    method: 'getDemandBalances',
    objectName: 'DDABalRec',
    objectsRequiredAsArray: [
      'ExtAcctBal'
    ],
    requestName: 'DDABalInqRq',
    responseName: 'DDABalInqRs',
    service: ACCOUNTS_SERVICE
  };
  public static CREDITCARD_BALANCE: IStructureProperties  = {
    method: 'getCreditCardBalances',
    objectName: 'CCABalRec',
    objectsRequiredAsArray: [
      'ExtAcctBal'
    ],
    requestName: 'CCABalInqRq',
    responseName: 'CCABalInqRs',
    service: ACCOUNTS_SERVICE
  };
  public static LOAN_BALANCE: IStructureProperties  = {
    method: 'getLoanBalances',
    objectName: 'LOCBalRec',
    objectsRequiredAsArray: [
      'ExtAcctBal'
    ],
    requestName: 'LOCBalInqRq',
    responseName: 'LOCBalInqRs',
    service: ACCOUNTS_SERVICE
  };
  public static TRUST_BALANCE: IStructureProperties  = {
    method: 'getTrustBalances',
    objectName: 'TrustBalRec',
    objectsRequiredAsArray: [
      'ExtAcctBal'
    ],
    requestName: 'TrustBalInqRq',
    responseName: 'TrustBalInqRs',
    service: ACCOUNTS_SERVICE
  };
  public static CERTIFICATE_BALANCE: IStructureProperties  = {
    method: 'getCertificateBalances',
    objectName: 'CDABalRec',
    objectsRequiredAsArray: [
      'ExtAcctBal'
    ],
    requestName: 'CDABalInqRq',
    responseName: 'CDABalInqRs',
    service: ACCOUNTS_SERVICE
  };
  public static CUSTOMER_PRODUCT: IStructureProperties  = {
    method: 'getLoanAcctDetail',
    objectName: 'CreditDetailRec',
    objectsRequiredAsArray: [
      'ExtAcctBal'
    ],
    requestName: 'LoanAcctDetailInqRq',
    responseName: 'LoanAcctDetailInqRs',
    service: ACCOUNTS_SERVICE
  };
  public static LOAN_QUOTA: IStructureProperties  = {
    method: 'getLoanQuota',
    objectName: 'AcctBal',
    objectsRequiredAsArray: [
      'CurAmt'
    ],
    requestName: 'LoanQuotaInqRq',
    responseName: 'LoanQuotaInqRs',
    service: 'customers'
  };
}
