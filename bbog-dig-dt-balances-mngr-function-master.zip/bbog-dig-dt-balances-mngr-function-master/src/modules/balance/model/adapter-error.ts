import { StringNullable } from '../util/GenericTypes';
import { IErrorStatusDto } from './IErrorStatusDto';

export class AdapterError {
    public static getErrorFromMessage(reason: any, statusCode: number, serverStatusCode?: number): AdapterError {
        serverStatusCode = serverStatusCode ? serverStatusCode : statusCode;
        const status: IErrorStatusDto = {
            ServerStatusCode: `${serverStatusCode}`,
            Severity: 'Error',
            StatusCode: statusCode,
            StatusDesc: 'object' === typeof reason ? JSON.stringify(reason) : reason
        };
        return new AdapterError(status);
    }

    public Status: IErrorStatusDto;
    public EndDt: StringNullable;

    constructor(status: IErrorStatusDto) {
        this.Status = status;
        this.EndDt = new Date().toISOString();
    }
}
