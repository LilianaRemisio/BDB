import { Request } from 'express';
import { RequestHeadersModel } from './request-headers.model';
import { RequestBranchId } from './requestBranchId';

export class ReqHeadersAdditionalCertificate {
    public generalHeaders: RequestHeadersModel;
    public branchIdHeaders: RequestBranchId;

    constructor(request: Request) {
        this.generalHeaders = new RequestHeadersModel(request);
        this.branchIdHeaders = new RequestBranchId(request);
    }
}
