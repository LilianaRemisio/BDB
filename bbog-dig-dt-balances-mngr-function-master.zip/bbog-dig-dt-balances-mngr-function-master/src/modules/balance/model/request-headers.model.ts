import { Request } from 'express';

type stringNullable = string | null | undefined;

export const xRqUID = 'X-RqUID';
export const xChannel = 'X-Channel';
export const xCompanyId = 'X-CompanyId';
export const xCustIdentType = 'X-CustIdentType';
export const xCustIdentNum = 'X-CustIdentNum';
export const xIPAddr = 'X-IPAddr';
export const xName = 'X-Name';
export const xTerminalId = 'X-TerminalId';
export const xNetworkOwner = 'X-NetworkOwner';

export class RequestHeadersModel {
    public 'X-RqUID': stringNullable;
    public 'X-Channel': stringNullable;
    public 'X-CompanyId': stringNullable;
    public 'X-CustIdentType': stringNullable;
    public 'X-CustIdentNum': stringNullable;
    public 'X-IPAddr': stringNullable;
    public 'X-Name': stringNullable;
    public 'X-TerminalId': stringNullable;
    public 'X-NetworkOwner': stringNullable;

    constructor(request: Request) {
        this[xRqUID] = request.header(xRqUID);
        this[xChannel] = request.header(xChannel);
        this[xCompanyId] = request.header(xCompanyId);
        this[xCustIdentType] = request.header(xCustIdentType);
        this[xCustIdentNum] = request.header(xCustIdentNum);
        this[xIPAddr] = request.header(xIPAddr);
        this[xName] = request.header(xName);
        this[xTerminalId] = request.header(xTerminalId);
        this[xNetworkOwner] = request.header(xNetworkOwner);
    }
}
