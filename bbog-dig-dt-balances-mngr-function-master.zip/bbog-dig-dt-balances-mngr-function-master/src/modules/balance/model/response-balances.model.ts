
  export interface IBankInfo {
    BranchId: string;
  }

  export interface IAcctBasicInfo {
    AcctId: string;
    AcctType: string;
    BankInfo: IBankInfo;
  }

  export interface IGovIssueIdent {
    GovIssueIdentType: string;
    IdentSerialNum: string;
  }

  export interface IPersonInfo {
    GovIssueIdent: IGovIssueIdent;
    FullName: string;
  }

  export interface IAccountStatus {
    StatusCode: string;
    StatusDesc: string;
    EffDt: string;
  }

  export interface IAcctBal {
    BalType: string;
    CurAmt: ICurAmt;
  }

  export interface IExtAcctBal {
    ExtBalType: string;
    CurAmt: ICurAmt;
  }

  export interface ICurAmt {
    Amt: string;
    CurCode: string;
    CurRate: string;
  }

  export interface IFee {
    FeeType: string;
    CurAmt: ICurAmt;
    Rate: string;
  }

  export interface INextPmtCurAmt {
    Amt: string;
    CurCode: string;
  }

  export interface IMinPmtCurAmt {
    Amt: string;
  }

  export interface ITerm {
    Count: string;
    TermUnits: string;
  }

  export interface IFinalCurAmt {
    Amt: string;
  }

  export interface IBalancesResponse {
    AccInfo: IGetBalancesResponse[];
  }

  export interface IGetBalancesResponse {
    AcctBasicInfo: IAcctBasicInfo;
    PersonInfo: IPersonInfo;
    AccountStatus: IAccountStatus;
    AcctBal: IAcctBal[];
    ExtAcctBal: IExtAcctBal[];
    OwnerInd: string;
    openDt: string;
    RefInfo: any;
    OpenDt: string;
    ExpDt: string;
    UpDt?: Date;
    PaidDt: string;
    DueDt: string;
    MinPmtCurAmt?: IMinPmtCurAmt;
    Term?: ITerm;
    Rate?: string;
    OverdraftDays?: string;
    Fee?: IFee;
    NextPmtCurAmt?: INextPmtCurAmt;
    Ownership?: string;
    FinalCurAmt?: IFinalCurAmt;
  }

  export interface ILoanQuotaResponse {
    AccInfo: IGetLoanQuotaResponse[];
  }

  export interface IGetLoanQuotaResponse {
    CurAmt: ILoanQuotaItemResponse[];
    EffDt: string;
  }

  export interface ILoanQuotaItemResponse {
    Amt: string;
  }

  export interface IGetLoanQuotaResponse {
    InterestRate: string;
    InterestAmount: string;
    TotalRepmtAmt: string;
    FlatAmount: string;
    PaymentAmount: string;
    MaturityDate: string;
  }
