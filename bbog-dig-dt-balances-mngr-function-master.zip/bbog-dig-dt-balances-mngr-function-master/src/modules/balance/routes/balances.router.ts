import { Router } from 'express';
import balancesController from '../controller/balances.controller';
import { OpenApiValidatorProvider } from '../util/utils';

class BalancesRouter {
  public router: Router = Router();

   constructor() {
   this.config();
  }
  private config(): void {
    this.router.post(
      '/retrieveGroupBalances',
      OpenApiValidatorProvider,
      balancesController.retrieveGroupBalances
    );
    this.router.get(
      '/:acctId/retrieveSavingBalance',
      OpenApiValidatorProvider,
      balancesController.retrieveSavingBalance
    );
    this.router.get(
      '/:acctId/retrieveDemandBalance',
      OpenApiValidatorProvider,
      balancesController.retrieveDemandBalance
    );
    this.router.get(
      '/:acctId/retrieveCreditCardBalance',
      OpenApiValidatorProvider,
      balancesController.retrieveCreditCardBalance
    );
    this.router.get(
      '/:acctId/retrieveLoanBalance',
      OpenApiValidatorProvider,
      balancesController.retrieveLoanBalance
    );
    this.router.get(
      '/:acctId/retrieveCertificateBalance',
      OpenApiValidatorProvider,
      balancesController.retrieveCertificateBalance
    );
    this.router.get(
      '/:acctId/retrieveTrustBalance',
      OpenApiValidatorProvider,
      balancesController.retrieveTrustBalance
    );
    this.router.get(
      '/retrieveDetailCreditInfo',
      OpenApiValidatorProvider,
      balancesController.retrieveDetailCreditInfo
    );

    this.router.get(
      '/retrieveLoanQuota',
      OpenApiValidatorProvider,
      balancesController.retrieveLoanQuota
    );
  }
}

const balancesRouter = new BalancesRouter();
export default balancesRouter.router;
