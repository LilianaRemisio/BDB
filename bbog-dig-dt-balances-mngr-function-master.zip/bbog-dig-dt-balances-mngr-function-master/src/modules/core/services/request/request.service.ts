import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';
import { ResponseFetchModel } from '../../models/response-fetch.model';
import getLogger from '../../../balance/service/utils/GetLogger';

const TIMEOUT_IN_MILLISECONDS =25*1000;
const POST_OPERATION = 'POST REQUEST';
const POST_OPERATION_RESPONSE = 'POST RESPONSE';

const logBdb = getLogger('bdb:RequestService');

export class RequestService {
  public get = async <T>(
    params: {
      url: string,
      queryParams?: { [key: string]: string },
      headers?: { [key: string]: string }
    }
  ): Promise<ResponseFetchModel<T>> => {
    const options: AxiosRequestConfig = {
      headers: {
        'Content-Type': 'application/json',
        ...params.headers,
      },
      params: params.queryParams
    };
    return axios.get(`${params.url}`, options)
      .then((r: AxiosResponse) => {
        return new ResponseFetchModel(r.data as T, r.status, 'OK');
      }).catch((err: any) => {
        return Promise.reject(err.response.data);
      });
  }

  public post = async <T>(
    params: {
      url: string,
      reqId?: string;
      body?: any,
      queryParams?: { [key: string]: string },
      headers?: { [key: string]: string },
    },
    timeoutParam: number = TIMEOUT_IN_MILLISECONDS
  ): Promise<ResponseFetchModel<T>> => {
    const options: AxiosRequestConfig = {
      headers: {
        'Content-Type': 'application/xml',
        ...params.headers
      },
      params: params.queryParams,
      timeout:timeoutParam,
    };
    logBdb.debug(params.reqId, `[${POST_OPERATION}] ${JSON.stringify(options)}`);
      return axios.post(`${params.url}`, params.body || {}, options)
      .then((r: AxiosResponse) => {
        logBdb.debug(params.reqId, 'axios', `[${POST_OPERATION_RESPONSE}] ${r.data}`);
          return new ResponseFetchModel(r.data  as T , r.status, 'OK');
      }).catch((err: any) => {
        const error = err.response?.data ? err.response.data : err.message;
        logBdb.error(params.reqId, `[POST RESPONSE ERROR]: ${JSON.stringify({'Error': error})}`);
          return Promise.reject(error);
      });
  }
}
