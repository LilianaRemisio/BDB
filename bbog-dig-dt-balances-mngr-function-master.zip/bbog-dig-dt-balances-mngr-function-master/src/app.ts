import validateHeaders from '@npm-bbta/bbog-dig-dt-consumer-validator-lib';
import cookieParser from 'cookie-parser';
import express from 'express';
import balancesRouter from './modules/balance/routes/balances.router';
import indexRouter from './modules/core/routes/index.router';
import getLogger from './modules/balance/service/utils/GetLogger';


const app = express();
app.disable('x-powered-by');
const logBdb = getLogger('bdb:AppBalances');
const DEBUG_TEXT = 'Ha ocurrido un error en la lambda:';


app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.use(cookieParser());
app.use(validateHeaders);

app.use('/', indexRouter);
app.use('/V1/Enterprise/BalanceManagement', balancesRouter);

app.use((err: any, req: any, res: any, next: any) => {
    const statusCode = err.statusCode || 500;
    logBdb.debug(DEBUG_TEXT, err.message);
    res.status(statusCode).json({
        error: {
            data: err.data,
            message: err.message,
            name: err.name,
        },
    });
});

export default app;
