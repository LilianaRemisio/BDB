import debugLib from 'debug';
import * as dotenv from 'dotenv';
import * as fs from 'fs';
let envConfig: { [key: string]: string } = {};
const debug = debugLib('bdb:Config');
export const config = () => {
  debug('variable entorno', process.env.NODE_ENV || '');
  if (['PROD', 'ST', 'DEVELOP'].includes(process.env.NODE_ENV || '')) {
    envConfig = envVariables as any;
  } else {
    envConfig = dotenv.parse(fs.readFileSync('.env'));
  }
  return true;
};
const envVariables = {
      LOGS: {
        CLOUD: process.env.CLOUD_LOGS,
        LEVEL: process.env.LEVEL_LOGS,
      },
      API_ENDPOINT: process.env.API_ENDPOINT || '',
      AUTH_ENDPOINT: process.env.AUTH_ENDPOINT || '',
      CERTIFICATE_BALANCES_ENDPOINT: process.env.CERTIFICATE_BALANCES_ENDPOINT || '',
      CREDITCARD_BALANCES_ENDPOINT: process.env.CREDITCARD_BALANCES_ENDPOINT || '',
      CUSTOMER_PRODUCT_ENDPOINT: process.env.CUSTOMER_PRODUCT_ENDPOINT || '',
      DEMAND_BALANCES_ENDPOINT: process.env.DEMAND_BALANCES_ENDPOINT || '',
      LOAN_BALANCES_ENDPOINT: process.env.LOAN_BALANCES_ENDPOINT || '',
      LOAN_QUOTA_ENDPOINT: process.env.LOAN_QUOTA_ENDPOINT || '',
      PORT: process.env.PORT || '',
      SAVING_BALANCES_ENDPOINT: process.env.SAVING_BALANCES_ENDPOINT || '',
      STATIC_FILE_VALIDATIONS: process.env.STATIC_FILE_VALIDATIONS || '',
      TIMEOUT_SERVICE: process.env.TIMEOUT_SERVICE,
      TRUST_BALANCES_ENDPOINT: process.env.TRUST_BALANCES_ENDPOINT || '',
};
const getVariable = async (key: string): Promise<string> => {
  try {
    if (!Object.keys(envConfig).length) {
      config();
    }
    return envConfig[key];
  } catch (err) {
    debug(`config error: %j`, err);
    throw new Error('failed to get variable');
  }
};
export { getVariable };
