import chai from 'chai';
import { RequestService } from '../../../../../src/modules/core/services/request/request.service';
import nock from 'nock';

const expect = chai.expect;

describe('RequestService', () => {
  const req = new RequestService();
  it('should get', async () => {
    nock('https://httpstat.us/200').get('').reply(200, 'not found');
    expect(await req.get({ url: 'https://httpstat.us/200' })).not.to.be.an('undefined');
  });

  it('should not get', async () => {
    try {
      nock('https://holahola.com/test-get').get('').reply(500, 'not found');
      await req.get({ url: 'https://holahola.com/test-get' });
    } catch (error) {
      expect(error).to.equals('not found');
    }
  });

  it('should post and reject', async () => {
    try {
      nock('https://holahola.com/test-post').post('').reply(404, 'not found');
      const response = await req.post({
        body: {},
        url: 'https://holahola.com/test-post'
      });

    } catch (error) {
      expect(error).to.be.equal('not found');
    }
  });

  it('should post and reject without body, branch', async () => {
    try {
      nock('https://holahola.com/test-post').post('').reply(404, 'not found');
      const response = await req.post({
        url: 'https://holahola.com/test-post'
      });

    } catch (error) {
      expect(error).to.be.equal('not found');
    }
  });
});
