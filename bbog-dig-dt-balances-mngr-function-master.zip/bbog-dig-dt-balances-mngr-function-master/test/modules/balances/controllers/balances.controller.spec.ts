import chai from 'chai';
import chaiHttp from 'chai-http';
import nock from 'nock';
import httpMocks from 'node-mocks-http';
import { getVariable } from '../../../../src/config';

import balanceController from '../../../../src/modules/balance/controller/balances.controller';
import { AdapterError } from '../../../../src/modules/balance/model/adapter-error';
import { SUCCESS_CERTIFICATE_RESPONSE } from '../../../mocks/balance-certificate/balance-certificate.mock';
import { SUCCESS_CREDITCARD_RESPONSE } from '../../../mocks/balance-creditcard/balance-creditcard.mock';
import { FALSE_SUCCESS_CERTIFICATE_RESPONSE } from '../../../mocks/balance-certificate/balance-certificate-200-with-error.mock';
import { FALSE_SUCCESS_CREDITCARD_RESPONSE } from '../../../mocks/balance-creditcard/balance-demand-200-with-error.mock';
import { FALSE_SUCCESS_DEMAND_RESPONSE } from '../../../mocks/balance-demands/balance-demand-200-with-error.mock';
import { FALSE_SUCCESS_TRUST_RESPONSE } from '../../../mocks/balance-trust/balance-trust-200-with-error.mock';
import { SUCCESS_DEMANDS_RESPONSE } from '../../../mocks/balance-demands/balance-demands.mock';
import { FALSE_SUCCESS_LOAN_RESPONSE } from '../../../mocks/balance-loan/balance-loan-200-with-error.mock';
import { GENERAL_EXCEPTION_ERROR } from '../../../mocks/balance-loan/balance-loan-general-exception.mock';
import { SUCCESS_LOAN_RESPONSE } from '../../../mocks/balance-loan/balance-loan.mock';
import { FALSE_SUCCESS_SAVING_RESPONSE } from '../../../mocks/balance-savings/balance-demand-200-with-error.mock';
import { SUCCESS_SAVING_RESPONSE } from '../../../mocks/balance-savings/balance-savings.mock';
import { SUCCESS_TRUST_RESPONSE } from '../../../mocks/balance-trust/balance-trust.mock';
import {
  DETAIL_CREDIT_DATA_ERROR, DETAIL_CREDIT_DATA_ERROR_NOSTATUS,
  DETAIL_CREDIT_GENERIC_ERROR
} from '../../../mocks/detail-credit/detail-credit-error.mock';
import { SUCCESS_LOAN_QUOTA_RESPONSE } from '../../../mocks/loan-quota/loan-quota.mock';
import { GENERAL_LOAN_QUOTA_EXCEPTION_ERROR } from '../../../mocks/loan-quota/loan-quota-general-exception.mock';

// Configure chai
chai.use(chaiHttp);
chai.should();
const expect = chai.expect;

describe('balanceController', () => {

  const requestBalancesNI = httpMocks.createRequest({
    method: "GET",
    url: "/V1/Enterprise/BalanceManagement/:acctId/retrieveSavingBalance",
    headers: {
      "X-Channel": "SMP",
      "X-NetworkOwner": "SMP",
      "X-CompanyId": "001",
      "X-CustIdentType": "NI",
      "X-IPAddr": "127.0.0.1",
      "X-IdentSerialNum": "8300218521",
      "X-Name": "bm-get-balance",
      "X-RqUID": "4ca5140b-e72c-4a60-b6e3-1aad3849800b",
      "X-TerminalId": "1234",
    },
    params: { acctId: "0056354103" },
  });

  const requestBalancesCC = httpMocks.createRequest({
    method: "GET",
    url: "/V1/Enterprise/BalanceManagement/:acctId/retrieveSavingBalance",
    headers: {
      "X-Channel": "SMP",
      "X-NetworkOwner": "SMP",
      "X-CompanyId": "001",
      "X-CustIdentType": "CC",
      "X-IPAddr": "127.0.0.1",
      "X-IdentSerialNum": "8300218521",
      "X-Name": "bm-get-balance",
      "X-RqUID": "4ca5140b-e72c-4a60-b6e3-1aad3849800b",
      "X-TerminalId": "1234",
    },
    params: { acctId: "0056354103" },
  });

  const requestBalancesCE = httpMocks.createRequest({
    method: "GET",
    url: "/V1/Enterprise/BalanceManagement/:acctId/retrieveSavingBalance",
    headers: {
      "X-Channel": "SMP",
      "X-NetworkOwner": "SMP",
      "X-CompanyId": "001",
      "X-CustIdentType": "CE",
      "X-IPAddr": "127.0.0.1",
      "X-IdentSerialNum": "8300218521",
      "X-Name": "bm-get-balance",
      "X-RqUID": "4ca5140b-e72c-4a60-b6e3-1aad3849800b",
      "X-TerminalId": "1234",
    },
    params: { acctId: "0056354103" },
  });

  const requestBalancesNE = httpMocks.createRequest({
    method: "GET",
    url: "/V1/Enterprise/BalanceManagement/:acctId/retrieveSavingBalance",
    headers: {
      "X-Channel": "SMP",
      "X-NetworkOwner": "SMP",
      "X-CompanyId": "001",
      "X-CustIdentType": "NE",
      "X-IPAddr": "127.0.0.1",
      "X-IdentSerialNum": "8300218521",
      "X-Name": "bm-get-balance",
      "X-RqUID": "4ca5140b-e72c-4a60-b6e3-1aad3849800b",
      "X-TerminalId": "1234",
    },
    params: { acctId: "0056354103" },
  });

  const requestBalancesPA = httpMocks.createRequest({
    method: 'GET',
    url: '/V1/Enterprise/BalanceManagement/:acctId/retrieveSavingBalance',
    headers: {
      'X-Channel': 'BancaVirtual',
      'X-CompanyId': '001',
      'X-CustIdentType': 'PA',
      'X-IPAddr': '127.0.0.1',
      'X-IdentSerialNum': '8300218521',
      'X-Name': 'bm-get-balance',
      'X-RqUID': '4ca5140b-e72c-4a60-b6e3-1aad3849800b',
      'X-TerminalId': '1234'
    },
    params: { acctId: '0056354103' }
  });

  const requestBalancesRC = httpMocks.createRequest({
    method: 'GET',
    url: '/V1/Enterprise/BalanceManagement/:acctId/retrieveSavingBalance',
    headers: {
      'X-Channel': 'BancaMovil',
      'X-CompanyId': '001',
      'X-CustIdentType': 'RC',
      'X-IPAddr': '127.0.0.1',
      'X-IdentSerialNum': '8300218521',
      'X-Name': 'bm-get-balance',
      'X-RqUID': '4ca5140b-e72c-4a60-b6e3-1aad3849800b',
      'X-TerminalId': '1234'
    },
    params: { acctId: '0056354103' }
  });

  const requestBalancesTI = httpMocks.createRequest({
    method: 'GET',
    url: '/V1/Enterprise/BalanceManagement/:acctId/retrieveSavingBalance',
    headers: {
      'X-Channel': 'SMP',
      'X-CompanyId': '001',
      'X-CustIdentType': 'TI',
      'X-IPAddr': '127.0.0.1',
      'X-IdentSerialNum': '8300218521',
      'X-Name': 'bm-get-balance',
      'X-RqUID': '4ca5140b-e72c-4a60-b6e3-1aad3849800b',
      'X-TerminalId': '1234'
    },
    params: { acctId: '0056354103' }
  });

  const requestBalancesErr = httpMocks.createRequest({
    method: 'GET',
    url: '/V1/Enterprise/BalanceManagement/:acctId/retrieveSavingBalance',
    headers: {
      'X-Channel': 'SMP',
      'X-CompanyId': '001',
      'X-CustIdentType': 'VA',
      'X-IPAddr': '127.0.0.1',
      'X-IdentSerialNum': '8300218521',
      'X-Name': 'bm-get-balance',
      'X-RqUID': '4ca5140b-e72c-4a60-b6e3-1aad3849800b',
      'X-TerminalId': '1234'
    },
    params: { acctId: '0056354103' }
  });

  const requestBalancesNJ = httpMocks.createRequest({
    method: 'GET',
    url: '/V1/Enterprise/BalanceManagement/:acctId/retrieveSavingBalance',
    headers: {
      'X-Channel': 'SMP',
      'X-CompanyId': '001',
      'X-CustIdentType': 'NJ',
      'X-IPAddr': '127.0.0.1',
      'X-IdentSerialNum': '8300218521',
      'X-Name': 'bm-get-balance',
      'X-RqUID': '4ca5140b-e72c-4a60-b6e3-1aad3849800b',
      'X-TerminalId': '1234'
    },
    params: { acctId: '0056354103' }
  });

  const requestCreditDetail = httpMocks.createRequest({
    method: 'GET',
    url: '/V1/Enterprise/BalanceManagement/retrieveDetailCreditInfo',
    headers: {
      'X-RqUID': '4ce9e7e1-2272-45f0-91e4-0281ec07e351',
      'X-Channel': 'Microfinanzas',
      'X-Name': 'Microfinanzas',
      'X-IPAddr': '100.20.30.40',
      'acctId': '559573565',
      'acctType': 'CCA',
      'TrnType': '0',
      'BaseEnvr': '1080220101000MOV3262019040914003010000',
      'X-CustIdentNum': 'EDoria1',
      'X-TerminalId': '1345',
      'X-CompanyId': '001',
      'X-CustIdentType': 'CC',
    },
  });
  const requestCreditDetailFail = httpMocks.createRequest({
    method: 'GET',
    url: '/V1/Enterprise/BalanceManagement/retrieveDetailCreditInfo',
    headers: {
      'X-RqUID': '4ce9e7e1-2272-45f0-91e4-0281ec07e351',
      'X-Channel': 'Microfinanzas',
      'X-Name': 'Microfinanzas',
      'X-IPAddr': '100.20.30.40',
      'X-CustIdentNum': 'EDoria1',
      'X-TerminalId': '1345',
      'X-CompanyId': '001',
      'X-CustIdentType': 'CC',
    },
  });

  const requestLoanQuota = httpMocks.createRequest({
    method: 'GET',
    url: '/V1/Enterprise/BalanceManagement/retrieveLoanQuota',
    headers: {
      'X-RqUID': '4ca5140b-e72c-4a60-b6e3-1aad3849800b',
      'X-Channel': 'SMP',
      'X-Name': 'bm-get-balance',
      'X-IPAddr': '127.0.0.1',
      'X-CustIdentNum': '8300218521',
      'X-TerminalId': '1234',
      'X-CustIdentType': 'NI',
      'rate': '15.24',
      'amount': '2375202',
      'term': '36',
      'frequency': '1',
      'increase': 'M',
      'accrualBase': '366',
      'accrualMethod': '360',
      'disbursementDate': '2022-03-25',
      'firstPaymentDate': '2022-06-01',
    }
  });

  const requestLoanQuotaFail = httpMocks.createRequest({
    method: 'GET',
    url: '/V1/Enterprise/BalanceManagement/retrieveLoanQuota',
    headers: {
      'X-RqUID': '4ca5140b-e72c-4a60-b6e3-1aad3849800b',
      'X-Channel': 'SMP',
      'X-Name': 'bm-get-balance',
      'X-IPAddr': '127.0.0.1',
      'X-CustIdentNum': '8300218521',
      'X-TerminalId': '1234',
      'X-CustIdentType': 'NI',
      'rate': '15.24',
      'amount': '2375202',
      'term': '36',
      'frequency': '1',
      'increase': 'M',
      'accrualBase': '366',
      'accrualMethod': '360',
      'firstPaymentDate': '2022-06-01',
    }
  });
  it('getSavingsBalances > It should return 200', async () => {
    nock(`${await getVariable('SAVING_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(200, SUCCESS_SAVING_RESPONSE);
    const response = httpMocks.createResponse();
    await balanceController.retrieveSavingBalance(requestBalancesCC, response, null);
    expect(response.statusCode).to.be.equal(200);
  });

  it('getGroupBalances > It should return 200', async () => {
    nock(`${ await getVariable('DEMAND_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(200, SUCCESS_DEMANDS_RESPONSE);
    nock(`${ await getVariable('CREDITCARD_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(200, SUCCESS_CREDITCARD_RESPONSE);
    nock(`${ await getVariable('LOAN_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(200, SUCCESS_LOAN_RESPONSE);
    nock(`${ await getVariable('SAVING_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(200, SUCCESS_SAVING_RESPONSE);
    nock(`${ await getVariable('CERTIFICATE_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(200, SUCCESS_CERTIFICATE_RESPONSE);
    nock(`${ await getVariable('TRUST_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(200, SUCCESS_TRUST_RESPONSE);
    const response = httpMocks.createResponse();
    requestBalancesNI._setBody( {
      accountsInfo: [
          {
              acctId: '0015055635',
              acctType: 'SDA'
          },
          {
              acctId: '00356795274',
              acctType: 'LOC'
          },
          {
              acctId: '0033971920',
              acctType: 'DDA'
          },
          {
              acctId: '4916171773516905',
              acctType: 'CCA',
              bankInfo: {
                branchId: '040'
              }
          },
          {
            acctId: '00190220152201',
            acctType: 'CDA'
          },
          {
            acctId: '00190220152202',
            acctType: 'CDA',
            bankInfo : {
              branchId: '0040'
            }
          },
          {
            acctId: '00190220152203',
            acctType: 'CDA',
            bankInfo : {
              branchId: undefined
            }
          }
      ]
  });
    await balanceController.retrieveGroupBalances(requestBalancesNI, response, null);
    expect(response.statusCode).to.be.equal(200);
  });

  it('getDemandBalances > It should return 200', async () => {
    nock(`${await getVariable('DEMAND_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(200, SUCCESS_DEMANDS_RESPONSE);

    requestBalancesNJ._setParameter('acctId','0056354103');
    const response = httpMocks.createResponse();
    await balanceController.retrieveDemandBalance(requestBalancesNJ, response, null);
    expect(response.statusCode).to.be.equal(200);
  });

  it('getCreditCardBalances > It should return 200', async () => {
    nock(`${await getVariable('CREDITCARD_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(200, SUCCESS_CREDITCARD_RESPONSE);
    requestBalancesCE._setParameter('acctId','00563541032');
    const response = httpMocks.createResponse();
    await balanceController.retrieveCreditCardBalance(requestBalancesCE, response, null);
    expect(response.statusCode).to.be.equal(200);
  });

  it('getLoanBalances > It should return 200', async () => {
    nock(`${await getVariable('LOAN_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(200, SUCCESS_LOAN_RESPONSE);
    requestBalancesNE._setParameter('acctId','0056354103');
    const response = httpMocks.createResponse();
    await balanceController.retrieveLoanBalance(requestBalancesNE, response, null);
    expect(response.statusCode).to.be.equal(200);
  });

  it('getCertificateBalances > It should return 200', async () => {
    nock(`${await getVariable('CERTIFICATE_BALANCES_ENDPOINT')}`)
        .post('')
        .reply(200, SUCCESS_CERTIFICATE_RESPONSE);
    requestBalancesPA._setParameter('acctId','00400959595950');
    const response = httpMocks.createResponse();
    await balanceController.retrieveCertificateBalance(requestBalancesPA, response, null);
    expect(response.statusCode).to.be.equal(200);
  });

  it('getCertificateBalances > It should return 500', async () => {
    requestBalancesErr._setParameter('acctId','00400959595950');
    const response = httpMocks.createResponse();
    await balanceController.retrieveCertificateBalance(requestBalancesErr, response, null);
    expect(response.statusCode).to.be.equal(500);
  });

  it('getTrustBalances > It should return 200', async () => {
    requestBalancesRC._setParameter('acctId','0987654321');
    const response = httpMocks.createResponse();
    await balanceController.retrieveTrustBalance(requestBalancesRC, response, null);
    expect(response.statusCode).to.be.equal(200);
  });

  it('getDemandBalances > It should return 409', async () => {
    nock(`${await getVariable('DEMAND_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(200, FALSE_SUCCESS_DEMAND_RESPONSE);

    requestBalancesTI._setParameter('acctId','00563541005635411103');
    const response = httpMocks.createResponse();
    await balanceController.retrieveDemandBalance(requestBalancesTI, response, null);

    expect(response.statusCode).to.be.equal(409);
  });

  it('getDemandBalances > It should return 500', async () => {
    nock(`${await getVariable('DEMAND_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(500, GENERAL_EXCEPTION_ERROR);
    requestBalancesCC._setParameter('acctId','0056354103');
    const response = httpMocks.createResponse();
    await balanceController.retrieveDemandBalance(requestBalancesCC, response, null);

    expect(response.statusCode).to.be.equal(500);
  });

  it('getSavingBalances > It should return 409', async () => {
    nock(`${await getVariable('SAVING_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(200, FALSE_SUCCESS_SAVING_RESPONSE);

    requestBalancesCC._setParameter('acctId','0056354103');
    const response = httpMocks.createResponse();
    await balanceController.retrieveSavingBalance(requestBalancesCC, response, null);

    expect(response.statusCode).to.be.equal(409);
  });

  it('getSavingBalances > It should return 500', async () => {
    nock(`${await getVariable('SAVING_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(500, GENERAL_EXCEPTION_ERROR);
    requestBalancesCC._setParameter('acctId','00563541032');
    const response = httpMocks.createResponse();
    await balanceController.retrieveSavingBalance(requestBalancesCC, response, null);
    expect(response.statusCode).to.be.equal(500);
  });

  it('getCreditCardBalances > It should return 409', async () => {
    nock(`${await getVariable('CREDITCARD_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(200, FALSE_SUCCESS_CREDITCARD_RESPONSE);

    requestBalancesCC._setParameter('acctId','00563541005635411103');
    const response = httpMocks.createResponse();
    await balanceController.retrieveCreditCardBalance(requestBalancesCC, response, null);

    expect(response.statusCode).to.be.equal(409);
  });

  it('getCreditCardBalances > It should return 500', async () => {
    nock(`${await getVariable('CREDITCARD_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(500, GENERAL_EXCEPTION_ERROR);
    requestBalancesCC._setParameter('acctId','0056354103');
    const response = httpMocks.createResponse();
    await balanceController.retrieveCreditCardBalance(requestBalancesCC, response, null);
    expect(response.statusCode).to.be.equal(500);
  });

  it('getLoanBalances > It should return 409', async () => {
    nock(`${await getVariable('LOAN_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(200, FALSE_SUCCESS_LOAN_RESPONSE);

    requestBalancesCC._setParameter('acctId','0056354100');
    const response = httpMocks.createResponse();
    await balanceController.retrieveLoanBalance(requestBalancesCC, response, null);

    expect(response.statusCode).to.be.equal(409);
  });

  it('getLoanBalances > It should return 500 Of general exception', async () => {
    nock(`${await getVariable('LOAN_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(500, GENERAL_EXCEPTION_ERROR);
    requestBalancesCC._setParameter('acctId','0056354100');
    const response = httpMocks.createResponse();
    await balanceController.retrieveLoanBalance(requestBalancesCC, response, null);

    expect(response.statusCode).to.be.equal(500);
  });

  it('getCreditCardBalances > It should return 500', async () => {
    nock(`${await getVariable('CREDITCARD_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(500, GENERAL_EXCEPTION_ERROR);
    requestBalancesCC._setParameter('acctId','0056354103');
    const response = httpMocks.createResponse();
    await balanceController.retrieveCreditCardBalance(requestBalancesCC, response, null);
    expect(response.statusCode).to.be.equal(500);
  });

  it('getSavingsBalances > It should return 500', async () => {
    nock(`${await getVariable('SAVING_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(500, GENERAL_EXCEPTION_ERROR);
    requestBalancesCC._setParameter('acctId','0056354103');
    const response = httpMocks.createResponse();
    await balanceController.retrieveSavingBalance(requestBalancesCC, response, null);
    expect(response.statusCode).to.be.equal(500);
  });

  it('getDemandBalances > It should return 500', async () => {
    nock(`${await getVariable('DEMAND_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(500, GENERAL_EXCEPTION_ERROR);

    requestBalancesCC._setParameter('acctId','00563541032');
    const response = httpMocks.createResponse();
    await balanceController.retrieveDemandBalance(requestBalancesCC, response, null);
    expect(response.statusCode).to.be.equal(500);
  });

  it('getCertificateBalances > It should return 500', async () => {
    nock(`${await getVariable('CERTIFICATE_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(500, GENERAL_EXCEPTION_ERROR);
    requestBalancesCC._setParameter('acctId','0056354103');
    const response = httpMocks.createResponse();
    await balanceController.retrieveCertificateBalance(requestBalancesCC, response, null);
    expect(response.statusCode).to.be.equal(500);
  });

  it('getCertificateBalances > It should return 409', async () => {
    nock(`${await getVariable('CERTIFICATE_BALANCES_ENDPOINT')}`)
        .post('')
        .reply(200, FALSE_SUCCESS_CERTIFICATE_RESPONSE);
    requestBalancesCC._setParameter('acctId','0056354103');
    const response = httpMocks.createResponse();
    await balanceController.retrieveCertificateBalance(requestBalancesCC, response, null);
    expect(response.statusCode).to.be.equal(409);
  });

  it('getTrustBalances > It should return 500', async () => {
    nock(`${await getVariable('TRUST_BALANCES_ENDPOINT')}`)
    .post('')
    .reply(500, GENERAL_EXCEPTION_ERROR);
    requestBalancesCC._setParameter('acctId','0056354103');
    const response = httpMocks.createResponse();
    await balanceController.retrieveTrustBalance(requestBalancesCC, response, null);
    expect(response.statusCode).to.be.equal(500);
  });

  it('getTrustBalances > It should return 409', async () => {
    nock(`${await getVariable('TRUST_BALANCES_ENDPOINT')}`)
        .post('')
        .reply(200, FALSE_SUCCESS_TRUST_RESPONSE);
    requestBalancesCC._setParameter('acctId','0056354103');
    const response = httpMocks.createResponse();
    await balanceController.retrieveTrustBalance(requestBalancesCC, response, null);
    expect(response.statusCode).to.be.equal(409);
  });

  it('getGroupBalances > It should fail ', async () => {
    nock(`${ await getVariable('DEMAND_BALANCES_ENDPOINT')}`)
        .post('')
        .reply(200, SUCCESS_DEMANDS_RESPONSE);
    nock(`${ await getVariable('CREDITCARD_BALANCES_ENDPOINT')}`)
        .post('')
        .reply(200, SUCCESS_CREDITCARD_RESPONSE);
    nock(`${ await getVariable('LOAN_BALANCES_ENDPOINT')}`)
        .post('')
        .reply(200, SUCCESS_LOAN_RESPONSE);
    nock(`${ await getVariable('SAVING_BALANCES_ENDPOINT')}`)
        .post('')
        .reply(500, SUCCESS_SAVING_RESPONSE);
    nock(`${ await getVariable('CERTIFICATE_BALANCES_ENDPOINT')}`)
        .post('')
        .reply(200, SUCCESS_CERTIFICATE_RESPONSE);
    nock(`${ await getVariable('TRUST_BALANCES_ENDPOINT')}`)
        .post('')
        .reply(200, '</zz>');
    const response = httpMocks.createResponse();
    requestBalancesNI._setBody( {
      accountsInfo: [
        {
          acctId: '0015055635',
          acctType: 'SDA'
        },
        {
          acctId: '00356795274',
          acctType: 'LOC'
        },
        {
          acctId: '0033971920',
          acctType: 'DDA'
        }, {
          acctId: '4916171773516905',
          acctType: 'CCA'
        }
      ]
    });
    await balanceController.retrieveGroupBalances(requestBalancesNI, response, null);

    expect(response.statusCode).to.be.equal(500);
  });

  it('catch undefined error ', async () => {
    const error = new AdapterError({
      ServerStatusCode: '500',
      Severity: 'Error',
      StatusCode: 500,
      StatusDesc: 'string'
    });
    AdapterError.getErrorFromMessage({}, 200, 200);

  });

  it('retrieveDetailCreditInfo > It should return 500', async () => {
    nock(`${await getVariable('CUSTOMER_PRODUCT_ENDPOINT')}`)
        .post('')
        .reply(500, DETAIL_CREDIT_GENERIC_ERROR);
    const response = httpMocks.createResponse();
    await balanceController.retrieveDetailCreditInfo(requestCreditDetail, response);

    expect(response.statusCode).to.be.equal(500);
  });
  it('retrieveDetailCreditInfo > It should return 409', async () => {
    nock(`${await getVariable('CUSTOMER_PRODUCT_ENDPOINT')}`)
        .post('')
        .reply(200, DETAIL_CREDIT_DATA_ERROR);
    const response = httpMocks.createResponse();
    await balanceController.retrieveDetailCreditInfo(requestCreditDetailFail, response);
    expect(response.statusCode).to.be.equal(409);
  });
  it('retrieveDetailCreditInfo > It should return 409 NO STATUS', async () => {
    nock(`${await getVariable('CUSTOMER_PRODUCT_ENDPOINT')}`)
        .post('')
        .reply(200, DETAIL_CREDIT_DATA_ERROR_NOSTATUS);
    const response = httpMocks.createResponse();
    await balanceController.retrieveDetailCreditInfo(requestCreditDetailFail, response);
    expect(response.statusCode).to.be.equal(409);
  });

  it('retrieveLoanQuota > It should return 200', async () => {
    nock(`${await getVariable('LOAN_QUOTA_ENDPOINT')}`)
        .post('')
        .reply(200, SUCCESS_LOAN_QUOTA_RESPONSE);
    const response = httpMocks.createResponse();
    await balanceController.retrieveLoanQuota(requestLoanQuota, response);
    expect(response.statusCode).to.be.equal(200);
  });

  it('retrieveLoanQuota > It should return 500 Of general exception', async () => {
    nock(`${await getVariable('LOAN_QUOTA_ENDPOINT')}`)
        .post('')
        .reply(500, GENERAL_LOAN_QUOTA_EXCEPTION_ERROR);
    const response = httpMocks.createResponse();
    await balanceController.retrieveLoanQuota(requestLoanQuotaFail, response);
    expect(response.statusCode).to.be.equal(500);
  });
});