export const GENERAL_EXCEPTION_ERROR = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="urn://bancodebogota.com/accounts/product/service/" xmlns:v1="urn://bancodebogota.com/ifx/base/v1/">
<soapenv:Body>
  <soapenv:Fault>
    <faultcode>Server</faultcode>
    <faultstring xml:lang="esCO">Error</faultstring>
    <detail>
        <v1:GeneralException>
          <v1:RqUID>e97ec742-c051-4fc3-b509-3ecc1f7b29c0</v1:RqUID>
          <v1:Status>
             <v1:StatusCode>100</v1:StatusCode>
             <v1:Severity>Error</v1:Severity>
             <v1:StatusDesc>Error General</v1:StatusDesc>
          </v1:Status>
        </v1:GeneralException>
    </detail>
  </soapenv:Fault>
</soapenv:Body>
</soapenv:Envelope>`;
