export const FALSE_SUCCESS_CREDITCARD_RESPONSE = `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="urn://bancodebogota.com/accounts/product/service/" xmlns:nsi="urn://bancodebogota.com/ifx/base/v1/" xmlns:ns1="urn://bancodebogota.com/accounts/product/event/" xmlns:ns2="urn://bancodebogota.com/accounts/product/v1/" xmlns:ns3="urn://bancodebogota.com/ifx/lite/v1/">
    <soapenv:Body>
        <ns:getCreditCardBalancesResponse>
            <ns1:CCABalInqRs>
                <nsi:RqUID>4ca5140b-e72c-4a60-b6e3-1aad3849800b</nsi:RqUID>
                <nsi:Status>
                    <nsi:StatusCode>100</nsi:StatusCode>
                    <nsi:ServerStatusCode>1020</nsi:ServerStatusCode>
                    <nsi:Severity>Error</nsi:Severity>
                    <nsi:StatusDesc>Error General</nsi:StatusDesc>
                    <nsi:ServerStatusDesc>TP en_US 1020  Required Element Not Included</nsi:ServerStatusDesc>
                    <nsi:AdditionalStatus>
                        <nsi:StatusCode>-100</nsi:StatusCode>
                        <nsi:ServerStatusCode>100</nsi:ServerStatusCode>
                        <nsi:Severity>Error</nsi:Severity>
                        <nsi:StatusDesc>Failed invoke to backend</nsi:StatusDesc>
                    </nsi:AdditionalStatus>
                </nsi:Status>
                <nsi:NetworkTrnInfo>
                    <nsi:NetworkOwner>SMP</nsi:NetworkOwner>
                    <nsi:TerminalId>875</nsi:TerminalId>
                    <nsi:BankId>001</nsi:BankId>
                </nsi:NetworkTrnInfo>
                <nsi:ServerDt>2020-04-17T08:24:03</nsi:ServerDt>
            </ns1:CCABalInqRs>
        </ns:getCreditCardBalancesResponse>
    </soapenv:Body>
</soapenv:Envelope>
`;
