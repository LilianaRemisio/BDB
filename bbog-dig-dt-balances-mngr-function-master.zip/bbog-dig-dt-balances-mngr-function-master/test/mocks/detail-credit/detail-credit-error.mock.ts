export const DETAIL_CREDIT_GENERIC_ERROR = `
<?xml version="1.0" encoding="UTF-8"?>
<NS1:Envelope xmlns:NS1="http://schemas.xmlsoap.org/soap/envelope/" xmlns:even="urn://bancodebogota.com/customers/product/event/" xmlns:ifx="urn://bancodebogota.com/ifx/" xmlns:ifxbase="urn://bancodebogota.com/ifx/base/v1/" xmlns:ser="urn://bancodebogota.com/customers/product/service/" xmlns:v11="urn://bancodebogota.com/ifx/lite/v1/">
   <NS1:Body>
      <ser:getLoanAcctDetailResponse>
         <even:LoanAcctDetailInqRs>
            <ifxbase:RqUID>68782f72-089a-4a72-8ac4-dc7e0d7f9fe7</ifxbase:RqUID>
            <ifxbase:Status>
               <ifxbase:StatusCode>500</ifxbase:StatusCode>
               <ifxbase:Severity>Error</ifxbase:Severity>
               <ifxbase:StatusDesc>Error Generico</ifxbase:StatusDesc>
            </ifxbase:Status>
            <ifxbase:CreditDetailRec />
         </even:LoanAcctDetailInqRs>
      </ser:getLoanAcctDetailResponse>
   </NS1:Body>
</NS1:Envelope>
`;

export const DETAIL_CREDIT_DATA_ERROR = `
<?xml version="1.0" encoding="UTF-8"?>
<NS1:Envelope xmlns:NS1="http://schemas.xmlsoap.org/soap/envelope/" xmlns:even="urn://bancodebogota.com/customers/product/event/" xmlns:ifx="urn://bancodebogota.com/ifx/" xmlns:ifxbase="urn://bancodebogota.com/ifx/base/v1/" xmlns:ser="urn://bancodebogota.com/customers/product/service/" xmlns:v11="urn://bancodebogota.com/ifx/lite/v1/">
   <NS1:Body>
      <ser:getLoanAcctDetailResponse>
         <even:LoanAcctDetailInqRs>
            <ifxbase:RqUID>68782f72-089a-4a72-8ac4-dc7e0d7f9fe7</ifxbase:RqUID>
            <ifxbase:Status>
               <ifxbase:StatusCode>100</ifxbase:StatusCode>
               <ifxbase:ServerStatusCode>AM1047</ifxbase:ServerStatusCode>
               <ifxbase:Severity>Error</ifxbase:Severity>
               <ifxbase:StatusDesc>Error Generico</ifxbase:StatusDesc>
               <ifxbase:ServerStatusDesc>AMPC AM1047 E: NO SE ENCUENTRA CUENTA</ifxbase:ServerStatusDesc>
               <ifxbase:AdditionalStatus>
                  <ifxbase:StatusCode>-1000</ifxbase:StatusCode>
                  <ifxbase:ServerStatusCode>-10361</ifxbase:ServerStatusCode>
                  <ifxbase:Severity>Error</ifxbase:Severity>
                  <ifxbase:StatusDesc>MESSAGES FOR NATIVE ACC 00001024554090</ifxbase:StatusDesc>
               </ifxbase:AdditionalStatus>
               <ifxbase:AdditionalStatus>
                  <ifxbase:StatusCode>100</ifxbase:StatusCode>
                  <ifxbase:ServerStatusCode>-10361</ifxbase:ServerStatusCode>
                  <ifxbase:Severity>Error</ifxbase:Severity>
                  <ifxbase:StatusDesc>TP en_US 100  General Error</ifxbase:StatusDesc>
               </ifxbase:AdditionalStatus>
               <ifxbase:AdditionalStatus>
                  <ifxbase:StatusCode>-1000</ifxbase:StatusCode>
                  <ifxbase:ServerStatusCode>-10361</ifxbase:ServerStatusCode>
                  <ifxbase:Severity>Error</ifxbase:Severity>
                  <ifxbase:StatusDesc>AMPC AM1047 E: NO SE ENCUENTRA CUENTA</ifxbase:StatusDesc>
               </ifxbase:AdditionalStatus>
            </ifxbase:Status>
            <ifxbase:CreditDetailRec />
         </even:LoanAcctDetailInqRs>
      </ser:getLoanAcctDetailResponse>
   </NS1:Body>
</NS1:Envelope>
`;

export const DETAIL_CREDIT_DATA_ERROR_NOSTATUS = `
<?xml version="1.0" encoding="UTF-8"?>
<NS1:Envelope xmlns:NS1="http://schemas.xmlsoap.org/soap/envelope/" xmlns:even="urn://bancodebogota.com/customers/product/event/" xmlns:ifx="urn://bancodebogota.com/ifx/" xmlns:ifxbase="urn://bancodebogota.com/ifx/base/v1/" xmlns:ser="urn://bancodebogota.com/customers/product/service/" xmlns:v11="urn://bancodebogota.com/ifx/lite/v1/">
   <NS1:Body>
      <ser:getLoanAcctDetailResponse>
         <even:LoanAcctDetailInqRs>
            <ifxbase:RqUID>68782f72-089a-4a72-8ac4-dc7e0d7f9fe7</ifxbase:RqUID>
            <ifxbase:Status>
               <ifxbase:StatusCode>100</ifxbase:StatusCode>
               <ifxbase:ServerStatusCode>AM1047</ifxbase:ServerStatusCode>
               <ifxbase:Severity>Error</ifxbase:Severity>
               <ifxbase:StatusDesc>Error Generico</ifxbase:StatusDesc>
               <ifxbase:AdditionalStatus>
                  <ifxbase:StatusCode>-1000</ifxbase:StatusCode>
                  <ifxbase:ServerStatusCode>-10361</ifxbase:ServerStatusCode>
                  <ifxbase:Severity>Error</ifxbase:Severity>
               </ifxbase:AdditionalStatus>
            </ifxbase:Status>
            <ifxbase:CreditDetailRec />
         </even:LoanAcctDetailInqRs>
      </ser:getLoanAcctDetailResponse>
   </NS1:Body>
</NS1:Envelope>
`;
