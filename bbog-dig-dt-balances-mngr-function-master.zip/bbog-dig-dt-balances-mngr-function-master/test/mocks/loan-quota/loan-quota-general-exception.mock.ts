export const GENERAL_LOAN_QUOTA_EXCEPTION_ERROR = `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope
	xmlns:soapenv="http://schemas.xmlsoap.org/wsdl/soap/">
	<soapenv:Header/>
	<soapenv:Body>
		<soapenv:Fault>
			<faultcode>soapenv:Server</faultcode>
			<faultstring>No es posible procesar la transaccion. Comuniquesecon la Entidad</faultstring>
			<detail>
				<GeneralException>
					<Status>
						<StatusCode>100</StatusCode>
						<ServerStatusCode>0x00230001</ServerStatusCode>
						<Severity>Error</Severity>
						<StatusDesc>Fallas Tecnicas nos impiden procesar la Transaccion</StatusDesc>
						<ServerStatusDesc>http://10.85.88.49:3590/customers/product/LoanQuotaInq: cvc-particle 3.1: in element {urn://bancodebogota.com/customers/product/event/}LoanQuotaInqRq of type {urn://bancodebogota.com/customers/product/event/}LoanQuotaInqRq_Type, found &lt;ns2:CustId> (in namespace urn://bancodebogota.com/ifx/base/v1/), but next item should be {urn://bancodebogota.com/ifx/base/v1/}RqUID</ServerStatusDesc>
					</Status>
				</GeneralException>
			</detail>
		</soapenv:Fault>
	</soapenv:Body>
</soapenv:Envelope>`;
