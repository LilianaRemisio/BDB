import { describe, expect, it, beforeEach, afterEach } from "@jest/globals";
import sinon from "sinon";
import request from 'supertest';
import config from '../src/config';

const rquidTest = '7118c962-bd3c-4388-bd1e-ae9b57bac687'
const app = require('../src/app').default;

beforeEach(() => {
  config.USE_CIRCUIT_BREAKER_SAVINGS = 'false';
  config.USE_CIRCUIT_BREAKER_DEMANDS = 'false';
  // Simula el método `onlyPublishInSns` para que no haga la llamada real
  // onlyPublishInSnsStub = sinon.stub(reportService, 'onlyPublishInSns').resolves({data:{"status": 'ok'}, status:200});

 // sinon.stub(reportService, 'onlyPublishInSns').resolves({data:{"status": 'ok'}, status:200});
});

afterEach(() => {
  // Restaura todos los mocks
  sinon.restore();
  config.USE_CIRCUIT_BREAKER_SAVINGS = 'true'; // Restaurar el valor original si es necesario
  config.USE_CIRCUIT_BREAKER_DEMANDS = 'true'; // Restaurar el valor original si es necesario

});

describe('app.spec [ app.spec ] async spec', () => {

  it('GIVEN EnviromentManagementService WHEN when use get resource THEN get envars', async () => {

    console.log(rquidTest, '[TEST CASE 1: EnviromentManagementService - Succes]');
    const response: any = await request(app)
      .get(`/balancesManagement/env-vars`)
      .set({ 'UseCircuitBreakerSavings': 'false' })
    console.log(rquidTest, `[TEST CASE 1: EnviromentManagementService - Response Success`, response.body);
    // console.log('tttt')
    expect(response.body).toEqual(expect.any(Object))
    // sinon.assert.calledOnce(onlyPublishInSnsStub);

  });

  it('GIVEN EnviromentManagementService WHEN when use post resource THEN update envars', async () => {

    console.log(rquidTest, '[TEST CASE 1: EnviromentManagementService - Succes]');
    const response: any = await request(app)
      .post(`/balancesManagement/env-vars`)
      .set({ 'UseCircuitBreakerSavings': 'false' })
    console.log(rquidTest, `[TEST CASE 1: EnviromentManagementService - Response Success`, JSON.stringify({ 'Salida': response.body }));
    expect(response.body).toEqual(expect.any(Object))
  });


  it('GIVEN EnviromentManagementService WHEN when use get resource THEN get envars', async () => {

    console.log(rquidTest, '[TEST CASE 1: EnviromentManagementService - Succes]');
    const response: any = await request(app)
      .get(`/balancesManagement/env-vars`)
      .set({ 'UseCircuitBreakerDemands': 'false' })
    console.log(rquidTest, `[TEST CASE 1: EnviromentManagementService - Response Success`, response.body);
    expect(response.body).toEqual(expect.any(Object))
  });

  it('GIVEN EnviromentManagementService WHEN when use post resource THEN update envars', async () => {

    console.log(rquidTest, '[TEST CASE 1: EnviromentManagementService - Succes]');
    const response: any = await request(app)
      .post(`/balancesManagement/env-vars`)
      .set({
        'UseCircuitBreakerDemands': 'false',
        'PrincipalEndpointDemands': '',
        'ContingencyEndpointDemands': ''
      })
    console.log(rquidTest, `[TEST CASE 1: EnviromentManagementService - Response Success`, JSON.stringify({ 'Salida': response.body }));
    expect(response.body).toEqual(expect.any(Object))
  });
});