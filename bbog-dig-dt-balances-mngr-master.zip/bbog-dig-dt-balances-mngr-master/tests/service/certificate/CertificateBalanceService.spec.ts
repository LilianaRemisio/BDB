import { describe, expect, it, jest, beforeEach, afterEach } from "@jest/globals";
import { CertificateBalanceService } from '../../../src/service/certificate/CertificateBalanceService';
import sinon from "sinon";
import axios from 'axios';
import { rq_Demand_Rest_200, rq_Demand_Rest_200_Without_NetWorkOwner, rs_Bck_Demand_REST_200, rs_Bck_Demand_REST_409, rs_Bck_Demand_XML_200, rs_Bck_Demand_XML_200_single, rs_Bck_Demand_XML_409, rs_Bck_Demand_XML_500 } from "../../mocks/balance-demands/mocks-service";
import config from '../../../src/config';
import BdbCircuitBreaker from '../../../src/service/circuitbreaker/bdbCircuitBreaker';
import {reportService} from '../../../src/service/circuitbreaker/bdbCircuitBreaker';
import { rq_Certificate_Rest_200, rs_Bck_Certificate_XML_200, rs_Bck_Certificate_XML_200_single, rs_Bck_Certificate_XML_409 } from "../../mocks/balance-certificate/mocks-service";

const acctId = '343434'
const rquidTest = '7118c962-bd3c-4388-bd1e-ae9b57bac687'

beforeEach(() => {
  config.USE_CIRCUIT_BREAKER_DEMANDS = 'false';
  // Stub the `onlyPublishInSns` method
  sinon.stub(reportService, 'onlyPublishInSns').resolves({data:{"status": 'ok'}, status:200});
});

afterEach(() => {
  sinon.restore();
  config.USE_CIRCUIT_BREAKER_DEMANDS = 'true'; // Restaurar el valor original si es necesario
});


describe('CertificateBalanceService.spec [ CertificateBalanceService - invokeCertificateBalanceService] async spec', () => {

  it('GIVEN CertificateBalanceService WHEN CircuitBreaker is FALSE and data is valid then response 200', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Certificate_XML_200));
    const response = await CertificateBalanceService.invokeCertificateBalanceService(acctId, rq_Certificate_Rest_200);
    console.log(rquidTest, `[TEST CASE 1: CertificateBalanceService retrieveCertificateBalance - Response mock Success ] `, JSON.stringify({ 'RESPONSE': response }));
    expect(response.AccInfo[0].ExtAcctBal[0].CurAmt?.Amt).toEqual("0.00");
    expect(response.AccInfo[0].ExtAcctBal[0].ExtBalType).toEqual("Redemption");
    expect(response).toEqual(expect.any(Object))
  });

  it('GIVEN CertificateBalanceService WHEN CircuitBreaker is FALSE and data is valid then response 200 single acctball', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Certificate_XML_200_single));
    const response = await CertificateBalanceService.invokeCertificateBalanceService(acctId, rq_Certificate_Rest_200);
    console.log(rquidTest, `[TEST CASE 1: CertificateBalanceService retrieveCertificateBalance - Response mock Success ] `, JSON.stringify({ 'RESPONSE': response }));
    expect(response).toEqual(expect.any(Object))
  });

  it('GIVEN CertificateBalanceService WHEN CircuitBreaker is FALSE and data is valid then response 409', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Certificate_XML_409));
    try {
      const response = await CertificateBalanceService.invokeCertificateBalanceService(acctId, rq_Certificate_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 2: CertificateBalanceService retrieveCertificateBalance - Response mock Bussiness Error ] `, JSON.stringify({ 'RESPONSE': error }));
      expect(error.Status.StatusCode).toEqual(409);
    }
  });

  it('GIVEN CertificateBalanceService WHEN CircuitBreaker is FALSE and response is other operation response 500 not matchin response', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Certificate_XML_200));
    try {
      const response = await CertificateBalanceService.invokeCertificateBalanceService(acctId, rq_Certificate_Rest_200);
      console.log('ohoh')
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 2: CertificateBalanceService retrieveCertificateBalance - Response mock Bussiness Error ] `, JSON.stringify({ 'RESPONSE': error }));
      expect(error.Status.StatusCode).toEqual(500);
    }
  });

  it('GIVEN CertificateBalanceService WHEN CircuitBreaker is FALSE and data is valid then response but backend give internal error', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False y genera error interno
    sinon.stub(axios, 'post').callsFake(() => {
      return Promise.reject({
        response: {
          status: 500,
          statusText: 'Internal Server Error',
          data: {
            error: 'Something went wrong on the server',
            code: 'BACKEND_ERROR',
          },
        },
        config: {}, // Configuración de la solicitud, opcional
        isAxiosError: true, // Indica que es un error de Axios
        toJSON: () => ({
          message: 'Request failed with status code 500',
          code: 'BACKEND_ERROR',
        }),
      });
    });

    try {
      const response = await CertificateBalanceService.invokeCertificateBalanceService(acctId, rq_Certificate_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 3: CertificateBalanceService retrieveCerBalance - Response mock Internal Error: ${error.Status.StatusCode} ] `, JSON.stringify({ 'RESPONSE_ERROR': error }));
      expect(error.Status.StatusCode).toEqual(500);
    }
  });

  it('GIVEN CertificateBalanceService WHEN CircuitBreaker is FALSE and data is valid then response but backend give Timeout error', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False y genera Timeout interno
    // Simula un timeout en axios.post
    sinon.stub(axios, 'post').callsFake(() => {
      return Promise.reject({
        code: 'ECONNABORTED',
        message: 'timeout of 5000ms exceeded',
        config: {}, // Configuración de la solicitud, opcional
        isAxiosError: true, // Indica que es un error de Axios
        toJSON: () => ({
          message: 'timeout of 5000ms exceeded',
          code: 'ECONNABORTED',
        }),
      });
    });

    try {
      const response = await CertificateBalanceService.invokeCertificateBalanceService(acctId, rq_Certificate_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 4: CertificateBalanceService retrieveCertificateBalance - Response mock Timeout Error: ${error.Status.StatusCode} ] `, JSON.stringify({ 'RESPONSE_ERROR': error }));
      expect(error.Status.StatusCode).toEqual(408);
    }
  });

});
