import { describe, expect, it, jest, beforeEach, afterEach } from "@jest/globals";
import { GroupBalanceService } from '../../../src/service/group/GroupBalanceService';
import sinon from "sinon";
import axios from 'axios';
import config from '../../../src/config';
import { reportService } from '../../../src/service/circuitbreaker/bdbCircuitBreaker';
import { rqGetGroupBalanceRest_200_CCA, rqGetGroupBalanceRest_200_CDA, rqGetGroupBalanceRest_200_DDA, rqGetGroupBalanceRest_200_FDA, rqGetGroupBalanceRest_200_LOC, rqGetGroupBalanceRest_200_SDA, rqGetGroupBalanceRest_200_TTT, rq_Group_Rest_200 } from "../../mocks/balance-group/mocks-service";
import { IAccountsInfoRestModel } from "../../../src/model/IAccountsInfoRestModel";
import { rs_Bck_Savings_XML_200 } from "../../mocks/balance-savings/mocks-service";
import { rs_Bck_Trust_XML_200 } from "../../mocks/balance-trust/mocks-service";
import { rs_Bck_Demand_XML_200 } from "../../mocks/balance-demands/mocks-service";
import { rs_Bck_CreditCard_XML_200 } from "../../mocks/balance-creditcard/mocks-service";
import { rs_Bck_Certificate_XML_200 } from "../../mocks/balance-certificate/mocks-service";
import { rs_Bck_Loan_XML_200 } from "../../mocks/balance-loan/mocks-service";

const rquidTest = '7118c962-bd3c-4388-bd1e-ae9b57bac687'

beforeEach(() => {
  config.USE_CIRCUIT_BREAKER_DEMANDS = 'false';
  // Stub the `onlyPublishInSns` method
  sinon.stub(reportService, 'onlyPublishInSnsCircuitBreakerEvent').resolves();
});

afterEach(() => {
  sinon.restore();
  config.USE_CIRCUIT_BREAKER_DEMANDS = 'true'; // Restaurar el valor original si es necesario
});

describe('GroupBalanceService.spec [ GroupBalanceService - invokeGroupBalanceService] async spec', () => {
  it('GIVEN GroupBalanceService WHEN accountType is SDA and data is valid then response 200', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Savings_XML_200));
    const accounts = rqGetGroupBalanceRest_200_SDA.body as IAccountsInfoRestModel;
    const response = await GroupBalanceService.invokeGroupBalanceService(accounts.AccountsInfo, rq_Group_Rest_200);
    console.log(rquidTest, `[TEST CASE 1: GroupBalanceService retrieveSavingsBalance - Response mock Success ] `, JSON.stringify({ 'RESPONSE': response }));
    expect(response.AccInfo[0].AcctBal[0].CurAmt.Amt).toEqual("18499647.00");
    expect(response.AccInfo[0].AcctBal[0].BalType).toEqual("Current");
    expect(response).toEqual(expect.any(Object))
  });

  it('GIVEN GroupBalanceService WHEN accountType is DDA and data is valid then response 200', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend SDA
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Demand_XML_200));
    const accounts = rqGetGroupBalanceRest_200_DDA.body as IAccountsInfoRestModel;
    const response = await GroupBalanceService.invokeGroupBalanceService(accounts.AccountsInfo, rq_Group_Rest_200);
    console.log(rquidTest, `[TEST CASE 1: GroupBalanceService retrieveDemandBalance - Response mock Success ] `, JSON.stringify({ 'RESPONSE': response }));
    expect(response.AccInfo[0].AcctBal[0].CurAmt.Amt).toEqual("3311843.45");
    expect(response.AccInfo[0].AcctBal[0].BalType).toEqual("Avail");
    expect(response).toEqual(expect.any(Object))
  });

  it('GIVEN GroupBalanceService WHEN accountType is FDA and data is valid then response 200', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend FDA
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Trust_XML_200));
    const accounts = rqGetGroupBalanceRest_200_FDA.body as IAccountsInfoRestModel;
    const response = await GroupBalanceService.invokeGroupBalanceService(accounts.AccountsInfo, rq_Group_Rest_200);
    console.log(rquidTest, `[TEST CASE 1: GroupBalanceService retrieveTrustBalance - Response mock Success ] `, JSON.stringify({ 'RESPONSE': response }));
    expect(response.AccInfo[0].AcctBal[0].CurAmt.Amt).toEqual("87356872.98");
    expect(response.AccInfo[0].AcctBal[0].BalType).toEqual("Avail");
  });

  it('GIVEN GroupBalanceService WHEN accountType is CCA and data is valid then response 200', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend SDA
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_CreditCard_XML_200));
    const accounts = rqGetGroupBalanceRest_200_CCA.body as IAccountsInfoRestModel;
    const response = await GroupBalanceService.invokeGroupBalanceService(accounts.AccountsInfo, rq_Group_Rest_200);
    console.log(rquidTest, `[TEST CASE 1: GroupBalanceService retrieveCreditCardBalance - Response mock Success ] `, JSON.stringify({ 'RESPONSE': response }));
    expect(response.AccInfo[0].AcctBal[0].CurAmt.Amt).toEqual("2000000.00");
    expect(response.AccInfo[0].AcctBal[0].BalType).toEqual("Avail");
    expect(response).toEqual(expect.any(Object))
  });

  it('GIVEN GroupBalanceService WHEN accountType is CCA and data is valid then response 200', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend SDA
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Certificate_XML_200));
    const accounts = rqGetGroupBalanceRest_200_CDA.body as IAccountsInfoRestModel;
    const response = await GroupBalanceService.invokeGroupBalanceService(accounts.AccountsInfo, rq_Group_Rest_200);
    console.log(rquidTest, `[TEST CASE 1: GroupBalanceService retrieveCertificateBalance - Response mock Success ] `, JSON.stringify({ 'RESPONSE': response }));
    expect(response.AccInfo[0].ExtAcctBal[0].CurAmt.Amt).toEqual("0.00");
    expect(response.AccInfo[0].ExtAcctBal[0].ExtBalType).toEqual("Redemption");
    expect(response).toEqual(expect.any(Object))
  });

  it('GIVEN GroupBalanceService WHEN accountType is LOC and data is valid then response 200', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend SDA
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Loan_XML_200));
    const accounts = rqGetGroupBalanceRest_200_LOC.body as IAccountsInfoRestModel;
    const response = await GroupBalanceService.invokeGroupBalanceService(accounts.AccountsInfo, rq_Group_Rest_200);
    console.log(rquidTest, `[TEST CASE 1: GroupBalanceService retrieveLoanBalance - Response mock Success ] `, JSON.stringify({ 'RESPONSE': response }));
    expect(response.AccInfo[0].AcctBal[0].CurAmt.Amt).toEqual("6314284.00");
    expect(response.AccInfo[0].AcctBal[0].BalType).toEqual("PayoffAmt");
    expect(response).toEqual(expect.any(Object))
  });

  it('GIVEN GroupBalanceService WHEN accountType is TT and data is not valid then response 409', async () => {
    const accounts = rqGetGroupBalanceRest_200_TTT.body as IAccountsInfoRestModel;
    try {
      const response = await GroupBalanceService.invokeGroupBalanceService(accounts.AccountsInfo, rq_Group_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 2: GroupBalanceService retrieveExceptionBalance - Response mock  Error ] `, JSON.stringify({ 'RESPONSE': error }));
      expect(error.Status.StatusCode).toEqual(409);
    }
  });
  /*
  it('GIVEN GroupBalanceService WHEN accountType is CCA and data is not valid then response 409', async () => {
    const accounts = rqGetGroupBalanceRest_200_CCA.body as IAccountsInfoRestModel;
    try {
      const response = await GroupBalanceService.invokeGroupBalanceService(accounts.AccountsInfo, rq_Group_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 2: GroupBalanceService retrieveExceptionBalance - Response mock  Error ] `, JSON.stringify({ 'RESPONSE': error }));
      expect(error.Status.StatusCode).toEqual(409);
    }
  });

  it('GIVEN GroupBalanceService WHEN accountType is TT and data is not valid then response 409', async () => {
    const accounts = rqGetGroupBalanceRest_200_CDA.body as IAccountsInfoRestModel;
    try {
      const response = await GroupBalanceService.invokeGroupBalanceService(accounts.AccountsInfo, rq_Group_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 2: GroupBalanceService retrieveExceptionBalance - Response mock  Error ] `, JSON.stringify({ 'RESPONSE': error }));
      expect(error.Status.StatusCode).toEqual(409);
    }
  });

  it('GIVEN GroupBalanceService WHEN accountType is LOC and data is not valid then response 409', async () => {
    const accounts = rqGetGroupBalanceRest_200_LOC.body as IAccountsInfoRestModel;
    try {
      const response = await GroupBalanceService.invokeGroupBalanceService(accounts.AccountsInfo, rq_Group_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 2: GroupBalanceService retrieveExceptionBalance - Response mock  Error ] `, JSON.stringify({ 'RESPONSE': error }));
      expect(error.Status.StatusCode).toEqual(409);
    }
  });

*/
});
