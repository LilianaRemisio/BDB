import { describe, expect, it, jest, beforeEach, afterEach } from "@jest/globals";
import { OverdraftService } from "../../../src/service/overdraft/OverdraftService";
import sinon from "sinon";
import axios from 'axios';
import { reportService } from '../../../src/service/circuitbreaker/bdbCircuitBreaker';
import { rqGetRetrieveOverdraftRest_200, rq_RetrieveOverdraftParams, rs_Bck_Overdraft_XML_200, rs_Bck_Overdraft_200_BussinessError, rs_Bck_Overdraft_XML_500, rq_RetrieveOverdraftParams_without_optionals } from "../../mocks/retrieve-overdraft/mocks-service";

const acctId = '343434'
const rquidTest = '7118c962-bd3c-4388-bd1e-ae9b57bac687'

beforeEach(() => {
    // Stub the `onlyPublishInSns` method
    sinon.stub(reportService, 'onlyPublishInSns').resolves({ data: { "status": 'ok' }, status: 200 });
});

afterEach(() => {
    sinon.restore();
});


describe.only('OverdraftBalanceService.spec [ OverdraftBalanceService - invokeOverdraftService] async spec', () => {

    it('GIVEN OverdraftBalanceService WHEN data is valid THEN response 200', async () => {
        sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Overdraft_XML_200));
        const headers = rqGetRetrieveOverdraftRest_200.headers;
        const response = await OverdraftService.invokeOverdraftService(headers, rq_RetrieveOverdraftParams);
        console.log(rquidTest, `[TEST CASE 1: OverdraftBalanceService - Response mock Success ] `, JSON.stringify({ 'RESPONSE': response }));
        expect(response.AcctBalRec.AcctBasicInfo.AcctId).toEqual("343434");
        expect(response.AcctBalRec.AcctBal.EffDt).toEqual("2020-02-04");
        expect(response).toEqual(expect.any(Object))
    });

    it('GIVEN OverdraftBalanceService WHEN data is valid and headers without optionals THEN response 200', async () => {
        sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Overdraft_XML_200));
        const headers = rqGetRetrieveOverdraftRest_200.headers;
        const response = await OverdraftService.invokeOverdraftService(headers, rq_RetrieveOverdraftParams_without_optionals);
        console.log(rquidTest, `[TEST CASE 1: OverdraftBalanceService - Response mock Success ] `, JSON.stringify({ 'RESPONSE': response }));
        expect(response.AcctBalRec.AcctBasicInfo.AcctId).toEqual("343434");
        expect(response.AcctBalRec.AcctBasicInfo.AcctType).toEqual("DDA");
        expect(response.AcctBalRec.AcctBal.EffDt).toEqual("2020-02-04");
        expect(response).toEqual(expect.any(Object))
    });


    it('GIVEN OverdraftBalanceService WHEN data is valid THEN response 409', async () => {
        sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Overdraft_200_BussinessError));
        try {
            const headers = rqGetRetrieveOverdraftRest_200.headers;
            const response = await OverdraftService.invokeOverdraftService(headers, rq_RetrieveOverdraftParams);
        } catch (error: any) {
            console.log(rquidTest, `[TEST CASE 2: OverdraftBalanceService - Response mock Bussiness Error ] `, JSON.stringify({ 'RESPONSE': error }));
            expect(error.Status.StatusCode).toEqual(409);
        }
    });

    it('GIVEN OverdraftBalanceService WHEN data is valid and response is other operation response 500 not matchin response', async () => {
        sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Overdraft_XML_500));
        try {
            const headers = rqGetRetrieveOverdraftRest_200.headers;
            const response = await OverdraftService.invokeOverdraftService(headers, rq_RetrieveOverdraftParams);
            console.log('ohoh')
        } catch (error: any) {
            console.log(rquidTest, `[TEST CASE 2: OverdraftBalanceService - Response mock Bussiness Error ] `, JSON.stringify({ 'RESPONSE': error }));
            expect(error.Status.StatusCode).toEqual(500);
        }
    });

    it('GIVEN OverdraftBalanceService WHEN data is valid THEN response but backend give internal error', async () => {
        sinon.stub(axios, 'post').callsFake(() => {
            return Promise.reject({
                response: {
                    status: 500,
                    statusText: 'Internal Server Error',
                    data: {
                        error: 'Something went wrong on the server',
                        code: 'BACKEND_ERROR',
                    },
                },
                config: {}, // Configuración de la solicitud, opcional
                isAxiosError: true, // Indica que es un error de Axios
                toJSON: () => ({
                    message: 'Request failed with status code 500',
                    code: 'BACKEND_ERROR',
                }),
            });
        });

        try {
            const headers = rqGetRetrieveOverdraftRest_200.headers;
            const response = await OverdraftService.invokeOverdraftService(headers, rq_RetrieveOverdraftParams);
        } catch (error: any) {
            console.log(rquidTest, `[TEST CASE 3: OverdraftBalanceService - Response mock Internal Error: ${error.Status.StatusCode} ] `, JSON.stringify({ 'RESPONSE_ERROR': error }));
            expect(error.Status.StatusCode).toEqual(500);
        }
    });

    it('GIVEN OverdraftBalanceService WHEN data is valid THEN response but backend give Timeout error', async () => {
        // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False y genera Timeout interno
        // Simula un timeout en axios.post
        sinon.stub(axios, 'post').callsFake(() => {
            return Promise.reject({
                code: 'ECONNABORTED',
                message: 'timeout of 5000ms exceeded',
                config: {}, // Configuración de la solicitud, opcional
                isAxiosError: true, // Indica que es un error de Axios
                toJSON: () => ({
                    message: 'timeout of 5000ms exceeded',
                    code: 'ECONNABORTED',
                }),
            });
        });

        try {
            const headers = rqGetRetrieveOverdraftRest_200.headers;
            const response = await OverdraftService.invokeOverdraftService(headers, rq_RetrieveOverdraftParams);
        } catch (error: any) {
            console.log(rquidTest, `[TEST CASE 4: OverdraftBalanceService - Response mock Timeout Error: ${error.Status.StatusCode} ] `, JSON.stringify({ 'RESPONSE_ERROR': error }));
            expect(error.Status.StatusCode).toEqual(408);
        }
    });
});
