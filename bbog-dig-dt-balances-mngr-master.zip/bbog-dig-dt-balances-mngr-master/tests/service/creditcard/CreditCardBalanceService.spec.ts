import { describe, expect, it, jest, beforeEach, afterEach } from "@jest/globals";
import { CreditCardBalanceService } from '../../../src/service/creditcard/CreditCardBalanceService';
import sinon from "sinon";
import axios from 'axios';
import {reportService} from '../../../src/service/circuitbreaker/bdbCircuitBreaker';
import { rq_CreditCard_Rest_200, rs_Bck_CreditCard_XML_200, rs_Bck_CreditCard_XML_200_single, rs_Bck_CreditCard_XML_409, rs_Bck_CreditCard_XML_500 } from "../../mocks/balance-creditcard/mocks-service";

const acctId = '343434'
const rquidTest = '7118c962-bd3c-4388-bd1e-ae9b57bac687'

beforeEach(() => {
  // Stub the `onlyPublishInSns` method
  sinon.stub(reportService, 'onlyPublishInSns').resolves({data:{"status": 'ok'}, status:200});
});

afterEach(() => {
  sinon.restore();
});


describe('CreditCardBalanceService.spec [ CreditCardBalanceService - invokeCreditCardBalanceService] async spec', () => {

  it('GIVEN CreditCardBalanceService WHEN CircuitBreaker is FALSE and data is valid then response 200', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_CreditCard_XML_200));
    const response = await CreditCardBalanceService.invokeCreditCardBalanceService(acctId, rq_CreditCard_Rest_200);
    console.log(rquidTest, `[TEST CASE 1: CreditCardBalanceService retrieveDemandBalance - Response mock Success ] `, JSON.stringify({ 'RESPONSE': response }));
    expect(response.AccInfo[0].AcctBal[0].CurAmt.Amt).toEqual("2000000.00");
    expect(response.AccInfo[0].AcctBal[0].BalType).toEqual("Avail");
    expect(response).toEqual(expect.any(Object))
  });

  it('GIVEN CreditCardBalanceService WHEN CircuitBreaker is FALSE and data is valid then response 200 single acctball', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_CreditCard_XML_200_single));
    const response = await CreditCardBalanceService.invokeCreditCardBalanceService(acctId, rq_CreditCard_Rest_200);
    console.log(rquidTest, `[TEST CASE 1: CreditCardBalanceService retrieveDemandBalance - Response mock Success ] `, JSON.stringify({ 'RESPONSE': response }));
    expect(response).toEqual(expect.any(Object))
  });

  it('GIVEN CreditCardBalanceService WHEN CircuitBreaker is FALSE and data is valid then response 409', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_CreditCard_XML_409));
    try {
      const response = await CreditCardBalanceService.invokeCreditCardBalanceService(acctId, rq_CreditCard_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 2: CreditCardBalanceService retrieveDemandBalance - Response mock Bussiness Error ] `, JSON.stringify({ 'RESPONSE': error }));
      expect(error.Status.StatusCode).toEqual(409);
    }
  });

  it('GIVEN CreditCardBalanceService WHEN CircuitBreaker is FALSE and response is other operation response 500 not matchin response', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_CreditCard_XML_500));
    try {
      const response = await CreditCardBalanceService.invokeCreditCardBalanceService(acctId, rq_CreditCard_Rest_200);
      console.log('ohoh')
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 2: CreditCardBalanceService retrieveDemandBalance - Response mock Bussiness Error ] `, JSON.stringify({ 'RESPONSE': error }));
      expect(error.Status.StatusCode).toEqual(500);
    }
  });

  it('GIVEN CreditCardBalanceService WHEN CircuitBreaker is FALSE and data is valid then response but backend give internal error', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False y genera error interno
    sinon.stub(axios, 'post').callsFake(() => {
      return Promise.reject({
        response: {
          status: 500,
          statusText: 'Internal Server Error',
          data: {
            error: 'Something went wrong on the server',
            code: 'BACKEND_ERROR',
          },
        },
        config: {}, // Configuración de la solicitud, opcional
        isAxiosError: true, // Indica que es un error de Axios
        toJSON: () => ({
          message: 'Request failed with status code 500',
          code: 'BACKEND_ERROR',
        }),
      });
    });

    try {
      const response = await CreditCardBalanceService.invokeCreditCardBalanceService(acctId, rq_CreditCard_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 3: CreditCardBalanceService retrieveDemandBalance - Response mock Internal Error: ${error.Status.StatusCode} ] `, JSON.stringify({ 'RESPONSE_ERROR': error }));
      expect(error.Status.StatusCode).toEqual(500);
    }
  });

  it('GIVEN CreditCardBalanceService WHEN CircuitBreaker is FALSE and data is valid then response but backend give Timeout error', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False y genera Timeout interno
    // Simula un timeout en axios.post
    sinon.stub(axios, 'post').callsFake(() => {
      return Promise.reject({
        code: 'ECONNABORTED',
        message: 'timeout of 5000ms exceeded',
        config: {}, // Configuración de la solicitud, opcional
        isAxiosError: true, // Indica que es un error de Axios
        toJSON: () => ({
          message: 'timeout of 5000ms exceeded',
          code: 'ECONNABORTED',
        }),
      });
    });

    try {
      const response = await CreditCardBalanceService.invokeCreditCardBalanceService(acctId, rq_CreditCard_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 4: CreditCardBalanceService retrieveDemandBalance - Response mock Timeout Error: ${error.Status.StatusCode} ] `, JSON.stringify({ 'RESPONSE_ERROR': error }));
      expect(error.Status.StatusCode).toEqual(408);
    }
  });

});
