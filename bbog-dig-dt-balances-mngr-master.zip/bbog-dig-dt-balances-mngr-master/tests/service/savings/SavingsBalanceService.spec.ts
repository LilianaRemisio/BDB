import { describe, expect, it, jest, beforeEach, afterEach } from "@jest/globals";
import { SavingsBalanceService } from '../../../src/service/savings/SavingsBalanceService';
import sinon from "sinon";
import axios from 'axios';
import { rq_Savings_Rest_200, rq_Savings_Rest_200_Without_NetWorkOwner, rs_Bck_Savings_REST_200, rs_Bck_Savings_REST_409, rs_Bck_Savings_XML_200, rs_Bck_Savings_XML_200_single, rs_Bck_Savings_XML_409, rs_Bck_Savings_XML_500 } from "../../mocks/balance-savings/mocks-service";
import config from '../../../src/config';
import BdbCircuitBreaker from '../../../src/service/circuitbreaker/bdbCircuitBreaker';
import {reportService} from '../../../src/service/circuitbreaker/bdbCircuitBreaker';

const acctId = '343434'
const rquidTest = '7118c962-bd3c-4388-bd1e-ae9b57bac687'

beforeEach(() => {
  // Stub the `onlyPublishInSns` method
  sinon.stub(reportService, 'onlyPublishInSnsCircuitBreakerEvent').resolves();
  config.USE_CIRCUIT_BREAKER_SAVINGS = 'false';
});

afterEach(() => {
  sinon.restore();
  config.USE_CIRCUIT_BREAKER_SAVINGS = 'true'; // Restaurar el valor original si es necesario
});


describe('SavingsBalanceService.spec [ SavingsBalanceService - invokeSavingBalanceService CIRCUIT BREAKER OFF] async spec', () => {

  it('GIVEN SavingsBalanceService WHEN CircuitBreaker is FALSE and data is valid then response 200', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Savings_XML_200));
    const response = await SavingsBalanceService.invokeSavingBalanceService(acctId, rq_Savings_Rest_200);
    console.log(rquidTest, `[TEST CASE 1: SavingsBalanceService retrieveSavingBalance - Response mock Success ] `, JSON.stringify({ 'RESPONSE': response }));

    expect(response.AccInfo[0].AcctBal[0].CurAmt.Amt).toEqual("18499647.00");
    expect(response.AccInfo[0].AcctBal[0].BalType).toEqual("Current");
    expect(response).toEqual(expect.any(Object))
  });

  it('GIVEN SavingsBalanceService WHEN CircuitBreaker is FALSE and data is valid then response 200 single acctball', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Savings_XML_200_single));
    const response = await SavingsBalanceService.invokeSavingBalanceService(acctId, rq_Savings_Rest_200_Without_NetWorkOwner);
    console.log(rquidTest, `[TEST CASE 1: SavingsBalanceService retrieveSavingBalance - Response mock Success ] `, JSON.stringify({ 'RESPONSE': response }));
    expect(response).toEqual(expect.any(Object))
  });

  it('GIVEN SavingsBalanceService WHEN CircuitBreaker is FALSE and data is valid then response 409', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Savings_XML_409));
    try {
      const response = await SavingsBalanceService.invokeSavingBalanceService(acctId, rq_Savings_Rest_200);
      console.log('ohoh')
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 2: SavingsBalanceService retrieveSavingBalance - Response mock Bussiness Error ] `, JSON.stringify({ 'RESPONSE': error }));
      expect(error.Status.StatusCode).toEqual(409);
    }
  });

  it('GIVEN SavingsBalanceService WHEN CircuitBreaker is FALSE and response is other operation response 500 not matchin response', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Savings_XML_500));
    try {
      const response = await SavingsBalanceService.invokeSavingBalanceService(acctId, rq_Savings_Rest_200);
      console.log('ohoh')
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 2: SavingsBalanceService retrieveSavingBalance - Response mock Bussiness Error ] `, JSON.stringify({ 'RESPONSE': error }));
      expect(error.Status.StatusCode).toEqual(500);
    }
  });


  it('GIVEN SavingsBalanceService WHEN CircuitBreaker is FALSE and data is valid then response but backend give internal error', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False y genera error interno
    sinon.stub(axios, 'post').callsFake(() => {
      return Promise.reject({
        response: {
          status: 500,
          statusText: 'Internal Server Error',
          data: {
            error: 'Something went wrong on the server',
            code: 'BACKEND_ERROR',
          },
        },
        config: {}, // Configuración de la solicitud, opcional
        isAxiosError: true, // Indica que es un error de Axios
        toJSON: () => ({
          message: 'Request failed with status code 500',
          code: 'BACKEND_ERROR',
        }),
      });
    });

    try {
      const response = await SavingsBalanceService.invokeSavingBalanceService(acctId, rq_Savings_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 3: SavingsBalanceService retrieveSavingBalance - Response mock Internal Error: ${error.Status.StatusCode} ] `, JSON.stringify({ 'RESPONSE_ERROR': error }));
      expect(error.Status.StatusCode).toEqual(500);
    }
  });

  it('GIVEN SavingsBalanceService WHEN CircuitBreaker is FALSE and data is valid then response but backend give Timeout error', async () => {
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en False y genera Timeout interno
    // Simula un timeout en axios.post
    sinon.stub(axios, 'post').callsFake(() => {
      return Promise.reject({
        code: 'ECONNABORTED',
        message: 'timeout of 5000ms exceeded',
        config: {}, // Configuración de la solicitud, opcional
        isAxiosError: true, // Indica que es un error de Axios
        toJSON: () => ({
          message: 'timeout of 5000ms exceeded',
          code: 'ECONNABORTED',
        }),
      });
    });

    try {
      const response = await SavingsBalanceService.invokeSavingBalanceService(acctId, rq_Savings_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 4: SavingsBalanceService retrieveSavingBalance - Response mock Timeout Error: ${error.Status.StatusCode} ] `, JSON.stringify({ 'RESPONSE_ERROR': error }));
      expect(error.Status.StatusCode).toEqual(408);
    }
  });
});


describe('SavingsBalanceService.spec [ SavingsBalanceService - invokeSavingBalanceService CIRCUIT BREAKER ON - CLOSE] async spec', () => {
  it('GIVEN SavingsBalanceService WHEN CircuitBreaker is ON and data is valid then response 200', async () => {
    console.log(rquidTest, `[TEST CASE 5: SavingsBalanceService retrieveSavingBalance useCircuitBreaker = TRUE y  principalServiceUsed = TRUE ]`);
    config.USE_CIRCUIT_BREAKER_SAVINGS = 'true';

    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en ON
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Savings_XML_200));
    const response = await SavingsBalanceService.invokeSavingBalanceService(acctId, rq_Savings_Rest_200);
    console.log(rquidTest, `[TEST CASE 5: SavingsBalanceService retrieveSavingBalance - Response mock Success ] `, JSON.stringify({ 'RESPONSE': response }));

    expect(response.AccInfo[0].AcctBal[0].CurAmt.Amt).toEqual("18499647.00");
    expect(response.AccInfo[0].AcctBal[0].BalType).toEqual("Current");
    expect(response).toEqual(expect.any(Object))
  });

  it('GIVEN SavingsBalanceService WHEN CircuitBreaker is ON and data is valid then response 409', async () => {
    console.log(rquidTest, `[TEST CASE 6: SavingsBalanceService retrieveSavingBalance useCircuitBreaker = TRUE y  principalServiceUsed = TRUE ]`);
    config.USE_CIRCUIT_BREAKER_SAVINGS = 'true';
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en ON
    sinon.stub(axios, 'post').returns(Promise.resolve(rs_Bck_Savings_XML_409));
    try {
      const response = await SavingsBalanceService.invokeSavingBalanceService(acctId, rq_Savings_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 6: SavingsBalanceService retrieveSavingBalance - Response mock Bussiness Error ] `, JSON.stringify({ 'RESPONSE': error }));
      expect(error.Status.StatusCode).toEqual(409);
    }
  });

  it('GIVEN SavingsBalanceService WHEN CircuitBreaker is ON and data is valid then response but backend give internal error 500', async () => {
    console.log(rquidTest, `[TEST CASE 7: SavingsBalanceService retrieveSavingBalance useCircuitBreaker = TRUE y  principalServiceUsed = TRUE ]`);
    config.USE_CIRCUIT_BREAKER_SAVINGS = 'true';
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en ON y genera error interno
    sinon.stub(axios, 'post').callsFake(() => {
      return Promise.reject({
        response: {
          status: 500,
          statusText: 'Internal Server Error',
          data: {
            error: 'Something went wrong on the server',
            code: 'BACKEND_ERROR',
          },
        },
        config: {}, // Configuración de la solicitud, opcional
        isAxiosError: true, // Indica que es un error de Axios
        toJSON: () => ({
          message: 'Request failed with status code 500',
          code: 'BACKEND_ERROR',
        }),
      });
    });

    try {
      const response = await SavingsBalanceService.invokeSavingBalanceService(acctId, rq_Savings_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 7: SavingsBalanceService retrieveSavingBalance - Response mock Internal Error: ${error.Status.StatusCode} ] `, JSON.stringify({ 'RESPONSE_ERROR': error }));
      expect(error.Status.StatusCode).toEqual(500);
    }
  });

  it('GIVEN SavingsBalanceService WHEN CircuitBreaker is ON and data is valid then response but backend give Timeout error 408', async () => {
    config.USE_CIRCUIT_BREAKER_SAVINGS = 'true';
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en ON y genera Timeout interno
    sinon.stub(axios, 'post').callsFake(() => {
      return Promise.reject({
        code: 'ECONNABORTED',
        message: 'timeout of 5000ms exceeded',
        config: {}, // Configuración de la solicitud, opcional
        isAxiosError: true, // Indica que es un error de Axios
        toJSON: () => ({
          message: 'timeout of 5000ms exceeded',
          code: 'ECONNABORTED',
        }),
      });
    });

    try {
      console.log(rquidTest, `[TEST CASE 8: SavingsBalanceService retrieveSavingBalance useCircuitBreaker = TRUE y  principalServiceUsed = TRUE ]`);
      const response = await SavingsBalanceService.invokeSavingBalanceService(acctId, rq_Savings_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 8: SavingsBalanceService retrieveSavingBalance - Response mock Timeout Error: ${error.Status.StatusCode} ] `, JSON.stringify({ 'RESPONSE_ERROR': error }));
      expect(error.Status.StatusCode).toEqual(408);
    }
  });
});


describe('SavingsBalanceService.spec [ SavingsBalanceService - invokeSavingBalanceService CIRCUIT BREAKER ON - OPEN] async spec', () => {
  it('GIVEN SavingsBalanceService WHEN CircuitBreaker is ON and data is valid then response 200', async () => {
    console.log(rquidTest, `[TEST CASE 5: SavingsBalanceService retrieveSavingBalance useCircuitBreaker = TRUE y  principalServiceUsed = FALSE ]`);
    config.USE_CIRCUIT_BREAKER_SAVINGS = 'true';

    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en ON
    sinon.stub(BdbCircuitBreaker.prototype, 'execute').returns(Promise.resolve(rs_Bck_Savings_REST_200));
    const response = await SavingsBalanceService.invokeSavingBalanceService(acctId, rq_Savings_Rest_200);
    console.log(rquidTest, `[TEST CASE 5: SavingsBalanceService retrieveSavingBalance - Response mock Success ] `, JSON.stringify({ 'RESPONSE': response }));

    expect(response.AccInfo[0].AcctBal[0].CurAmt.Amt).toEqual("2.00");
    expect(response.AccInfo[0].AcctBal[0].BalType).toEqual("Avail");
    expect(response).toEqual(expect.any(Object))
  });

  it('GIVEN SavingsBalanceService WHEN CircuitBreaker is ON and data is valid then response 409', async () => {
    console.log(rquidTest, `[TEST CASE 5: SavingsBalanceService retrieveSavingBalance useCircuitBreaker = TRUE y  principalServiceUsed = FALSE ]`);
    config.USE_CIRCUIT_BREAKER_SAVINGS = 'true';

    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en ON
    sinon.stub(BdbCircuitBreaker.prototype, 'execute').returns(Promise.resolve(rs_Bck_Savings_REST_409));

    try {
      const response = await SavingsBalanceService.invokeSavingBalanceService(acctId, rq_Savings_Rest_200);

    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 5: SavingsBalanceService retrieveSavingBalance - Response mock Success ] `, JSON.stringify({ 'ERROR RESPONSE': error }));
      expect(error.Status.StatusCode).toEqual(409);
      expect(error).toEqual(expect.any(Object))
    }
  });



  it('GIVEN SavingsBalanceService WHEN CircuitBreaker is ON and data is valid then response but backend give internal error', async () => {
    console.log(rquidTest, `[TEST CASE 7: SavingsBalanceService retrieveSavingBalance useCircuitBreaker = TRUE y  principalServiceUsed = FALSE ]`);
    config.USE_CIRCUIT_BREAKER_SAVINGS = 'true';
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en ON y genera error interno
    sinon.stub(BdbCircuitBreaker.prototype, 'execute').callsFake(() => {
      return Promise.reject({
        response: {
          status: 500,
          statusText: 'Internal Server Error',
          data: {
            error: 'Something went wrong on the server',
            code: 'BACKEND_ERROR',
          },
        },
        config: {}, // Configuración de la solicitud, opcional
        isAxiosError: true, // Indica que es un error de Axios
        toJSON: () => ({
          message: 'Request failed with status code 500',
          code: 'BACKEND_ERROR',
        }),
      });
    });

    try {
      const response = await SavingsBalanceService.invokeSavingBalanceService(acctId, rq_Savings_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 7: SavingsBalanceService retrieveSavingBalance - Response mock Internal Error: ${error.Status.StatusCode} ] `, JSON.stringify({ 'RESPONSE_ERROR': error }));
      expect(error.Status.StatusCode).toEqual(500);
    }
  });

  it('GIVEN SavingsBalanceService WHEN CircuitBreaker is ON and data is valid then response but backend give Timeout error', async () => {
    config.USE_CIRCUIT_BREAKER_SAVINGS = 'true';
    // Mock de la clase axios para cuando se realiza invocacion backend con circuitbreaker en ON y genera Timeout interno
    sinon.stub(BdbCircuitBreaker.prototype, 'execute').callsFake(() => {
      return Promise.reject({
        code: 'ECONNABORTED',
        message: 'timeout of 5000ms exceeded',
        config: {}, // Configuración de la solicitud, opcional
        isAxiosError: true, // Indica que es un error de Axios
        toJSON: () => ({
          message: 'timeout of 5000ms exceeded',
          code: 'ECONNABORTED',
        }),
      });
    });

    try {
      console.log(rquidTest, `[TEST CASE 8: SavingsBalanceService retrieveSavingBalance useCircuitBreaker = TRUE y  principalServiceUsed = FALSE ]`);
      const response = await SavingsBalanceService.invokeSavingBalanceService(acctId, rq_Savings_Rest_200);
    } catch (error: any) {
      console.log(rquidTest, `[TEST CASE 8: SavingsBalanceService retrieveSavingBalance - Response mock Timeout Error: ${error.Status.StatusCode} ] `, JSON.stringify({ 'RESPONSE_ERROR': error }));
      expect(error.Status.StatusCode).toEqual(408);
    }
  });
});