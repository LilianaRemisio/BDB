import { describe, expect, it } from "@jest/globals";
import request from 'supertest';

const app = require('../../src/app').default;
const rquidTest = '7118c962-bd3c-4388-bd1e-ae9b57bac687'

describe('IndexController.spec [ Index Controller - lealth] async spec', () => {
    it('GIVEN GET /healt WHEN request valid THEN response 200', async () => {
        console.log(rquidTest, '[TEST CASE 1: COntroller IndexController - Succes]');
        const response: any = await request(app)
            .get(`/health`)
        console.log(rquidTest, `[TEST CASE 1: COntroller IndexController - Response mock Success ${response.statusCode} ] `, response.text);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /balancesManagement/env-vars WHEN request valid THEN response 200', async () => {
        console.log(rquidTest, '[TEST CASE 1: COntroller balancesManagement/env-vars - Succes]');
        const response: any = await request(app)
            .get(`/balancesManagement/env-vars`)
        console.log(rquidTest, `[TEST CASE 1: COntroller balancesManagement/env-vars - Response mock Success ${response.statusCode} ] `, JSON.stringify({ 'Environment': response.body }));
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN POST /balancesManagement/env-vars WHEN request valid THEN response 200', async () => {
        const headers = {
            UseCircuitBreaker: 'false',
            PrincipalEndpointSavings: 'http://localhost:3090/accounts/product/SavingsBalancesInquiry',
            ContingencyEndpointSavings: 'http://localhost:5701/ods/ods_stag/pr_ws_consul_ah'
        }
        console.log(rquidTest, '[TEST CASE 1: COntroller balancesManagement/env-vars - Succes]');
        const response: any = await request(app)
            .post(`/balancesManagement/env-vars`)
            .set(headers)
        console.log(rquidTest, `[TEST CASE 1: COntroller balancesManagement/env-vars - Response mock Success ${response.statusCode} ] `, JSON.stringify({ 'Environment': response.body }));
        expect(response.body).toEqual(expect.any(Object))
    });
});