import { describe, expect, it, jest } from "@jest/globals";
import request from 'supertest';
import { SavingsBalanceService } from '../../src/service/savings/SavingsBalanceService';
import { rqGetSavingsBalanceRest_200, rqGetSavingsBalanceRest_400, rqGetSavingsBalanceRest_409, rsGetSavingsBalanceRest_200, rsGetSavingsBalanceRest_408, rsGetSavingsBalanceRest_409, rsGetSavingsBalanceRest_500, rsGetSavingsBalanceRest_500_1 } from "../mocks/balance-savings/mocks-service";
import { DemandBalanceService } from "../../src/service/demands/DemandBalanceService";
import { rqGetDemandBalanceRest_200, rqGetDemandBalanceRest_400, rqGetDemandBalanceRest_409, rsGetDemandBalanceRest_200, rsGetDemandBalanceRest_408, rsGetDemandBalanceRest_409, rsGetDemandBalanceRest_500, rsGetDemandBalanceRest_500_1 } from "../mocks/balance-demands/mocks-service";
import { TrustBalanceService } from "../../src/service/trust/TrustBalanceService";
import { rqGetTrustBalanceRest_200, rqGetTrustBalanceRest_400, rqGetTrustBalanceRest_409, rsGetTrustBalanceRest_200, rsGetTrustBalanceRest_408, rsGetTrustBalanceRest_409, rsGetTrustBalanceRest_500, rsGetTrustBalanceRest_500_1 } from "../mocks/balance-trust/mocks-service";
import { CreditCardBalanceService } from "../../src/service/creditcard/CreditCardBalanceService";
import { rsGetCreditCardBalanceRest_500, rsGetCreditCardBalanceRest_500_1, rqGetCreditCardBalanceRest_200, rqGetCreditCardBalanceRest_400, rqGetCreditCardBalanceRest_409, rsGetCreditCardBalanceRest_200, rsGetCreditCardBalanceRest_408, rsGetCreditCardBalanceRest_409 } from "../mocks/balance-creditcard/mocks-service";
import { GroupBalanceService } from "../../src/service/group/GroupBalanceService";
import { rqGetGroupBalanceRest_200, rsGetGroupBalanceRest_200, rsGetGroupBalanceRest_500 } from "../mocks/balance-group/mocks-service";
import { CertificateBalanceService } from "../../src/service/certificate/CertificateBalanceService";
import { rqGetCertificateBalanceRest_200, rqGetCertificateBalanceRest_400, rqGetCertificateBalanceRest_409, rsGetCertificateBalanceRest_200, rsGetCertificateBalanceRest_408, rsGetCertificateBalanceRest_409, rsGetCertificateBalanceRest_500, rsGetCertificateBalanceRest_500_1 } from "../mocks/balance-certificate/mocks-service";
import { rqGetLoanBalanceRest_200, rqGetLoanBalanceRest_400, rqGetLoanBalanceRest_409, rsGetLoanBalanceRest_200, rsGetLoanBalanceRest_408, rsGetLoanBalanceRest_409, rsGetLoanBalanceRest_500, rsGetLoanBalanceRest_500_1 } from "../mocks/balance-loan/mocks-service";
import { LoanBalanceService } from "../../src/service/loan/LoanBalanceService";
import { rqGetDetailCreditInfoRest_200, rqGetDetailCreditInfoRest_400, rqGetDetailCreditInfoRest_409, rsGetDetailCreditInfoRest_200, rsGetDetailCreditInfoRest_408, rsGetDetailCreditInfoRest_409, rsGetDetailCreditInfoRest_500, rsGetDetailCreditInfoRest_500_1 } from "../mocks/detail-credit/mocks-service";
import { ProductInquiryService } from "../../src/service/product/ProductInquiryService";
import { LoanQuotaService } from "../../src/service/loanquota/LoanQuotaService";
import { rqGetLoanQuotaBalanceRest_200, rqGetLoanQuotaBalanceRest_400, rqGetLoanQuotaBalanceRest_409, rsGetLoanQuotaBalanceRest_200, rsGetLoanQuotaBalanceRest_408, rsGetLoanQuotaBalanceRest_409, rsGetLoanQuotaBalanceRest_500, rsGetLoanQuotaBalanceRest_500_1 } from "../mocks/loan-quota/mocks-service";
import { OverdraftService } from "../../src/service/overdraft/OverdraftService";
import { rsGetRetrieveOverdraftRest_200, rqGetRetrieveOverdraftRest_200, rqGetRetrieveOverdraftRest_400, rsGetRetrieveOverdraftRest_409, rsGetRetrieveOverdraftRest_408, rsGetRetrieveOverdraftRest_500, rsGetRetrieveOverdraftRest_500_1 } from "../mocks/retrieve-overdraft/mocks-service";

const app = require('../../src/app').default;
const rquidTest = '7118c962-bd3c-4388-bd1e-ae9b57bac687'
const acctId = '343434'
const FULL_URL = `/V2/Enterprise/BalanceManagement/${acctId}/retrieveSavingBalance`;
const FULL_URL_DEMAND = `/V2/Enterprise/BalanceManagement/${acctId}/retrieveDemandBalance`;

describe('BalancesController.spec [ Balances Controller - retrieveSavingBalance] async spec', () => {
    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveSavingBalance WHEN request valid THEN response 200', async () => {
        mockService(SavingsBalanceService, 'invokeSavingBalanceService', true, rsGetSavingsBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveSavingBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveSavingBalance`)
            .set(rqGetSavingsBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveSavingBalance - Response mock Success ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(200);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveSavingBalance WHEN request valid and header invalid THEN response 400', async () => {
        mockService(SavingsBalanceService, 'invokeSavingBalanceService', true, rsGetSavingsBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveSavingBalance - Response mock BadRequest]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveSavingBalance`)
            .set(rqGetSavingsBalanceRest_400.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveSavingBalance - Response mock BadRequest ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(400);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveSavingBalance WHEN request valid and invalid url THEN response 404', async () => {
        mockService(SavingsBalanceService, 'invokeSavingBalanceService', true, rsGetSavingsBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveSavingBalance - Response mock not found]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveSavingBalance-fail`)
            .set(rqGetSavingsBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveSavingBalance - Response mock not found ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(404);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveSavingBalance WHEN request is valid but account doesnot exist THEN response 409', async () => {
        mockService(SavingsBalanceService, 'invokeSavingBalanceService', false, rsGetSavingsBalanceRest_409);
        console.log(rquidTest, '[TEST CASE 3: COntroller retrieveSavingBalance - Succes]');
        const response: any = await request(app)
            .get(FULL_URL)
            .query({ acctId })
            .set(rqGetSavingsBalanceRest_409.headers)
        console.log(rquidTest, `[TEST CASE 3: COntroller retrieveSavingBalance - Response mock Bussiness Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(409);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveSavingBalance WHEN request is valid but service give timeout THEN response 408', async () => {
        mockService(SavingsBalanceService, 'invokeSavingBalanceService', false, rsGetSavingsBalanceRest_408);
        console.log(rquidTest, '[TEST CASE 4: COntroller retrieveSavingBalance - Succes]');
        const response: any = await request(app)
            .get(FULL_URL)
            .query({ acctId })
            .set(rqGetSavingsBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 4: C0ntroller retrieveSavingBalance - Response mock Timeout Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(408);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveSavingBalance WHEN request is valid but service fail THEN response 500', async () => {
        mockService(SavingsBalanceService, 'invokeSavingBalanceService', false, rsGetSavingsBalanceRest_500);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveSavingBalance - Succes]');
        const response: any = await request(app)
            .get(FULL_URL)
            .query({ acctId })
            .set(rqGetSavingsBalanceRest_200.headers)
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveSavingBalance - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveSavingBalance WHEN request is valid but service fail THEN response 500', async () => {
        mockService(SavingsBalanceService, 'invokeSavingBalanceService', false, rsGetSavingsBalanceRest_500_1);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveSavingBalance - Succes]');
        const response: any = await request(app)
            .get(FULL_URL)
            .query({ acctId })
            .set(rqGetSavingsBalanceRest_200.headers)
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveSavingBalance - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });
});

describe('BalancesController.spec [ Balances Controller - retrieveDemandBalance] async spec', () => {
    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveDemandBalance WHEN request valid THEN response 200', async () => {
        mockService(DemandBalanceService, 'invokeDemandBalanceService', true, rsGetDemandBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveDemandBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveDemandBalance`)
            .set(rqGetDemandBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveDemandBalance - Response mock Success ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(200);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveDemandBalance WHEN request valid and header invalid THEN response 400', async () => {
        mockService(DemandBalanceService, 'invokeDemandBalanceService', true, rsGetDemandBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveDemandBalance - Response mock BadRequest]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveDemandBalance`)
            .set(rqGetDemandBalanceRest_400.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveDemandBalance - Response mock BadRequest ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(400);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveDemandBalance WHEN request valid and invalid url THEN response 404', async () => {
        mockService(DemandBalanceService, 'invokeDemandBalanceService', true, rsGetDemandBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveDemandBalance - Response mock not found]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveDemandBalance-fail`)
            .set(rqGetDemandBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveDemandBalance - Response mock not found ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(404);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveDemandBalance WHEN request is valid but account doesnot exist THEN response 409', async () => {
        mockService(DemandBalanceService, 'invokeDemandBalanceService', false, rsGetDemandBalanceRest_409);
        console.log(rquidTest, '[TEST CASE 3: COntroller retrieveDemandBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveDemandBalance`)
            .query({ acctId })
            .set(rqGetDemandBalanceRest_409.headers)
        console.log(rquidTest, `[TEST CASE 3: COntroller retrieveDemandBalance - Response mock Bussiness Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(409);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveDemandBalance WHEN request is valid but service give timeout THEN response 408', async () => {
        mockService(DemandBalanceService, 'invokeDemandBalanceService', false, rsGetDemandBalanceRest_408);
        console.log(rquidTest, '[TEST CASE 4: COntroller retrieveDemandBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveDemandBalance`)
            .query({ acctId })
            .set(rqGetDemandBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 4: C0ntroller retrieveDemandBalance - Response mock Timeout Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(408);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveDemandBalance WHEN request is valid but service fail THEN response 500', async () => {
        mockService(DemandBalanceService, 'invokeDemandBalanceService', false, rsGetDemandBalanceRest_500);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveDemandBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveDemandBalance`)
            .query({ acctId })
            .set(rqGetDemandBalanceRest_200.headers)
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveDemandBalance - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveDemandBalance WHEN request is valid but service fail THEN response 500', async () => {
        mockService(DemandBalanceService, 'invokeDemandBalanceService', false, rsGetDemandBalanceRest_500_1);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveDemandBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveDemandBalance`)
            .query({ acctId })
            .set(rqGetDemandBalanceRest_200.headers)
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveDemandBalance - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });


});

describe('BalancesController.spec [ Balances Controller - retrieveTrustBalance] async spec', () => {
    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveTrustBalance WHEN request valid THEN response 200', async () => {
        mockService(TrustBalanceService, 'invokeTrustBalanceService', true, rsGetTrustBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveTrustBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveTrustBalance?branchId=0890&acctType=FDA&acctSubType=109FB`)
            .set(rqGetTrustBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveTrustBalance - Response mock Success ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(200);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveTrustBalance WHEN request valid and header invalid THEN response 400', async () => {
        mockService(TrustBalanceService, 'invokeTrustBalanceService', true, rsGetTrustBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveTrustBalance - Response mock BadRequest]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveTrustBalance?branchId=0890&acctType=FDA&acctSubType=109FB`)
            .set(rqGetTrustBalanceRest_400.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveTrustBalance - Response mock BadRequest ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(400);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveTrustBalance WHEN request valid and invalid url THEN response 404', async () => {
        mockService(TrustBalanceService, 'invokeTrustBalanceService', true, rsGetTrustBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveTrustBalance - Response mock not found]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveTrustBalance1?branchId=0890&acctType=FDA&acctSubType=109FB`)
            .set(rqGetTrustBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveTrustBalance - Response mock not found ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(404);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveTrustBalance WHEN request is valid but account doesnot exist THEN response 409', async () => {
        mockService(TrustBalanceService, 'invokeTrustBalanceService', false, rsGetTrustBalanceRest_409);
        console.log(rquidTest, '[TEST CASE 3: COntroller retrieveTrustBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveTrustBalance?branchId=0890&acctType=FDA&acctSubType=109FB`)
            .query({ acctId })
            .set(rqGetTrustBalanceRest_409.headers)
        console.log(rquidTest, `[TEST CASE 3: COntroller retrieveTrustBalance - Response mock Bussiness Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(409);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveTrustBalance WHEN request is valid but service give timeout THEN response 408', async () => {
        mockService(TrustBalanceService, 'invokeTrustBalanceService', false, rsGetTrustBalanceRest_408);
        console.log(rquidTest, '[TEST CASE 4: COntroller retrieveTrustBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveTrustBalance?branchId=0890&acctType=FDA&acctSubType=109FB`)
            .query({ acctId })
            .set(rqGetTrustBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 4: C0ntroller retrieveTrustBalance - Response mock Timeout Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(408);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveTrustBalance WHEN request is valid but service fail THEN response 500', async () => {
        mockService(TrustBalanceService, 'invokeTrustBalanceService', false, rsGetTrustBalanceRest_500);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveTrustBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveTrustBalance?branchId=0890&acctType=FDA&acctSubType=109FB`)
            .query({ acctId })
            .set(rqGetTrustBalanceRest_200.headers)
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveTrustBalance - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveTrustBalance WHEN request is valid but service fail THEN response 500', async () => {
        mockService(TrustBalanceService, 'invokeTrustBalanceService', false, rsGetTrustBalanceRest_500_1);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveTrustBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveTrustBalance?branchId=0890&acctType=FDA&acctSubType=109FB`)
            .query({ acctId })
            .set(rqGetTrustBalanceRest_200.headers)
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveTrustBalance - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });
});

describe('BalancesController.spec [ Balances Controller - retrieveCreditCardBalance] async spec', () => {
    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveCreditCardBalance WHEN request valid THEN response 200', async () => {
        mockService(CreditCardBalanceService, 'invokeCreditCardBalanceService', true, rsGetCreditCardBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveCreditCardBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveCreditCardBalance`)
            .set(rqGetCreditCardBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveCreditCardBalance - Response mock Success ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(200);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveCreditCardBalance WHEN request valid and header invalid THEN response 400', async () => {
        mockService(CreditCardBalanceService, 'invokeCreditCardBalanceService', true, rsGetCreditCardBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveCreditCardBalance - Response mock BadRequest]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveCreditCardBalance`)
            .set(rqGetCreditCardBalanceRest_400.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveCreditCardBalance - Response mock BadRequest ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(400);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveCreditCardBalance WHEN request valid and invalid url THEN response 404', async () => {
        mockService(CreditCardBalanceService, 'invokeCreditCardBalanceService', true, rsGetCreditCardBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveCreditCardBalance - Response mock not found]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveCreditCardBalance1`)
            .set(rqGetCreditCardBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveCreditCardBalance - Response mock not found ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(404);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveCreditCardBalance WHEN request is valid but account doesnot exist THEN response 409', async () => {
        mockService(CreditCardBalanceService, 'invokeCreditCardBalanceService', false, rsGetCreditCardBalanceRest_409);
        console.log(rquidTest, '[TEST CASE 3: COntroller retrieveCreditCardBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveCreditCardBalance`)
            .query({ acctId })
            .set(rqGetCreditCardBalanceRest_409.headers)
        console.log(rquidTest, `[TEST CASE 3: COntroller retrieveCreditCardBalance - Response mock Bussiness Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(409);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveCreditCardBalance WHEN request is valid but service give timeout THEN response 408', async () => {
        mockService(CreditCardBalanceService, 'invokeCreditCardBalanceService', false, rsGetCreditCardBalanceRest_408);
        console.log(rquidTest, '[TEST CASE 4: COntroller retrieveCreditCardBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveCreditCardBalance`)
            .query({ acctId })
            .set(rqGetCreditCardBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 4: C0ntroller retrieveCreditCardBalance - Response mock Timeout Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(408);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveCreditCardBalance WHEN request is valid but service fail THEN response 500', async () => {
        mockService(CreditCardBalanceService, 'invokeCreditCardBalanceService', false, rsGetCreditCardBalanceRest_500);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveCreditCardBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveCreditCardBalance`)
            .query({ acctId })
            .set(rqGetCreditCardBalanceRest_200.headers)
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveCreditCardBalance - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveCreditCardBalance WHEN request is valid but service fail THEN response 500', async () => {
        mockService(CreditCardBalanceService, 'invokeCreditCardBalanceService', false, rsGetCreditCardBalanceRest_500_1);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveCreditCardBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveCreditCardBalance`)
            .query({ acctId })
            .set(rqGetCreditCardBalanceRest_200.headers)
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveCreditCardBalance - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });
});

describe('BalancesController.spec [ Balances Controller - retrieveGroupBalance] async spec', () => {
    it('GIVEN GET /V2/Enterprise/BalanceManagement/retrieveGroupBalance WHEN request valid THEN response 200', async () => {
        mockService(GroupBalanceService, 'invokeGroupBalanceService', true, rsGetGroupBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveGroupBalance - Succes]');
        const response: any = await request(app)
            .post(`/V2/Enterprise/BalanceManagement/retrieveGroupBalances`)
            .set(rqGetGroupBalanceRest_200.headers)
            .send(rqGetGroupBalanceRest_200.body);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveGroupBalance - Response mock Success ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(200);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/retrieveGroupBalance WHEN request is valid but service fail THEN response 500', async () => {
        mockService(GroupBalanceService, 'invokeGroupBalanceService', false, rsGetGroupBalanceRest_500);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveGroupBalance - Succes]');
        const response: any = await request(app)
            .post(`/V2/Enterprise/BalanceManagement/retrieveGroupBalances`)
            .set(rqGetGroupBalanceRest_200.headers)
            .send(rqGetGroupBalanceRest_200.body);
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveGroupBalance - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });
});


describe('BalancesController.spec [ Balances Controller - retrieveCertificateBalance] async spec', () => {
    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveCertificateBalance WHEN request valid THEN response 200', async () => {
        mockService(CertificateBalanceService, 'invokeCertificateBalanceService', true, rsGetCertificateBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveCertificateBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveCertificateBalance`)
            .set(rqGetCertificateBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveCertificateBalance - Response mock Success ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(200);
        expect(response.body).toEqual(expect.any(Object))
    });
    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveCertificateBalance WHEN request valid and header invalid THEN response 400', async () => {
        mockService(CertificateBalanceService, 'invokeCertificateBalanceService', true, rsGetCertificateBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveCertificateBalance - Response mock BadRequest]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveCertificateBalance`)
            .set(rqGetCertificateBalanceRest_400.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveCertificateBalance - Response mock BadRequest ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(400);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveCertificateBalance WHEN request valid and invalid url THEN response 404', async () => {
        mockService(CertificateBalanceService, 'invokeCertificateBalanceService', true, rsGetCertificateBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveCertificateBalance - Response mock not found]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveCertificateBalance1`)
            .set(rqGetCertificateBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveCertificateBalance - Response mock not found ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(404);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveCertificateBalance WHEN request is valid but account doesnot exist THEN response 409', async () => {
        mockService(CertificateBalanceService, 'invokeCertificateBalanceService', false, rsGetCertificateBalanceRest_409);
        console.log(rquidTest, '[TEST CASE 3: COntroller retrieveCertificateBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveCertificateBalance`)
            .query({ acctId })
            .set(rqGetCertificateBalanceRest_409.headers)
        console.log(rquidTest, `[TEST CASE 3: COntroller retrieveCertificateBalance - Response mock Bussiness Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(409);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveCertificateBalance WHEN request is valid but service give timeout THEN response 408', async () => {
        mockService(CertificateBalanceService, 'invokeCertificateBalanceService', false, rsGetCertificateBalanceRest_408);
        console.log(rquidTest, '[TEST CASE 4: COntroller retrieveCertificateBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveCertificateBalance`)
            .query({ acctId })
            .set(rqGetCertificateBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 4: C0ntroller retrieveCertificateBalance - Response mock Timeout Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(408);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveCertificateBalance WHEN request is valid but service fail THEN response 500', async () => {
        mockService(CertificateBalanceService, 'invokeCertificateBalanceService', false, rsGetCertificateBalanceRest_500);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveCertificateBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveCertificateBalance`)
            .query({ acctId })
            .set(rqGetCertificateBalanceRest_200.headers)
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveCertificateBalance - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveCertificateBalance WHEN request is valid but service fail THEN response 500', async () => {
        mockService(CertificateBalanceService, 'invokeCertificateBalanceService', false, rsGetCertificateBalanceRest_500_1);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveCertificateBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveCertificateBalance`)
            .query({ acctId })
            .set(rqGetCertificateBalanceRest_200.headers)
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveCertificateBalance - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });
});

describe('BalancesController.spec [ Balances Controller - retrieveLoanBalance] async spec', () => {
    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveLoanBalance WHEN request valid THEN response 200', async () => {
        mockService(LoanBalanceService, 'invokeLoanBalanceService', true, rsGetLoanBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveLoanBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveLoanBalance`)
            .set(rqGetLoanBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveLoanBalance - Response mock Success ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(200);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveLoanBalance WHEN request valid and header invalid THEN response 400', async () => {
        mockService(LoanBalanceService, 'invokeLoanBalanceService', true, rsGetLoanBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveLoanBalance - Response mock BadRequest]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveLoanBalance`)
            .set(rqGetLoanBalanceRest_400.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveLoanBalance - Response mock BadRequest ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(400);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveLoanBalance WHEN request valid and invalid url THEN response 404', async () => {
        mockService(LoanBalanceService, 'invokeLoanBalanceService', true, rsGetLoanBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveLoanBalance - Response mock not found]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveLoanBalance1`)
            .set(rqGetLoanBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveLoanBalance - Response mock not found ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(404);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveLoanBalance WHEN request is valid but account doesnot exist THEN response 409', async () => {
        mockService(LoanBalanceService, 'invokeLoanBalanceService', false, rsGetLoanBalanceRest_409);
        console.log(rquidTest, '[TEST CASE 3: COntroller retrieveLoanBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveLoanBalance`)
            .query({ acctId })
            .set(rqGetLoanBalanceRest_409.headers)
        console.log(rquidTest, `[TEST CASE 3: COntroller retrieveLoanBalance - Response mock Bussiness Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(409);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveLoanBalance WHEN request is valid but service give timeout THEN response 408', async () => {
        mockService(LoanBalanceService, 'invokeLoanBalanceService', false, rsGetLoanBalanceRest_408);
        console.log(rquidTest, '[TEST CASE 4: COntroller retrieveLoanBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveLoanBalance`)
            .query({ acctId })
            .set(rqGetLoanBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 4: C0ntroller retrieveLoanBalance - Response mock Timeout Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(408);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveLoanBalance WHEN request is valid but service fail THEN response 500', async () => {
        mockService(LoanBalanceService, 'invokeLoanBalanceService', false, rsGetLoanBalanceRest_500);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveLoanBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveLoanBalance`)
            .query({ acctId })
            .set(rqGetLoanBalanceRest_200.headers)
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveLoanBalance - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveLoanBalance WHEN request is valid but service fail THEN response 500', async () => {
        mockService(LoanBalanceService, 'invokeLoanBalanceService', false, rsGetLoanBalanceRest_500_1);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveLoanBalance - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveLoanBalance`)
            .query({ acctId })
            .set(rqGetLoanBalanceRest_200.headers)
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveLoanBalance - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });
});

describe('BalancesController.spec [ Balances Controller - retrieveDetailCreditInfo] async spec', () => {
    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveDetailCreditInfo WHEN request valid THEN response 200', async () => {
        mockService(ProductInquiryService, 'invokeProductInquiryService', true, rsGetDetailCreditInfoRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveDetailCreditInfo - Succes]');
        const response: any = await request(app)
            //.get(`/V2/Enterprise/BalanceManagement/retrieveDetailCreditInfo/?acctType=LOC&trnType=0`)
            .get(`/V2/Enterprise/BalanceManagement/retrieveDetailCreditInfo/${acctId}/?acctType=LOC&trnType=0`)
            .set(rqGetDetailCreditInfoRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveDetailCreditInfo - Response mock Success ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(200);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveDetailCreditInfo WHEN request valid and header invalid THEN response 400', async () => {
        mockService(ProductInquiryService, 'invokeProductInquiryService', true, rsGetDetailCreditInfoRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveDetailCreditInfo - Response mock BadRequest]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/retrieveDetailCreditInfo/${acctId}/?acctType=LOC&trnType=0`)
            .set(rqGetDetailCreditInfoRest_400.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveDetailCreditInfo - Response mock BadRequest ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(400);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveDetailCreditInfo WHEN request valid and invalid url THEN response 404', async () => {
        mockService(ProductInquiryService, 'invokeProductInquiryService', true, rsGetDetailCreditInfoRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveDetailCreditInfo - Response mock not found]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/retrieveDetailCreditInfo1/${acctId}/?acctType=LOC&trnType=0`)
            .set(rqGetDetailCreditInfoRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveDetailCreditInfo - Response mock not found ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(404);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveDetailCreditInfo WHEN request is valid but account doesnot exist THEN response 409', async () => {
        mockService(ProductInquiryService, 'invokeProductInquiryService', false, rsGetDetailCreditInfoRest_409);
        console.log(rquidTest, '[TEST CASE 3: COntroller retrieveDetailCreditInfo - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/retrieveDetailCreditInfo/${acctId}/?acctType=LOC&trnType=0`)
            .set(rqGetDetailCreditInfoRest_409.headers)
        console.log(rquidTest, `[TEST CASE 3: COntroller retrieveDetailCreditInfo - Response mock Bussiness Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(409);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveDetailCreditInfo WHEN request is valid but service give timeout THEN response 408', async () => {
        mockService(ProductInquiryService, 'invokeProductInquiryService', false, rsGetDetailCreditInfoRest_408);
        console.log(rquidTest, '[TEST CASE 4: COntroller retrieveDetailCreditInfo - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/retrieveDetailCreditInfo/${acctId}/?acctType=LOC&trnType=0`)
            .set(rqGetDetailCreditInfoRest_200.headers);
        console.log(rquidTest, `[TEST CASE 4: C0ntroller retrieveDetailCreditInfo - Response mock Timeout Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(408);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveDetailCreditInfo WHEN request is valid but service fail THEN response 500', async () => {
        mockService(ProductInquiryService, 'invokeProductInquiryService', false, rsGetDetailCreditInfoRest_500);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveDetailCreditInfo - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/retrieveDetailCreditInfo/${acctId}/?acctType=LOC&trnType=0`)
            .set(rqGetDetailCreditInfoRest_200.headers)
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveDetailCreditInfo - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveDetailCreditInfo WHEN request is valid but service fail THEN response 500', async () => {
        mockService(ProductInquiryService, 'invokeProductInquiryService', false, rsGetDetailCreditInfoRest_500_1);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveDetailCreditInfo - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/retrieveDetailCreditInfo/${acctId}/?acctType=LOC&trnType=0`)
            .query({ acctId })
            .set(rqGetDetailCreditInfoRest_200.headers)
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveDetailCreditInfo - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });
});


describe('BalancesController.spec [ Balances Controller - retrieveloanQuota] async spec', () => {
    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveloanQuota WHEN request valid THEN response 200', async () => {
        mockService(LoanQuotaService, 'invokeLoanQuotaService', true, rsGetLoanQuotaBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveloanQuota - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/retrieveloanQuota`)
            .set(rqGetLoanQuotaBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveloanQuota - Response mock Success ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(200);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveloanQuota WHEN request valid and header invalid THEN response 400', async () => {
        mockService(LoanQuotaService, 'invokeLoanQuotaService', true, rsGetLoanQuotaBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveloanQuota - Response mock BadRequest]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/retrieveloanQuota`)
            .set(rqGetLoanQuotaBalanceRest_400.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveloanQuota - Response mock BadRequest ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(400);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveloanQuota WHEN request valid and invalid url THEN response 404', async () => {
        mockService(LoanQuotaService, 'invokeLoanQuotaService', true, rsGetLoanQuotaBalanceRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveloanQuota - Response mock not found]');
        const response: any = await request(app)
        .get(`/V2/Enterprise/BalanceManagement/retrieveloanQuota1`)
        .set(rqGetLoanQuotaBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveloanQuota - Response mock not found ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(404);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveloanQuota WHEN request is valid but account doesnot exist THEN response 409', async () => {
        mockService(LoanQuotaService, 'invokeLoanQuotaService', false, rsGetLoanQuotaBalanceRest_409);
        console.log(rquidTest, '[TEST CASE 3: COntroller retrieveloanQuota - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/retrieveloanQuota`)
            .set(rqGetLoanQuotaBalanceRest_409.headers)
        console.log(rquidTest, `[TEST CASE 3: COntroller retrieveloanQuota - Response mock Bussiness Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(409);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveloanQuota WHEN request is valid but service give timeout THEN response 408', async () => {
        mockService(LoanQuotaService, 'invokeLoanQuotaService', false, rsGetLoanQuotaBalanceRest_408);
        console.log(rquidTest, '[TEST CASE 4: COntroller retrieveloanQuota - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/retrieveloanQuota`)
            .set(rqGetLoanQuotaBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 4: C0ntroller retrieveloanQuota - Response mock Timeout Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(408);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveloanQuota WHEN request is valid but service fail THEN response 500', async () => {
        mockService(LoanQuotaService, 'invokeLoanQuotaService', false, rsGetLoanQuotaBalanceRest_500);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveloanQuota - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/retrieveloanQuota`)
            .set(rqGetLoanQuotaBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveloanQuota - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveloanQuota WHEN request is valid but service fail THEN response 500', async () => {
        mockService(LoanQuotaService, 'invokeLoanQuotaService', false, rsGetLoanQuotaBalanceRest_500_1);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveloanQuota - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/retrieveloanQuota`)
            .set(rqGetLoanQuotaBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveloanQuota - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });
});

describe('BalancesController.spec [ Balances Controller - retrieveOverdraft] async spec', () => {
    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveOverdraft WHEN request valid THEN response 200', async () => {
        mockService(OverdraftService, 'invokeOverdraftService', true, rsGetRetrieveOverdraftRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveOverdraft - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveOverdraft`)
            .set(rqGetRetrieveOverdraftRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveOverdraft - Response mock Success ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(200);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveOverdraft WHEN request valid and header invalid THEN response 400', async () => {
        mockService(OverdraftService, 'invokeOverdraftService', true, rsGetRetrieveOverdraftRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveOverdraft - Response mock BadRequest]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveOverdraft`)
            .set(rqGetRetrieveOverdraftRest_400.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveOverdraft - Response mock BadRequest ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(400);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveOverdraft WHEN request valid and invalid url THEN response 404', async () => {
        mockService(OverdraftService, 'invokeOverdraftService', true, rsGetRetrieveOverdraftRest_200);
        console.log(rquidTest, '[TEST CASE 1: COntroller retrieveOverdraft - Response mock not found]');
        const response: any = await request(app)
        .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveOverdraft1`)
        .set(rqGetRetrieveOverdraftRest_200.headers);
        console.log(rquidTest, `[TEST CASE 1: COntroller retrieveOverdraft - Response mock not found ${response.statusCode} ] `, response.body);
        expect(response.statusCode).toEqual(404);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveOverdraft WHEN request is valid but account doesnot exist THEN response 409', async () => {
        mockService(OverdraftService, 'invokeOverdraftService', false, rsGetRetrieveOverdraftRest_409);
        console.log(rquidTest, '[TEST CASE 3: COntroller retrieveOverdraft - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveOverdraft`)
            .set(rqGetRetrieveOverdraftRest_200.headers)
        console.log(rquidTest, `[TEST CASE 3: COntroller retrieveOverdraft - Response mock Bussiness Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(409);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveOverdraft WHEN request is valid but service give timeout THEN response 408', async () => {
        mockService(OverdraftService, 'invokeOverdraftService', false, rsGetRetrieveOverdraftRest_408);
        console.log(rquidTest, '[TEST CASE 4: COntroller retrieveOverdraft - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveOverdraft`)
            .set(rqGetRetrieveOverdraftRest_200.headers);
        console.log(rquidTest, `[TEST CASE 4: C0ntroller retrieveOverdraft - Response mock Timeout Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(408);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveOverdraft WHEN request is valid but service fail THEN response 500', async () => {
        mockService(OverdraftService, 'invokeOverdraftService', false, rsGetRetrieveOverdraftRest_500);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveloanQuota - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveOverdraft`)
            .set(rqGetLoanQuotaBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveloanQuota - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });

    it('GIVEN GET /V2/Enterprise/BalanceManagement/{acctId}/retrieveOverdraft WHEN request is valid but service fail THEN response 500', async () => {
        mockService(OverdraftService, 'invokeOverdraftService', false, rsGetRetrieveOverdraftRest_500_1);
        console.log(rquidTest, '[TEST CASE 5: COntroller retrieveOverdraft - Succes]');
        const response: any = await request(app)
            .get(`/V2/Enterprise/BalanceManagement/${acctId}/retrieveOverdraft`)
            .set(rqGetLoanQuotaBalanceRest_200.headers);
        console.log(rquidTest, `[TEST CASE 5: COntroller retrieveOverdraft - Response mock Internal Error ${response.statusCode} ]`, response.body);
        expect(response.statusCode).toEqual(500);
        expect(response.body).toEqual(expect.any(Object))
    });
});

const mockService = (inputClass: any, method: any, stateRs: boolean, result: any) => {
    jest.spyOn(inputClass, method).mockImplementation(() => {
        if (stateRs) {
            return Promise.resolve(result);
        } else {
            return Promise.reject(result);
        }
    })
}