import { describe, expect, it } from "@jest/globals";
import genericUtilities from '../../src/utils/GenericUtilities';
import { AdapterErrorN } from "../../src/utils/AdapterError";
import { DefaultStatusModelBuilder, IDefaultStatusModel } from "../../src/model/IDefaultStatusModel";
import { DefaultResponseModel } from "../../src/model/DefaultResponseModel";

describe('GenericUtilities.spec [ utils functions transformDocumentType] async spec ', () => {
  it('should return "C" for identityType "CC"', () => {
    expect(genericUtilities.transformDocumentType('CC')).toBe('C');
  });

  it('should return "L" for identityType "NI"', () => {
    expect(genericUtilities.transformDocumentType('NI')).toBe('L');
  });

  it('should return "E" for identityType "CE"', () => {
    expect(genericUtilities.transformDocumentType('CE')).toBe('E');
  });

  it('should return "N" for identityType "NJ"', () => {
    expect(genericUtilities.transformDocumentType('NJ')).toBe('N');
  });

  it('should return "I" for identityType "NE"', () => {
    expect(genericUtilities.transformDocumentType('NE')).toBe('I');
  });

  it('should return "P" for identityType "PA"', () => {
    expect(genericUtilities.transformDocumentType('PA')).toBe('P');
  });

  it('should return "R" for identityType "RC"', () => {
    expect(genericUtilities.transformDocumentType('RC')).toBe('R');
  });

  it('should return "T" for identityType "TI"', () => {
    expect(genericUtilities.transformDocumentType('TI')).toBe('T');
  });

  it('should throw an error for unspecified identityType', () => {
    expect(() => genericUtilities.transformDocumentType('XX')).toThrow('Documento no expecificado: XX');
  });
});

describe('GenericUtilities.spec [ utils functions formatDateOut] async spec', () => {
  it('should return the same date if date is empty', () => {
    expect(genericUtilities.formatDateOut('', 'dd/MM/yyyy')).toBe('');
  });

  it('should format date from "dd/MM/yyyy" to "yyyy-MM-dd"', () => {
    expect(genericUtilities.formatDateOut('25/12/2020', 'dd/MM/yyyy')).toBe('2020-12-25');
  });

  it('should format date from "yyyy-MM-dd" to "dd/MM/yyyy"', () => {
    expect(genericUtilities.formatDateOut('2020-12-25', 'yyyy-MM-dd')).toBe('25/12/2020');
  });

  it('should return the same date if date length is less than 10', () => {
    expect(genericUtilities.formatDateOut('2020-12', 'yyyy-MM-dd')).toBe('2020-12');
  });

  it('should return the same date if originFormat is not recognized', () => {
    expect(genericUtilities.formatDateOut('2020-12-25', 'MM/dd/yyyy')).toBe('');
  });
});

describe('GenericUtilities.spec [ utils functions stringToBoolean] async spec', () => {
  it('should return true for "true"', () => {
    expect(genericUtilities.stringToBoolean('true')).toBe(true);
  });

  it('should return true for "TRUE"', () => {
    expect(genericUtilities.stringToBoolean('TRUE')).toBe(true);
  });

  it('should return false for "false"', () => {
    expect(genericUtilities.stringToBoolean('false')).toBe(false);
  });

  it('should return false for "FALSE"', () => {
    expect(genericUtilities.stringToBoolean('FALSE')).toBe(false);
  });

  it('should return undefined for any other string', () => {
    expect(genericUtilities.stringToBoolean('not a boolean')).toBeUndefined();
  });

  it('should return undefined for an empty string', () => {
    expect(genericUtilities.stringToBoolean('')).toBeUndefined();
  });
});

describe('handlerErrorRestService', () => {
  const rquid = 'test-rquid';
  const serviceName = 'testService';

  it('should handle Business Error', () => {

    const status: IDefaultStatusModel = new DefaultStatusModelBuilder().setStatusCode(409)
      .setStatusDesc('Bussines Error')
      .setSeverity('Error')
      .setServerStatusCode('TS300')
      .setServerStatusDesc('Saldo no encontrado')
      .build();

    const defaultResponse: DefaultResponseModel = new DefaultResponseModel(status, rquid);
    const error = new AdapterErrorN('Error de negocio', 409, defaultResponse);
    const result = genericUtilities.handlerErrorRestService(rquid, serviceName, error);
    console.log(result);
    expect(result).toEqual(expect.any(Object));

  });
});

describe('validateChannel', () => {
  it('should return "SMP" for channel "BancaMovil"', () => {
    const result = genericUtilities.validateChannel('BancaMovil');
    expect(result).toBe('SMP');
  });

  it('should return "PB" for channel "BancaVirtual"', () => {
    const result = genericUtilities.validateChannel('BancaVirtual');
    expect(result).toBe('PB');
  });

  it('should return "BEP001" for channel "BdB Empresas"', () => {
    const result = genericUtilities.validateChannel('BdB Empresas');
    expect(result).toBe('BEP001');
  });

  it('should return "DIG482" for an unknown channel', () => {
    const result = genericUtilities.validateChannel('UnknownChannel');
    expect(result).toBe('DIG482');
  });
});

describe('safeStringify', () => {
  it('should return "object with safestringify"', () => {
    const obj = { field1: 1, field2: 'text' };
    const result = genericUtilities.safeStringify(obj);
    expect(result).toBe(JSON.stringify(obj, null, 2));
  });

  it('should return "object with safestringify"', () => {
    const obj = { field1: 1, field2: 'text' };
    const result = genericUtilities.safeStringify(obj, null, 4);
    expect(result).toBe(JSON.stringify(obj, null, 4));
  });
});

describe('FormatDate', () => {
  it('should return "format date"', () => {
    const inputDate = '2023-01-01T00:00:00Z';
    const originFormat = 'yyyy-MM-dd';
    const destFormat = 'dd/MM/yyyy';
    const result = genericUtilities.formatDate(inputDate, originFormat, destFormat);
    expect(result).toBe('01/01/2023');
  });

  it('should return "format date"', () => {
    const inputDate = 'invalid-date';
    const originFormat = 'yyyy-MM-dd';
    const destFormat = 'dd/MM/yyyy';
    // Asegurarse de que lanza un error
    expect(() => genericUtilities.formatDate(inputDate, originFormat, destFormat)).toThrow(Error);
  });
});