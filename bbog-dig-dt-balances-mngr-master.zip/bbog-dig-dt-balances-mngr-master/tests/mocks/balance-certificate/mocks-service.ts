import { RequestHeadersModel } from "../../../src/model/RequestHeadersModel"
import { ReqHeadersAdditionalRest } from "../../../src/model/ReqHeadersAdditionalRest"

export const rq_Certificate_Rest_200: ReqHeadersAdditionalRest = {
    "GeneralHeaders": {
      "X-RqUID": "a18eafa0-ce60-11e0-9572-999910867937",
      "X-Channel": "BancaVirtual",
      "X-CompanyId": "001",
      "X-CustIdentType": "CC",
      "X-CustIdentNum": "1080297719",
      "X-IPAddr": "100.20.30.40",
      "X-Name": "Banca Virtual",
      "X-TerminalId": "1234",
      "X-Journey": "1234",
      "X-NetworkOwner": "OPB001"
    },
    "BranchId": "0890",
    "AcctType": "FDA",
    "AcctSubType": "109FB"
  }

export const rq_Certificate_Rest_200_Without_NetWorkOwner: RequestHeadersModel = {
    "X-RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "X-Channel": "BancaVirtual",
    "X-CompanyId": "001",
    "X-CustIdentType": "CC",
    "X-CustIdentNum": "1080297719",
    "X-IPAddr": "100.20.30.40",
    "X-Journey": "001",
    "X-Name": "Banca Virtual",
    "X-TerminalId": "1234",
    "X-NetworkOwner": null
}

export const rs_Bck_Certificate_XML_200 = {
        data: `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="urn://bancodebogota.com/accounts/product/service/" xmlns:ns0="urn://bancodebogota.com/accounts/product/event/" xmlns:nsi="urn://bancodebogota.com/ifx/lite/v1/" xmlns:ns1="urn://bancodebogota.com/ifx/base/v1/" xmlns:ns2="urn://bancodebogota.com/accounts/product/v1/">
        <soapenv:Body>
           <ns:getCertificateBalancesResponse>
              <ns0:CDABalInqRs>
                 <ns1:RqUID>016202fc-0ae0-41ad-9011-fe231a6099a0</ns1:RqUID>
                 <ns1:Status>
                    <ns1:StatusCode>0</ns1:StatusCode>
                    <ns1:ServerStatusCode>0</ns1:ServerStatusCode>
                    <ns1:Severity>Info</ns1:Severity>
                    <ns1:StatusDesc>Transaccion Exitosa</ns1:StatusDesc>
                    <ns1:ServerStatusDesc>Transaccion Exitosa</ns1:ServerStatusDesc>
                 </ns1:Status>
                 <ns1:CustId>
                    <ns1:CustLoginId>1011459154</ns1:CustLoginId>
                 </ns1:CustId>
                 <ns1:NetworkTrnInfo>
                    <ns1:NetworkOwner>DIG482</ns1:NetworkOwner>
                    <ns1:TerminalId>IN01</ns1:TerminalId>
                    <ns1:BankId>001</ns1:BankId>
                 </ns1:NetworkTrnInfo>
                 <ns1:ServerDt>2025-02-17T16:59:55.849504-05:00</ns1:ServerDt>
                 <ns2:CDABalRec>
                    <nsi:AcctBasicInfo>
                       <ns1:AcctId>0000000546567876</ns1:AcctId>
                       <ns1:AcctType>CDA</ns1:AcctType>
                       <nsi:BankInfo/>
                    </nsi:AcctBasicInfo>
                    <nsi:PersonInfo>
                       <ns1:FullName>AUTOMATIZACION PRUEBAS,CLIENTE</ns1:FullName>
                    </nsi:PersonInfo>
                    <ns2:AccountStatus>
                       <ns1:StatusCode>06</ns1:StatusCode>
                       <ns1:StatusDesc>Unredeemed</ns1:StatusDesc>
                       <ns1:ExpDt>2014-07-12</ns1:ExpDt>
                    </ns2:AccountStatus>
                    <ns1:ExtAcctBal>
                       <ns1:ExtBalType>Redemption</ns1:ExtBalType>
                       <ns1:CurAmt>
                          <ns1:Amt>0.00</ns1:Amt>
                          <ns1:CurCode>COP</ns1:CurCode>
                       </ns1:CurAmt>
                    </ns1:ExtAcctBal>
                    <ns1:ExtAcctBal>
                       <ns1:ExtBalType>YTDInterest</ns1:ExtBalType>
                       <ns1:CurAmt>
                          <ns1:Amt>0.00</ns1:Amt>
                          <ns1:CurCode>COP</ns1:CurCode>
                       </ns1:CurAmt>
                    </ns1:ExtAcctBal>
                    <ns1:ExtAcctBal>
                       <ns1:ExtBalType>YTDWithhold</ns1:ExtBalType>
                       <ns1:CurAmt>
                          <ns1:Amt>7234.00</ns1:Amt>
                          <ns1:CurCode>COP</ns1:CurCode>
                       </ns1:CurAmt>
                    </ns1:ExtAcctBal>
                    <ns1:ExtAcctBal>
                       <ns1:ExtBalType>Orig</ns1:ExtBalType>
                       <ns1:CurAmt>
                          <ns1:Amt>5000000.00</ns1:Amt>
                          <ns1:CurCode>COP</ns1:CurCode>
                       </ns1:CurAmt>
                    </ns1:ExtAcctBal>
                    <ns1:OwnerInd>0</ns1:OwnerInd>
                    <ns1:OpenDt>2022-12-13</ns1:OpenDt>
                    <ns1:ExpDt>2024-12-13</ns1:ExpDt>
                    <ns1:Term>
                       <ns1:Count>6</ns1:Count>
                       <ns1:TermUnits>Months</ns1:TermUnits>
                    </ns1:Term>
                    <ns1:Rate>3.6172880</ns1:Rate>
                 </ns2:CDABalRec>
              </ns0:CDABalInqRs>
           </ns:getCertificateBalancesResponse>
        </soapenv:Body>
     </soapenv:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_Certificate_XML_200_single = {
    data: `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="urn://bancodebogota.com/accounts/product/service/" xmlns:ns0="urn://bancodebogota.com/accounts/product/event/" xmlns:nsi="urn://bancodebogota.com/ifx/lite/v1/" xmlns:ns1="urn://bancodebogota.com/ifx/base/v1/" xmlns:ns2="urn://bancodebogota.com/accounts/product/v1/">
    <soapenv:Body>
       <ns:getCertificateBalancesResponse>
          <ns0:CDABalInqRs>
             <ns1:RqUID>016202fc-0ae0-41ad-9011-fe231a6099a0</ns1:RqUID>
             <ns1:Status>
                <ns1:StatusCode>0</ns1:StatusCode>
                <ns1:ServerStatusCode>0</ns1:ServerStatusCode>
                <ns1:Severity>Info</ns1:Severity>
                <ns1:StatusDesc>Transaccion Exitosa</ns1:StatusDesc>
                <ns1:ServerStatusDesc>Transaccion Exitosa</ns1:ServerStatusDesc>
             </ns1:Status>
             <ns1:CustId>
                <ns1:CustLoginId>1011459154</ns1:CustLoginId>
             </ns1:CustId>
             <ns1:NetworkTrnInfo>
                <ns1:NetworkOwner>DIG482</ns1:NetworkOwner>
                <ns1:TerminalId>IN01</ns1:TerminalId>
                <ns1:BankId>001</ns1:BankId>
             </ns1:NetworkTrnInfo>
             <ns1:ServerDt>2025-02-17T16:59:55.849504-05:00</ns1:ServerDt>
             <ns2:CDABalRec>
                <nsi:AcctBasicInfo>
                   <ns1:AcctId>0000000546567876</ns1:AcctId>
                   <ns1:AcctType>CDA</ns1:AcctType>
                   <nsi:BankInfo/>
                </nsi:AcctBasicInfo>
                <nsi:PersonInfo>
                   <ns1:FullName>AUTOMATIZACION PRUEBAS,CLIENTE</ns1:FullName>
                </nsi:PersonInfo>
                <ns2:AccountStatus>
                   <ns1:StatusCode>06</ns1:StatusCode>
                   <ns1:StatusDesc>Unredeemed</ns1:StatusDesc>
                   <ns1:ExpDt>2014-07-12</ns1:ExpDt>
                </ns2:AccountStatus>
                <ns1:ExtAcctBal>
                   <ns1:ExtBalType>Redemption</ns1:ExtBalType>
                   <ns1:CurAmt>
                      <ns1:Amt>0.00</ns1:Amt>
                      <ns1:CurCode>COP</ns1:CurCode>
                   </ns1:CurAmt>
                </ns1:ExtAcctBal>
               
                <ns1:OwnerInd>0</ns1:OwnerInd>
                <ns1:OpenDt>2022-12-13</ns1:OpenDt>
                <ns1:ExpDt>2024-12-13</ns1:ExpDt>
                <ns1:Term>
                   <ns1:Count>6</ns1:Count>
                   <ns1:TermUnits>Months</ns1:TermUnits>
                </ns1:Term>
                <ns1:Rate>3.6172880</ns1:Rate>
             </ns2:CDABalRec>
          </ns0:CDABalInqRs>
       </ns:getCertificateBalancesResponse>
    </soapenv:Body>
 </soapenv:Envelope>`,
status: 200,
code: 'OK',
principalServiceUsed: true,
circuitBreakerState: 'circuit breaker not used'
}


export const rs_Bck_Certificate_XML_409 = {
    data: `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="urn://bancodebogota.com/accounts/product/service/" xmlns:nsi="urn://bancodebogota.com/ifx/base/v1/" xmlns:ns1="urn://bancodebogota.com/accounts/product/event/" xmlns:ns2="urn://bancodebogota.com/accounts/product/v1/" xmlns:ns3="urn://bancodebogota.com/ifx/lite/v1/">
    <soapenv:Body>
       <ns:getCertificateBalancesResponse>
          <ns1:CDABalInqRs>
             <NS3:RqUID xmlns:NS3="urn://bancodebogota.com/ifx/base/v1/">016202fc-0ae0-41ad-9011-fe231a6099a0</NS3:RqUID>
             <nsi:Status>
                <nsi:StatusCode>100</nsi:StatusCode>
                <nsi:ServerStatusCode>TS9260</nsi:ServerStatusCode>
                <nsi:Severity>Error</nsi:Severity>
                <nsi:StatusDesc>General Error</nsi:StatusDesc>
                <nsi:ServerStatusDesc>XPCD TS9260 F: REG O CTA NO EXISTE SITABOX</nsi:ServerStatusDesc>
                <nsi:AdditionalStatus>
                   <nsi:StatusCode>-1000</nsi:StatusCode>
                   <nsi:ServerStatusCode>-10361</nsi:ServerStatusCode>
                   <nsi:Severity>Error</nsi:Severity>
                   <nsi:StatusDesc>MESSAGES FOR CONSUL CDT TSLG34</nsi:StatusDesc>
                </nsi:AdditionalStatus>
                <nsi:AdditionalStatus>
                   <nsi:StatusCode>100</nsi:StatusCode>
                   <nsi:ServerStatusCode>-10361</nsi:ServerStatusCode>
                   <nsi:Severity>Error</nsi:Severity>
                   <nsi:StatusDesc>TP en_US 100  General Error</nsi:StatusDesc>
                </nsi:AdditionalStatus>
                <nsi:AdditionalStatus>
                   <nsi:StatusCode>-1000</nsi:StatusCode>
                   <nsi:ServerStatusCode>-10361</nsi:ServerStatusCode>
                   <nsi:Severity>Error</nsi:Severity>
                   <nsi:StatusDesc>XPCD TS9260 F: REG O CTA NO EXISTE SITABOX</nsi:StatusDesc>
                </nsi:AdditionalStatus>
             </nsi:Status>
             <nsi:NetworkTrnInfo>
                <nsi:NetworkOwner>DIG482</nsi:NetworkOwner>
                <nsi:TerminalId>IN01</nsi:TerminalId>
                <nsi:BankId>001</nsi:BankId>
             </nsi:NetworkTrnInfo>
             <nsi:ServerDt>2025-02-17T17:01:00.407187-05:00</nsi:ServerDt>
          </ns1:CDABalInqRs>
       </ns:getCertificateBalancesResponse>
    </soapenv:Body>
 </soapenv:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_Certificate_XML_500 = {
    'data': '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">'+
    '                <soapenv:Header/>\n '+
    '                <soapenv:Body>\n '+
    '                <soapenv:Fault>\n '+
    '                    <faultcode>soapenv:Server</faultcode>\n '+
    '                    <faultstring>No es posible procesar la transaccion. Comuniquese con la Entidad</faultstring>\n '+
    '                    <detail>\n '+
    '                        <GeneralException>\n '+
    '                            <Status>\n '+
    '                            <StatusCode>100</StatusCode>\n '+
    '                            <ServerStatusCode>0x00d30003</ServerStatusCode>\n '+
    '                            <Severity>Error</Severity>\n '+
    '                            <StatusDesc>Fallas Tecnicas nos impiden procesar la Transaccion</StatusDesc>\n '+
    '                            <ServerStatusDesc>El canal PB11 no está parametrizado, debe enviar un valor de NetworkOwner correcto, para mas informacion con arquitectura de aplicaciones: En PowerApps CatalogoApps_AQA</ServerStatusDesc>\n '+
    '                            </Status>\n '+
    '                        </GeneralException>\n '+
    '                    </detail>\n '+
    '                </soapenv:Fault>\n '+
    '                </soapenv:Body>\n '+
    '            </soapenv:Envelope>',
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rqGetCertificateBalanceRest_200 = {
    headers: {
      "Content-Type": "application/json",
      "X-CustIdentType": "CC",
      "X-CustIdentNum": "41496038",
      "X-IPAddr": "127.0.0.1",
      "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
      "X-Channel": "Web",
      "X-Name": "Transversales",
      "X-CompanyId": "001",
      "X-TerminalId": "BOP0",
      "X-NetworkOwner": "BPM_315",
      'X-Journey': 'tes',
      "x-api-key": "xxxx"
    }
}

export const rqGetCertificateBalanceRest_400 = {
    headers: {
      "Content-Type": "application/json",
      "X-CustIdentType": "CC",
      "X-CustIdentNum": "41496038",
      "X-IPAddr": "127.0.0.1",
      "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
      "X-Channel": "Web",
      "X-Name": "Transversales",
      "X-CompanyId": "001",
      "X-TerminalId": "BOP0",
      "x-api-key": "xxxx"
    }
}

export const rqGetCertificateBalanceRest_409 = {
    headers: {
        "Content-Type": "application/json",
        "X-CustIdentType": "CC",
        "X-CustIdentNum": "41496038",
        "X-IPAddr": "127.0.0.1",
        "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
        "X-Channel": "Web",
        "X-Name": "Transversales",
        "X-CompanyId": "001",
        "X-TerminalId": "BOP0",
        "X-NetworkOwner": "BPM_315",
        'X-Journey': 'tes',
        "x-api-key": "xxxx"
    },
    params: {
        acctId: "343435"
    }
}

export const rsGetCertificateBalanceRest_200 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac686",
    "Status": {
        "StatusCode": 0,
        "StatusDesc": "Transaccion exitosa",
        "Severity": "Info",
        "ServerStatusCode": "OK",
        "ServerStatusDesc": "200"
    },
    "EndDt": "2025-02-17T16:27:04",
    "AccInfo": [
        {
            "AcctBasicInfo": {
                "AcctId": "0000000546567876",
                "AcctType": "CDA",
                "AcctSubType": null,
                "AcctCur": null,
                "BankInfo": {
                    "BankId": null,
                    "RefInfo": {
                        "RefType": null,
                        "RefId": null
                    },
                    "BranchId": null
                }
            },
            "PersonInfo": {
                "FullName": "AUTOMATIZACION PRUEBAS,CLIENTE",
                "GovIssueIdent": {
                    "GovIssueIdentType": null,
                    "IdentSerialNum": null
                }
            },
            "AccountStatus": {
                "StatusCode": "06",
                "StatusDesc": "Unredeemed"
            },
            "AcctBal": [],
            "ExtAcctBal": [
                {
                    "ExtBalType": "Redemption",
                    "CurAmt": {
                        "Amt": "0.00",
                        "CurCode": "COP"
                    }
                },
                {
                    "ExtBalType": "YTDInterest",
                    "CurAmt": {
                        "Amt": "0.00",
                        "CurCode": "COP"
                    }
                },
                {
                    "ExtBalType": "YTDWithhold",
                    "CurAmt": {
                        "Amt": "7234.00",
                        "CurCode": "COP"
                    }
                },
                {
                    "ExtBalType": "Orig",
                    "CurAmt": {
                        "Amt": "5000000.00",
                        "CurCode": "COP"
                    }
                }
            ],
            "OwnerInd": "0",
            "RefInfo": [],
            "OpenDt": "2022-12-13",
            "ExpDt": "2024-12-13",
            "PaidDt": "",
            "MinPmtCurAmt": null,
            "Term": {
                "Count": "6",
                "TermUnits": "Months"
            },
            "Rate": "3.6172880",
            "OverdraftDays": null,
            "Fee": null,
            "NextPmtCurAmt": null,
            "DueDt": "",
            "Ownership": null,
            "FinalCurAmt": null
        }
    ],
    "isPrincipalServiceUsed": true,
    "circuitBreakerState": "circuit breaker not used"
}



export const rsGetCertificateBalanceRest_409 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 409,
        "StatusDesc": "Bussines Error",
        "Severity": "Error",
        "ServerStatusCode": "TS9260",
        "ServerStatusDesc": "CTL1 TS9260 F: REG O CTA NO EXISTE STMEM01 00000033971920"
    },
    "EndDt": "2024-12-09T10:29:23"
}

export const rsGetCertificateBalanceRest_408 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 408,
        "StatusDesc": "timeout of 3000ms exceeded",
        "Severity": "Error",
        "ServerStatusCode": "408",
        "ServerStatusDesc": "Error calling service getSavignsBalanceService - Timeout"
    },
    "EndDt": "2024-12-09T10:31:20"
}

export const rsGetCertificateBalanceRest_500 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 500,
        "StatusDesc": "Internal Server Error",
        "Severity": "Error",
        "ServerStatusCode": 500,
        "ServerStatusDesc": "Request failed with status code 500"
    },
    "EndDt": "2024-12-09T10:31:01"
}

export const rsGetCertificateBalanceRest_500_1 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status1": {
        "StatusDesc": "Internal Server Error",
        "Severity": "Error",
        "ServerStatusCode": 500,
        "ServerStatusDesc": "Request failed with status code 500"
    },
    "EndDt": "2024-12-09T10:31:01"
}