import { RequestHeadersModel } from "../../../src/model/RequestHeadersModel"

export const rqGetDemandBalanceRest_200 = {
    headers: {
        "Content-Type": "application/json",
        "X-CustIdentType": "CC",
        "X-CustIdentNum": "41496038",
        "X-IPAddr": "127.0.0.1",
        "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
        "X-Channel": "Web",
        "X-Name": "Transversales",
        "X-CompanyId": "001",
        "X-TerminalId": "BOP0",
        'X-Journey': 'tes',
        "X-NetworkOwner": "BPM_315",
        "x-api-key": "xxxx"
    },
    params: {
        acctId: "343435"
    }
}

export const rqGetDemandBalanceRest_400 = {
    headers: {
        "Content-Type": "application/json",
        "X-CustIdentType": "CC",
        "X-CustIdentNum": "41496038",
        "X-IPAddr": "127.0.0.1",
        "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
        "X-Name": "Transversales",
        "X-CompanyId": "001",
        "X-TerminalId": "BOP0",
        'X-Journey': 'tes',
        "X-NetworkOwner": "BPM_315",
        "x-api-key": "xxxx"
    }
}

export const rqGetDemandBalanceRest_409 = {
    headers: {
        "Content-Type": "application/json",
        "X-CustIdentType": "CC",
        "X-CustIdentNum": "41496038",
        "X-IPAddr": "127.0.0.1",
        "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
        "X-Channel": "Web",
        "X-Name": "Transversales",
        "X-CompanyId": "001",
        "X-TerminalId": "BOP0",
        'X-Journey': 'tes',
        "X-NetworkOwner": "BPM_315",
        "x-api-key": "xxxx"
    },
    params: {
        acctId: "343435"
    }
}

export const rsGetDemandBalanceRest_200 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac686",
    "Status": {
        "StatusCode": 0,
        "StatusDesc": "Transaccion exitosa",
        "Severity": "Info",
        "ServerStatusCode": "OK",
        "ServerStatusDesc": "200"
    },
    "EndDt": "2025-01-02T23:14:08",
    "AccInfo": [
        {
            "AcctBasicInfo": {
                "AcctId": "0000000006581714",
                "AcctType": "DDA"
            },
            "PersonInfo": "",
            "AccountStatus": {
                "StatusCode": "00",
                "StatusDesc": "Active"
            },
            "AcctBal": [
                {
                    "BalType": "Avail",
                    "CurAmt": {
                        "Amt": "8998805.00",
                        "CurCode": "COP"
                    }
                },
                {
                    "BalType": "Current",
                    "CurAmt": {
                        "Amt": "8998805.00",
                        "CurCode": "COP"
                    }
                },
                {
                    "BalType": "CashAvail2",
                    "CurAmt": {
                        "Amt": "100000.00",
                        "CurCode": "COP"
                    }
                }
            ],
            "ExtAcctBal": [
                {
                    "ExtBalType": "PendAuthAmt",
                    "CurAmt": {
                        "Amt": "0.00",
                        "CurCode": "COP"
                    }
                },
                {
                    "ExtBalType": "LastStmBal",
                    "CurAmt": {
                        "Amt": "8998805.00",
                        "CurCode": "COP"
                    }
                },
                {
                    "ExtBalType": "CashLimit",
                    "CurAmt": {
                        "Amt": "100000.00",
                        "CurCode": "COP"
                    },
                    "EffDt": "2025-01-02T23:14:14.383250-05:00"
                },
                {
                    "ExtBalType": "CashAvail",
                    "CurAmt": {
                        "Amt": "0.00",
                        "CurCode": "COP"
                    },
                    "EffDt": "2025-01-02T23:14:14.383250-05:00"
                }
            ],
            "OwnerInd": "0",
            "RefInfo": [],
            "OpenDt": "",
            "ExpDt": "",
            "PaidDt": "2025-01-03",
            "MinPmtCurAmt": null,
            "Term": null,
            "Rate": null,
            "OverdraftDays": "0",
            "Fee": null,
            "NextPmtCurAmt": null,
            "DueDt": "",
            "Ownership": null,
            "FinalCurAmt": null
        }
    ],
    "isPrincipalServiceUsed": true,
    "circuitBreakerState": "circuit breaker not used"
}

export const rsGetDemandBalanceRest_409 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 409,
        "StatusDesc": "Bussines Error",
        "Severity": "Error",
        "ServerStatusCode": "TS9260",
        "ServerStatusDesc": "CTL1 TS9260 F: REG O CTA NO EXISTE STMEM01 00000033971920"
    },
    "EndDt": "2024-12-09T10:29:23"
}

export const rsGetDemandBalanceRest_408 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 408,
        "StatusDesc": "timeout of 3000ms exceeded",
        "Severity": "Error",
        "ServerStatusCode": "408",
        "ServerStatusDesc": "Error calling service getSavignsBalanceService - Timeout"
    },
    "EndDt": "2024-12-09T10:31:20"
}

export const rsGetDemandBalanceRest_500 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 500,
        "StatusDesc": "Internal Server Error",
        "Severity": "Error",
        "ServerStatusCode": 500,
        "ServerStatusDesc": "Request failed with status code 500"
    },
    "EndDt": "2024-12-09T10:31:01"
}

export const rsGetDemandBalanceRest_500_1 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status1": {
        "StatusDesc": "Internal Server Error",
        "Severity": "Error",
        "ServerStatusCode": 500,
        "ServerStatusDesc": "Request failed with status code 500"
    },
    "EndDt": "2024-12-09T10:31:01"
}

export const rq_Demand_Rest_200: RequestHeadersModel = {
    "X-RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "X-Channel": "BancaVirtual",
    "X-CompanyId": "001",
    "X-CustIdentType": "CC",
    "X-CustIdentNum": "1080297719",
    "X-IPAddr": "100.20.30.40",
    "X-Journey": "001",
    "X-Name": "Banca Virtual",
    "X-TerminalId": "1234",
    "X-NetworkOwner": "1234"
}

export const rq_Demand_Rest_200_Without_NetWorkOwner: RequestHeadersModel = {
    "X-RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "X-Channel": "BancaVirtual",
    "X-CompanyId": "001",
    "X-CustIdentType": "CC",
    "X-CustIdentNum": "1080297719",
    "X-IPAddr": "100.20.30.40",
    "X-Journey": "001",
    "X-Name": "Banca Virtual",
    "X-TerminalId": "1234",
    "X-NetworkOwner": null
}

export const rs_Bck_Demand_XML_200 = {
    data: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="urn://bancodebogota.com/accounts/product/service/" xmlns:nsi="urn://bancodebogota.com/ifx/base/v1/" xmlns:ns1="urn://bancodebogota.com/accounts/product/event/" xmlns:ns2="urn://bancodebogota.com/accounts/product/v1/" xmlns:ns3="urn://bancodebogota.com/ifx/lite/v1/">\n' +
        '            <soapenv:Body>\n' +
        '            <ns:getDemandBalancesResponse>\n' +
        '                <ns1:DDABalInqRs>\n' +
        '                    <nsi:RqUID>e2e8f084-7186-44f7-89c3-19bb0930716f</nsi:RqUID>\n' +
        '                    <nsi:Status>\n' +
        '                        <nsi:StatusCode>0</nsi:StatusCode>\n' +
        '                        <nsi:ServerStatusCode>0</nsi:ServerStatusCode>\n' +
        '                        <nsi:Severity>Info</nsi:Severity>\n' +
        '                        <nsi:StatusDesc>Transaccion Exitosa</nsi:StatusDesc>\n' +
        '                        <nsi:ServerStatusDesc>Transaccion Exitosa</nsi:ServerStatusDesc>\n' +
        '                    </nsi:Status>\n' +
        '                    <nsi:CustId>\n' +
        '                        <nsi:CustLoginId>2006699</nsi:CustLoginId>\n' +
        '                    </nsi:CustId>\n' +
        '                    <nsi:NetworkTrnInfo>\n' +
        '                        <nsi:NetworkOwner>SMP</nsi:NetworkOwner>\n' +
        '                        <nsi:TerminalId>IN01</nsi:TerminalId>\n' +
        '                        <nsi:BankId>001</nsi:BankId>\n' +
        '                    </nsi:NetworkTrnInfo>\n' +
        '                    <nsi:ServerDt>2023-03-22T09:25:26.759791-05:00</nsi:ServerDt>\n' +
        '                    <ns2:DDABalRec>\n' +
        '                        <ns3:AcctBasicInfo>\n' +
        '                        <nsi:AcctId>************2226</nsi:AcctId>\n' +
        '                        <nsi:AcctType>DDA</nsi:AcctType>\n' +
        '                        <ns3:BankInfo/>\n' +
        '                        </ns3:AcctBasicInfo>\n' +
        '                        <ns2:AccountStatus>\n' +
        '                        <nsi:StatusCode>00</nsi:StatusCode>\n' +
        '                        <nsi:StatusDesc>Active</nsi:StatusDesc>\n' +
        '                        </ns2:AccountStatus>\n' +
        '                        <ns2:AcctBal>\n' +
        '                        <nsi:BalType>Avail</nsi:BalType>\n' +
        '                        <ns2:CurAmt>\n' +
        '                            <nsi:Amt>3311843.45</nsi:Amt>\n' +
        '                            <nsi:CurCode>COP</nsi:CurCode>\n' +
        '                        </ns2:CurAmt>\n' +
        '                        </ns2:AcctBal>\n' +
        '                        <ns2:AcctBal>\n' +
        '                        <nsi:BalType>Current</nsi:BalType>\n' +
        '                        <ns2:CurAmt>\n' +
        '                            <nsi:Amt>3311843.45</nsi:Amt>\n' +
        '                            <nsi:CurCode>COP</nsi:CurCode>\n' +
        '                        </ns2:CurAmt>\n' +
        '                        </ns2:AcctBal>\n' +
        '                        <ns2:AcctBal>\n' +
        '                        <nsi:BalType>CashAvail2</nsi:BalType>\n' +
        '                        <ns2:CurAmt>\n' +
        '                            <nsi:Amt>1.00</nsi:Amt>\n' +
        '                            <nsi:CurCode>COP</nsi:CurCode>\n' +
        '                        </ns2:CurAmt>\n' +
        '                        </ns2:AcctBal>\n' +
        '                        <nsi:ExtAcctBal>\n' +
        '                        <nsi:ExtBalType>PendAuthAmt</nsi:ExtBalType>\n' +
        '                        <nsi:CurAmt>\n' +
        '                            <nsi:Amt>0.00</nsi:Amt>\n' +
        '                            <nsi:CurCode>COP</nsi:CurCode>\n' +
        '                        </nsi:CurAmt>\n' +
        '                        </nsi:ExtAcctBal>\n' +
        '                        <nsi:ExtAcctBal>\n' +
        '                        <nsi:ExtBalType>LastStmBal</nsi:ExtBalType>\n' +
        '                        <nsi:CurAmt>\n' +
        '                            <nsi:Amt>3311843.45</nsi:Amt>\n' +
        '                            <nsi:CurCode>COP</nsi:CurCode>\n' +
        '                        </nsi:CurAmt>\n' +
        '                        </nsi:ExtAcctBal>\n' +
        '                        <nsi:ExtAcctBal>\n' +
        '                        <nsi:ExtBalType>CashLimit</nsi:ExtBalType>\n' +
        '                        <nsi:CurAmt>\n' +
        '                            <nsi:Amt>1.00</nsi:Amt>\n' +
        '                            <nsi:CurCode>COP</nsi:CurCode>\n' +
        '                        </nsi:CurAmt>\n' +
        '                        <nsi:EffDt>2023-03-22T09:25:26.736214-05:00</nsi:EffDt>\n' +
        '                        </nsi:ExtAcctBal>\n' +
        '                        <nsi:ExtAcctBal>\n' +
        '                        <nsi:ExtBalType>CashAvail</nsi:ExtBalType>\n' +
        '                        <nsi:CurAmt>\n' +
        '                            <nsi:Amt>0.00</nsi:Amt>\n' +
        '                            <nsi:CurCode>COP</nsi:CurCode>\n' +
        '                        </nsi:CurAmt>\n' +
        '                        <nsi:EffDt>2023-03-22T09:25:26.736214-05:00</nsi:EffDt>\n' +
        '                        </nsi:ExtAcctBal>\n' +
        '                        <nsi:OwnerInd>0</nsi:OwnerInd>\n' +
        '                        <nsi:PaidDt>2023-03-22</nsi:PaidDt>\n' +
        '                        <nsi:OverdraftDays>0</nsi:OverdraftDays>\n' +
        '                    </ns2:DDABalRec>\n' +
        '                </ns1:DDABalInqRs>\n' +
        '            </ns:getDemandBalancesResponse>\n' +
        '            </soapenv:Body>\n' +
        '        </soapenv:Envelope>',
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_Demand_XML_200_single = {
    data: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="urn://bancodebogota.com/accounts/product/service/" xmlns:nsi="urn://bancodebogota.com/ifx/base/v1/" xmlns:ns1="urn://bancodebogota.com/accounts/product/event/" xmlns:ns2="urn://bancodebogota.com/accounts/product/v1/" xmlns:ns3="urn://bancodebogota.com/ifx/lite/v1/">\n' +
        '            <soapenv:Body>\n' +
        '            <ns:getDemandBalancesResponse>\n' +
        '                <ns1:DDABalInqRs>\n' +
        '                    <nsi:RqUID>e2e8f084-7186-44f7-89c3-19bb0930716f</nsi:RqUID>\n' +
        '                    <nsi:Status>\n' +
        '                        <nsi:StatusCode>0</nsi:StatusCode>\n' +
        '                        <nsi:ServerStatusCode>0</nsi:ServerStatusCode>\n' +
        '                        <nsi:Severity>Info</nsi:Severity>\n' +
        '                        <nsi:StatusDesc>Transaccion Exitosa</nsi:StatusDesc>\n' +
        '                        <nsi:ServerStatusDesc>Transaccion Exitosa</nsi:ServerStatusDesc>\n' +
        '                    </nsi:Status>\n' +
        '                    <nsi:CustId>\n' +
        '                        <nsi:CustLoginId>2006699</nsi:CustLoginId>\n' +
        '                    </nsi:CustId>\n' +
        '                    <nsi:NetworkTrnInfo>\n' +
        '                        <nsi:NetworkOwner>SMP</nsi:NetworkOwner>\n' +
        '                        <nsi:TerminalId>IN01</nsi:TerminalId>\n' +
        '                        <nsi:BankId>001</nsi:BankId>\n' +
        '                    </nsi:NetworkTrnInfo>\n' +
        '                    <nsi:ServerDt>2023-03-22T09:25:26.759791-05:00</nsi:ServerDt>\n' +
        '                    <ns2:DDABalRec>\n' +
        '                        <ns3:AcctBasicInfo>\n' +
        '                        <nsi:AcctId>************2226</nsi:AcctId>\n' +
        '                        <nsi:AcctType>DDA</nsi:AcctType>\n' +
        '                        <ns3:BankInfo/>\n' +
        '                        </ns3:AcctBasicInfo>\n' +
        '                        <ns2:AccountStatus>\n' +
        '                        <nsi:StatusCode>00</nsi:StatusCode>\n' +
        '                        <nsi:StatusDesc>Active</nsi:StatusDesc>\n' +
        '                        </ns2:AccountStatus>\n' +
        '                        <ns2:AcctBal>\n' +
        '                        <nsi:BalType>Avail</nsi:BalType>\n' +
        '                        <ns2:CurAmt>\n' +
        '                            <nsi:Amt>3311843.45</nsi:Amt>\n' +
        '                            <nsi:CurCode>COP</nsi:CurCode>\n' +
        '                        </ns2:CurAmt>\n' +
        '                        </ns2:AcctBal>\n' +
        '                        <nsi:ExtAcctBal>\n' +
        '                        <nsi:ExtBalType>PendAuthAmt</nsi:ExtBalType>\n' +
        '                        <nsi:CurAmt>\n' +
        '                            <nsi:Amt>0.00</nsi:Amt>\n' +
        '                            <nsi:CurCode>COP</nsi:CurCode>\n' +
        '                        </nsi:CurAmt>\n' +
        '                        </nsi:ExtAcctBal>\n' +
        '                        <nsi:ExtAcctBal>\n' +
        '                        <nsi:ExtBalType>LastStmBal</nsi:ExtBalType>\n' +
        '                        <nsi:CurAmt>\n' +
        '                            <nsi:Amt>3311843.45</nsi:Amt>\n' +
        '                            <nsi:CurCode>COP</nsi:CurCode>\n' +
        '                        </nsi:CurAmt>\n' +
        '                        </nsi:ExtAcctBal>\n' +
        '                        <nsi:ExtAcctBal>\n' +
        '                        <nsi:ExtBalType>CashLimit</nsi:ExtBalType>\n' +
        '                        <nsi:CurAmt>\n' +
        '                            <nsi:Amt>1.00</nsi:Amt>\n' +
        '                            <nsi:CurCode>COP</nsi:CurCode>\n' +
        '                        </nsi:CurAmt>\n' +
        '                        <nsi:EffDt>2023-03-22T09:25:26.736214-05:00</nsi:EffDt>\n' +
        '                        </nsi:ExtAcctBal>\n' +
        '                        <nsi:ExtAcctBal>\n' +
        '                        <nsi:ExtBalType>CashAvail</nsi:ExtBalType>\n' +
        '                        <nsi:CurAmt>\n' +
        '                            <nsi:Amt>0.00</nsi:Amt>\n' +
        '                            <nsi:CurCode>COP</nsi:CurCode>\n' +
        '                        </nsi:CurAmt>\n' +
        '                        <nsi:EffDt>2023-03-22T09:25:26.736214-05:00</nsi:EffDt>\n' +
        '                        </nsi:ExtAcctBal>\n' +
        '                    </ns2:DDABalRec>\n' +
        '                </ns1:DDABalInqRs>\n' +
        '            </ns:getDemandBalancesResponse>\n' +
        '            </soapenv:Body>\n' +
        '        </soapenv:Envelope>',
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}


export const rs_Bck_Demand_XML_409 = {
    data: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="urn://bancodebogota.com/accounts/product/service/" xmlns:nsi="urn://bancodebogota.com/ifx/base/v1/" xmlns:ns1="urn://bancodebogota.com/accounts/product/event/" xmlns:ns2="urn://bancodebogota.com/accounts/product/v1/" xmlns:ns3="urn://bancodebogota.com/ifx/lite/v1/">\n' +
        '<soapenv:Body>\n' +
        '   <ns:getDemandBalancesResponse>\n' +
        '      <ns1:DDABalInqRs>\n' +
        '         <nsi:RqUID>e2e8f084-7186-44f7-89c3-19bb0930716f</nsi:RqUID>\n' +
        '         <nsi:Status>\n' +
        '            <nsi:StatusCode>100</nsi:StatusCode>\n' +
        '            <nsi:ServerStatusCode>TS9260</nsi:ServerStatusCode>\n' +
        '            <nsi:Severity>Error</nsi:Severity>\n' +
        '            <nsi:StatusDesc>Error Generico</nsi:StatusDesc>\n' +
        '            <nsi:ServerStatusDesc>CTL1 TS9260 F: REG O CTA NO EXISTE STMEM01 00000033971920</nsi:ServerStatusDesc>\n' +
        '         </nsi:Status>\n' +
        '         <nsi:CustId>\n' +
        '            <nsi:CustLoginId>2006699</nsi:CustLoginId>\n' +
        '         </nsi:CustId>\n' +
        '         <nsi:NetworkTrnInfo>\n' +
        '            <nsi:NetworkOwner>SMP</nsi:NetworkOwner>\n' +
        '            <nsi:TerminalId>IN01</nsi:TerminalId>\n' +
        '            <nsi:BankId>001</nsi:BankId>\n' +
        '         </nsi:NetworkTrnInfo>\n' +
        '         <nsi:ServerDt>2023-03-22T09:25:26.759791-05:00</nsi:ServerDt>\n' +
        '      </ns1:DDABalInqRs>\n' +
        '   </ns:getDemandBalancesResponse>\n' +
        '</soapenv:Body>\n' +
        '</soapenv:Envelope>',
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_Demand_XML_500 = {
    'data': '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">\n' +
        '<soapenv:Header/>\n' +
        '<soapenv:Body>\n' +
        '<soapenv:Fault>\n' +
        '<faultcode>soapenv:Server</faultcode>\n' +
        '<faultstring>No es posible procesar la transaccion. Comuniquese con la Entidad</faultstring>\n' +
        '<detail>\n' +
        '<GeneralException>\n' +
        '<Status>\n' +
        '<StatusCode>100</StatusCode>\n' +
        '<ServerStatusCode>0x00d30003</ServerStatusCode>\n' +
        '<Severity>Error</Severity>\n' +
        '<StatusDesc>Fallas Tecnicas nos impiden procesar la Transaccion</StatusDesc>\n' +
        '<ServerStatusDesc>El canal BPM_1315 no </ServerStatusDesc>\n' +
        '</Status>\n' +
        '</GeneralException>\n' +
        '</detail>\n' +
        '</soapenv:Fault>\n' +
        '</soapenv:Body>\n' +
        '</soapenv:Envelope>\n',
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_Demand_REST_200 = {
    data: {
        "AcctBasicInfo": {
            "AcctId": "0128339173",
            "AcctType": "SDA"
        },
        "PersonInfo": {
            "GovIssueIdent": {
                "GovIssueIdentType": "C",
                "IdentSerialNum": "2006821"
            }
        },
        "AccountStatus": { "StatusCode": "00" },
        "OverdraftDays": "0",
        "AcctBal": [
            {
                "BalType": "Avail",
                "CurAmt": { "Amt": "22310225.70" }
            },
            {
                "BalType": "Current",
                "CurAmt": { "Amt": "22310225.70" }
            }
        ],
        "ExtAcctBal": [
            {
                "ExtBalType": "PendAuthAmt",
                "CurAmt": { "Amt": "0" }
            },
            {
                "ExtBalType": "LastStmtBal",
                "CurAmt": { "Amt": "21101670.7000" }
            },
            {
                "ExtBalType": "CashAvail",
                "CurAmt": { "Amt": "100000.0000" }
            }
        ],
        "RefInfo": [
            {
                "RefType": "ProdType",
                "RefId": "CCT"
            },
            {
                "RefType": "PayrollCode",
                "RefId": {}
            }
        ],
        "OpenDt": "05-12-2022",
        "Ownership": "01"
    },
    status: 200,
    code: 'OK',
    principalServiceUsed: false,
    circuitBreakerState: 'circuit breaker used'
}

export const rs_Bck_Demand_REST_409 = {
    data: {
        "error": {
            "codigo": "0x00d30003",
            "mensaje": "No existen datos para esta consulta",
            "mensajeNegocio": "Param mensajeNegocio no configurado",
            "tipo": "Param tipoError no configurado",
            "recurso": "Param recurso no configurado",
            "componente": "Param componente no configurado",
            "backend": "Param backend no configurado"
        }
    },
    status: 200,
    code: 'OK',
    principalServiceUsed: false,
    circuitBreakerState: 'circuit breaker used'
}

export const rs_Bck_Demand_REST_500 = {
    data: {
        "error": {
            "codigo": "0x00d30003",
            "mensaje": "No existen datos para esta consulta",
            "mensajeNegocio": "Param mensajeNegocio no configurado",
            "tipo": "Param tipoError no configurado",
            "recurso": "Param recurso no configurado",
            "componente": "Param componente no configurado",
            "backend": "Param backend no configurado"
        }
    },
    status: 500,
    code: 'OK',
    principalServiceUsed: false,
    circuitBreakerState: 'circuit breaker used'
}