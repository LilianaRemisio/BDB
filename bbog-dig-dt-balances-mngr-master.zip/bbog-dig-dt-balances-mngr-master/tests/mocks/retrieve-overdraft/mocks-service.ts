import { RequestHeadersModel } from "../../../src/model/RequestHeadersModel"
import { LoanQuotaHeadersModel } from "../../../src/model/loanquota-headers.model"
import { OverdraftHeadersModel } from "../../../src/model/Overdraft-headers.model"

export const rqGetRetrieveOverdraftRest_200 = {
    headers: {
        "Content-Type": "application/json",
        "X-CustIdentType": "CC",
        "X-CustIdentNum": "41496038",
        "X-IPAddr": "127.0.0.1",
        "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
        "X-Channel": "Web",
        "X-Name": "Transversales",
        "X-CompanyId": "001",
        "X-TerminalId": "BOP0",
        "X-NetworkOwner": "BPM_315",
        "x-api-key": "xxxx",
        'X-Journey': 'tes'
    }
}

export const rqGetRetrieveOverdraftRest_400 = {
    headers: {
        "Content-Type": "application/json",
        "X-CustIdentType": "CC",
        "X-CustIdentNum": "41496038",
        "X-IPAddr": "127.0.0.1",
        "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
        "X-Channel": "Web",
        "X-Name": "Transversales",
        "X-TerminalId": "BOP0",
        "X-NetworkOwner": "BPM_315",
        "x-api-key": "xxxx",
        'X-Journey': 'tes',
    }
}

export const rqGetRetrieveOverdraftRest_409 = {
    headers: {
        "Content-Type": "application/json",
        "X-CustIdentType": "CC",
        "X-CustIdentNum": "41496038",
        "X-IPAddr": "127.0.0.1",
        "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
        "X-Channel": "Web",
        "X-Name": "Transversales",
        "X-CompanyId": "001",
        "X-TerminalId": "BOP0",
        "X-NetworkOwner": "BPM_315",
        "x-api-key": "xxxx",
        'X-Journey': 'tes',
        "rate": "15.24",
        "amount": "2375202",
        "term": "36",
        "frequency": "D",
        "increase": "1",
        "accrualBase": "360",
        "accrualMethod": "366",
        "disbursementDate": "2024-03-06",
        "firstPaymentDate": "2023-05-06"
    }
}

export const rsGetRetrieveOverdraftRest_200 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac689",
    "Status": {
        "StatusCode": 0,
        "StatusDesc": "Transaccion exitosa",
        "Severity": "Info",
        "ServerStatusCode": "OK",
        "ServerStatusDesc": "200"
    },
    "EndDt": "2025-05-30T10:08:51",
    "AcctBalRec": {
        "AcctBasicInfo": {
            "AcctId": "343434",
            "AcctType": "DDA"
        },
        "AcctBal": {
            "EffDt": "2020-02-04",
            "ExpDt": "2025-11-24"
        }
    }
}

export const rsGetRetrieveOverdraftRest_409 = {
    "RqUID": "d5fb7166-ce61-406e-b97e-d92fa4e81ad3",
    "Status": {
        "StatusCode": 409,
        "StatusDesc": "Business Error",
        "Severity": "Error",
        "ServerStatusCode": "TS9260",
        "ServerStatusDesc": "CTL1 TS9260 F: REG O CTA NO EXISTE IMMEM04 0003433434"
    },
    "EndDt": "2025-03-06T07:18:39"
}

export const rsGetRetrieveOverdraftRest_408 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 408,
        "StatusDesc": "timeout of 3000ms exceeded",
        "Severity": "Error",
        "ServerStatusCode": "408",
        "ServerStatusDesc": "Error calling service getLoanBalanceService - Timeout"
    },
    "EndDt": "2024-12-09T10:31:20"
}

export const rsGetRetrieveOverdraftRest_500 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 500,
        "StatusDesc": "Internal Server Error",
        "Severity": "Error",
        "ServerStatusCode": 500,
        "ServerStatusDesc": "Request failed with status code 500"
    },
    "EndDt": "2024-12-09T10:31:01"
}

export const rsGetRetrieveOverdraftRest_500_1 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status1": {
        "StatusDesc": "Internal Server Error",
        "Severity": "Error",
        "ServerStatusCode": 500,
        "ServerStatusDesc": "Request failed with status code 500"
    },
    "EndDt": "2024-12-09T10:31:01"
}

export const rs_Bck_Overdraft_XML_200 = {
    data: `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="urn://bancodebogota.com/accounts/product/service/" xmlns:even="urn://bancodebogota.com/accounts/product/event/" xmlns:v1="urn://bancodebogota.com/ifx/base/v1/" xmlns:v11="urn://bancodebogota.com/accounts/product/v1/" xmlns:v12="urn://bancodebogota.com/ifx/lite/v1/">
    <soapenv:Body>
        <ser:getOverdraftBalancesResponse>
            <even:OverdraftBalancesInqRs>
                <v1:RqUID>532dea5e-c57b-4f18-be79-f0e0f743a3f7</v1:RqUID>
                <v1:Status>
                    <v1:StatusCode>0</v1:StatusCode>
                    <v1:ServerStatusCode>0</v1:ServerStatusCode>
                    <v1:Severity>Info</v1:Severity>
                    <v1:StatusDesc>Transaccion Exitosa</v1:StatusDesc>
                    <v1:ServerStatusDesc>Success</v1:ServerStatusDesc>
                </v1:Status>
                <v11:AcctBalRec>
                    <v12:AcctBasicInfo>
                        <v1:AcctId>343434</v1:AcctId>
                        <v1:AcctType>DDA</v1:AcctType>
                    </v12:AcctBasicInfo>
                    <v11:AcctBal>
                        <v1:EffDt>2020-02-04</v1:EffDt>
                        <v1:ExpDt>2025-11-24</v1:ExpDt>
                    </v11:AcctBal>
                </v11:AcctBalRec>
            </even:OverdraftBalancesInqRs>
        </ser:getOverdraftBalancesResponse>
    </soapenv:Body>
</soapenv:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_Overdraft_200_BussinessError = {
    data: `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="urn://bancodebogota.com/accounts/product/service/" xmlns:even="urn://bancodebogota.com/accounts/product/event/" xmlns:v1="urn://bancodebogota.com/ifx/base/v1/">
    <soapenv:Body>
        <ser:getOverdraftBalancesResponse>
            <even:OverdraftBalancesInqRs>
                <v1:RqUID>532dea5e-c57b-4f18-be79-f0e0f743a3f7</v1:RqUID>
                <v1:Status>
                    <v1:StatusCode>100</v1:StatusCode>
                    <v1:ServerStatusCode>TS9260</v1:ServerStatusCode>
                    <v1:Severity>Error</v1:Severity>
                    <v1:StatusDesc>Error Generico</v1:StatusDesc>
                    <v1:ServerStatusDesc>CTL1 TS9260 F: REG O CTA NO EXISTE IMMEM04 0003433434</v1:ServerStatusDesc>
                </v1:Status>
            </even:OverdraftBalancesInqRs>
        </ser:getOverdraftBalancesResponse>
    </soapenv:Body>
</soapenv:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_Overdraft_XML_500 = {
    data: `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <soapenv:Header/>
    <soapenv:Body>
        <soapenv:Fault>
            <faultcode>soapenv:Server</faultcode>
            <faultstring>No es posible procesar la transaccion. Comuniquese con la Entidad</faultstring>
            <detail>
                <GeneralException>
                    <Status>
                        <StatusCode>100</StatusCode>
                        <ServerStatusCode>0x00d30003</ServerStatusCode>
                        <Severity>Error</Severity>
                        <StatusDesc>Fallas Tecnicas nos impiden procesar la Transaccion</StatusDesc>
                        <ServerStatusDesc>El canal ddEMB no está parametrizado, debe enviar un valor de NetworkOwner correcto, para mas informacion con arquitectura de aplicaciones: En PowerApps CatalogoApps_AQA </ServerStatusDesc>
                    </Status>
                </GeneralException>
            </detail>
        </soapenv:Fault>
    </soapenv:Body>
</soapenv:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rq_LoanQuota_Rest_200: RequestHeadersModel = {
    "X-RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "X-Channel": "BancaVirtual",
    "X-CompanyId": "001",
    "X-CustIdentType": "CC",
    "X-CustIdentNum": "1080297719",
    "X-IPAddr": "100.20.30.40",
    "X-Journey": "001",
    "X-Name": "Banca Virtual",
    "X-TerminalId": "1234",
    "X-NetworkOwner": "1234"
}

export const rq_RetrieveOverdraftParams: OverdraftHeadersModel = {
    acctId: '2375202',
    acctType: 'DDA',
    refType: 'refType',
    refId: '1',
}

export const rq_RetrieveOverdraftParams_without_optionals: OverdraftHeadersModel = {
    acctId: '2375202',
    acctType: null,
    refType: null,
    refId: null,
}