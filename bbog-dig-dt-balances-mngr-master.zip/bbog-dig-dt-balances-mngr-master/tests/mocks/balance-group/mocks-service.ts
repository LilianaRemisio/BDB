import { RequestHeadersModel } from "../../../src/model/RequestHeadersModel"

export const rq_Group_Rest_200: RequestHeadersModel = {
    "X-RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "X-Channel": "BancaVirtual",
    "X-CompanyId": "001",
    "X-CustIdentType": "CC",
    "X-CustIdentNum": "1080297719",
    "X-IPAddr": "100.20.30.40",
    "X-Journey": "001",
    "X-Name": "Banca Virtual",
    "X-TerminalId": "1234",
    "X-NetworkOwner": "OPB001"
}


export const rqGetGroupBalanceRest_200 = {
    headers: {
        "X-RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
        "X-Channel": "BancaVirtual",
        "X-CompanyId": "001",
        "X-CustIdentType": "CC",
        "X-CustIdentNum": "1080297719",
        "X-IPAddr": "100.20.30.40",
        "X-Journey": "001",
        "X-Name": "Banca Virtual",
        "X-TerminalId": "1234",
        "X-NetworkOwner": "OPB001"
    },
    params: {
        acctId: "343435"
    },
    body: {
        "AccountsInfo": [
            {
                "AcctId": "0000959767",
                "AcctType": "SDA",
                "BankInfo": {
                    "BranchId": "001"
                }
            },
            {
                "AcctId": "0019507102",
                "AcctType": "DDA",
                "BankInfo": {
                    "BranchId": "001"
                }
            },
            {
                "AcctId": "001000164010",
                "AcctType": "FDA",
                "AcctSubType": "109FB",
                "BankInfo": {
                    "BranchId": "0890"
                }
            }
        ]
    }
}

export const rqGetGroupBalanceRest_200_SDA = {
    headers: {
        'X-CustIdentType': 'CC',
        'x-custidentnum': '41496038',
        'x-ipaddr': '127.0.0.1',
        'x-rquid': 'e956d488-b39e-48f7-ab11-670b06f9a7dd',
        'x-channel': 'Web',
        'x-journey': 'tes',
        'x-name': 'Transversales',
        'x-terminalid': 'BOP0',
        'x-companyid': '001',
    },
    params: {
        acctId: "343435"
    },
    body: {
        "AccountsInfo": [
            {
                "AcctId": "0000959767",
                "AcctType": "SDA",
                "BankInfo": {
                    "BranchId": "001"
                }
            }
        ]
    }
}

export const rqGetGroupBalanceRest_200_DDA = {
    headers: {
        'X-CustIdentType': 'CC',
        'x-custidentnum': '41496038',
        'x-ipaddr': '127.0.0.1',
        'x-rquid': 'e956d488-b39e-48f7-ab11-670b06f9a7dd',
        'x-channel': 'Web',
        'x-journey': 'tes',
        'x-name': 'Transversales',
        'x-terminalid': 'BOP0',
        'x-companyid': '001',
    },
    params: {
        acctId: "343435"
    },
    body: {
        "AccountsInfo": [
            {
                "AcctId": "0019507102",
                "AcctType": "DDA",
                "BankInfo": {
                    "BranchId": "001"
                }
            }
        ]
    }
}

export const rqGetGroupBalanceRest_200_FDA = {
    headers: {
        'X-CustIdentType': 'CC',
        'x-custidentnum': '41496038',
        'x-ipaddr': '127.0.0.1',
        'x-rquid': 'e956d488-b39e-48f7-ab11-670b06f9a7dd',
        'x-channel': 'Web',
        'x-journey': 'tes',
        'x-name': 'Transversales',
        'x-terminalid': 'BOP0',
        'x-companyid': '001',
    },
    params: {
        acctId: "343435"
    },
    body: {
        "AccountsInfo": [
            {
                "AcctId": "001000164010",
                "AcctType": "FDA",
                "AcctSubType": "109FB",
                "BankInfo": {
                    "BranchId": "0890"
                }
            }
        ]
    }
}

export const rqGetGroupBalanceRest_200_CCA = {
    headers: {
        'X-CustIdentType': 'CC',
        'x-custidentnum': '41496038',
        'x-ipaddr': '127.0.0.1',
        'x-rquid': 'e956d488-b39e-48f7-ab11-670b06f9a7dd',
        'x-channel': 'Web',
        'x-journey': 'tes',
        'x-name': 'Transversales',
        'x-terminalid': 'BOP0',
        'x-companyid': '001',
    },
    params: {
        acctId: "343435"
    },
    body: {
        "AccountsInfo": [
            {
                "AcctId": "0019507102",
                "AcctType": "CCA",
                "BankInfo": {
                    "BranchId": "001"
                }
            }
        ]
    }
}

export const rqGetGroupBalanceRest_200_CDA = {
    headers: {
        'X-CustIdentType': 'CC',
        'x-custidentnum': '41496038',
        'x-ipaddr': '127.0.0.1',
        'x-rquid': 'e956d488-b39e-48f7-ab11-670b06f9a7dd',
        'x-channel': 'Web',
        'x-journey': 'tes',
        'x-name': 'Transversales',
        'x-terminalid': 'BOP0',
        'x-companyid': '001',
    },
    params: {
        acctId: "343435"
    },
    body: {
        "AccountsInfo": [
            {
                "AcctId": "0019507102",
                "AcctType": "CDA",
                "BankInfo": {
                    "BranchId": "001"
                }
            }
        ]
    }
}

export const rqGetGroupBalanceRest_200_LOC = {
    headers: {
        'X-CustIdentType': 'CC',
        'x-custidentnum': '41496038',
        'x-ipaddr': '127.0.0.1',
        'x-rquid': 'e956d488-b39e-48f7-ab11-670b06f9a7dd',
        'x-channel': 'Web',
        'x-journey': 'tes',
        'x-name': 'Transversales',
        'x-terminalid': 'BOP0',
        'x-companyid': '001',
    },
    params: {
        acctId: "343435"
    },
    body: {
        "AccountsInfo": [
            {
                "AcctId": "0019507102",
                "AcctType": "LOC",
                "BankInfo": {
                    "BranchId": "001"
                }
            }
        ]
    }
}

export const rqGetGroupBalanceRest_200_TTT = {
    headers: {
        'X-CustIdentType': 'CC',
        'x-custidentnum': '41496038',
        'x-ipaddr': '127.0.0.1',
        'x-rquid': 'e956d488-b39e-48f7-ab11-670b06f9a7dd',
        'x-channel': 'Web',
        'x-journey': 'tes',
        'x-name': 'Transversales',
        'x-terminalid': 'BOP0',
        'x-companyid': '001',
    },
    params: {
        acctId: "343435"
    },
    body: {
        "AccountsInfo": [
            {
                "AcctId": "001000164010",
                "AcctType": "TTT",
                "AcctSubType": "109FB",
                "BankInfo": {
                    "BranchId": "0890"
                }
            }
        ]
    }
}

export const rsGetGroupBalanceRest_200 = {
    "RqUID": "7c852cee-fd07-4801-a9e0-54bd57149c49",
    "Status": {
        "StatusCode": 0,
        "StatusDesc": "Transaccion exitosa",
        "Severity": "Info",
        "ServerStatusCode": "0",
        "ServerStatusDesc": "Transaccion exitosa"
    },
    "EndDt": "2025-02-10T06:11:08",
    "AccInfo": [
        {
            "AcctBasicInfo": {
                "AcctId": "001000164010",
                "AcctType": "FDA",
                "AcctSubType": "",
                "AcctCur": "COP",
                "BankInfo": {
                    "BankId": "001",
                    "RefInfo": {
                        "RefType": "Fund",
                        "RefId": "109"
                    },
                    "BranchId": "8"
                }
            },
            "PersonInfo": {
                "FullName": "JOSE IVAN MUNOZ IBANEZ",
                "GovIssueIdent": {
                    "GovIssueIdentType": "C",
                    "IdentSerialNum": "19902734"
                }
            },
            "AccountStatus": {
                "StatusCode": "A",
                "StatusDesc": "Activo"
            },
            "AcctBal": [
                {
                    "BalType": "Avail",
                    "CurAmt": {
                        "Amt": "87315007.88",
                        "CurCode": "COP"
                    }
                },
                {
                    "BalType": "Current",
                    "CurAmt": {
                        "Amt": "92801857.62",
                        "CurCode": "COP"
                    }
                },
                {
                    "BalType": "TotalHeld",
                    "CurAmt": {
                        "Amt": "0",
                        "CurCode": "COP"
                    }
                }
            ],
            "ExtAcctBal": [
                {
                    "ExtBalType": "Redemption",
                    "CurAmt": {
                        "Amt": "0",
                        "CurCode": "COP"
                    }
                },
                {
                    "ExtBalType": "PendAuthAmt",
                    "CurAmt": {
                        "Amt": "0",
                        "CurCode": "COP"
                    }
                }
            ],
            "OwnerInd": null,
            "RefInfo": [],
            "OpenDt": "",
            "ExpDt": "",
            "PaidDt": "",
            "MinPmtCurAmt": null,
            "Term": null,
            "Rate": null,
            "OverdraftDays": null,
            "Fee": null,
            "NextPmtCurAmt": null,
            "DueDt": "",
            "Ownership": null,
            "FinalCurAmt": null
        },
        {
            "AcctBasicInfo": {
                "AcctId": "0000000000368548",
                "AcctType": "SDA",
                "AcctSubType": null,
                "AcctCur": null,
                "BankInfo": {
                    "BankId": null,
                    "RefInfo": {
                        "RefType": null,
                        "RefId": null
                    },
                    "BranchId": null
                }
            },
            "PersonInfo": {
                "FullName": null,
                "GovIssueIdent": {
                    "GovIssueIdentType": null,
                    "IdentSerialNum": null
                }
            },
            "AccountStatus": {
                "StatusCode": "00",
                "StatusDesc": "Active"
            },
            "AcctBal": [
                {
                    "BalType": "Avail",
                    "CurAmt": {
                        "Amt": "103248068.90",
                        "CurCode": "COP"
                    }
                },
                {
                    "BalType": "Current",
                    "CurAmt": {
                        "Amt": "103248068.90",
                        "CurCode": "COP"
                    }
                },
                {
                    "BalType": "CashAvail2",
                    "CurAmt": {
                        "Amt": "0.00",
                        "CurCode": "COP"
                    }
                }
            ],
            "ExtAcctBal": [
                {
                    "ExtBalType": "PendAuthAmt",
                    "CurAmt": {
                        "Amt": "0.00",
                        "CurCode": "COP"
                    }
                },
                {
                    "ExtBalType": "LastStmBal",
                    "CurAmt": {
                        "Amt": "103248068.90",
                        "CurCode": "COP"
                    }
                },
                {
                    "ExtBalType": "CashLimit",
                    "CurAmt": {
                        "Amt": "0.00",
                        "CurCode": "COP"
                    },
                    "EffDt": "2025-02-10T06:11:15.311313-05:00"
                },
                {
                    "ExtBalType": "CashAvail",
                    "CurAmt": {
                        "Amt": "0.00",
                        "CurCode": "COP"
                    },
                    "EffDt": "2025-02-10T06:11:15.311313-05:00"
                }
            ],
            "OwnerInd": "0",
            "RefInfo": [],
            "OpenDt": "",
            "ExpDt": "",
            "PaidDt": "2025-02-10",
            "MinPmtCurAmt": null,
            "Term": null,
            "Rate": null,
            "OverdraftDays": null,
            "Fee": null,
            "NextPmtCurAmt": null,
            "DueDt": "",
            "Ownership": null,
            "FinalCurAmt": null
        }
    ]
}

export const rsGetGroupBalanceRest_500 = {
    "RqUID": "7c852cee-fd07-4801-a9e0-54bd57149c49",
    "Status": {
        "StatusCode": 500,
        "StatusDesc": "Internal error",
        "Severity": "Error",
        "ServerStatusCode": 500,
        "ServerStatusDesc": "Internal error"
    },
    "EndDt": "2025-02-10T07:09:29"
}
