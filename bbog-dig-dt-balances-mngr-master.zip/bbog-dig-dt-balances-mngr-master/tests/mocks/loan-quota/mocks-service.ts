import { RequestHeadersModel } from "../../../src/model/RequestHeadersModel"
import { LoanQuotaHeadersModel } from "../../../src/model/loanquota-headers.model"

export const rqGetLoanQuotaBalanceRest_200 = {
   headers: {
      "Content-Type": "application/json",
      "X-CustIdentType": "CC",
      "X-CustIdentNum": "41496038",
      "X-IPAddr": "127.0.0.1",
      "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
      "X-Channel": "Web",
      "X-Name": "Transversales",
      "X-CompanyId": "001",
      "X-TerminalId": "BOP0",
      "X-NetworkOwner": "BPM_315",
      "x-api-key": "xxxx",
      'X-Journey': 'tes',
      "rate": "15.24",
      "amount": "2375202",
      "term": "36",
      "frequency": "D",
      "increase": "1",
      "accrualBase": "360",
      "accrualMethod": "366",
      "disbursementDate": "2024-03-06",
      "firstPaymentDate": "2024-05-06"
   }
}

export const rqGetLoanQuotaBalanceRest_400 = {
   headers: {
      "Content-Type": "application/json",
      "X-CustIdentType": "CC",
      "X-CustIdentNum": "41496038",
      "X-IPAddr": "127.0.0.1",
      "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
      "X-Channel": "Web",
      "X-Name": "Transversales",
      "X-CompanyId": "001",
      "X-TerminalId": "BOP0",
      "X-NetworkOwner": "BPM_315",
      "x-api-key": "xxxx",
      'X-Journey': 'tes',
      "amount": "2375202",
      "term": "36",
      "frequency": "D",
      "increase": "1",
      "accrualBase": "360",
      "accrualMethod": "366",
      "disbursementDate": "2024-03-06",
      "firstPaymentDate": "2024-05-06"
   }
}

export const rqGetLoanQuotaBalanceRest_409 = {
   headers: {
      "Content-Type": "application/json",
      "X-CustIdentType": "CC",
      "X-CustIdentNum": "41496038",
      "X-IPAddr": "127.0.0.1",
      "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
      "X-Channel": "Web",
      "X-Name": "Transversales",
      "X-CompanyId": "001",
      "X-TerminalId": "BOP0",
      "X-NetworkOwner": "BPM_315",
      "x-api-key": "xxxx",
      'X-Journey': 'tes',
      "rate": "15.24",
      "amount": "2375202",
      "term": "36",
      "frequency": "D",
      "increase": "1",
      "accrualBase": "360",
      "accrualMethod": "366",
      "disbursementDate": "2024-03-06",
      "firstPaymentDate": "2023-05-06"
   }
}

export const rsGetLoanQuotaBalanceRest_200 = {
   "RqUID": "d5fb7166-ce61-406e-b97e-d92fa4e81ad3",
   "Status": {
      "StatusCode": 0,
      "StatusDesc": "Transaccion exitosa",
      "Severity": "Info",
      "ServerStatusCode": "OK",
      "ServerStatusDesc": "200"
   },
   "EndDt": "2025-03-06T06:46:16",
   "InterestRate": "182.8800000",
   "InterestAmount": "969606.68",
   "TotalRepmtAmt": "3344808.68",
   "FlatAmount": "90583.58",
   "PaymentAmount": "92977.86",
   "MaturityDate": "2024-06-10"
}

export const rsGetLoanQuotaBalanceRest_409 = {
   "RqUID": "d5fb7166-ce61-406e-b97e-d92fa4e81ad3",
   "Status": {
      "StatusCode": 409,
      "StatusDesc": "Business Error",
      "Severity": "Error",
      "ServerStatusCode": "AM1806",
      "ServerStatusDesc": "AMPC AM1806 E: PRIMERA FCHA A PAGAR INVALIDA"
   },
   "EndDt": "2025-03-06T07:18:39"
}

export const rsGetLoanQuotaBalanceRest_408 = {
   "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
   "Status": {
      "StatusCode": 408,
      "StatusDesc": "timeout of 3000ms exceeded",
      "Severity": "Error",
      "ServerStatusCode": "408",
      "ServerStatusDesc": "Error calling service getLoanBalanceService - Timeout"
   },
   "EndDt": "2024-12-09T10:31:20"
}

export const rsGetLoanQuotaBalanceRest_500 = {
   "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
   "Status": {
      "StatusCode": 500,
      "StatusDesc": "Internal Server Error",
      "Severity": "Error",
      "ServerStatusCode": 500,
      "ServerStatusDesc": "Request failed with status code 500"
   },
   "EndDt": "2024-12-09T10:31:01"
}

export const rsGetLoanQuotaBalanceRest_500_1 = {
   "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
   "Status1": {
      "StatusDesc": "Internal Server Error",
      "Severity": "Error",
      "ServerStatusCode": 500,
      "ServerStatusDesc": "Request failed with status code 500"
   },
   "EndDt": "2024-12-09T10:31:01"
}

export const rs_Bck_LoanQuota_XML_200 = {
   data: `<NS1:Envelope xmlns:v12="urn://bancodebogota.com/creditcard/product/v1/" xmlns:v1="urn://bancodebogota.com/ifx/base/v1/" xmlns:ifx="urn://bancodebogota.com/ifx/" xmlns:even="urn://bancodebogota.com/customers/product/event/" xmlns:ser="urn://bancodebogota.com/customers/product/service/" xmlns:NS1="http://schemas.xmlsoap.org/soap/envelope/">
    <NS1:Body>
       <ser:getLoanQuotaResponse>
          <even:LoanQuotaInqRs>
             <v1:RqUID>5a18481f-0f84-4002-a2ea-5da0d2ee9f26</v1:RqUID>
             <v1:Status>
                <v1:StatusCode>0</v1:StatusCode>
                <v1:ServerStatusCode>0</v1:ServerStatusCode>
                <v1:Severity>Info</v1:Severity>
                <v1:StatusDesc>Transaccion Exitosa</v1:StatusDesc>
                <v1:ServerStatusDesc>Success</v1:ServerStatusDesc>
                <v1:AdditionalStatus>
                   <v1:StatusCode>0</v1:StatusCode>
                   <v1:Severity>Info</v1:Severity>
                   <v1:StatusDesc>Success</v1:StatusDesc>
                </v1:AdditionalStatus>
             </v1:Status>
             <v1:ServerDt>2025-03-05T17:58:51-05:00</v1:ServerDt>
             <v1:AcctBal>
                <v1:CurAmt>
                   <v1:Amt>182.8800000</v1:Amt>
                </v1:CurAmt>
                <v1:CurAmt>
                   <v1:Amt>969606.68</v1:Amt>
                </v1:CurAmt>
                <v1:CurAmt>
                   <v1:Amt>3344808.68</v1:Amt>
                </v1:CurAmt>
                <v1:CurAmt>
                   <v1:Amt>90583.58</v1:Amt>
                </v1:CurAmt>
                <v1:CurAmt>
                   <v1:Amt>92977.86</v1:Amt>
                </v1:CurAmt>
                <v1:EffDt>2024-06-10</v1:EffDt>
             </v1:AcctBal>
          </even:LoanQuotaInqRs>
       </ser:getLoanQuotaResponse>
    </NS1:Body>
 </NS1:Envelope>`,
   status: 200,
   code: 'OK',
   principalServiceUsed: true,
   circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_LoanQuota_XML_200_BussinessError = {
   data: `<NS1:Envelope xmlns:v12="urn://bancodebogota.com/creditcard/product/v1/" xmlns:v1="urn://bancodebogota.com/ifx/base/v1/" xmlns:ifx="urn://bancodebogota.com/ifx/" xmlns:even="urn://bancodebogota.com/customers/product/event/" xmlns:ser="urn://bancodebogota.com/customers/product/service/" xmlns:NS1="http://schemas.xmlsoap.org/soap/envelope/">
    <NS1:Body>
       <ser:getLoanQuotaResponse>
          <even:LoanQuotaInqRs>
             <v1:RqUID>5a18481f-0f84-4002-a2ea-5da0d2ee9f26</v1:RqUID>
             <v1:Status>
                <v1:StatusCode>100</v1:StatusCode>
                <v1:ServerStatusCode>AM1806</v1:ServerStatusCode>
                <v1:Severity>Error</v1:Severity>
                <v1:StatusDesc>Error Generico</v1:StatusDesc>
                <v1:ServerStatusDesc>AMPC AM1806 E: PRIMERA FCHA A PAGAR INVALIDA</v1:ServerStatusDesc>
                <v1:AdditionalStatus>
                   <v1:StatusCode>-1000</v1:StatusCode>
                   <v1:ServerStatusCode>-10361</v1:ServerStatusCode>
                   <v1:Severity>Error</v1:Severity>
                   <v1:StatusDesc>MESSAGES FOR AMB4 INQ   CANALES   AMB4PP0101</v1:StatusDesc>
                </v1:AdditionalStatus>
                <v1:AdditionalStatus>
                   <v1:StatusCode>100</v1:StatusCode>
                   <v1:ServerStatusCode>-10361</v1:ServerStatusCode>
                   <v1:Severity>Error</v1:Severity>
                   <v1:StatusDesc>TP en_US 100  General Error</v1:StatusDesc>
                </v1:AdditionalStatus>
                <v1:AdditionalStatus>
                   <v1:StatusCode>-1000</v1:StatusCode>
                   <v1:ServerStatusCode>-10361</v1:ServerStatusCode>
                   <v1:Severity>Error</v1:Severity>
                   <v1:StatusDesc>AMPC AM1806 E: PRIMERA FCHA A PAGAR INVALIDA</v1:StatusDesc>
                </v1:AdditionalStatus>
             </v1:Status>
          </even:LoanQuotaInqRs>
       </ser:getLoanQuotaResponse>
    </NS1:Body>
 </NS1:Envelope>`,
   status: 200,
   code: 'OK',
   principalServiceUsed: true,
   circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_LoanQuota_XML_200_single = {
   data: `<NS1:Envelope xmlns:v12="urn://bancodebogota.com/creditcard/product/v1/" xmlns:v1="urn://bancodebogota.com/ifx/base/v1/" xmlns:ifx="urn://bancodebogota.com/ifx/" xmlns:even="urn://bancodebogota.com/customers/product/event/" xmlns:ser="urn://bancodebogota.com/customers/product/service/" xmlns:NS1="http://schemas.xmlsoap.org/soap/envelope/">
    <NS1:Body>
       <ser:getLoanQuotaResponse>
          <even:LoanQuotaInqRs>
             <v1:RqUID>5a18481f-0f84-4002-a2ea-5da0d2ee9f26</v1:RqUID>
             <v1:Status>
                <v1:StatusCode>0</v1:StatusCode>
                <v1:ServerStatusCode>0</v1:ServerStatusCode>
                <v1:Severity>Info</v1:Severity>
                <v1:StatusDesc>Transaccion Exitosa</v1:StatusDesc>
                <v1:ServerStatusDesc>Success</v1:ServerStatusDesc>
                <v1:AdditionalStatus>
                   <v1:StatusCode>0</v1:StatusCode>
                   <v1:Severity>Info</v1:Severity>
                   <v1:StatusDesc>Success</v1:StatusDesc>
                </v1:AdditionalStatus>
             </v1:Status>
             <v1:ServerDt>2025-03-05T17:58:51-05:00</v1:ServerDt>
             <v1:AcctBal>
                <v1:CurAmt>
                   <v1:Amt>182.8800000</v1:Amt>
                </v1:CurAmt>
                <v1:EffDt>2024-06-10</v1:EffDt>
             </v1:AcctBal>
          </even:LoanQuotaInqRs>
       </ser:getLoanQuotaResponse>
    </NS1:Body>
 </NS1:Envelope>`,
   status: 200,
   code: 'OK',
   principalServiceUsed: true,
   circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_LoanQuota_XML_500 = {
   data: `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <soapenv:Header/>
    <soapenv:Body>
       <soapenv:Fault>
          <faultcode>soapenv:Server</faultcode>
          <faultstring>No es posible procesar la transaccion. Comuniquese con la Entidad</faultstring>
          <detail>
             <GeneralException>
                <Status>
                   <StatusCode>100</StatusCode>
                   <ServerStatusCode>0x00d30003</ServerStatusCode>
                   <Severity>Error</Severity>
                   <StatusDesc>Fallas Tecnicas nos impiden procesar la Transaccion</StatusDesc>
                   <ServerStatusDesc>El canal PB7 no está parametrizado, debe enviar un valor de NetworkOwner correcto, para mas informacion con arquitectura de aplicaciones: En PowerApps CatalogoApps_AQA</ServerStatusDesc>
                </Status>
             </GeneralException>
          </detail>
       </soapenv:Fault>
    </soapenv:Body>
 </soapenv:Envelope>`,
   status: 200,
   code: 'OK',
   principalServiceUsed: true,
   circuitBreakerState: 'circuit breaker not used'
}

export const rq_LoanQuota_Rest_200: RequestHeadersModel = {
   "X-RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
   "X-Channel": "BancaVirtual",
   "X-CompanyId": "001",
   "X-CustIdentType": "CC",
   "X-CustIdentNum": "1080297719",
   "X-IPAddr": "100.20.30.40",
   "X-Journey": "001",
   "X-Name": "Banca Virtual",
   "X-TerminalId": "1234",
   "X-NetworkOwner": "1234"
}

export const rq_loanQuotaParams: LoanQuotaHeadersModel = {
   rate: '15.24',
   amount: '2375202',
   term: '36',
   frequency: 'D',
   increase: '1',
   accrualBase: '360',
   accrualMethod: '366',
   disbursementDate: '2024-03-06',
   firstPaymentDate: '2023-05-06'
}