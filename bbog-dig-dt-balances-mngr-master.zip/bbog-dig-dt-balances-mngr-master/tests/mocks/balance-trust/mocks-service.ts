import { RequestHeadersModel } from "../../../src/model/RequestHeadersModel"
import { ReqHeadersAdditionalRest } from "../../../src/model/ReqHeadersAdditionalRest"

export const rq_Trust_Rest_200: ReqHeadersAdditionalRest = {
    "GeneralHeaders": {
      "X-RqUID": "a18eafa0-ce60-11e0-9572-999910867937",
      "X-Channel": "BancaVirtual",
      "X-CompanyId": "001",
      "X-CustIdentType": "CC",
      "X-CustIdentNum": "1080297719",
      "X-IPAddr": "100.20.30.40",
      "X-Name": "Banca Virtual",
      "X-TerminalId": "1234",
      "X-Journey": "1234",
      "X-NetworkOwner": "OPB001"
    },
    "BranchId": "0890",
    "AcctType": "FDA",
    "AcctSubType": "109FB"
  }


export const rq_Trust_Rest_200_Without_NetWorkOwner: RequestHeadersModel = {
    "X-RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "X-Channel": "BancaVirtual",
    "X-CompanyId": "001",
    "X-CustIdentType": "CC",
    "X-CustIdentNum": "1080297719",
    "X-IPAddr": "100.20.30.40",
    "X-Journey": "001",
    "X-Name": "Banca Virtual",
    "X-TerminalId": "1234",
    "X-NetworkOwner": null
}

export const rs_Bck_Trust_XML_200 = {
        data: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="urn://bancodebogota.com/accounts/product/service/" xmlns:nsi="urn://bancodebogota.com/ifx/base/v1/" xmlns:ns1="urn://bancodebogota.com/accounts/product/event/" xmlns:ns2="urn://bancodebogota.com/accounts/product/v1/" xmlns:ns3="urn://bancodebogota.com/ifx/lite/v1/" xmlns:ns4="urn://bancodebogota.com/ifx/base/v1/">\n' +
        '<soapenv:Body>\n' +
        '<ns:getTrustBalancesResponse>\n' +
        '    <ns1:TrustBalInqRs>\n' +
        '        <ns4:RqUID>9c16b564-241d-41b4-aa78-6d2b3635dd20</ns4:RqUID>\n' +
        '        <ns4:Status>\n' +
        '            <ns4:StatusCode>0</ns4:StatusCode>\n' +
        '            <ns4:ServerStatusCode>0</ns4:ServerStatusCode>\n' +
        '            <ns4:Severity>Info</ns4:Severity>\n' +
        '            <ns4:StatusDesc>Transaccion Exitosa</ns4:StatusDesc>\n' +
        '            <ns4:ServerStatusDesc>Transaccion Exitosa</ns4:ServerStatusDesc>\n' +
        '        </ns4:Status>\n' +
        '        <ns4:CustId>\n' +
        '            <ns4:CustLoginId>1080297719</ns4:CustLoginId>\n' +
        '        </ns4:CustId>\n' +
        '        <ns4:NetworkTrnInfo>\n' +
        '            <ns4:NetworkOwner>PB</ns4:NetworkOwner>\n' +
        '            <ns4:TerminalId>1234</ns4:TerminalId>\n' +
        '            <ns4:BankId>001</ns4:BankId>\n' +
        '        </ns4:NetworkTrnInfo>\n' +
        '        <ns2:TrustBalRec>\n' +
        '            <ns3:AcctBasicInfo>\n' +
        '            <ns4:AcctId>001000164010</ns4:AcctId>\n' +
        '            <ns4:AcctType>FDA</ns4:AcctType>\n' +
        '            <ns4:AcctSubType/>\n' +
        '            <ns4:AcctCur>COP</ns4:AcctCur>\n' +
        '            <ns3:BankInfo>\n' +
        '                <ns4:BankId>001</ns4:BankId>\n' +
        '                <ns3:RefInfo>\n' +
        '                    <ns4:RefType>Fund</ns4:RefType>\n' +
        '                    <ns4:RefId>109</ns4:RefId>\n' +
        '                </ns3:RefInfo>\n' +
        '                <ns4:BranchId>8</ns4:BranchId>\n' +
        '            </ns3:BankInfo>\n' +
        '            </ns3:AcctBasicInfo>\n' +
        '            <ns3:PersonInfo>\n' +
        '            <ns4:FullName>JOSE IVAN MUNOZ IBANEZ</ns4:FullName>\n' +
        '            <ns3:GovIssueIdent>\n' +
        '                <ns4:GovIssueIdentType>C</ns4:GovIssueIdentType>\n' +
        '                <ns4:IdentSerialNum>19902734</ns4:IdentSerialNum>\n' +
        '            </ns3:GovIssueIdent>\n' +
        '            </ns3:PersonInfo>\n' +
        '            <ns2:AccountStatus>\n' +
        '            <ns4:StatusCode>A</ns4:StatusCode>\n' +
        '            <ns4:StatusDesc>Activo</ns4:StatusDesc>\n' +
        '            </ns2:AccountStatus>\n' +
        '            <ns2:AcctBal>\n' +
        '            <ns4:BalType>Avail</ns4:BalType>\n' +
        '            <ns2:CurAmt>\n' +
        '                <ns4:Amt>87356872.98</ns4:Amt>\n' +
        '                <ns4:CurCode>COP</ns4:CurCode>\n' +
        '            </ns2:CurAmt>\n' +
        '            </ns2:AcctBal>\n' +
        '            <ns2:AcctBal>\n' +
        '            <ns4:BalType>Current</ns4:BalType>\n' +
        '            <ns2:CurAmt>\n' +
        '                <ns4:Amt>92847363.16</ns4:Amt>\n' +
        '                <ns4:CurCode>COP</ns4:CurCode>\n' +
        '            </ns2:CurAmt>\n' +
        '            </ns2:AcctBal>\n' +
        '            <ns2:AcctBal>\n' +
        '            <ns4:BalType>TotalHeld</ns4:BalType>\n' +
        '            <ns2:CurAmt>\n' +
        '                <ns4:Amt>0</ns4:Amt>\n' +
        '                <ns4:CurCode>COP</ns4:CurCode>\n' +
        '            </ns2:CurAmt>\n' +
        '            </ns2:AcctBal>\n' +
        '            <ns4:ExtAcctBal>\n' +
        '            <ns4:ExtBalType>Redemption</ns4:ExtBalType>\n' +
        '            <ns4:CurAmt>\n' +
        '                <ns4:Amt>0</ns4:Amt>\n' +
        '                <ns4:CurCode>COP</ns4:CurCode>\n' +
        '            </ns4:CurAmt>\n' +
        '            </ns4:ExtAcctBal>\n' +
        '            <ns4:ExtAcctBal>\n' +
        '            <ns4:ExtBalType>PendAuthAmt</ns4:ExtBalType>\n' +
        '            <ns4:CurAmt>\n' +
        '                <ns4:Amt>0</ns4:Amt>\n' +
        '                <ns4:CurCode>COP</ns4:CurCode>\n' +
        '            </ns4:CurAmt>\n' +
        '            </ns4:ExtAcctBal>\n' +
        '            <ns4:CanRecId/>\n' +
        '        </ns2:TrustBalRec>\n' +
        '    </ns1:TrustBalInqRs>\n' +
        '</ns:getTrustBalancesResponse>\n' +
        '</soapenv:Body>\n' +
    '</soapenv:Envelope>\n',
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_Trust_XML_200_single = {
    data: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="urn://bancodebogota.com/accounts/product/service/" xmlns:nsi="urn://bancodebogota.com/ifx/base/v1/" xmlns:ns1="urn://bancodebogota.com/accounts/product/event/" xmlns:ns2="urn://bancodebogota.com/accounts/product/v1/" xmlns:ns3="urn://bancodebogota.com/ifx/lite/v1/" xmlns:ns4="urn://bancodebogota.com/ifx/base/v1/">\n' +
    '<soapenv:Body>\n' +
    '<ns:getTrustBalancesResponse>\n' +
    '    <ns1:TrustBalInqRs>\n' +
    '        <ns4:RqUID>9c16b564-241d-41b4-aa78-6d2b3635dd20</ns4:RqUID>\n' +
    '        <ns4:Status>\n' +
    '            <ns4:StatusCode>0</ns4:StatusCode>\n' +
    '            <ns4:ServerStatusCode>0</ns4:ServerStatusCode>\n' +
    '            <ns4:Severity>Info</ns4:Severity>\n' +
    '            <ns4:StatusDesc>Transaccion Exitosa</ns4:StatusDesc>\n' +
    '            <ns4:ServerStatusDesc>Transaccion Exitosa</ns4:ServerStatusDesc>\n' +
    '        </ns4:Status>\n' +
    '        <ns4:CustId>\n' +
    '            <ns4:CustLoginId>1080297719</ns4:CustLoginId>\n' +
    '        </ns4:CustId>\n' +
    '        <ns4:NetworkTrnInfo>\n' +
    '            <ns4:NetworkOwner>PB</ns4:NetworkOwner>\n' +
    '            <ns4:TerminalId>1234</ns4:TerminalId>\n' +
    '            <ns4:BankId>001</ns4:BankId>\n' +
    '        </ns4:NetworkTrnInfo>\n' +
    '        <ns2:TrustBalRec>\n' +
    '            <ns3:AcctBasicInfo>\n' +
    '            <ns4:AcctId>001000164010</ns4:AcctId>\n' +
    '            <ns4:AcctType>FDA</ns4:AcctType>\n' +
    '            <ns4:AcctSubType/>\n' +
    '            <ns4:AcctCur>COP</ns4:AcctCur>\n' +
    '            <ns3:BankInfo>\n' +
    '                <ns4:BankId>001</ns4:BankId>\n' +
    '                <ns3:RefInfo>\n' +
    '                    <ns4:RefType>Fund</ns4:RefType>\n' +
    '                    <ns4:RefId>109</ns4:RefId>\n' +
    '                </ns3:RefInfo>\n' +
    '                <ns4:BranchId>8</ns4:BranchId>\n' +
    '            </ns3:BankInfo>\n' +
    '            </ns3:AcctBasicInfo>\n' +
    '            <ns3:PersonInfo>\n' +
    '            <ns4:FullName>JOSE IVAN MUNOZ IBANEZ</ns4:FullName>\n' +
    '            <ns3:GovIssueIdent>\n' +
    '                <ns4:GovIssueIdentType>C</ns4:GovIssueIdentType>\n' +
    '                <ns4:IdentSerialNum>19902734</ns4:IdentSerialNum>\n' +
    '            </ns3:GovIssueIdent>\n' +
    '            </ns3:PersonInfo>\n' +
    '            <ns2:AccountStatus>\n' +
    '            <ns4:StatusCode>A</ns4:StatusCode>\n' +
    '            <ns4:StatusDesc>Activo</ns4:StatusDesc>\n' +
    '            </ns2:AccountStatus>\n' +
    '            <ns2:AcctBal>\n' +
    '            <ns4:BalType>Avail</ns4:BalType>\n' +
    '            <ns2:CurAmt>\n' +
    '                <ns4:Amt>87356872.98</ns4:Amt>\n' +
    '                <ns4:CurCode>COP</ns4:CurCode>\n' +
    '            </ns2:CurAmt>\n' +
    '            </ns2:AcctBal>\n' +
 
    '            <ns4:ExtAcctBal>\n' +
    '            <ns4:ExtBalType>Redemption</ns4:ExtBalType>\n' +
    '            <ns4:CurAmt>\n' +
    '                <ns4:Amt>0</ns4:Amt>\n' +
    '                <ns4:CurCode>COP</ns4:CurCode>\n' +
    '            </ns4:CurAmt>\n' +
    '            </ns4:ExtAcctBal>\n' +
    '            <ns4:ExtAcctBal>\n' +
    '            <ns4:ExtBalType>PendAuthAmt</ns4:ExtBalType>\n' +
    '            <ns4:CurAmt>\n' +
    '                <ns4:Amt>0</ns4:Amt>\n' +
    '                <ns4:CurCode>COP</ns4:CurCode>\n' +
    '            </ns4:CurAmt>\n' +
    '            </ns4:ExtAcctBal>\n' +
    '            <ns4:CanRecId/>\n' +
    '        </ns2:TrustBalRec>\n' +
    '    </ns1:TrustBalInqRs>\n' +
    '</ns:getTrustBalancesResponse>\n' +
    '</soapenv:Body>\n' +
'</soapenv:Envelope>\n',
status: 200,
code: 'OK',
principalServiceUsed: true,
circuitBreakerState: 'circuit breaker not used'
}


export const rs_Bck_Trust_XML_409 = {
    data: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="urn://bancodebogota.com/accounts/product/service/" xmlns:nsi="urn://bancodebogota.com/ifx/base/v1/" xmlns:ns1="urn://bancodebogota.com/accounts/product/event/" xmlns:ns2="urn://bancodebogota.com/accounts/product/v1/" xmlns:ns3="urn://bancodebogota.com/ifx/lite/v1/" xmlns:ns4="urn://bancodebogota.com/ifx/base/v1/">' +
            '        <soapenv:Body>\n' +
            '        <ns:getTrustBalancesResponse>\n' +
            '            <ns1:TrustBalInqRs>\n' +
            '                <NS1:RqUID xmlns:NS1="urn://bancodebogota.com/ifx/base/v1/">9c16b564-241d-41b4-aa78-6d2b3635dd20</NS1:RqUID>\n' +
            '                <ns4:Status>\n' +
            '                    <ns4:StatusCode>100</ns4:StatusCode>\n' +
            '                    <ns4:ServerStatusCode xmlns:ns2="http://www.fidubogota.com/int-bancos/FBINBC000/FBINBC000_Commons">1401</ns4:ServerStatusCode>\n' +
            '                    <ns4:Severity>Error</ns4:Severity>\n' +
            '                    <ns4:StatusDesc>Error Generico</ns4:StatusDesc>\n' +
            '                    <ns4:ServerStatusDesc xmlns:ns2="http://www.fidubogota.com/int-bancos/FBINBC000/FBINBC000_Commons">Error plan o fondo no existe.</ns4:ServerStatusDesc>\n' +
            '                </ns4:Status>\n' +
            '            </ns1:TrustBalInqRs>\n' +
            '        </ns:getTrustBalancesResponse>\n' +
            '        </soapenv:Body>\n' +
            '    </soapenv:Envelope>',
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_Trust_XML_500 = {
    'data': '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">'+
    '                <soapenv:Header/>\n '+
    '                <soapenv:Body>\n '+
    '                <soapenv:Fault>\n '+
    '                    <faultcode>soapenv:Server</faultcode>\n '+
    '                    <faultstring>No es posible procesar la transaccion. Comuniquese con la Entidad</faultstring>\n '+
    '                    <detail>\n '+
    '                        <GeneralException>\n '+
    '                            <Status>\n '+
    '                            <StatusCode>100</StatusCode>\n '+
    '                            <ServerStatusCode>0x00d30003</ServerStatusCode>\n '+
    '                            <Severity>Error</Severity>\n '+
    '                            <StatusDesc>Fallas Tecnicas nos impiden procesar la Transaccion</StatusDesc>\n '+
    '                            <ServerStatusDesc>El canal PB11 no está parametrizado, debe enviar un valor de NetworkOwner correcto, para mas informacion con arquitectura de aplicaciones: En PowerApps CatalogoApps_AQA</ServerStatusDesc>\n '+
    '                            </Status>\n '+
    '                        </GeneralException>\n '+
    '                    </detail>\n '+
    '                </soapenv:Fault>\n '+
    '                </soapenv:Body>\n '+
    '            </soapenv:Envelope>',
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}


export const rs_Bck_Trust_REST_200 = {
    data: {
        "AcctBasicInfo": {
            "AcctId": "0000959767",
            "AcctType": "SDA",
            "BranchId": "0000"
        },
        "PersonInfo": {
            "GovIssueIdent": {
                "GovIssueIdentType": "C",
                "IdentSerialNum": "39540030"
            }
        },
        "AccountStatus": { "StatusCode": "01" },
        "AcctBal": [
            {
                "BalType": "Avail",
                "CurAmt": {"Amt": "2.00"}
            },
            {
                "BalType": "Current",
                "CurAmt": {"Amt": "2.00"}
            }
        ],
        "ExtAcctBal": [
            {
                "BalType": "PendAuthAmt",
                "CurAmt": {"Amt": "2.00"}
            },
            {
                "BalType": "LastStmtBal",
                "CurAmt": {"Amt": "2.00"}
            }
        ],
        "RefInfo": [
            {
                "RefType": "ProdType",
                "RefId": "CAH"
            },
            {
                "RefType": "PayrollCode",
                "RefId": "000"
            }
        ],
        "OpenDt": "06-03-2015",
        "Ownership": "01"
    },
    status: 200,
    code: 'OK',
    principalServiceUsed: false,
    circuitBreakerState: 'circuit breaker used'
}

export const rs_Bck_Trust_REST_500 = {
    data: {
        "error": {
            "codigo": "0x00d30003",
            "mensaje": "No existen datos para esta consulta",
            "mensajeNegocio": "Param mensajeNegocio no configurado",
            "tipo": "Param tipoError no configurado",
            "recurso": "Param recurso no configurado",
            "componente": "Param componente no configurado",
            "backend": "Param backend no configurado"
        }
    },
    status: 500,
    code: 'OK',
    principalServiceUsed: false,
    circuitBreakerState: 'circuit breaker used'
}

export const rs_Bck_Trust_REST_409 = {
    data: {
        "error": {
            "codigo": "0x00d30003",
            "mensaje": "No existen datos para esta consulta",
            "mensajeNegocio": "Param mensajeNegocio no configurado",
            "tipo": "Param tipoError no configurado",
            "recurso": "Param recurso no configurado",
            "componente": "Param componente no configurado",
            "backend": "Param backend no configurado"
        }
    },
    status: 200,
    code: 'OK',
    principalServiceUsed: false,
    circuitBreakerState: 'circuit breaker used'
}

export const rqGetTrustBalanceRest_200 = {
    headers: {
        "Content-Type": "application/json",
        "X-CustIdentType": "CC",
        "X-CustIdentNum": "41496038",
        "X-IPAddr": "127.0.0.1",
        "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
        "X-Channel": "Web",
        "X-Name": "Transversales",
        "X-CompanyId": "001",
        "X-TerminalId": "BOP0",
        "X-NetworkOwner": "BPM_315",
        'X-Journey': 'tes',
        "x-api-key": "xxxx"
    }
}

export const rqGetTrustBalanceRest_400 = {
    headers: {
        'X-CustIdentType': 'CT',
        'x-custidentnum': '41496038',
        'x-ipaddr': '127.0.0.1',
        'x-rquid': 'e956d488-b39e-48f7-ab11-670b06f9a7dd',
        'x-channel': 'Web',
        'x-journey': 'tes',
        'x-name': 'Transversales',
        'x-terminalid': 'BOP0',
        'x-companyid': '001',
    }
}

export const rqGetTrustBalanceRest_409 = {
    headers: {
        "Content-Type": "application/json",
        "X-CustIdentType": "CC",
        "X-CustIdentNum": "41496038",
        "X-IPAddr": "127.0.0.1",
        "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
        "X-Channel": "Web",
        "X-Name": "Transversales",
        'X-Journey': 'tes',
        "X-CompanyId": "001",
        "X-TerminalId": "BOP0",
        "X-NetworkOwner": "BPM_315",
        "x-api-key": "xxxx"
    },
    params: {
        acctId: "343435"
    }
}

export const rsGetTrustBalanceRest_200 = {
    "RqUID": "a18eafa0-ce60-11e0-9572-999910867937",
    "Status": {
        "StatusCode": 0,
        "StatusDesc": "Transaccion exitosa",
        "Severity": "Info",
        "ServerStatusCode": "OK",
        "ServerStatusDesc": "200"
    },
    "EndDt": "2025-01-23T15:48:15",
    "AccInfo": [
        {
            "AcctBasicInfo": {
                "AcctId": "001000164010",
                "AcctType": "FDA",
                "AcctSubType": "",
                "AcctCur": "COP",
                "BankInfo": {
                    "BankId": "001",
                    "RefInfo": {
                        "RefType": "Fund",
                        "RefId": "109"
                    },
                    "BranchId": "8"
                }
            },
            "PersonInfo": {
                "FullName": "JOSE IVAN MUNOZ IBANEZ",
                "GovIssueIdent": {
                    "GovIssueIdentType": "C",
                    "IdentSerialNum": "19902734"
                }
            },
            "AccountStatus": {
                "StatusCode": "A",
                "StatusDesc": "Activo"
            },
            "AcctBal": [
                {
                    "BalType": "Avail",
                    "CurAmt": {
                        "Amt": "87356872.98",
                        "CurCode": "COP"
                    }
                },
                {
                    "BalType": "Current",
                    "CurAmt": {
                        "Amt": "92847363.16",
                        "CurCode": "COP"
                    }
                },
                {
                    "BalType": "TotalHeld",
                    "CurAmt": {
                        "Amt": "0",
                        "CurCode": "COP"
                    }
                }
            ],
            "ExtAcctBal": [
                {
                    "ExtBalType": "Redemption",
                    "CurAmt": {
                        "Amt": "0",
                        "CurCode": "COP"
                    }
                },
                {
                    "ExtBalType": "PendAuthAmt",
                    "CurAmt": {
                        "Amt": "0",
                        "CurCode": "COP"
                    }
                }
            ],
            "OwnerInd": null,
            "RefInfo": [],
            "OpenDt": "",
            "ExpDt": "",
            "PaidDt": "",
            "MinPmtCurAmt": null,
            "Term": null,
            "Rate": null,
            "OverdraftDays": null,
            "Fee": null,
            "NextPmtCurAmt": null,
            "DueDt": "",
            "Ownership": null,
            "FinalCurAmt": null
        }
    ],
    "isPrincipalServiceUsed": true,
    "circuitBreakerState": "circuit breaker not used"
}



export const rsGetTrustBalanceRest_409 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 409,
        "StatusDesc": "Bussines Error",
        "Severity": "Error",
        "ServerStatusCode": "TS9260",
        "ServerStatusDesc": "CTL1 TS9260 F: REG O CTA NO EXISTE STMEM01 00000033971920"
    },
    "EndDt": "2024-12-09T10:29:23"
}

export const rsGetTrustBalanceRest_408 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 408,
        "StatusDesc": "timeout of 3000ms exceeded",
        "Severity": "Error",
        "ServerStatusCode": "408",
        "ServerStatusDesc": "Error calling service getSavignsBalanceService - Timeout"
    },
    "EndDt": "2024-12-09T10:31:20"
}

export const rsGetTrustBalanceRest_500 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 500,
        "StatusDesc": "Internal Server Error",
        "Severity": "Error",
        "ServerStatusCode": 500,
        "ServerStatusDesc": "Request failed with status code 500"
    },
    "EndDt": "2024-12-09T10:31:01"
}

export const rsGetTrustBalanceRest_500_1 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status1": {
        "StatusDesc": "Internal Server Error",
        "Severity": "Error",
        "ServerStatusCode": 500,
        "ServerStatusDesc": "Request failed with status code 500"
    },
    "EndDt": "2024-12-09T10:31:01"
}