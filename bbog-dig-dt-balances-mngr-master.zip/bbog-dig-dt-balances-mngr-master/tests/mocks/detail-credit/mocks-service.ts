import { RequestHeadersModel } from "../../../src/model/RequestHeadersModel"


export const rqGetDetailCreditInfoRest_200 = {
    headers: {
      "Content-Type": "application/json",
      "X-CustIdentType": "CC",
      "X-CustIdentNum": "41496038",
      "X-IPAddr": "127.0.0.1",
      "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
      "X-Channel": "Web",
      "X-Name": "Transversales",
      "X-CompanyId": "001",
      "X-TerminalId": "BOP0",
      'X-Journey': 'tes',
      "X-NetworkOwner": "BPM_315",
      "x-api-key": "xxxx"
    }
}

export const rqGetDetailCreditInfoRest_400 = {
    headers: {
      "Content-Type": "application/json",
      "X-CustIdentType": "CC",
      "X-CustIdentNum": "41496038",
      "X-IPAddr": "127.0.0.1",
      "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
      "X-Name": "Transversales",
      "X-CompanyId": "001",
      "X-TerminalId": "BOP0",
      'X-Journey': 'tes',
      "X-NetworkOwner": "BPM_315",
      "x-api-key": "xxxx"
    }
}

export const rqGetDetailCreditInfoRest_409 = {
    headers: {
        "Content-Type": "application/json",
        "X-CustIdentType": "CC",
        "X-CustIdentNum": "41496038",
        "X-IPAddr": "127.0.0.1",
        "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
        "X-Channel": "Web",
        "X-Name": "Transversales",
        "X-CompanyId": "001",
        "X-TerminalId": "BOP0",
        "X-NetworkOwner": "BPM_315",
        'X-Journey': 'tes',
        "x-api-key": "xxxx"
    },
    params: {
        acctId: "343435"
    }
}

export const rsGetDetailCreditInfoRest_200 = {
   "RqUID": "d5fb7166-ce61-406e-b97e-d92fa4e81ad3",
   "Status": {
       "StatusCode": 0,
       "StatusDesc": "Transaccion exitosa",
       "Severity": "Info",
       "ServerStatusCode": "OK",
       "ServerStatusDesc": "200"
   },
   "EndDt": "2025-02-23T17:07:45",
   "AccInfo": [
       {
           "AcctBasicInfo": {
               "AcctId": null,
               "AcctType": null,
               "AcctSubType": null,
               "AcctCur": null,
               "BankInfo": {
                   "BankId": null,
                   "RefInfo": {
                       "RefType": null,
                       "RefId": null
                   },
                   "BranchId": null
               }
           },
           "PersonInfo": {
               "FullName": "CLIENTE GENERICO AUTOMATIZACION PRU",
               "GovIssueIdent": {
                   "GovIssueIdentType": "C",
                   "IdentSerialNum": "001243088174"
               }
           },
           "AccountStatus": {
               "StatusCode": "",
               "StatusDesc": ""
           },
           "AcctBal": [
               {
                   "BalType": "BillCapital",
                   "CurAmt": {
                       "Amt": "30321600",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "BillRate",
                   "CurAmt": {
                       "Amt": "9936056.66",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "BillExpRate",
                   "CurAmt": {
                       "Amt": "10118154.77",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "BillExpenses",
                   "CurAmt": {
                       "Amt": "410067.00",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "PaidBillCapital",
                   "CurAmt": {
                       "Amt": "0",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "PaidBillRate",
                   "CurAmt": {
                       "Amt": "0.00",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "PaidBillExpRate",
                   "CurAmt": {
                       "Amt": "0.00",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "PaidBillExpenses",
                   "CurAmt": {
                       "Amt": "0.00",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "ExpBillCapital",
                   "CurAmt": {
                       "Amt": "23762192",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "ExpBillRate",
                   "CurAmt": {
                       "Amt": "9773087.98",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "ExpBillExpRate",
                   "CurAmt": {
                       "Amt": "8950235.09",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "ExpBillExpenses",
                   "CurAmt": {
                       "Amt": "156216.00",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "TotalAmtBill",
                   "CurAmt": {
                       "Amt": "43809650",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "TotalAmtPaidBill",
                   "CurAmt": {
                       "Amt": "0",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "TotalAmtExpBill",
                   "CurAmt": {
                       "Amt": "43809650",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "NextAmtFee",
                   "CurAmt": {
                       "Amt": "2190769.14",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "AbailableAmt",
                   "CurAmt": {
                       "Amt": "0",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "TotalCapitalDebt",
                   "CurAmt": {
                       "Amt": "30321600",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "TotalDebt",
                   "CurAmt": {
                       "Amt": "50785879",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "TotalBal",
                   "CurAmt": {
                       "Amt": "30321600",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "AmtFee",
                   "CurAmt": {
                       "Amt": "1663364.00",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "Commission01",
                   "CurAmt": {
                       "Amt": "0.00",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "Commission02",
                   "CurAmt": {
                       "Amt": "0.00",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "AmtDemand",
                   "CurAmt": {
                       "Amt": "43809650.77",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "FeesPaid",
                   "CurAmt": {
                       "Amt": "0.00",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "FeesPayable",
                   "CurAmt": {
                       "Amt": "0.00",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "RateWOutBen",
                   "CurAmt": {
                       "Amt": "33.2997300",
                       "CurCode": "COP"
                   }
               }
           ],
           "ExtAcctBal": [],
           "OwnerInd": null,
           "RefInfo": [],
           "OpenDt": "",
           "ExpDt": "",
           "PaidDt": "",
           "MinPmtCurAmt": null,
           "Term": {
               "Count": "24",
               "Freq": "M"
           },
           "Rate": null,
           "OverdraftDays": null,
           "Fee": {
               "FeeType": "CF",
               "CurAmt": {
                   "Amt": "0"
               }
           },
           "NextPmtCurAmt": null,
           "DueDt": "",
           "Ownership": null,
           "FinalCurAmt": null
       }
   ],
   "isPrincipalServiceUsed": true,
   "circuitBreakerState": "circuit breaker not used"
}



export const rsGetDetailCreditInfoRest_409 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac686",
    "Status": {
        "StatusCode": 409,
        "StatusDesc": "Business Error",
        "Severity": "Error",
        "ServerStatusCode": "VPL5SAI04E",
        "ServerStatusDesc": "REQUESTED CARD/ACCT NUMBER IS NOT NUMERIC OR EQUAL SPACES"
    },
    "EndDt": "2025-02-07T09:54:39"
}

export const rsGetDetailCreditInfoRest_408 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 408,
        "StatusDesc": "timeout of 3000ms exceeded",
        "Severity": "Error",
        "ServerStatusCode": "408",
        "ServerStatusDesc": "Error calling service getSavignsBalanceService - Timeout"
    },
    "EndDt": "2024-12-09T10:31:20"
}

export const rsGetDetailCreditInfoRest_500 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 500,
        "StatusDesc": "Internal Server Error",
        "Severity": "Error",
        "ServerStatusCode": 500,
        "ServerStatusDesc": "Request failed with status code 500"
    },
    "EndDt": "2024-12-09T10:31:01"
}

export const rsGetDetailCreditInfoRest_500_1 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status1": {
        "StatusDesc": "Internal Server Error",
        "Severity": "Error",
        "ServerStatusCode": 500,
        "ServerStatusDesc": "Request failed with status code 500"
    },
    "EndDt": "2024-12-09T10:31:01"
}

export const rs_Bck_DetailCredit_XML_200 = {
    data: `<NS1:Envelope xmlns:NS1="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="urn://bancodebogota.com/customers/product/service/" xmlns:even="urn://bancodebogota.com/customers/product/event/" xmlns:v11="urn://bancodebogota.com/ifx/lite/v1/" xmlns:ifx="urn://bancodebogota.com/ifx/" xmlns:ifxbase="urn://bancodebogota.com/ifx/base/v1/">
    <NS1:Body>
       <ser:getLoanAcctDetailResponse>
          <even:LoanAcctDetailInqRs>
             <ifxbase:RqUID>024b84a4-8b7a-4f9f-905b-0bf174138fc9</ifxbase:RqUID>
             <ifxbase:Status>
                <ifxbase:StatusCode>0</ifxbase:StatusCode>
                <ifxbase:ServerStatusCode>0</ifxbase:ServerStatusCode>
                <ifxbase:Severity>Info</ifxbase:Severity>
                <ifxbase:StatusDesc>Transaccion Exitosa</ifxbase:StatusDesc>
                <ifxbase:ServerStatusDesc>Success</ifxbase:ServerStatusDesc>
                <ifxbase:AdditionalStatus>
                   <ifxbase:StatusCode>0</ifxbase:StatusCode>
                   <ifxbase:Severity>Info</ifxbase:Severity>
                   <ifxbase:StatusDesc>Success</ifxbase:StatusDesc>
                </ifxbase:AdditionalStatus>
             </ifxbase:Status>
             <ifxbase:CreditDetailRec>
                <ifxbase:LoanAcctId>
                   <ifxbase:AcctId>00000559781590</ifxbase:AcctId>
                   <ifxbase:BankInfo>
                      <ifxbase:BranchId>1128</ifxbase:BranchId>
                   </ifxbase:BankInfo>
                </ifxbase:LoanAcctId>
                <v11:DepAcctId>
                   <ifxbase:AcctId>0000000001</ifxbase:AcctId>
                   <ifxbase:AcctType>01</ifxbase:AcctType>
                </v11:DepAcctId>
                <v11:PersonInfo>
                   <ifxbase:FullName>CLIENTE GENERICO AUTOMATIZACION PRU</ifxbase:FullName>
                   <v11:GovIssueIdent>
                      <ifxbase:GovIssueIdentType>C</ifxbase:GovIssueIdentType>
                      <ifxbase:IdentSerialNum>001243088174</ifxbase:IdentSerialNum>
                   </v11:GovIssueIdent>
                </v11:PersonInfo>
                <ifxbase:ProductId>BA81</ifxbase:ProductId>
                <ifxbase:SelRangeDt>
                   <ifxbase:StartDt>2023-05-23</ifxbase:StartDt>
                   <ifxbase:EndDt>2025-05-23</ifxbase:EndDt>
                </ifxbase:SelRangeDt>
                <ifxbase:IntRateInfo>
                   <ifxbase:Rate>29.0900000</ifxbase:Rate>
                   <ifxbase:Desc>V</ifxbase:Desc>
                   <ifxbase:IntAPY>33.2997300</ifxbase:IntAPY>
                </ifxbase:IntRateInfo>
                <ifxbase:InitialCurAmt>
                   <ifxbase:Amt>50785879</ifxbase:Amt>
                   <ifxbase:CurCode>024</ifxbase:CurCode>
                </ifxbase:InitialCurAmt>
                <ifxbase:ExpRate>51.1545500</ifxbase:ExpRate>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>BillCapital</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>30321600</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>BillRate</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>9936056.66</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>BillExpRate</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>10118154.77</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>BillExpenses</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>410067.00</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>PaidBillCapital</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>0</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>PaidBillRate</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>0.00</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>PaidBillExpRate</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>0.00</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>PaidBillExpenses</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>0.00</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>ExpBillCapital</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>23762192</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>ExpBillRate</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>9773087.98</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>ExpBillExpRate</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>8950235.09</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>ExpBillExpenses</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>156216.00</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>TotalAmtBill</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>43809650</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>TotalAmtPaidBill</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>0</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>TotalAmtExpBill</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>43809650</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>NextAmtFee</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>2190769.14</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>AbailableAmt</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>0</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>TotalCapitalDebt</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>30321600</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>TotalDebt</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>50785879</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>TotalBal</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>30321600</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>AmtFee</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>1663364.00</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>Commission01</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>0.00</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>Commission02</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>0.00</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>AmtDemand</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>43809650.77</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>FeesPaid</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>0.00</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>FeesPayable</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>0.00</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>RateWOutBen</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>33.2997300</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                <ifxbase:LoanInfoCommon>
                   <ifxbase:PurposeDesc>0.0000000</ifxbase:PurposeDesc>
                   <ifxbase:CollateralDesc>0</ifxbase:CollateralDesc>
                   <ifxbase:DueDt>2023-06-23</ifxbase:DueDt>
                   <ifxbase:NextPmtCurAmt>
                      <ifxbase:Amt>0</ifxbase:Amt>
                   </ifxbase:NextPmtCurAmt>
                   <ifxbase:LastPmtDt>0002-12-31</ifxbase:LastPmtDt>
                </ifxbase:LoanInfoCommon>
                <ifxbase:Term>
                   <ifxbase:Count>24</ifxbase:Count>
                   <ifxbase:Freq>M</ifxbase:Freq>
                </ifxbase:Term>
                <ifxbase:Fee>
                   <ifxbase:FeeType>CF</ifxbase:FeeType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>0</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:Fee>
                <ifxbase:DayPastDue>599</ifxbase:DayPastDue>
                <ifxbase:RateInfoType>F</ifxbase:RateInfoType>
                <ifxbase:CurAmtFeeStatus>0</ifxbase:CurAmtFeeStatus>
                <ifxbase:LawyerType>0</ifxbase:LawyerType>
                <ifxbase:LegalStep>0</ifxbase:LegalStep>
             </ifxbase:CreditDetailRec>
          </even:LoanAcctDetailInqRs>
       </ser:getLoanAcctDetailResponse>
    </NS1:Body>
 </NS1:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_DetailCredit_XML_200_single = {
    data: `<NS1:Envelope xmlns:NS1="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="urn://bancodebogota.com/customers/product/service/" xmlns:even="urn://bancodebogota.com/customers/product/event/" xmlns:v11="urn://bancodebogota.com/ifx/lite/v1/" xmlns:ifx="urn://bancodebogota.com/ifx/" xmlns:ifxbase="urn://bancodebogota.com/ifx/base/v1/">
    <NS1:Body>
       <ser:getLoanAcctDetailResponse>
          <even:LoanAcctDetailInqRs>
             <ifxbase:RqUID>024b84a4-8b7a-4f9f-905b-0bf174138fc9</ifxbase:RqUID>
             <ifxbase:Status>
                <ifxbase:StatusCode>0</ifxbase:StatusCode>
                <ifxbase:ServerStatusCode>0</ifxbase:ServerStatusCode>
                <ifxbase:Severity>Info</ifxbase:Severity>
                <ifxbase:StatusDesc>Transaccion Exitosa</ifxbase:StatusDesc>
                <ifxbase:ServerStatusDesc>Success</ifxbase:ServerStatusDesc>
                <ifxbase:AdditionalStatus>
                   <ifxbase:StatusCode>0</ifxbase:StatusCode>
                   <ifxbase:Severity>Info</ifxbase:Severity>
                   <ifxbase:StatusDesc>Success</ifxbase:StatusDesc>
                </ifxbase:AdditionalStatus>
             </ifxbase:Status>
             <ifxbase:CreditDetailRec>
                <ifxbase:LoanAcctId>
                   <ifxbase:AcctId>00000559781590</ifxbase:AcctId>
                   <ifxbase:BankInfo>
                      <ifxbase:BranchId>1128</ifxbase:BranchId>
                   </ifxbase:BankInfo>
                </ifxbase:LoanAcctId>
                <v11:DepAcctId>
                   <ifxbase:AcctId>0000000001</ifxbase:AcctId>
                   <ifxbase:AcctType>01</ifxbase:AcctType>
                </v11:DepAcctId>
                <v11:PersonInfo>
                   <ifxbase:FullName>CLIENTE GENERICO AUTOMATIZACION PRU</ifxbase:FullName>
                   <v11:GovIssueIdent>
                      <ifxbase:GovIssueIdentType>C</ifxbase:GovIssueIdentType>
                      <ifxbase:IdentSerialNum>001243088174</ifxbase:IdentSerialNum>
                   </v11:GovIssueIdent>
                </v11:PersonInfo>
                <ifxbase:ProductId>BA81</ifxbase:ProductId>
                <ifxbase:SelRangeDt>
                   <ifxbase:StartDt>2023-05-23</ifxbase:StartDt>
                   <ifxbase:EndDt>2025-05-23</ifxbase:EndDt>
                </ifxbase:SelRangeDt>
                <ifxbase:IntRateInfo>
                   <ifxbase:Rate>29.0900000</ifxbase:Rate>
                   <ifxbase:Desc>V</ifxbase:Desc>
                   <ifxbase:IntAPY>33.2997300</ifxbase:IntAPY>
                </ifxbase:IntRateInfo>
                <ifxbase:InitialCurAmt>
                   <ifxbase:Amt>50785879</ifxbase:Amt>
                   <ifxbase:CurCode>024</ifxbase:CurCode>
                </ifxbase:InitialCurAmt>
                <ifxbase:ExpRate>51.1545500</ifxbase:ExpRate>
                <ifxbase:AcctBal>
                   <ifxbase:BalType>BillCapital</ifxbase:BalType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>30321600</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:AcctBal>
                
                <ifxbase:LoanInfoCommon>
                   <ifxbase:PurposeDesc>0.0000000</ifxbase:PurposeDesc>
                   <ifxbase:CollateralDesc>0</ifxbase:CollateralDesc>
                   <ifxbase:DueDt>2023-06-23</ifxbase:DueDt>
                   <ifxbase:NextPmtCurAmt>
                      <ifxbase:Amt>0</ifxbase:Amt>
                   </ifxbase:NextPmtCurAmt>
                   <ifxbase:LastPmtDt>0002-12-31</ifxbase:LastPmtDt>
                </ifxbase:LoanInfoCommon>
                <ifxbase:Term>
                   <ifxbase:Count>24</ifxbase:Count>
                   <ifxbase:Freq>M</ifxbase:Freq>
                </ifxbase:Term>
                <ifxbase:Fee>
                   <ifxbase:FeeType>CF</ifxbase:FeeType>
                   <ifxbase:CurAmt>
                      <ifxbase:Amt>0</ifxbase:Amt>
                   </ifxbase:CurAmt>
                </ifxbase:Fee>
                <ifxbase:DayPastDue>599</ifxbase:DayPastDue>
                <ifxbase:RateInfoType>F</ifxbase:RateInfoType>
                <ifxbase:CurAmtFeeStatus>0</ifxbase:CurAmtFeeStatus>
                <ifxbase:LawyerType>0</ifxbase:LawyerType>
                <ifxbase:LegalStep>0</ifxbase:LegalStep>
             </ifxbase:CreditDetailRec>
          </even:LoanAcctDetailInqRs>
       </ser:getLoanAcctDetailResponse>
    </NS1:Body>
 </NS1:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}


export const rs_Bck_DetailCredit_XML_409 = {
    data: `<NS1:Envelope xmlns:NS1="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ser="urn://bancodebogota.com/customers/product/service/" xmlns:even="urn://bancodebogota.com/customers/product/event/" xmlns:v11="urn://bancodebogota.com/ifx/lite/v1/" xmlns:ifx="urn://bancodebogota.com/ifx/" xmlns:ifxbase="urn://bancodebogota.com/ifx/base/v1/">
    <NS1:Body>
       <ser:getLoanAcctDetailResponse>
          <even:LoanAcctDetailInqRs>
             <ifxbase:RqUID>024b84a4-8b7a-4f9f-905b-0bf174138fc9</ifxbase:RqUID>
             <ifxbase:Status>
                <ifxbase:StatusCode>100</ifxbase:StatusCode>
                <ifxbase:ServerStatusCode>AM1047</ifxbase:ServerStatusCode>
                <ifxbase:Severity>Error</ifxbase:Severity>
                <ifxbase:StatusDesc>Error Generico</ifxbase:StatusDesc>
                <ifxbase:ServerStatusDesc>AMPC AM1047 E: NO SE ENCUENTRA CUENTA</ifxbase:ServerStatusDesc>
                <ifxbase:AdditionalStatus>
                   <ifxbase:StatusCode>-1000</ifxbase:StatusCode>
                   <ifxbase:ServerStatusCode>-10361</ifxbase:ServerStatusCode>
                   <ifxbase:Severity>Error</ifxbase:Severity>
                   <ifxbase:StatusDesc>MESSAGES FOR NATIVE ACC 00005597815901</ifxbase:StatusDesc>
                </ifxbase:AdditionalStatus>
                <ifxbase:AdditionalStatus>
                   <ifxbase:StatusCode>100</ifxbase:StatusCode>
                   <ifxbase:ServerStatusCode>-10361</ifxbase:ServerStatusCode>
                   <ifxbase:Severity>Error</ifxbase:Severity>
                   <ifxbase:StatusDesc>TP en_US 100  General Error</ifxbase:StatusDesc>
                </ifxbase:AdditionalStatus>
                <ifxbase:AdditionalStatus>
                   <ifxbase:StatusCode>-1000</ifxbase:StatusCode>
                   <ifxbase:ServerStatusCode>-10361</ifxbase:ServerStatusCode>
                   <ifxbase:Severity>Error</ifxbase:Severity>
                   <ifxbase:StatusDesc>AMPC AM1047 E: NO SE ENCUENTRA CUENTA</ifxbase:StatusDesc>
                </ifxbase:AdditionalStatus>
             </ifxbase:Status>
             <ifxbase:CreditDetailRec/>
          </even:LoanAcctDetailInqRs>
       </ser:getLoanAcctDetailResponse>
    </NS1:Body>
 </NS1:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_DetailCredit_XML_500 = {
    data: `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <soapenv:Header/>
    <soapenv:Body>
       <soapenv:Fault>
          <faultcode>soapenv:Server</faultcode>
          <faultstring>No es posible procesar la transaccion. Comuniquese con la Entidad</faultstring>
          <detail>
             <GeneralException>
                <Status>
                   <StatusCode>100</StatusCode>
                   <ServerStatusCode>0x00d30003</ServerStatusCode>
                   <Severity>Error</Severity>
                   <StatusDesc>Fallas Tecnicas nos impiden procesar la Transaccion</StatusDesc>
                   <ServerStatusDesc>El canal PB7 no está parametrizado, debe enviar un valor de NetworkOwner correcto, para mas informacion con arquitectura de aplicaciones: En PowerApps CatalogoApps_AQA</ServerStatusDesc>
                </Status>
             </GeneralException>
          </detail>
       </soapenv:Fault>
    </soapenv:Body>
 </soapenv:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}



export const rq_DetailCredit_Rest_200: RequestHeadersModel = {
    "X-RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "X-Channel": "BancaVirtual",
    "X-CompanyId": "001",
    "X-CustIdentType": "CC",
    "X-CustIdentNum": "1080297719",
    "X-IPAddr": "100.20.30.40",
    "X-Journey": "001",
    "X-Name": "Banca Virtual",
    "X-TerminalId": "1234",
    "X-NetworkOwner": "1234"
}