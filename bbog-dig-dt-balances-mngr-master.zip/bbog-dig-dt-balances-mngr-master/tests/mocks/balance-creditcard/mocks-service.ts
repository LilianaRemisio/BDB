import { RequestHeadersModel } from "../../../src/model/RequestHeadersModel"


export const rqGetCreditCardBalanceRest_200 = {
    headers: {
      "Content-Type": "application/json",
      "X-CustIdentType": "CC",
      "X-CustIdentNum": "41496038",
      "X-IPAddr": "127.0.0.1",
      "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
      "X-Channel": "Web",
      "X-Name": "Transversales",
      "X-CompanyId": "001",
      "X-TerminalId": "BOP0",
      'X-Journey': 'tes',
      "X-NetworkOwner": "BPM_315",
      "x-api-key": "xxxx"
    }
}

export const rqGetCreditCardBalanceRest_400 = {
    headers: {
      "Content-Type": "application/json",
      "X-CustIdentType": "CC",
      "X-CustIdentNum": "41496038",
      "X-IPAddr": "127.0.0.1",
      "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
      "X-Name": "Transversales",
      "X-CompanyId": "001",
      "X-TerminalId": "BOP0",
      'X-Journey': 'tes',
      "X-NetworkOwner": "BPM_315",
      "x-api-key": "xxxx"
    }
}

export const rqGetCreditCardBalanceRest_409 = {
    headers: {
        "Content-Type": "application/json",
        "X-CustIdentType": "CC",
        "X-CustIdentNum": "41496038",
        "X-IPAddr": "127.0.0.1",
        "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
        "X-Channel": "Web",
        "X-Name": "Transversales",
        "X-CompanyId": "001",
        "X-TerminalId": "BOP0",
        "X-NetworkOwner": "BPM_315",
        'X-Journey': 'tes',
        "x-api-key": "xxxx"
    },
    params: {
        acctId: "343435"
    }
}

export const rsGetCreditCardBalanceRest_200 = {
    "RqUID": "a18eafa0-ce60-11e0-9572-999910867937",
    "Status": {
        "StatusCode": 0,
        "StatusDesc": "Transaccion exitosa",
        "Severity": "Info",
        "ServerStatusCode": "OK",
        "ServerStatusDesc": "200"
    },
    "EndDt": "2025-01-23T15:48:15",
    "AccInfo": [
        {
            "AcctBasicInfo": {
                "AcctId": "001000164010",
                "AcctType": "FDA",
                "AcctSubType": "",
                "AcctCur": "COP",
                "BankInfo": {
                    "BankId": "001",
                    "RefInfo": {
                        "RefType": "Fund",
                        "RefId": "109"
                    },
                    "BranchId": "8"
                }
            },
            "PersonInfo": {
                "FullName": "JOSE IVAN MUNOZ IBANEZ",
                "GovIssueIdent": {
                    "GovIssueIdentType": "C",
                    "IdentSerialNum": "19902734"
                }
            },
            "AccountStatus": {
                "StatusCode": "A",
                "StatusDesc": "Activo"
            },
            "AcctBal": [
                {
                    "BalType": "Avail",
                    "CurAmt": {
                        "Amt": "87356872.98",
                        "CurCode": "COP"
                    }
                },
                {
                    "BalType": "Current",
                    "CurAmt": {
                        "Amt": "92847363.16",
                        "CurCode": "COP"
                    }
                },
                {
                    "BalType": "TotalHeld",
                    "CurAmt": {
                        "Amt": "0",
                        "CurCode": "COP"
                    }
                }
            ],
            "ExtAcctBal": [
                {
                    "ExtBalType": "Redemption",
                    "CurAmt": {
                        "Amt": "0",
                        "CurCode": "COP"
                    }
                },
                {
                    "ExtBalType": "PendAuthAmt",
                    "CurAmt": {
                        "Amt": "0",
                        "CurCode": "COP"
                    }
                }
            ],
            "OwnerInd": null,
            "RefInfo": [],
            "OpenDt": "",
            "ExpDt": "",
            "PaidDt": "",
            "MinPmtCurAmt": null,
            "Term": null,
            "Rate": null,
            "OverdraftDays": null,
            "Fee": null,
            "NextPmtCurAmt": null,
            "DueDt": "",
            "Ownership": null,
            "FinalCurAmt": null
        }
    ],
    "isPrincipalServiceUsed": true,
    "circuitBreakerState": "circuit breaker not used"
}



export const rsGetCreditCardBalanceRest_409 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac686",
    "Status": {
        "StatusCode": 409,
        "StatusDesc": "Business Error",
        "Severity": "Error",
        "ServerStatusCode": "VPL5SAI04E",
        "ServerStatusDesc": "REQUESTED CARD/ACCT NUMBER IS NOT NUMERIC OR EQUAL SPACES"
    },
    "EndDt": "2025-02-07T09:54:39"
}

export const rsGetCreditCardBalanceRest_408 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 408,
        "StatusDesc": "timeout of 3000ms exceeded",
        "Severity": "Error",
        "ServerStatusCode": "408",
        "ServerStatusDesc": "Error calling service getSavignsBalanceService - Timeout"
    },
    "EndDt": "2024-12-09T10:31:20"
}

export const rsGetCreditCardBalanceRest_500 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 500,
        "StatusDesc": "Internal Server Error",
        "Severity": "Error",
        "ServerStatusCode": 500,
        "ServerStatusDesc": "Request failed with status code 500"
    },
    "EndDt": "2024-12-09T10:31:01"
}

export const rsGetCreditCardBalanceRest_500_1 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status1": {
        "StatusDesc": "Internal Server Error",
        "Severity": "Error",
        "ServerStatusCode": 500,
        "ServerStatusDesc": "Request failed with status code 500"
    },
    "EndDt": "2024-12-09T10:31:01"
}

export const rs_Bck_CreditCard_XML_200 = {
    data: `<soapenv:Envelope xmlns:ns3="urn://bancodebogota.com/accounts/product/v1/" xmlns:ns2="urn://bancodebogota.com/accounts/product/v1/" xmlns:ns1="urn://bancodebogota.com/accounts/product/event/" xmlns:nsi="urn://bancodebogota.com/ifx/base/v1/" xmlns:ns="urn://bancodebogota.com/accounts/product/service/" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <soapenv:Body>
       <ns:getCreditCardBalancesResponse>
          <ns1:CCABalInqRs>
             <nsi:RqUID>7bfd2017-3260-4294-acfd-722db4decf02</nsi:RqUID>
             <nsi:Status>
                <nsi:StatusCode>0</nsi:StatusCode>
                <nsi:ServerStatusCode>0</nsi:ServerStatusCode>
                <nsi:Severity>Info</nsi:Severity>
                <nsi:StatusDesc>Transaccion Exitosa</nsi:StatusDesc>
                <nsi:ServerStatusDesc>Transaccion Exitosa</nsi:ServerStatusDesc>
             </nsi:Status>
             <nsi:CustId>
                <nsi:CustLoginId>1022426979</nsi:CustLoginId>
             </nsi:CustId>
             <nsi:NetworkTrnInfo>
                <nsi:NetworkOwner>PB</nsi:NetworkOwner>
                <nsi:TerminalId>1234</nsi:TerminalId>
                <nsi:BankId>001</nsi:BankId>
             </nsi:NetworkTrnInfo>
             <nsi:ServerDt>2025-02-07T14:09:58</nsi:ServerDt>
             <ns3:CCABalRec>
                <NS1:AcctBasicInfo xmlns:NS1="urn://bancodebogota.com/ifx/lite/v1/">
                   <nsi:AcctId>0008001030001608727</nsi:AcctId>
                   <nsi:AcctType>CCA</nsi:AcctType>
                </NS1:AcctBasicInfo>
                <ns3:AcctBal>
                   <nsi:BalType>Avail</nsi:BalType>
                   <ns3:CurAmt>
                      <nsi:Amt>2000000.00</nsi:Amt>
                   </ns3:CurAmt>
                </ns3:AcctBal>
                <ns3:AcctBal>
                   <nsi:BalType>Outstanding</nsi:BalType>
                   <ns3:CurAmt>
                      <nsi:Amt>0.00</nsi:Amt>
                   </ns3:CurAmt>
                </ns3:AcctBal>
                <ns3:AcctBal>
                   <nsi:BalType>AvailCredit</nsi:BalType>
                   <ns3:CurAmt>
                      <nsi:Amt>2000000.00</nsi:Amt>
                   </ns3:CurAmt>
                </ns3:AcctBal>
                <ns3:AcctBal>
                   <nsi:BalType>CreditLimit</nsi:BalType>
                   <ns3:CurAmt>
                      <nsi:Amt>2000000.00</nsi:Amt>
                   </ns3:CurAmt>
                </ns3:AcctBal>
                <ns3:AcctBal>
                   <nsi:BalType>PayoffAmt</nsi:BalType>
                   <ns3:CurAmt>
                      <nsi:Amt>0.00</nsi:Amt>
                   </ns3:CurAmt>
                </ns3:AcctBal>
                <nsi:ExtAcctBal>
                   <nsi:ExtBalType>CashAvail</nsi:ExtBalType>
                   <nsi:CurAmt>
                      <nsi:Amt>0.00</nsi:Amt>
                   </nsi:CurAmt>
                </nsi:ExtAcctBal>
                <nsi:MinPmtCurAmt>
                   <nsi:Amt>0.00</nsi:Amt>
                </nsi:MinPmtCurAmt>
             </ns3:CCABalRec>
          </ns1:CCABalInqRs>
       </ns:getCreditCardBalancesResponse>
    </soapenv:Body>
 </soapenv:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_CreditCard_XML_200_single = {
    data: `<soapenv:Envelope xmlns:ns3="urn://bancodebogota.com/accounts/product/v1/" xmlns:ns2="urn://bancodebogota.com/accounts/product/v1/" xmlns:ns1="urn://bancodebogota.com/accounts/product/event/" xmlns:nsi="urn://bancodebogota.com/ifx/base/v1/" xmlns:ns="urn://bancodebogota.com/accounts/product/service/" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <soapenv:Body>
       <ns:getCreditCardBalancesResponse>
          <ns1:CCABalInqRs>
             <nsi:RqUID>7bfd2017-3260-4294-acfd-722db4decf02</nsi:RqUID>
             <nsi:Status>
                <nsi:StatusCode>0</nsi:StatusCode>
                <nsi:ServerStatusCode>0</nsi:ServerStatusCode>
                <nsi:Severity>Info</nsi:Severity>
                <nsi:StatusDesc>Transaccion Exitosa</nsi:StatusDesc>
                <nsi:ServerStatusDesc>Transaccion Exitosa</nsi:ServerStatusDesc>
             </nsi:Status>
             <nsi:CustId>
                <nsi:CustLoginId>1022426979</nsi:CustLoginId>
             </nsi:CustId>
             <nsi:NetworkTrnInfo>
                <nsi:NetworkOwner>PB</nsi:NetworkOwner>
                <nsi:TerminalId>1234</nsi:TerminalId>
                <nsi:BankId>001</nsi:BankId>
             </nsi:NetworkTrnInfo>
             <nsi:ServerDt>2025-02-07T14:09:58</nsi:ServerDt>
             <ns3:CCABalRec>
                <NS1:AcctBasicInfo xmlns:NS1="urn://bancodebogota.com/ifx/lite/v1/">
                   <nsi:AcctId>0008001030001608727</nsi:AcctId>
                   <nsi:AcctType>CCA</nsi:AcctType>
                </NS1:AcctBasicInfo>
                <ns3:AcctBal>
                   <nsi:BalType>Principal</nsi:BalType>
                   <ns3:CurAmt>
                      <nsi:Amt>2000000.00</nsi:Amt>
                   </ns3:CurAmt>
                </ns3:AcctBal>
               
                <nsi:ExtAcctBal>
                   <nsi:ExtBalType>CashAvail</nsi:ExtBalType>
                   <nsi:CurAmt>
                      <nsi:Amt>0.00</nsi:Amt>
                   </nsi:CurAmt>
                </nsi:ExtAcctBal>
                <nsi:MinPmtCurAmt>
                   <nsi:Amt>0.00</nsi:Amt>
                </nsi:MinPmtCurAmt>
             </ns3:CCABalRec>
          </ns1:CCABalInqRs>
       </ns:getCreditCardBalancesResponse>
    </soapenv:Body>
 </soapenv:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}


export const rs_Bck_CreditCard_XML_409 = {
    data: `<soapenv:Envelope xmlns:ns3="urn://bancodebogota.com/ifx/lite/v1/" xmlns:ns2="urn://bancodebogota.com/accounts/product/v1/" xmlns:ns1="urn://bancodebogota.com/accounts/product/event/" xmlns:nsi="urn://bancodebogota.com/ifx/base/v1/" xmlns:ns="urn://bancodebogota.com/accounts/product/service/" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <soapenv:Body>
       <ns:getCreditCardBalancesResponse>
          <ns1:CCABalInqRs>
             <NS1:RqUID xmlns:NS1="urn://bancodebogota.com/ifx/base/v1/">7bfd2017-3260-4294-acfd-722db4decf02</NS1:RqUID>
             <nsi:Status>
                <nsi:StatusCode>VPL5SAI09S</nsi:StatusCode>
                <nsi:ServerStatusCode>VPL5SAI09S</nsi:ServerStatusCode>
                <nsi:Severity>Warn</nsi:Severity>
                <nsi:StatusDesc>ACCOUNT NUMBER NOT FOUND</nsi:StatusDesc>
                <nsi:ServerStatusDesc>ACCOUNT NUMBER NOT FOUND</nsi:ServerStatusDesc>
                <nsi:AdditionalStatus>
                   <nsi:StatusCode>VPL5SAI09S</nsi:StatusCode>
                   <nsi:StatusDesc>ACCOUNT NUMBER NOT FOUND</nsi:StatusDesc>
                </nsi:AdditionalStatus>
             </nsi:Status>
             <nsi:NetworkTrnInfo>
                <nsi:NetworkOwner>PB</nsi:NetworkOwner>
                <nsi:TerminalId>1234</nsi:TerminalId>
                <nsi:BankId>001</nsi:BankId>
             </nsi:NetworkTrnInfo>
             <nsi:ServerDt>2025-02-07T14:13:45.994332-05:00</nsi:ServerDt>
          </ns1:CCABalInqRs>
       </ns:getCreditCardBalancesResponse>
    </soapenv:Body>
 </soapenv:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_CreditCard_XML_500 = {
    data: `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <soapenv:Header/>
    <soapenv:Body>
       <soapenv:Fault>
          <faultcode>soapenv:Server</faultcode>
          <faultstring>No es posible procesar la transaccion. Comuniquese con la Entidad</faultstring>
          <detail>
             <GeneralException>
                <Status>
                   <StatusCode>100</StatusCode>
                   <ServerStatusCode>0x00d30003</ServerStatusCode>
                   <Severity>Error</Severity>
                   <StatusDesc>Fallas Tecnicas nos impiden procesar la Transaccion</StatusDesc>
                   <ServerStatusDesc>El canal PB7 no está parametrizado, debe enviar un valor de NetworkOwner correcto, para mas informacion con arquitectura de aplicaciones: En PowerApps CatalogoApps_AQA</ServerStatusDesc>
                </Status>
             </GeneralException>
          </detail>
       </soapenv:Fault>
    </soapenv:Body>
 </soapenv:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}



export const rq_CreditCard_Rest_200: RequestHeadersModel = {
    "X-RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "X-Channel": "BancaVirtual",
    "X-CompanyId": "001",
    "X-CustIdentType": "CC",
    "X-CustIdentNum": "1080297719",
    "X-IPAddr": "100.20.30.40",
    "X-Journey": "001",
    "X-Name": "Banca Virtual",
    "X-TerminalId": "1234",
    "X-NetworkOwner": "1234"
}