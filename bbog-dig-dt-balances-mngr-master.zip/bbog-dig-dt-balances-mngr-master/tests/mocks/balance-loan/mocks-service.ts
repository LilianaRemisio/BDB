import { RequestHeadersModel } from "../../../src/model/RequestHeadersModel"


export const rqGetLoanBalanceRest_200 = {
    headers: {
      "Content-Type": "application/json",
      "X-CustIdentType": "CC",
      "X-CustIdentNum": "41496038",
      "X-IPAddr": "127.0.0.1",
      "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
      "X-Channel": "Web",
      "X-Name": "Transversales",
      "X-CompanyId": "001",
      "X-TerminalId": "BOP0",
      "X-NetworkOwner": "BPM_315",
      "x-api-key": "xxxx",
      'X-Journey': 'tes'
    }
}

export const rqGetLoanBalanceRest_400 = {
    headers: {
        'X-CustIdentType': 'CT',
        'x-custidentnum': '41496038',
        'x-ipaddr': '127.0.0.1',
        'x-rquid': 'e956d488-b39e-48f7-ab11-670b06f9a7dd',
        'x-channel': 'Web',
        'x-journey': 'tes',
        'x-name': 'Transversales',
        'x-terminalid': 'BOP0',
        'x-companyid': '001',
    }
}

export const rqGetLoanBalanceRest_409 = {
    headers: {
        "Content-Type": "application/json",
        "X-CustIdentType": "CC",
        "X-CustIdentNum": "41496038",
        "X-IPAddr": "127.0.0.1",
        "X-RqUID": "e956d488-b39e-48f7-ab11-670b06f9a7dd",
        "X-Channel": "Web",
        "X-Name": "Transversales",
        "X-CompanyId": "001",
        "X-TerminalId": "BOP0",
        "X-NetworkOwner": "BPM_315",
        "x-api-key": "xxxx",
        'X-Journey': 'tes'
    },
    params: {
        acctId: "343435"
    }
}

export const rsGetLoanBalanceRest_200 = {
   "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac686",
   "Status": {
       "StatusCode": 0,
       "StatusDesc": "Transaccion exitosa",
       "Severity": "Info",
       "ServerStatusCode": "OK",
       "ServerStatusDesc": "200"
   },
   "EndDt": "2025-02-17T07:34:45",
   "AccInfo": [
       {
           "AcctBasicInfo": {
               "AcctId": "00559691232",
               "AcctType": "DLA",
               "AcctSubType": null,
               "AcctCur": null,
               "BankInfo": {
                   "BankId": null,
                   "RefInfo": {
                       "RefType": null,
                       "RefId": null
                   },
                   "BranchId": "0047"
               }
           },
           "PersonInfo": {
               "FullName": "CLIENTE GENERICO AUTOMATIZACION PRU",
               "GovIssueIdent": {
                   "GovIssueIdentType": null,
                   "IdentSerialNum": null
               }
           },
           "AccountStatus": {
               "StatusCode": "AC",
               "StatusDesc": "Active"
           },
           "AcctBal": [
               {
                   "BalType": "PayoffAmt",
                   "CurAmt": {
                       "Amt": "6314284.00",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "AvailCredit",
                   "CurAmt": {
                       "Amt": "0.00",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "Outstanding",
                   "CurAmt": {
                       "Amt": "0.00",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "CreditLimit",
                   "CurAmt": {
                       "Amt": "10000000.00",
                       "CurCode": "COP"
                   }
               },
               {
                   "BalType": "Principal",
                   "CurAmt": {
                       "Amt": "6300425.42",
                       "CurCode": "COP"
                   }
               }
           ],
           "ExtAcctBal": [
               {
                   "ExtBalType": "PendAuthAmt",
                   "CurAmt": {
                       "Amt": "0.00",
                       "CurCode": "COP"
                   }
               },
               {
                   "ExtBalType": "UnpaidAccruedInt",
                   "CurAmt": {
                       "Amt": "5250.36",
                       "CurCode": "COP"
                   }
               },
               {
                   "ExtBalType": "PeriodFees",
                   "CurAmt": {
                       "Amt": "8608.00",
                       "CurCode": "COP"
                   }
               }
           ],
           "OwnerInd": "0",
           "RefInfo": [
               {
                   "RefType": "ProductId",
                   "RefId": "BS88"
               }
           ],
           "OpenDt": "2022-12-14",
           "ExpDt": "2027-12-14",
           "PaidDt": "2025-02-14",
           "MinPmtCurAmt": null,
           "Term": null,
           "Rate": null,
           "OverdraftDays": null,
           "Fee": {
               "FeeType": "Late",
               "CurAmt": {
                   "Amt": "0.00",
                   "CurCode": "COP",
                   "CurRate": "10.0000000"
               },
               "Rate": "51.1545500"
           },
           "NextPmtCurAmt": {
               "Amt": "221078.00",
               "CurCode": "COP"
           },
           "DueDt": "2025-03-14",
           "Ownership": null,
           "FinalCurAmt": null
       }
   ],
   "isPrincipalServiceUsed": true,
   "circuitBreakerState": "circuit breaker not used"
}


export const rsGetLoanBalanceRest_409 = {
   "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac686",
   "Status": {
       "StatusCode": 409,
       "StatusDesc": "Business Error",
       "Severity": "Error",
       "ServerStatusCode": "AM1047",
       "ServerStatusDesc": "AMPC AM1047 E: NO SE ENCUENTRA CUENTA"
   },
   "EndDt": "2025-02-17T08:34:32"
}

export const rsGetLoanBalanceRest_408 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 408,
        "StatusDesc": "timeout of 3000ms exceeded",
        "Severity": "Error",
        "ServerStatusCode": "408",
        "ServerStatusDesc": "Error calling service getLoanBalanceService - Timeout"
    },
    "EndDt": "2024-12-09T10:31:20"
}

export const rsGetLoanBalanceRest_500 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status": {
        "StatusCode": 500,
        "StatusDesc": "Internal Server Error",
        "Severity": "Error",
        "ServerStatusCode": 500,
        "ServerStatusDesc": "Request failed with status code 500"
    },
    "EndDt": "2024-12-09T10:31:01"
}

export const rsGetLoanBalanceRest_500_1 = {
    "RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "Status1": {
        "StatusDesc": "Internal Server Error",
        "Severity": "Error",
        "ServerStatusCode": 500,
        "ServerStatusDesc": "Request failed with status code 500"
    },
    "EndDt": "2024-12-09T10:31:01"
}

export const rs_Bck_Loan_XML_200 = {
    data: `<soapenv:Envelope xmlns:ns3="urn://bancodebogota.com/ifx/lite/v1/" xmlns:ns2="urn://bancodebogota.com/accounts/product/v1/" xmlns:ns1="urn://bancodebogota.com/accounts/product/event/" xmlns:nsi="urn://bancodebogota.com/ifx/base/v1/" xmlns:ns="urn://bancodebogota.com/accounts/product/service/" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <soapenv:Body>
       <ns:getLoanBalancesResponse>
          <ns1:LOCBalInqRs>
             <nsi:RqUID>6c437be4-941b-4cf5-abf7-a006c4326edf</nsi:RqUID>
             <nsi:Status>
                <nsi:StatusCode>0</nsi:StatusCode>
                <nsi:ServerStatusCode>0</nsi:ServerStatusCode>
                <nsi:Severity>Info</nsi:Severity>
                <nsi:StatusDesc>Transaccion Exitosa</nsi:StatusDesc>
                <nsi:ServerStatusDesc>Transaccion Exitosa</nsi:ServerStatusDesc>
             </nsi:Status>
             <nsi:CustId>
                <nsi:CustLoginId>1011459181</nsi:CustLoginId>
             </nsi:CustId>
             <nsi:NetworkTrnInfo>
                <nsi:NetworkOwner>DIG482</nsi:NetworkOwner>
                <nsi:TerminalId>IN01</nsi:TerminalId>
                <nsi:BankId>001</nsi:BankId>
             </nsi:NetworkTrnInfo>
             <nsi:ServerDt>2025-02-17T07:26:14</nsi:ServerDt>
             <ns2:LOCBalRec>
                <ns3:AcctBasicInfo>
                   <nsi:AcctId>00559691232</nsi:AcctId>
                   <nsi:AcctType>DLA</nsi:AcctType>
                   <ns3:BankInfo>
                      <nsi:BranchId>0047</nsi:BranchId>
                   </ns3:BankInfo>
                </ns3:AcctBasicInfo>
                <ns3:PersonInfo>
                   <nsi:FullName>CLIENTE GENERICO AUTOMATIZACION PRU</nsi:FullName>
                </ns3:PersonInfo>
                <ns2:AccountStatus>
                   <nsi:StatusCode>AC</nsi:StatusCode>
                   <nsi:StatusDesc>Active</nsi:StatusDesc>
                </ns2:AccountStatus>
                <ns2:AcctBal>
                   <nsi:BalType>PayoffAmt</nsi:BalType>
                   <ns2:CurAmt>
                      <nsi:Amt>6314284.00</nsi:Amt>
                      <nsi:CurCode>COP</nsi:CurCode>
                   </ns2:CurAmt>
                </ns2:AcctBal>
                <ns2:AcctBal>
                   <nsi:BalType>AvailCredit</nsi:BalType>
                   <ns2:CurAmt>
                      <nsi:Amt>0.00</nsi:Amt>
                      <nsi:CurCode>COP</nsi:CurCode>
                   </ns2:CurAmt>
                </ns2:AcctBal>
                <ns2:AcctBal>
                   <nsi:BalType>Outstanding</nsi:BalType>
                   <ns2:CurAmt>
                      <nsi:Amt>0.00</nsi:Amt>
                      <nsi:CurCode>COP</nsi:CurCode>
                   </ns2:CurAmt>
                </ns2:AcctBal>
                <ns2:AcctBal>
                   <nsi:BalType>CreditLimit</nsi:BalType>
                   <ns2:CurAmt>
                      <nsi:Amt>10000000.00</nsi:Amt>
                      <nsi:CurCode>COP</nsi:CurCode>
                   </ns2:CurAmt>
                </ns2:AcctBal>
                <ns2:AcctBal>
                   <nsi:BalType>Principal</nsi:BalType>
                   <ns2:CurAmt>
                      <nsi:Amt>6300425.42</nsi:Amt>
                      <nsi:CurCode>COP</nsi:CurCode>
                   </ns2:CurAmt>
                </ns2:AcctBal>
                <nsi:ExtAcctBal>
                   <nsi:ExtBalType>PendAuthAmt</nsi:ExtBalType>
                   <nsi:CurAmt>
                      <nsi:Amt>0.00</nsi:Amt>
                      <nsi:CurCode>COP</nsi:CurCode>
                   </nsi:CurAmt>
                </nsi:ExtAcctBal>
                <nsi:ExtAcctBal>
                   <nsi:ExtBalType>UnpaidAccruedInt</nsi:ExtBalType>
                   <nsi:CurAmt>
                      <nsi:Amt>5250.36</nsi:Amt>
                      <nsi:CurCode>COP</nsi:CurCode>
                   </nsi:CurAmt>
                </nsi:ExtAcctBal>
                <nsi:ExtAcctBal>
                   <nsi:ExtBalType>PeriodFees</nsi:ExtBalType>
                   <nsi:CurAmt>
                      <nsi:Amt>8608.00</nsi:Amt>
                      <nsi:CurCode>COP</nsi:CurCode>
                   </nsi:CurAmt>
                </nsi:ExtAcctBal>
                <nsi:OwnerInd>0</nsi:OwnerInd>
                <nsi:OpenDt>2022-12-14</nsi:OpenDt>
                <nsi:ExpDt>2027-12-14</nsi:ExpDt>
                <nsi:UpDt>2025-02-17T12:00:00</nsi:UpDt>
                <nsi:PaidDt>2025-02-14</nsi:PaidDt>
                <nsi:DueDt>2025-03-14</nsi:DueDt>
                <nsi:Fee>
                   <nsi:FeeType>Late</nsi:FeeType>
                   <nsi:CurAmt>
                      <nsi:Amt>0.00</nsi:Amt>
                      <nsi:CurCode>COP</nsi:CurCode>
                      <nsi:CurRate>10.0000000</nsi:CurRate>
                   </nsi:CurAmt>
                   <nsi:Rate>51.1545500</nsi:Rate>
                </nsi:Fee>
                <nsi:NextPmtCurAmt>
                   <nsi:Amt>221078.00</nsi:Amt>
                   <nsi:CurCode>COP</nsi:CurCode>
                </nsi:NextPmtCurAmt>
                <ns3:RefInfo>
                   <nsi:RefType>ProductId</nsi:RefType>
                   <nsi:RefId>BS88</nsi:RefId>
                </ns3:RefInfo>
             </ns2:LOCBalRec>
          </ns1:LOCBalInqRs>
       </ns:getLoanBalancesResponse>
    </soapenv:Body>
 </soapenv:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_Loan_XML_200_BussinessError = {
    data: `<soapenv:Envelope xmlns:ns3="urn://bancodebogota.com/ifx/lite/v1/" xmlns:ns2="urn://bancodebogota.com/accounts/product/v1/" xmlns:ns1="urn://bancodebogota.com/accounts/product/event/" xmlns:nsi="urn://bancodebogota.com/ifx/base/v1/" xmlns:ns="urn://bancodebogota.com/accounts/product/service/" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <soapenv:Body>
       <ns:getLoanBalancesResponse>
          <ns1:LOCBalInqRs>
             <nsi:RqUID>6c437be4-941b-4cf5-abf7-a006c4326edf</nsi:RqUID>
             <nsi:Status>
                <nsi:StatusCode>100</nsi:StatusCode>
                <nsi:ServerStatusCode>AM1047</nsi:ServerStatusCode>
                <nsi:Severity>Error</nsi:Severity>
                <nsi:StatusDesc/>
                <nsi:ServerStatusDesc>AMPC AM1047 E: NO SE ENCUENTRA CUENTA</nsi:ServerStatusDesc>
                <nsi:AdditionalStatus>
                   <nsi:StatusCode>-1000</nsi:StatusCode>
                   <nsi:ServerStatusCode>-10361</nsi:ServerStatusCode>
                   <nsi:Severity>Error</nsi:Severity>
                   <nsi:StatusDesc>MESSAGES FOR NATIVE ACC 00005596912321</nsi:StatusDesc>
                </nsi:AdditionalStatus>
                <nsi:AdditionalStatus>
                   <nsi:StatusCode>100</nsi:StatusCode>
                   <nsi:ServerStatusCode>-10361</nsi:ServerStatusCode>
                   <nsi:Severity>Error</nsi:Severity>
                   <nsi:StatusDesc>TP en_US 100  General Error</nsi:StatusDesc>
                </nsi:AdditionalStatus>
                <nsi:AdditionalStatus>
                   <nsi:StatusCode>-1000</nsi:StatusCode>
                   <nsi:ServerStatusCode>-10361</nsi:ServerStatusCode>
                   <nsi:Severity>Error</nsi:Severity>
                   <nsi:StatusDesc>AMPC AM1047 E: NO SE ENCUENTRA CUENTA</nsi:StatusDesc>
                </nsi:AdditionalStatus>
             </nsi:Status>
             <nsi:NetworkTrnInfo>
                <nsi:NetworkOwner>DIG482</nsi:NetworkOwner>
                <nsi:TerminalId>IN01</nsi:TerminalId>
                <nsi:BankId>001</nsi:BankId>
             </nsi:NetworkTrnInfo>
             <nsi:ServerDt>2025-02-17T09:01:00</nsi:ServerDt>
          </ns1:LOCBalInqRs>
       </ns:getLoanBalancesResponse>
    </soapenv:Body>
 </soapenv:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_Loan_XML_200_single = {
    data: `<soapenv:Envelope xmlns:ns3="urn://bancodebogota.com/ifx/lite/v1/" xmlns:ns2="urn://bancodebogota.com/accounts/product/v1/" xmlns:ns1="urn://bancodebogota.com/accounts/product/event/" xmlns:nsi="urn://bancodebogota.com/ifx/base/v1/" xmlns:ns="urn://bancodebogota.com/accounts/product/service/" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <soapenv:Body>
       <ns:getLoanBalancesResponse>
          <ns1:LOCBalInqRs>
             <nsi:RqUID>6c437be4-941b-4cf5-abf7-a006c4326edf</nsi:RqUID>
             <nsi:Status>
                <nsi:StatusCode>0</nsi:StatusCode>
                <nsi:ServerStatusCode>0</nsi:ServerStatusCode>
                <nsi:Severity>Info</nsi:Severity>
                <nsi:StatusDesc>Transaccion Exitosa</nsi:StatusDesc>
                <nsi:ServerStatusDesc>Transaccion Exitosa</nsi:ServerStatusDesc>
             </nsi:Status>
             <nsi:CustId>
                <nsi:CustLoginId>1011459181</nsi:CustLoginId>
             </nsi:CustId>
             <nsi:NetworkTrnInfo>
                <nsi:NetworkOwner>DIG482</nsi:NetworkOwner>
                <nsi:TerminalId>IN01</nsi:TerminalId>
                <nsi:BankId>001</nsi:BankId>
             </nsi:NetworkTrnInfo>
             <nsi:ServerDt>2025-02-17T07:26:14</nsi:ServerDt>
             <ns2:LOCBalRec>
                <ns3:AcctBasicInfo>
                   <nsi:AcctId>00559691232</nsi:AcctId>
                   <nsi:AcctType>DLA</nsi:AcctType>
                   <ns3:BankInfo>
                      <nsi:BranchId>0047</nsi:BranchId>
                   </ns3:BankInfo>
                </ns3:AcctBasicInfo>
                <ns3:PersonInfo>
                   <nsi:FullName>CLIENTE GENERICO AUTOMATIZACION PRU</nsi:FullName>
                </ns3:PersonInfo>
                <ns2:AccountStatus>
                   <nsi:StatusCode>AC</nsi:StatusCode>
                   <nsi:StatusDesc>Active</nsi:StatusDesc>
                </ns2:AccountStatus>
                <ns2:AcctBal>
                   <nsi:BalType>PayoffAmt</nsi:BalType>
                   <ns2:CurAmt>
                      <nsi:Amt>6314284.00</nsi:Amt>
                      <nsi:CurCode>COP</nsi:CurCode>
                   </ns2:CurAmt>
                </ns2:AcctBal>
                
                <nsi:ExtAcctBal>
                   <nsi:ExtBalType>PendAuthAmt</nsi:ExtBalType>
                   <nsi:CurAmt>
                      <nsi:Amt>0.00</nsi:Amt>
                      <nsi:CurCode>COP</nsi:CurCode>
                   </nsi:CurAmt>
                </nsi:ExtAcctBal>
                <nsi:ExtAcctBal>
                   <nsi:ExtBalType>UnpaidAccruedInt</nsi:ExtBalType>
                   <nsi:CurAmt>
                      <nsi:Amt>5250.36</nsi:Amt>
                      <nsi:CurCode>COP</nsi:CurCode>
                   </nsi:CurAmt>
                </nsi:ExtAcctBal>
                <nsi:ExtAcctBal>
                   <nsi:ExtBalType>PeriodFees</nsi:ExtBalType>
                   <nsi:CurAmt>
                      <nsi:Amt>8608.00</nsi:Amt>
                      <nsi:CurCode>COP</nsi:CurCode>
                   </nsi:CurAmt>
                </nsi:ExtAcctBal>
                <nsi:OwnerInd>0</nsi:OwnerInd>
                <nsi:OpenDt>2022-12-14</nsi:OpenDt>
                <nsi:ExpDt>2027-12-14</nsi:ExpDt>
                <nsi:UpDt>2025-02-17T12:00:00</nsi:UpDt>
                <nsi:PaidDt>2025-02-14</nsi:PaidDt>
                <nsi:DueDt>2025-03-14</nsi:DueDt>
                <nsi:Fee>
                   <nsi:FeeType>Late</nsi:FeeType>
                   <nsi:CurAmt>
                      <nsi:Amt>0.00</nsi:Amt>
                      <nsi:CurCode>COP</nsi:CurCode>
                      <nsi:CurRate>10.0000000</nsi:CurRate>
                   </nsi:CurAmt>
                   <nsi:Rate>51.1545500</nsi:Rate>
                </nsi:Fee>
                <nsi:NextPmtCurAmt>
                   <nsi:Amt>221078.00</nsi:Amt>
                   <nsi:CurCode>COP</nsi:CurCode>
                </nsi:NextPmtCurAmt>
                <ns3:RefInfo>
                   <nsi:RefType>ProductId</nsi:RefType>
                   <nsi:RefId>BS88</nsi:RefId>
                </ns3:RefInfo>
             </ns2:LOCBalRec>
          </ns1:LOCBalInqRs>
       </ns:getLoanBalancesResponse>
    </soapenv:Body>
 </soapenv:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}

export const rs_Bck_Loan_XML_500 = {
    data: `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <soapenv:Header/>
    <soapenv:Body>
       <soapenv:Fault>
          <faultcode>soapenv:Server</faultcode>
          <faultstring>No es posible procesar la transaccion. Comuniquese con la Entidad</faultstring>
          <detail>
             <GeneralException>
                <Status>
                   <StatusCode>100</StatusCode>
                   <ServerStatusCode>0x00d30003</ServerStatusCode>
                   <Severity>Error</Severity>
                   <StatusDesc>Fallas Tecnicas nos impiden procesar la Transaccion</StatusDesc>
                   <ServerStatusDesc>El canal PB7 no está parametrizado, debe enviar un valor de NetworkOwner correcto, para mas informacion con arquitectura de aplicaciones: En PowerApps CatalogoApps_AQA</ServerStatusDesc>
                </Status>
             </GeneralException>
          </detail>
       </soapenv:Fault>
    </soapenv:Body>
 </soapenv:Envelope>`,
    status: 200,
    code: 'OK',
    principalServiceUsed: true,
    circuitBreakerState: 'circuit breaker not used'
}



export const rq_Loan_Rest_200: RequestHeadersModel = {
    "X-RqUID": "7118c962-bd3c-4388-bd1e-ae9b57bac687",
    "X-Channel": "BancaVirtual",
    "X-CompanyId": "001",
    "X-CustIdentType": "CC",
    "X-CustIdentNum": "1080297719",
    "X-IPAddr": "100.20.30.40",
    "X-Journey": "001",
    "X-Name": "Banca Virtual",
    "X-TerminalId": "1234",
    "X-NetworkOwner": "1234"
}