/** @type {import('ts-jest').JestConfigWithTsJest} */
module.exports = {
	preset: 'ts-jest',
	testEnvironment: 'node',
	roots: ['<rootDir>/tests'],
	testMatch: ['**/tests/**/*.+(ts|js)', '**/?(*.)+(spec|tests).+(ts|js)'],
	testPathIgnorePatterns: ['/tests/mocks.ts', '/tests/mocks'],
	transform: {
		'^.+\\.(ts|tsx)$': 'ts-jest',
	},
};
