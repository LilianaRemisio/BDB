import { Router } from 'express';
import balancesController from '../controller/BalancesController';
import { OpenApiValidatorProvider } from '../utils/OpenApiValidatorProvider';

class BalancesRouter {
  public router: Router = Router();

  constructor() {
    this.config();
  }

  private async config(): Promise<void> {
    const validator = await OpenApiValidatorProvider();
    this.router.post(
      '/retrieveGroupBalances',
      validator.validate('post', '/V2/Enterprise/BalanceManagement/retrieveGroupBalances'),
      balancesController.retrieveGroupBalances
    );
    this.router.get(
      '/:acctId/retrieveSavingBalance',
      validator.validate('get', '/V2/Enterprise/BalanceManagement/{acctId}/retrieveSavingBalance'),
      balancesController.retrieveSavingBalance
    );
    this.router.get(
      '/:acctId/retrieveDemandBalance',
      validator.validate('get', '/V2/Enterprise/BalanceManagement/{acctId}/retrieveDemandBalance'),
      balancesController.retrieveDemandBalance
    );
    this.router.get(
      '/:acctId/retrieveTrustBalance',
      validator.validate('get', '/V2/Enterprise/BalanceManagement/{acctId}/retrieveTrustBalance'),
      balancesController.retrieveTrustBalance
    );
    this.router.get(
      '/:acctId/retrieveCreditCardBalance',
      validator.validate('get', '/V2/Enterprise/BalanceManagement/{acctId}/retrieveCreditCardBalance'),
      balancesController.retrieveCreditCardBalance
    );
    this.router.get(
      '/:acctId/retrieveCertificateBalance',
      validator.validate('get', '/V2/Enterprise/BalanceManagement/{acctId}/retrieveCertificateBalance'),
      balancesController.retrieveCertificateBalance
    );
    this.router.get(
      '/:acctId/retrieveLoanBalance',
      validator.validate('get', '/V2/Enterprise/BalanceManagement/{acctId}/retrieveLoanBalance'),
      balancesController.retrieveLoanBalance
    );
    this.router.get(
      '/retrieveDetailCreditInfo/:acctId',
      validator.validate('get', '/V2/Enterprise/BalanceManagement/retrieveDetailCreditInfo/{acctId}'),
      balancesController.retrieveDetailCreditInfo
    );
    this.router.get(
      '/retrieveLoanQuota',
      validator.validate('get', '/V2/Enterprise/BalanceManagement/retrieveLoanQuota'),
      balancesController.retrieveLoanQuota
    );
    this.router.get(
      '/:acctId/retrieveOverdraft',
      validator.validate('get', '/V2/Enterprise/BalanceManagement/{acctId}/retrieveOverdraft'),
      balancesController.retrieveOverdraft
    );
  }
}

const balancesRouter = new BalancesRouter();
export default balancesRouter.router;
