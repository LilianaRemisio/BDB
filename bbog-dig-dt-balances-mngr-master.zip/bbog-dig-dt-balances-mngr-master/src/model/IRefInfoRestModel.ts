
export interface IRefInfoRestModel {
    RefType: string;
    RefId: string;
}

export class RefInfoRestModelBuilder {
    private readonly refInfoRestModel:IRefInfoRestModel;

    constructor() {
        this.refInfoRestModel = {} as IRefInfoRestModel;
    }

    setRefType(RefType: string): RefInfoRestModelBuilder{
        this.refInfoRestModel.RefType = RefType;
        return this;
    }

    setRefId(RefId: string): RefInfoRestModelBuilder{
        this.refInfoRestModel.RefId = RefId;
        return this;
    }

    build(): IRefInfoRestModel {
        return this.refInfoRestModel;
    }
}
