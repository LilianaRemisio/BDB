import { IDefaultStatusModel } from './IDefaultStatusModel';
export interface ILoanQuotaRestRsModel {
    RqUID: string;
    Status: IDefaultStatusModel;
    EndDt: string;
    InterestRate?: string;
    InterestAmount?: string;
    TotalRepmtAmt?: string;
    FlatAmount?: string;
    PaymentAmount?: string;
    MaturityDate?: string;
}

export class LoanQuotaRestRsModelBuilder {
    private readonly loanQuotaRestRsModel: ILoanQuotaRestRsModel;

    constructor();
    constructor(initialData?: Partial<ILoanQuotaRestRsModel>) {
      this.loanQuotaRestRsModel = initialData ? { ...initialData } as ILoanQuotaRestRsModel : {} as ILoanQuotaRestRsModel;
    }

    setRqUID(rqUID: string): LoanQuotaRestRsModelBuilder {
        this.loanQuotaRestRsModel.RqUID = rqUID;
        return this;
    }
    setStatus(status: IDefaultStatusModel): LoanQuotaRestRsModelBuilder {
        this.loanQuotaRestRsModel.Status = status;
        return this;
    }

    setEndDt(endDt: string): LoanQuotaRestRsModelBuilder {
        this.loanQuotaRestRsModel.EndDt = endDt;
        return this;
    }

    setInterestRate(interestRate: string): LoanQuotaRestRsModelBuilder{
        this.loanQuotaRestRsModel.InterestRate = interestRate;
        return this;
    }

    setInterestAmount(interestAmount: string): LoanQuotaRestRsModelBuilder{
        this.loanQuotaRestRsModel.InterestAmount = interestAmount;
        return this;
    }

    setTotalRepmtAmt(totalRepmtAmt: string): LoanQuotaRestRsModelBuilder{
        this.loanQuotaRestRsModel.TotalRepmtAmt = totalRepmtAmt;
        return this;
    }

    setFlatAmount(flatAmount: string): LoanQuotaRestRsModelBuilder{
        this.loanQuotaRestRsModel.FlatAmount = flatAmount;
        return this;
    }

    setPaymentAmount(paymentAmount: string): LoanQuotaRestRsModelBuilder{
        this.loanQuotaRestRsModel.PaymentAmount = paymentAmount;
        return this;
    }

    setMaturityDate(maturityDate: string): LoanQuotaRestRsModelBuilder{
        this.loanQuotaRestRsModel.MaturityDate = maturityDate;
        return this;
    }

    build(): ILoanQuotaRestRsModel {
        return this.loanQuotaRestRsModel;
    }
}


