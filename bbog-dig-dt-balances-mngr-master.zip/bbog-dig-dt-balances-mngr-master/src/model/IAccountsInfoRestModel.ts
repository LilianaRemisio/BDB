import { IAcctBasicInfo } from './IAcctBasicInfo';

export interface IAccountsInfoRestModel {
    AccountsInfo: IAcctBasicInfo[];
}
