
export interface IAccountStatus {
    StatusCode: string;
    StatusDesc: string;
}
