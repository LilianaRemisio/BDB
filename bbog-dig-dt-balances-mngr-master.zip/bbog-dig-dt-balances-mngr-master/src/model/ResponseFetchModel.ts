export class ResponseFetchModel<T> {
  public data: T;
  public status: number;
  public code: string;
  public principalServiceUsed: boolean;
  public circuitBreakerState: string;

  constructor(data: T, status: number, code: string, principalServiceUsed: boolean, circuitBreakerState: string) {
      this.data = data;
      this.status = status;
      this.code = code;
      this.principalServiceUsed = principalServiceUsed;
      this.circuitBreakerState = circuitBreakerState;
  }
}
