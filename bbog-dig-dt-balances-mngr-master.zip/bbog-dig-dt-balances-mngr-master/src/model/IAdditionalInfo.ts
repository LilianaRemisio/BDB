import { IDefaultStatusModel } from './IDefaultStatusModel';

export interface IAdditionalInfo {
    AcctId: string;
    AcctType: string;
    StatusBalance: IDefaultStatusModel;
}
