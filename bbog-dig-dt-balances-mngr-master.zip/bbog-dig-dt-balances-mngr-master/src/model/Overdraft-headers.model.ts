import { Request } from 'express';
import { StringNullable } from './GenericTypes';

type stringNullable = string | null | undefined;

export const acctId = 'acctId';
export const acctType = 'acctType';
export const refType = 'refType';
export const refId = 'refId';

export class OverdraftHeadersModel {
    public 'acctId': stringNullable;
    public 'acctType': stringNullable;
    public 'refType': stringNullable;
    public 'refId': stringNullable;

    constructor(request: Request) {
        this[acctId] = request.params.acctId;
        this[acctType] = request.query.acctType as StringNullable;
        this[refType] = request.query.refType as StringNullable;
        this[refId] = request.query.refId as StringNullable;
    }
}
