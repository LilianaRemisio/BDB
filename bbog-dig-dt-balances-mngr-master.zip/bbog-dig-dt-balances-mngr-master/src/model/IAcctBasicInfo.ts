import { IBankInfo } from './IBankInfo';

export interface IAcctBasicInfo {
    AcctId: string;
    AcctType: string;
    AcctSubType: string;
    AcctCur: string;
    BankInfo: IBankInfo;
}

export class AcctBasicInfoBuilder {
    private readonly acctBasicInfo: IAcctBasicInfo;

    constructor() {
        // Initialize with default values
        this.acctBasicInfo = {
            AcctId: '',
            AcctType: '',
            AcctSubType: '',
            AcctCur: '',
            BankInfo: {BankId: '',BranchId: '',RefInfo: {RefType:'', RefId:''}},
        };
    }

    public setAcctId(acctId: string): AcctBasicInfoBuilder {
        this.acctBasicInfo.AcctId = acctId;
        return this;
    }

    public setAcctType(acctType: string): AcctBasicInfoBuilder {
        this.acctBasicInfo.AcctType = acctType;
        return this;
    }

    public setAcctSubType(acctSubType: string): AcctBasicInfoBuilder {
        this.acctBasicInfo.AcctSubType = acctSubType;
        return this;
    }

    public setAcctCur(acctCur: string): AcctBasicInfoBuilder {
        this.acctBasicInfo.AcctCur = acctCur;
        return this;
    }

    // Set BankInfo
    public setBankInfo(bankInfo: IBankInfo): AcctBasicInfoBuilder {
        this.acctBasicInfo.BankInfo = bankInfo;
        return this;
    }

    public build(): IAcctBasicInfo {
        return this.acctBasicInfo;
    }
}
