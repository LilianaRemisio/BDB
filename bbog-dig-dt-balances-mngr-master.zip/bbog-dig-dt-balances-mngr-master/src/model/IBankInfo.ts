import { IRefInfo } from './IRefInfo';

export interface IBankInfo {
    BankId: string;
    RefInfo: IRefInfo;
    BranchId: string;
}

// Class implementing IBankInfo with a constructor
export class BankInfo implements IBankInfo {
    BankId: string;
    RefInfo: IRefInfo;
    BranchId: string;

    // Constructor with optional parameters and default values
    constructor(
        bankId: string,
        refInfo: IRefInfo,
        branchId: string
    ) {
        this.BankId = bankId;
        this.RefInfo = refInfo;
        this.BranchId = branchId;
    }
}
