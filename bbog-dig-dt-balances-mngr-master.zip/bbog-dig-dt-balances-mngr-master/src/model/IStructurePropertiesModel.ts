export interface IStructurePropertiesModel {
    method: string;
    requestName: string;
    responseName: string;
    objectName: string;
    objectsRequiredAsArray?: string[];
    service: string;
    accountsItemsIdentification: boolean;
}
