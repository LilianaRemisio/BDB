import { SeverityType } from './GenericTypes';
import { IAdditionalInfo } from './IAdditionalInfo';

export interface IDefaultStatusModel {
    StatusCode: string | number;
    StatusDesc: string;
    Severity: SeverityType;
    ServerStatusCode: string;
    ServerStatusDesc?: string;
    AdditionalStatus?: IAdditionalInfo[];
}

export class DefaultStatusModelBuilder {
    private readonly model: IDefaultStatusModel;

    constructor() {
        this.model = {} as IDefaultStatusModel;
    }

    setStatusCode(statusCode: string | number): this {
        this.model.StatusCode = statusCode;
        return this;
    }

    setStatusDesc(statusDesc: string): this {
        this.model.StatusDesc = statusDesc;
        return this;
    }

    setSeverity(severity: SeverityType): this {
        this.model.Severity = severity;
        return this;
    }

    setServerStatusCode(serverStatusCode: string): this {
        this.model.ServerStatusCode = serverStatusCode;
        return this;
    }

    setServerStatusDesc(serverStatusDesc: string | undefined): this {
        this.model.ServerStatusDesc = serverStatusDesc;
        return this;
    }

    setAdditionalStatus(additionalStatus?: IAdditionalInfo[]): this {
        this.model.AdditionalStatus = additionalStatus;
        return this;
    }

    build(): IDefaultStatusModel {
        return this.model;
    }
}
