export interface IRefInfo {
    RefType: string;
    RefId: string;
}
