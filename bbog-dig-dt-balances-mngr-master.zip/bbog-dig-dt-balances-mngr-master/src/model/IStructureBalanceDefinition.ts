import { IStructurePropertiesModel } from './IStructurePropertiesModel';

const ACCOUNTS_SERVICE = 'accounts';
export class IStructureBalanceDefinition {
  public static SAVING_BALANCE: IStructurePropertiesModel = {
    method: 'getSavingsBalances',
    objectName: 'SDABalRec',
    objectsRequiredAsArray: [
      'ExtAcctBal'
    ],
    requestName: 'SDABalInqRq',
    responseName: 'SDABalInqRs',
    service: ACCOUNTS_SERVICE,
    accountsItemsIdentification: true
  };

  public static DEMAND_BALANCE: IStructurePropertiesModel  = {
    method: 'getDemandBalances',
    objectName: 'DDABalRec',
    objectsRequiredAsArray: [
      'ExtAcctBal'
    ],
    requestName: 'DDABalInqRq',
    responseName: 'DDABalInqRs',
    service: ACCOUNTS_SERVICE,
    accountsItemsIdentification: true
  };
  public static CREDITCARD_BALANCE: IStructurePropertiesModel  = {
    method: 'getCreditCardBalances',
    objectName: 'CCABalRec',
    objectsRequiredAsArray: [
      'ExtAcctBal'
    ],
    requestName: 'CCABalInqRq',
    responseName: 'CCABalInqRs',
    service: ACCOUNTS_SERVICE,
    accountsItemsIdentification: true
  };
  public static LOAN_BALANCE: IStructurePropertiesModel  = {
    method: 'getLoanBalances',
    objectName: 'LOCBalRec',
    objectsRequiredAsArray: [
      'ExtAcctBal'
    ],
    requestName: 'LOCBalInqRq',
    responseName: 'LOCBalInqRs',
    service: ACCOUNTS_SERVICE,
    accountsItemsIdentification: true
  };
  public static TRUST_BALANCE: IStructurePropertiesModel  = {
    method: 'getTrustBalances',
    objectName: 'TrustBalRec',
    objectsRequiredAsArray: [
      'ExtAcctBal'
    ],
    requestName: 'TrustBalInqRq',
    responseName: 'TrustBalInqRs',
    service: ACCOUNTS_SERVICE,
    accountsItemsIdentification: true
  };
  public static CERTIFICATE_BALANCE: IStructurePropertiesModel  = {
    method: 'getCertificateBalances',
    objectName: 'CDABalRec',
    objectsRequiredAsArray: [
      'ExtAcctBal'
    ],
    requestName: 'CDABalInqRq',
    responseName: 'CDABalInqRs',
    service: ACCOUNTS_SERVICE,
    accountsItemsIdentification: true
  };
  public static CUSTOMER_PRODUCT: IStructurePropertiesModel  = {
    method: 'getLoanAcctDetail',
    objectName: 'CreditDetailRec',
    objectsRequiredAsArray: [
      'ExtAcctBal'
    ],
    requestName: 'LoanAcctDetailInqRq',
    responseName: 'LoanAcctDetailInqRs',
    service: ACCOUNTS_SERVICE,
    accountsItemsIdentification: true
  };
  public static LOAN_QUOTA: IStructurePropertiesModel  = {
    method: 'getLoanQuota',
    objectName: 'AcctBal',
    objectsRequiredAsArray: [
      'CurAmt'
    ],
    requestName: 'LoanQuotaInqRq',
    responseName: 'LoanQuotaInqRs',
    service: 'customers',
    accountsItemsIdentification: false
  };

  public static SAVING_BALANCE_CONTINGENCY: IStructurePropertiesModel  = {
    method: '',
    objectName: 'data',
    objectsRequiredAsArray: [],
    requestName: '',
    responseName: '',
    service: 'ods',
    accountsItemsIdentification: false
  };

  public static OVERDRAFT_BALANCE: IStructurePropertiesModel  = {
    method: 'getOverdraftBalances',
    objectName: 'AcctBal',
    objectsRequiredAsArray: [
      'CurAmt'
    ],
    requestName: 'OverdraftBalancesInqRq',
    responseName: 'OverdraftBalancesInqRs',
    service: ACCOUNTS_SERVICE,
    accountsItemsIdentification: false
  };
}
