export interface IBalanceRequestModel {
    rqUID: string;
    customerLoginId: string;
    networkOwner: string;
    terminalId: string;
    bankId: string;
    typeId: string;
    participantId: string;
    acctId: string;
}

export class BalanceRequestModelBuilder {
    private readonly savingBalance: IBalanceRequestModel;

    constructor() {
        this.savingBalance = {} as IBalanceRequestModel;
    }

    setRqUID(rqUID: string): BalanceRequestModelBuilder {
        this.savingBalance.rqUID = rqUID;
        return this;
    }

    setNetworkOwner(networkOwner: string): BalanceRequestModelBuilder {
        this.savingBalance.networkOwner = networkOwner;
        return this;
    }

    setTerminalId(terminalId: string): BalanceRequestModelBuilder {
        this.savingBalance.terminalId = terminalId;
        return this;
    }

    setBankId(bankId: string): BalanceRequestModelBuilder {
        this.savingBalance.bankId = bankId;
        return this;
    }

    setTypeId(typeId: string): BalanceRequestModelBuilder {
        this.savingBalance.typeId = typeId;
        return this;
    }

    setParticipantId(participantId: string): BalanceRequestModelBuilder {
        this.savingBalance.participantId = participantId;
        return this;
    }

    setAcctId(acctId: string): BalanceRequestModelBuilder {
        this.savingBalance.acctId = acctId;
        return this;
    }

    build(): IBalanceRequestModel {
        return this.savingBalance;
    }
}
