import { IAccountStatus } from './IAccountStatus';
import { IAcctBalRestModel } from './IAcctBalRestModel';
import { IAcctBasicInfo } from './IAcctBasicInfo';
import { IExtAcctBalRestModel } from './IExtAcctBalRestModel';
import { IRefInfoRestModel } from './IRefInfoRestModel';
import { IPersonInfo } from './IPersonInfo';

export interface IAccInfoRestModel {
    AcctBasicInfo: IAcctBasicInfo;
    PersonInfo: IPersonInfo;
    AccountStatus: IAccountStatus;
    AcctBal: IAcctBalRestModel[];
    ExtAcctBal: IExtAcctBalRestModel[];
    OwnerInd: string;
    RefInfo: IRefInfoRestModel[];
    OpenDt: string;
    ExpDt: string;
    PaidDt: string;
    DueDt: string;
    MinPmtCurAmt: string;
    Term: string;
    Rate: string;
    OverdraftDays: string;
    Fee: string;
    NextPmtCurAmt: string;
    Ownership: string;
    FinalCurAmt: string;
    isPrincipalServiceUsed?: boolean;
    circuitBreakerState?: string;
}

export class AccInfoRestModelBuilder {
    private readonly accInfoRestModel: IAccInfoRestModel;

    constructor() {
        this.accInfoRestModel = {} as IAccInfoRestModel;
    }

    // Recibe los valores individuales necesarios para construir IAcctBasicInfo
    setAcctBasicInfo(acctBasicInfo: IAcctBasicInfo): AccInfoRestModelBuilder {
        this.accInfoRestModel.AcctBasicInfo = acctBasicInfo;
        return this;
    }

    setPersonInfo(PersonInfo: IPersonInfo): AccInfoRestModelBuilder{
        this.accInfoRestModel.PersonInfo = PersonInfo;
        return this;
    }

    // Recibe los valores individuales necesarios para construir IAcctBasicInfo
    setAccountStatus(statusCode: string, statusDesc: string): AccInfoRestModelBuilder {
        this.accInfoRestModel.AccountStatus = {
            StatusCode: statusCode,
            StatusDesc: statusDesc
        };
        return this;
    }

    setAcctBal(AcctBal: IAcctBalRestModel[]): AccInfoRestModelBuilder {
        this.accInfoRestModel.AcctBal = AcctBal;
        return this;
    }


    setOwnerInd(OwnerInd: string): AccInfoRestModelBuilder{
        this.accInfoRestModel.OwnerInd = OwnerInd;
        return this;
    }
    setRefInfo(RefInfo: IRefInfoRestModel[]): AccInfoRestModelBuilder{
        this.accInfoRestModel.RefInfo = RefInfo;
        return this;
    }
    setOpenDt(OpenDt: string): AccInfoRestModelBuilder{
        this.accInfoRestModel.OpenDt = OpenDt;
        return this;
    }
    setExpDt(ExpDt: string): AccInfoRestModelBuilder{
        this.accInfoRestModel.ExpDt = ExpDt;
        return this;
    }
    setPaidDt(PaidDt: string): AccInfoRestModelBuilder{
        this.accInfoRestModel.PaidDt = PaidDt;
        return this;
    }
    setMinPmtCurAmt(MinPmtCurAmt: string): AccInfoRestModelBuilder{
        this.accInfoRestModel.MinPmtCurAmt = MinPmtCurAmt;
        return this;
    }
    setTerm(Term: string): AccInfoRestModelBuilder{
        this.accInfoRestModel.Term = Term;
        return this;
    }
    setRate(Rate: string): AccInfoRestModelBuilder{
        this.accInfoRestModel.Rate = Rate;
        return this;
    }
    setOverdraftDays(OverdraftDays: string): AccInfoRestModelBuilder{
        this.accInfoRestModel.OverdraftDays = OverdraftDays;
        return this;
    }
    setFee(Fee: string): AccInfoRestModelBuilder{
        this.accInfoRestModel.Fee = Fee;
        return this;
    }
    setNextPmtCurAmt(NextPmtCurAmt: string): AccInfoRestModelBuilder{
        this.accInfoRestModel.NextPmtCurAmt = NextPmtCurAmt;
        return this;
    }
    setDueDt(DueDt: string): AccInfoRestModelBuilder{
        this.accInfoRestModel.DueDt = DueDt;
        return this;
    }
    setOwnership(Ownership: string): AccInfoRestModelBuilder{
        this.accInfoRestModel.Ownership = Ownership;
        return this;
    }
    setFinalCurAmt(FinalCurAmt: string): AccInfoRestModelBuilder{
        this.accInfoRestModel.FinalCurAmt = FinalCurAmt;
        return this;
    }

    setExtAcctBal(ExtAcctBal: IExtAcctBalRestModel[]): AccInfoRestModelBuilder {
        this.accInfoRestModel.ExtAcctBal = ExtAcctBal;
        return this;
    }

    build(): IAccInfoRestModel {
        return this.accInfoRestModel;
    }
}
