import { StringNullable } from './GenericTypes';
import { RequestHeadersModel } from './RequestHeadersModel';

export class ReqHeadersAdditionalRest {
    public GeneralHeaders: RequestHeadersModel;
    public AcctType: StringNullable;
    public AcctSubType: StringNullable;
    public BranchId: StringNullable;

    constructor(generalHeaders: RequestHeadersModel, acctType? :string, acctSubType?:string, branchId?: string) {
        this.GeneralHeaders = generalHeaders;
        this.AcctType = acctType;
        this.AcctSubType = acctSubType;
        this.BranchId = branchId;
    }
}
