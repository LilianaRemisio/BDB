
export interface IGovIssueIdent {
    GovIssueIdentType: string;
    IdentSerialNum: string;
}
