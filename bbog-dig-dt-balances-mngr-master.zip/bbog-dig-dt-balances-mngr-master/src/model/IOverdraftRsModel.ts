import { IDefaultStatusModel } from './IDefaultStatusModel';
export interface IOverdraftRsModel {
    RqUID: string;
    Status: IDefaultStatusModel;
    EndDt: string;
    AcctBalRec: AcctBalRec;
}

export interface AcctBalRec {
    AcctBasicInfo: AcctBasicInfo;
    AcctBal: AcctBal;
}

export interface AcctBasicInfo {
    AcctId: string;
    AcctType: string;
}

export interface AcctBal {
    EffDt: string;
    ExpDt: string;
}

export class IOverdraftRsModelBuilder {
    private readonly IOverdraftRsModel: IOverdraftRsModel;

    constructor() {
        this.IOverdraftRsModel = {} as IOverdraftRsModel;
        this.IOverdraftRsModel.RqUID = '';
        this.IOverdraftRsModel.Status = {} as IDefaultStatusModel;
        this.IOverdraftRsModel.EndDt = '';
        this.IOverdraftRsModel.AcctBalRec = {} as AcctBalRec;
    }

    setRqUID(rqUID: string): IOverdraftRsModelBuilder {
        this.IOverdraftRsModel.RqUID = rqUID;
        return this;
    }

    setStatus(status: IDefaultStatusModel): IOverdraftRsModelBuilder {
        this.IOverdraftRsModel.Status = status;
        return this;
    }

    setEndDt(endDt: string): IOverdraftRsModelBuilder {
        this.IOverdraftRsModel.EndDt = endDt;
        return this;
    }

    setAcctBasicInfo(acctBasicInfo: AcctBasicInfo): IOverdraftRsModelBuilder {
        this.IOverdraftRsModel.AcctBalRec.AcctBasicInfo = acctBasicInfo;
        return this;
    }

    setAcctBal(acctBal: AcctBal): IOverdraftRsModelBuilder {
        this.IOverdraftRsModel.AcctBalRec.AcctBal = acctBal;
        return this;
    }

    build(): IOverdraftRsModel {
        return this.IOverdraftRsModel;
    }
}


