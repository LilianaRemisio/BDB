import { IGovIssueIdent } from './IGovIssueIdent';

export interface IPersonInfo {
    FullName: string;
    GovIssueIdent: IGovIssueIdent;
}

export class PersonInfo implements IPersonInfo {
    FullName: string;
    GovIssueIdent: IGovIssueIdent;

    // Constructor que acepta todos los valores
    constructor(FullName: string, GovIssueIdentType: string, IdentSerialNum: string) {
        this.FullName = FullName;
        this.GovIssueIdent = {
            GovIssueIdentType,
            IdentSerialNum
        };
    }
}
