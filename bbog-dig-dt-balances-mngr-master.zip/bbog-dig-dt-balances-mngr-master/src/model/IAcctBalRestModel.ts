import { ICurAmtRestModel } from './ICurAmtRestModel';

export interface IAcctBalRestModel {
    BalType: string;
    CurAmt: ICurAmtRestModel;
}

// Implementación del patrón Builder para IAcctBalRestModel
export class AcctBalRestModelBuilder {
    private readonly acctBalRestModel: IAcctBalRestModel;

    constructor() {
        // Inicialización utilizando 'as' para establecer un objeto vacío con el tipo deseado
        this.acctBalRestModel = {
            BalType: '',
            CurAmt: {} as ICurAmtRestModel,
        };
    }

    // Método para establecer el BalType
    public setBalType(balType: string): AcctBalRestModelBuilder {
        this.acctBalRestModel.BalType = balType;
        return this;
    }

    // Método para establecer CurAmt
    public setCurAmt(amt: string, curCode: string): AcctBalRestModelBuilder {
        this.acctBalRestModel.CurAmt = { Amt: amt, CurCode: curCode };
        return this;
    }

    // Método para construir el objeto final
    public build(): IAcctBalRestModel {
        return this.acctBalRestModel;
    }
}
