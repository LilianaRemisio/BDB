import { IDefaultStatusModel } from '../model/IDefaultStatusModel';
import genericUtilities from '../utils/GenericUtilities';


export class DefaultResponseModel {
    public RqUID: string; // Add this line
    public Status: IDefaultStatusModel;
    public EndDt: string;


    constructor(Status: IDefaultStatusModel, xRqUID: string) {
        this.RqUID = xRqUID;
        this.Status = Status;
        this.EndDt = genericUtilities.getCurrentDateStringFormat('yyyy-mm-dd\'T\'HH:MM:ss');
    }
}
