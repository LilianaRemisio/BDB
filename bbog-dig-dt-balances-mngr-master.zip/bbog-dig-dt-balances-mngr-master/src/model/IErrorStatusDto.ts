import { SeverityType } from './GenericTypes';

export interface IErrorStatusDto {
    StatusCode: number;
    ServerStatusCode: string;
    Severity: SeverityType;
    StatusDesc: string;
}
