import { IDefaultStatusModel } from '../model/IDefaultStatusModel';
import { IAccInfoRestModel } from './IAccInfoRestModel';

export interface IBalanceListRestRsModel {
    RqUID: string;
    Status: IDefaultStatusModel;
    EndDt: string;
    AccInfo: IAccInfoRestModel[];
    isPrincipalServiceUsed?: boolean;
    circuitBreakerState?: string;
}

export class BalanceListRestRsModelBuilder {
    private readonly balanceListRestRsModel: IBalanceListRestRsModel;

    constructor();
    constructor(initialData?: Partial<IBalanceListRestRsModel>) {
      this.balanceListRestRsModel = initialData ? { ...initialData } as IBalanceListRestRsModel : {} as IBalanceListRestRsModel;
    }

    setRqUID(rqUID: string): BalanceListRestRsModelBuilder {
        this.balanceListRestRsModel.RqUID = rqUID;
        return this;
    }
    setStatus(status: IDefaultStatusModel): BalanceListRestRsModelBuilder {
        this.balanceListRestRsModel.Status = status;
        return this;
    }

    setEndDt(endDt: string): BalanceListRestRsModelBuilder {
        this.balanceListRestRsModel.EndDt = endDt;
        return this;
    }

    setListBalance(AccInfo: IAccInfoRestModel[]): BalanceListRestRsModelBuilder {
        this.balanceListRestRsModel.AccInfo = AccInfo;
        return this;
    }

    setIsPrincipalServiceUsed(isPrincipalServiceUsed: boolean): BalanceListRestRsModelBuilder{
        this.balanceListRestRsModel.isPrincipalServiceUsed = isPrincipalServiceUsed;
        return this;
    }

    setCircuitBreakerState(circuitBreakerState: string): BalanceListRestRsModelBuilder{
        this.balanceListRestRsModel.circuitBreakerState = circuitBreakerState;
        return this;
    }

    build(): IBalanceListRestRsModel {
        return this.balanceListRestRsModel;
    }
}


