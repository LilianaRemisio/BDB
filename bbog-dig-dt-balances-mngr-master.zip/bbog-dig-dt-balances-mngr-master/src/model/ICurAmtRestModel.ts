export interface ICurAmtRestModel {
    Amt: string;
    CurCode: string;
}



