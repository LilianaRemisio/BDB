import { ICurAmtRestModel } from './ICurAmtRestModel';

export interface IExtAcctBalRestModel {
    ExtBalType: string;
    CurAmt: ICurAmtRestModel;
    EffDt: string;
}

// Implementación del patrón Builder para IExtAcctBalRestModel
export class ExtAcctBalRestModelBuilder {
    private readonly extAcctBalRestModel: IExtAcctBalRestModel;

    constructor() {
        // Inicialización utilizando 'as' para establecer un objeto vacío con el tipo deseado
        this.extAcctBalRestModel = {
            ExtBalType: '',
            CurAmt: {} as ICurAmtRestModel,
            EffDt: '',
        };
    }

    // Método para establecer el BalType
    public setExtBalType(ExtBalType: string): ExtAcctBalRestModelBuilder {
        this.extAcctBalRestModel.ExtBalType = ExtBalType;
        return this;
    }

    // Método para establecer CurAmt
    public setCurAmt(amt: string, curCode: string): ExtAcctBalRestModelBuilder {
        this.extAcctBalRestModel.CurAmt = { Amt: amt, CurCode: curCode };
        return this;
    }

    public setEffDt(EffDt: string): ExtAcctBalRestModelBuilder {
        this.extAcctBalRestModel.EffDt = EffDt;
        return this;
    }

    // Método para construir el objeto final
    public build(): IExtAcctBalRestModel {
        return this.extAcctBalRestModel;
    }
}
