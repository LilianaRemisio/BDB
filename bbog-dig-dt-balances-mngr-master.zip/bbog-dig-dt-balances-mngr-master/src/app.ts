import { IDetails, IReportData, IRequest, IResponse, ReportService } from '@npm-bbta/bbog-dig-dt-report-interceptor-lib';
import cookieParser from 'cookie-parser';
import express, { Request, Response } from 'express';
import balancesRouter from './routes/BalancesRouter';
import EnviromentManagementService from './service/request/EnviromentManagementService';
import indexRouter from './routes/IndexRouter';
import { constants } from 'http2';
import errorHandler from './utils/handler/ErrorHandler';
import mung from 'express-mung';
import { performance } from 'perf_hooks';
import getLogger from './utils/GetLogger';
import config from './config';

export const reportService = new ReportService();
const logBdb = getLogger('bdb:AppBalanceManagement');
const app = express();
app.disable('x-powered-by');

app.locals.fallbackServiceCalled = false;
app.locals.circuitBreakerState = 'close';

app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.use(cookieParser());

app.use((req, res, next) => {
  res.locals.initialDate = performance.now();
  next();
});

app.get('/balancesManagement/env-vars', (req: Request, res: Response) => {
  const result = EnviromentManagementService.getStatusOfEnvVars();
  res.status(constants.HTTP_STATUS_OK).json(result);
});

app.post('/balancesManagement/env-vars', (req: Request, res: Response) => {
  const result = EnviromentManagementService.updateEnvVars(req);
  res.status(constants.HTTP_STATUS_OK).json(result);
});

app.use(mung.jsonAsync(
  async function transform(body: any, req, res) {
    const finalDate = performance.now();
    const executionTime = finalDate - res.locals.initialDate;
    const rquid = req.headers['x-rquid'] as string;
    /* istanbul ignore else */
    const elasticsearch = {
        apiName: 'API_BALANCE_MANAGEMENT',
        executionTime,
        path: '/Enterprise/',
        useCircuitBreakerSavings: config.USE_CIRCUIT_BREAKER_SAVINGS,
        useCircuitBreakerDemands: config.USE_CIRCUIT_BREAKER_DEMANDS,
        circuitBreakerOptions: config.CIRCUIT_BREAKER_OPTIONS,
      };
    const detailsReport: IDetails = {
      elasticsearch_report: true,
      pentagono_report: false,
      pentagono: {
        eventClientId: config.EVENT_CLIENT_ID,
        eventSessionId: config.EVENT_SESSION_ID,
      }
    };
    const request: IRequest = {
      body: req.body,
      headers: req.headers,
      method:req.method,
      path: req.originalUrl,
      query: req.query
    };
    const response: IResponse = {
      details: detailsReport,
      infoDetails: elasticsearch,
      responseBody: {},
      responseStatus: body.status ? body.status : res.statusCode
    };
    const reportData: IReportData = {
        req:request,
        res: response,
        uuid: rquid
    };
    logBdb.debug(rquid, 'Reporting Data: ', JSON.stringify(reportData));
    try {
      const data = await reportService.onlyPublishInSns(reportData);
      logBdb.info(rquid, 'Elastic report sent', JSON.stringify(data));
    } catch (err: any) {
      const error = err.response?.data ? err.response.data : err.message;
      logBdb.error(rquid, 'Fail to send elastic report ', JSON.stringify(error));
    }
    return Promise.resolve(body);
  }, {mungError: true}
));

app.use('/', indexRouter);
app.use('/V2/Enterprise/BalanceManagement', balancesRouter);
app.use(errorHandler.handlerErrorResponse);
app.use(errorHandler.handlerError404Response);

export default app;