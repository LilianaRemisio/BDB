import xml2js from 'xml2js';
import xpath from 'xml2js-xpath';
import { IStructurePropertiesModel } from '../model/IStructurePropertiesModel';
import getLogger from '../utils/GetLogger';

const logBdb = getLogger('bdb:ResponseProcessor');
const PARSER_OPTIONS = {
    explicitArray: false,
    ignoreAttrs: true,
    tagNameProcessors: [xml2js.processors.stripPrefix],
};

class ResponseProcessor {
    private readonly parser: xml2js.Parser = new xml2js.Parser(PARSER_OPTIONS);

    public async parseXml(response: string): Promise<any> {
        return new Promise((resolve, reject) => {
            this.parser.parseString(response, (err: any, result: any) => {
                if (err){
                    reject(err);
                }
                else{
                    resolve(result);
                }
            });
        });
    }

    public extractData(result: any, structure: IStructurePropertiesModel): any {
        const method = `${structure.method}Response`;
        const matches = xpath.find(result, `//${structure.responseName}`);
        if (matches.length === 0) {
            throw new Error('No matching response found');
        }
        return result.Envelope.Body[method][structure.responseName];
    }

    public validateResponse(resultService: any): boolean {
        try {
            const statusCode = +resultService.Status?.StatusCode;
            return statusCode === 0;
        } catch {
            return false;
        }
    }
}

const responseProcessor = new ResponseProcessor();
export default responseProcessor;
