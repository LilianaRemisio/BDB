import genericUtilities from '../utils/GenericUtilities';
import { AcctBalRestModelBuilder, IAcctBalRestModel } from '../model/IAcctBalRestModel';
import { BalanceListRestRsModelBuilder, IBalanceListRestRsModel } from '../model/IBalanceListRestRsModel';
import { AccInfoRestModelBuilder, IAccInfoRestModel } from '../model/IAccInfoRestModel';
import { DefaultStatusModelBuilder, IDefaultStatusModel } from '../model/IDefaultStatusModel';
import { ExtAcctBalRestModelBuilder, IExtAcctBalRestModel } from '../model/IExtAcctBalRestModel';
import { ResponseFetchModel } from '../model/ResponseFetchModel';
import responseProcessor from './ResponseProcessor';
import { IStructurePropertiesModel } from '../model/IStructurePropertiesModel';
import getLogger from '../utils/GetLogger';
import { DefaultResponseModel } from '../model/DefaultResponseModel';
import { AdapterErrorN } from '../utils/AdapterError';
import { SeverityType, StringNullable } from '../model/GenericTypes';
import { RequestHeadersModel } from '../model/RequestHeadersModel';
import { IRefInfoRestModel, RefInfoRestModelBuilder } from '../model/IRefInfoRestModel';
import { ReqHeadersAdditionalRest } from '../model/ReqHeadersAdditionalRest';
import { IPersonInfo, PersonInfo } from '../model/IPersonInfo';
import { AcctBasicInfoBuilder, IAcctBasicInfo } from '../model/IAcctBasicInfo';
import { BankInfo } from '../model/IBankInfo';
import { IAdditionalInfo } from 'model/IAdditionalInfo';
import { ILoanQuotaRestRsModel, LoanQuotaRestRsModelBuilder } from '../model/ILoanQuotaRestRsModel';
import { IOverdraftRsModel, IOverdraftRsModelBuilder } from '../model/IOverdraftRsModel';

const logBdb = getLogger('bdb:BalancesManagerMapper');
export default class BalancesManagerMapper {

  public static mapperNetwrkOwner(requestHeadersModel: RequestHeadersModel): StringNullable {
    const xNetworkOwner = requestHeadersModel['X-NetworkOwner'];
    const xChannel = requestHeadersModel['X-Channel'];
    return xNetworkOwner ? xNetworkOwner : genericUtilities.validateChannel(xChannel);
  }

  public static async mapperXmlToRestRsBalance(rquid: string, structure: IStructurePropertiesModel, responseFetchModel: ResponseFetchModel<any>): Promise<IBalanceListRestRsModel> {
    try {
      const parsedResult = await responseProcessor.parseXml(responseFetchModel.data);
      const resultService = responseProcessor.extractData(parsedResult, structure);
      const isValidResponse = responseProcessor.validateResponse(resultService);
      if (!isValidResponse) {
        const statusIn = resultService.Status;
        const statusBusinessError: IDefaultStatusModel = this.mapperDefaultStatusModel(
          409, 'Business Error', statusIn.Severity, statusIn.ServerStatusCode, statusIn.ServerStatusDesc);
        const defaultResponse: DefaultResponseModel = new DefaultResponseModel(statusBusinessError, rquid);
        throw new AdapterErrorN('Error de negocio', 409, defaultResponse);
      }

      const statusSucces: IDefaultStatusModel = this.mapperDefaultStatusModel(0, 'Transaccion exitosa', 'Info', responseFetchModel.code, responseFetchModel.status.toString());
      const response: IBalanceListRestRsModel = new BalanceListRestRsModelBuilder()
        .setRqUID(rquid)
        .setStatus(statusSucces)
        .setEndDt(genericUtilities.getCurrentDateStringFormat('yyyy-mm-dd\'T\'HH:MM:ss'))
        .setListBalance(this.mapperIAccInfoRestModel(structure.objectName, resultService))
        .setIsPrincipalServiceUsed(responseFetchModel.principalServiceUsed)
        .setCircuitBreakerState(responseFetchModel.circuitBreakerState)
        .build();
      return response;
    } catch (err: any) {
      const error = err.response?.data ? err.response.data : err.message;
      logBdb.error(rquid, `Error mapper method`, error);
      throw err;
    }
  }

  public static async mapperXmlToRestLoanQuotaRsBalance(rquid: string, structure: IStructurePropertiesModel, responseFetchModel: ResponseFetchModel<any>): Promise<ILoanQuotaRestRsModel> {
    try {
      const parsedResult = await responseProcessor.parseXml(responseFetchModel.data);
      const resultService = responseProcessor.extractData(parsedResult, structure);
      const isValidResponse = responseProcessor.validateResponse(resultService);
      if (!isValidResponse) {
        const statusIn = resultService.Status;
        const statusBusinessError: IDefaultStatusModel = this.mapperDefaultStatusModel(
          409, 'Business Error', statusIn.Severity, statusIn.ServerStatusCode, statusIn.ServerStatusDesc);
        const defaultResponse: DefaultResponseModel = new DefaultResponseModel(statusBusinessError, rquid);
        throw new AdapterErrorN('Error de negocio', 409, defaultResponse);
      }
      const statusSucces: IDefaultStatusModel = this.mapperDefaultStatusModel(0, 'Transaccion exitosa', 'Info', responseFetchModel.code, responseFetchModel.status.toString());
      const response: ILoanQuotaRestRsModel = new LoanQuotaRestRsModelBuilder()
        .setRqUID(rquid)
        .setStatus(statusSucces)
        .setEndDt(genericUtilities.getCurrentDateStringFormat('yyyy-mm-dd\'T\'HH:MM:ss'))
        .setInterestRate(this.getValueOrNull( resultService.AcctBal.CurAmt[0].Amt ))
        .setInterestAmount((this.getValueOrNull( resultService.AcctBal.CurAmt[1].Amt )))
        .setTotalRepmtAmt((this.getValueOrNull( resultService.AcctBal.CurAmt[2].Amt )))
        .setFlatAmount((this.getValueOrNull( resultService.AcctBal.CurAmt[3].Amt )))
        .setPaymentAmount((this.getValueOrNull( resultService.AcctBal.CurAmt[4].Amt )))
        .setMaturityDate((this.getValueOrNull( resultService.AcctBal.EffDt )))
        .build();
      return response;
    } catch (err: any) {
      const error = err.response?.data ? err.response.data : err.message;
      logBdb.error(rquid, `Error mapper method`, error);
      throw err;
    }
  }

  public static mapperRestToRestGroupRsBalance(rquid: string, balanceServices: any[]): IBalanceListRestRsModel {
    const allFulfilled = balanceServices.every(b => b.status === 'fulfilled');
    const someFulfilled = balanceServices.some(b => b.status === 'fulfilled');
    const someConflict = balanceServices.some(b => b.status === 'rejected' && b.reason?.errorType === 409);
    const allInternalError = balanceServices.every(b => b.status === 'rejected' && b.reason?.errorType === 500);
    const allTimeoutError = balanceServices.every(b => b.status === 'rejected' && b.reason?.errorType === 408);

    if (allFulfilled) {
      return this.buildSuccessResponse(rquid, balanceServices, 200);
    }
    if (someFulfilled) {
      return this.buildSuccessResponse(rquid, balanceServices, 206);
    }
    if (someConflict) {
      this.throwBusinessError(rquid, balanceServices, 409, 'Business Error');
    }
    if (allInternalError) {
      this.throwBusinessError(rquid, balanceServices, 500, 'Internal Error');
    }
    if (allTimeoutError) {
      this.throwBusinessError(rquid, balanceServices, 408, 'Timeout Error');
    }

    // Caso desconocido
    return this.buildUnknownResponse(rquid, balanceServices);
  }

  private static extractAdditionalInfo(balances: any[]): IAdditionalInfo[] {
    return balances
      .filter(b => b?.reason)
      .map(b => ({
        AcctType: b.reason.AcctType,
        AcctId: b.reason.AcctId,
        StatusBalance: b.reason.error?.Status
      }));
  }

  private static buildSuccessResponse(rquid: string, balanceServices: any[], code: number): IBalanceListRestRsModel {
    const listAccInfoRestModel: IAccInfoRestModel[] = [];
    const additionalInfoList = this.extractAdditionalInfo(balanceServices);
    balanceServices.forEach((balance) => {
      const accInfo = balance?.value?.result?.AccInfo;
      if (accInfo && accInfo.length > 0) {
        accInfo[0].isPrincipalServiceUsed=balance?.value?.result?.isPrincipalServiceUsed;
        accInfo[0].circuitBreakerState=balance?.value?.result?.circuitBreakerState;
        listAccInfoRestModel.push(accInfo[0]);
      }
    });
    const statusSucces: IDefaultStatusModel = this.mapperDefaultStatusModel(code, 'Transaccion exitosa', 'Info', '0', 'Transaccion exitosa', additionalInfoList);
    const response: IBalanceListRestRsModel = new BalanceListRestRsModelBuilder()
      .setRqUID(rquid)
      .setStatus(statusSucces)
      .setEndDt(genericUtilities.getCurrentDateStringFormat('yyyy-mm-dd\'T\'HH:MM:ss'))
      .setListBalance(listAccInfoRestModel)
      .build();
    return response;
  }

  private static throwBusinessError(rquid: string, services: any[], code: number, description: string): never {
    const additionalInfoList = this.extractAdditionalInfo(services);
    const statusError = this.mapperDefaultStatusModel(
      code,
      description,
      'Error',
      code.toString(),
      'Error en respuesta servicios balances',
      additionalInfoList
    );

    const defaultResponse = new DefaultResponseModel(statusError, rquid);
    throw new AdapterErrorN(description, code, defaultResponse);
  }

  private static buildUnknownResponse(rquid: string, balances: any[]): IBalanceListRestRsModel {
    const additionalInfoList = this.extractAdditionalInfo(balances);
    const status = this.mapperDefaultStatusModel(
      500,
      'No se pudo determinar el estado de los balances',
      'Error',
      '500',
      'Estado desconocido',
      additionalInfoList
    );
    return new BalanceListRestRsModelBuilder()
      .setRqUID(rquid)
      .setStatus(status)
      .setEndDt(genericUtilities.getCurrentDateStringFormat('yyyy-mm-dd\'T\'HH:MM:ss'))
      .setListBalance([])
      .build();
  }

  public static mapperRestToRestRsBalance(rquid: string, structure: IStructurePropertiesModel, responseFetchModel: ResponseFetchModel<any>): IBalanceListRestRsModel {
    // Se valida primero si es una respuesta por error de negocio
    if (responseFetchModel.data.Status?.StatusCode === 100) {
      const statusIn = responseFetchModel.data?.Status;
      const statusBusinessError: IDefaultStatusModel = this.mapperDefaultStatusModel(409, 'Business Error', 'Error', statusIn.StatusCode, statusIn.StatusDesc);
      const defaultResponse: DefaultResponseModel = new DefaultResponseModel(statusBusinessError, rquid);
      throw new AdapterErrorN('Error de negocio', 409, defaultResponse);
    }

    const statusSucces: IDefaultStatusModel = this.mapperDefaultStatusModel(0, 'Transaccion exitosa', 'Info', responseFetchModel.code, responseFetchModel.status.toString());
    const response: IBalanceListRestRsModel = new BalanceListRestRsModelBuilder()
      .setRqUID(rquid)
      .setStatus(statusSucces)
      .setEndDt(genericUtilities.getCurrentDateStringFormat('yyyy-mm-dd\'T\'HH:MM:ss'))
      .setListBalance(this.mapperIAccInfoRestModel(structure.objectName, responseFetchModel))
      .setIsPrincipalServiceUsed(responseFetchModel.principalServiceUsed)
      .setCircuitBreakerState(responseFetchModel.circuitBreakerState)
      .build();
    return response;
  }

  public static mapperDefaultStatusModel(statusCode: number, statusDesc: string, severity: string, serverStatusCode: string, serverStatusDesc: string, additionalStatus?: IAdditionalInfo[]): IDefaultStatusModel {
    const status: IDefaultStatusModel = new DefaultStatusModelBuilder().setStatusCode(statusCode)
      .setStatusDesc(statusDesc)
      .setSeverity(severity as SeverityType)
      .setServerStatusCode(serverStatusCode)
      .setServerStatusDesc(serverStatusDesc)
      .setAdditionalStatus(additionalStatus)
      .build();
    return status;
  }

  public static mapperIAccInfoRestModel(objectName: string, responseIn: any): IAccInfoRestModel[] {
    const listAccInfoRestModel: IAccInfoRestModel[] = [];
    const objectRoot = responseIn[objectName];
    const accInfoRestModel = new AccInfoRestModelBuilder()
      .setAcctBasicInfo(this.mapperAcctBasicInfo(objectRoot?.AcctBasicInfo))
      .setPersonInfo(this.mapperPersonInfo(objectRoot))
      .setAccountStatus(objectRoot?.AccountStatus?.StatusCode || '', objectRoot?.AccountStatus?.StatusDesc || '')
      .setAcctBal(this.mapperAcctBal(objectRoot))
      .setExtAcctBal(this.mapperExtAcctBal(objectRoot))
      .setOwnerInd(genericUtilities.getValueOrNull(objectRoot?.OwnerInd))
      .setRefInfo(this.mapperRefInfo(objectRoot))
      .setOpenDt(genericUtilities.formatDateString(objectRoot?.OpenDt))
      .setExpDt(genericUtilities.formatDateString(objectRoot?.ExpDt))
      .setPaidDt(genericUtilities.formatDateString(objectRoot?.PaidDt))
      .setMinPmtCurAmt(genericUtilities.getValueOrNull(objectRoot?.MinPmtCurAmt))
      .setTerm(genericUtilities.getValueOrNull(objectRoot?.Term))
      .setRate(genericUtilities.getValueOrNull(objectRoot?.Rate))
      .setOverdraftDays(genericUtilities.getValueOrNull(objectRoot?.OverdraftDays))
      .setFee(genericUtilities.getValueOrNull(objectRoot?.Fee))
      .setNextPmtCurAmt(genericUtilities.getValueOrNull(objectRoot?.NextPmtCurAmt))
      .setDueDt(genericUtilities.formatDateString(objectRoot?.DueDt))
      .setOwnership(genericUtilities.getValueOrNull(objectRoot?.Ownership))
      .setFinalCurAmt(genericUtilities.getValueOrNull(objectRoot?.FinalCurAmt))
      .build();
    listAccInfoRestModel.push(accInfoRestModel);
    return listAccInfoRestModel;
  }

  public static mapperAcctBasicInfo(objectRoot: any): IAcctBasicInfo {
    const customBankInfo = new BankInfo(
      this.getValueOrNull(objectRoot?.BankInfo?.BankId),
      { RefType: this.getValueOrNull(objectRoot?.BankInfo?.RefInfo?.RefType), RefId: this.getValueOrNull(objectRoot?.BankInfo?.RefInfo?.RefId) },
      this.getValueOrNull(objectRoot?.BankInfo?.BranchId));

    const acctBasicInfo: IAcctBasicInfo = new AcctBasicInfoBuilder()
      .setAcctId(this.getValueOrNull(objectRoot?.AcctId))
      .setAcctType(this.getValueOrNull(objectRoot?.AcctType))
      .setAcctSubType(this.getValueOrNull(objectRoot?.AcctSubType))
      .setAcctCur(this.getValueOrNull(objectRoot?.AcctCur))
      .setBankInfo(customBankInfo)
      .build();
    return acctBasicInfo;
  }

  public static mapperPersonInfo(objectRoot: any): IPersonInfo {
    const fullName = genericUtilities.getValueOrNull(objectRoot?.PersonInfo?.FullName);
    const govIssueIdentType = genericUtilities.getValueOrNull(objectRoot?.PersonInfo?.GovIssueIdent?.GovIssueIdentType);
    const identSerialNum = genericUtilities.getValueOrNull(objectRoot?.PersonInfo?.GovIssueIdent?.IdentSerialNum);
    const personInfo: IPersonInfo = new PersonInfo(fullName, govIssueIdentType, identSerialNum);
    return personInfo;
  }

  public static mapperAcctBal(objectRoot: any): IAcctBalRestModel[] {
    const listAcctalBal: IAcctBalRestModel[] = [];
    // Validar si AcctBal existe y es un array, de lo contrario convertirlo a un array
    let acctBalArray: any[] = [];
    if (Array.isArray(objectRoot?.AcctBal)) {
      acctBalArray = objectRoot.AcctBal;
    } else if (objectRoot?.AcctBal) {
      acctBalArray = [objectRoot.AcctBal];
    }
    const acctBalList = acctBalArray;
    acctBalList.forEach((acctBalIn: any) => {
      const acctBalOut: IAcctBalRestModel = new AcctBalRestModelBuilder()
        .setBalType(acctBalIn?.BalType || '')
        .setCurAmt(acctBalIn.CurAmt?.Amt, 'COP')
        .build();
      listAcctalBal.push(acctBalOut);
    });
    return listAcctalBal;
  }

  public static mapperExtAcctBal(objectRoot: any): IExtAcctBalRestModel[] {
    const listExtAcctalBal: IExtAcctBalRestModel[] = [];
    // Validar si ExtAcctBal existe y es un array, de lo contrario convertirlo a un array
    let extAcctBalArray: any[] = [];
    if (Array.isArray(objectRoot?.ExtAcctBal)) {
      extAcctBalArray = objectRoot.ExtAcctBal;
    } else if (objectRoot?.ExtAcctBal) {
      extAcctBalArray = [objectRoot.ExtAcctBal];
    }
    const extAcctBalList = extAcctBalArray;
    // Iterar sobre el array generado
    extAcctBalList.forEach((extAcctBalIn: any) => {
      const extAcctBalOut: IExtAcctBalRestModel = new ExtAcctBalRestModelBuilder()
        .setExtBalType(extAcctBalIn?.ExtBalType || '')
        .setCurAmt(extAcctBalIn.CurAmt?.Amt, 'COP')
        .setEffDt(extAcctBalIn.EffDt)
        .build();
      listExtAcctalBal.push(extAcctBalOut);
    });
    return listExtAcctalBal;
  }

  public static mapperRefInfo(objectRoot: any): IRefInfoRestModel[] {
    const listRefInfo: IRefInfoRestModel[] = [];
    // Validar si RefInfo existe y es un array, de lo contrario convertirlo a un array
    let refInfoArray: any[] = [];
    if (Array.isArray(objectRoot?.RefInfo)) {
      refInfoArray = objectRoot.RefInfo;
    } else if (objectRoot?.RefInfo) {
      refInfoArray = [objectRoot.RefInfo];
    }
    const refInfoList = refInfoArray;
    // Iterar sobre el array generado
    refInfoList.forEach((refInfoIn: any) => {
      const refInfoOut: IRefInfoRestModel = new RefInfoRestModelBuilder()
        .setRefType(refInfoIn?.RefType || '')
        .setRefId(refInfoIn?.RefId || '')
        .build();
      listRefInfo.push(refInfoOut);
    });
    return listRefInfo;
  }

  public static mapperAddAccounts(acctId: string, params: ReqHeadersAdditionalRest): string {
    const acctType = params.AcctType ? `<v1:AcctType>${params.AcctType}</v1:AcctType>` : '';
    const acctSubType = params.AcctSubType ? `<v1:AcctSubType>${params.AcctSubType}</v1:AcctSubType>` : '';
    const branchId = params.BranchId ? `<v1:BranchId>${params.BranchId}</v1:BranchId>` : '';
    return `
    <v11:AcctBasicInfo>
        <v1:AcctId>${acctId}</v1:AcctId>
        ${acctType}
        ${acctSubType}
        <v11:BankInfo>
          ${branchId}
        </v11:BankInfo>
     </v11:AcctBasicInfo>`;
  }

  public static async mapperXmlToRestRetrieveOverdraftRs(rquid: string, structure: IStructurePropertiesModel, responseFetchModel: any): Promise<any> {
    try {
      const parsedResult = await responseProcessor.parseXml(responseFetchModel.data);
      const resultService = responseProcessor.extractData(parsedResult, structure);
      const isValidResponse = responseProcessor.validateResponse(resultService);
      if (!isValidResponse) {
        const statusIn = resultService.Status;
        const statusBusinessError: IDefaultStatusModel = this.mapperDefaultStatusModel(
          409, 'Business Error', statusIn.Severity, statusIn.ServerStatusCode, statusIn.ServerStatusDesc);
        const defaultResponse: DefaultResponseModel = new DefaultResponseModel(statusBusinessError, rquid);
        throw new AdapterErrorN('Error de negocio', 409, defaultResponse);
      }
      const statusSucces: IDefaultStatusModel = this.mapperDefaultStatusModel(0, 'Transaccion exitosa', 'Info', responseFetchModel.code, responseFetchModel.status.toString());
      const response: IOverdraftRsModel = new IOverdraftRsModelBuilder()
        .setRqUID(rquid)
        .setStatus(statusSucces)
        .setEndDt(genericUtilities.getCurrentDateStringFormat('yyyy-mm-dd\'T\'HH:MM:ss'))
        .setAcctBasicInfo(resultService.AcctBalRec.AcctBasicInfo)
        .setAcctBal(resultService.AcctBalRec.AcctBal)
        .build();
      return response;
    } catch (err: any) {
      const error = err.response?.data ? err.response.data : err.message;
      logBdb.error(rquid, `Error mapper method`, error);
      throw err;
    }
  }


  public static getValueOrNull(value: any): any {
    return value ?? null;
  }
}
