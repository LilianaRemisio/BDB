
import config from '../../config';
import { RequestService } from '../request/RequestService';
import { IStructureBalanceDefinition } from '../../model/IStructureBalanceDefinition';
import { generateXml } from '../CommonService';
import { IDefaultStatusModel } from '../../model/IDefaultStatusModel';
import genericUtilities from '../../utils/GenericUtilities';
import { DefaultResponseModel } from '../../model/DefaultResponseModel';
import getLogger from '../../utils/GetLogger';
import BalancesManagerMapper from '../../mapper/BalancesManagerMapper';
import { Options } from 'opossum';
import { RequestHeadersModel } from '../../model/RequestHeadersModel';

const logger = getLogger('bdb:LoanBalanceService');

export class LoanBalanceService {
  public static async invokeLoanBalanceService<T>(request: string, baseParams: RequestHeadersModel, timeout?: number): Promise<any> {
    const reqId = baseParams['X-RqUID'];
    try {
      logger.info(reqId, `INIT LoanBalanceService ${JSON.stringify({ HEADERS_IN: baseParams, PARAMS_IN: request })}`);
      const circuitBreakerOptions: Options = JSON.parse(config.CIRCUIT_BREAKER_OPTIONS.replace(/(['"])?([a-zA-Z0-9_]+)(['"])?:/g, '"$2":'));
      const urlService = config.LOAN_BALANCES_ENDPOINT;
      const headers = { 'Content-Type': 'application/xml' };
      const accountsXml = addAccounts(request);
      const requestXml = generateXml(baseParams, IStructureBalanceDefinition.LOAN_BALANCE, accountsXml);
      const requestService = RequestService.getInstance(reqId, 'idInstanceReqSerBalance', circuitBreakerOptions);
      logger.debug(reqId, '[ REQ LoanBalanceService ]: ', JSON.stringify({ URL: urlService, HEADERS_OUT: headers, BODY_OUT: requestXml }));
      const responseXml = await requestService.post({ url: urlService, reqId, body: requestXml, headers });
      logger.debug(reqId, ' [ RES LoanBalanceService ]: ', JSON.stringify(responseXml));
      return await BalancesManagerMapper.mapperXmlToRestRsBalance(reqId, IStructureBalanceDefinition.LOAN_BALANCE, responseXml);
    }
    catch (error) {
      const statusResponse: IDefaultStatusModel = genericUtilities.handlerErrorRestService(reqId, 'getLoanBalanceService', error);
      throw new DefaultResponseModel(statusResponse, reqId);
    }
  }
}

export const addAccounts = (acctId: string): string => {
  return `
      <v11:AcctBasicInfo>
      <v1:AcctId>${acctId}</v1:AcctId>
      <v1:AcctType>LOC</v1:AcctType>
      <v11:BankInfo>
        <v1:BranchId>001</v1:BranchId>
      </v11:BankInfo>
    </v11:AcctBasicInfo>`;
};

