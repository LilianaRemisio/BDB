import dateFormat from 'dateformat';
import debugLib from 'debug';
import uuid from 'uuid';
import xml2js from 'xml2js';
import { AdapterErrorN } from '../utils/AdapterError';
import { RequestHeadersModel } from '../model/RequestHeadersModel';
import { IStructurePropertiesModel } from '../model/IStructurePropertiesModel';
import { DefaultStatusModelBuilder, IDefaultStatusModel } from '../model/IDefaultStatusModel';
import genericUtilities from '../utils/GenericUtilities';
import { DefaultResponseModel } from '../model/DefaultResponseModel';
import { BalanceRequestModelBuilder, IBalanceRequestModel } from '../model/IBalanceRequestModel';
import BalancesManagerMapper from '../mapper/BalancesManagerMapper';

const PARSER_OPTIONS = {
  explicitArray: false,
  ignoreAttrs: true,
  tagNameProcessors: [xml2js.processors.stripPrefix],

};

const debug = debugLib('bdb:CommonService');




export const parseBusinessError = (errorResponse: any, rquid: string): any => {

  const status: IDefaultStatusModel = new DefaultStatusModelBuilder().setStatusCode(409)
    .setStatusDesc('Bussines Error')
    .setSeverity(errorResponse.Status.Severity)
    .setServerStatusCode(errorResponse.Status.ServerStatusCode)
    .setServerStatusDesc(errorResponse.Status.ServerStatusDesc)
    .build();

  const defaultResponse: DefaultResponseModel = new DefaultResponseModel(status, rquid);
  throw new AdapterErrorN('Error de negocio', 409, defaultResponse);
};
export const generateXml = (
  baseParams: RequestHeadersModel,
  methodService: IStructurePropertiesModel,
  additionalItems: string
): string => {
  const custIdentType = genericUtilities.transformDocumentType(baseParams['X-CustIdentType']);
  const xNetworkOwner = BalancesManagerMapper.mapperNetwrkOwner(baseParams);
  // const channel = genericUtilities.validateChannel(baseParams['X-Channel']);

  const method = `${methodService.method}Request`;
  const accountsItemsIdentification = `<v11:GovIssueIdent>
              <v1:GovIssueIdentType>${custIdentType
    }</v1:GovIssueIdentType>
              <v1:IdentSerialNum>${baseParams['X-CustIdentNum']
    }</v1:IdentSerialNum>
           </v11:GovIssueIdent>`;
  const requestXML = `<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
  xmlns:ser="urn://bancodebogota.com/${methodService.service}/product/service/"
  xmlns:even="urn://bancodebogota.com/${methodService.service}/product/event/"
  xmlns:v1="urn://bancodebogota.com/ifx/base/v1/" xmlns:v11="urn://bancodebogota.com/ifx/lite/v1/">
  <soapenv:Header/>
  <soapenv:Body>
     <ser:${method}>
        <even:${methodService.requestName}>
           <v1:RqUID>${baseParams['X-RqUID']}</v1:RqUID>
           <v1:CustId>
              <v1:CustLoginId>${baseParams['X-CustIdentNum']}</v1:CustLoginId>
           </v1:CustId>
           <v1:NetworkTrnInfo>
              <v1:NetworkOwner>${xNetworkOwner}</v1:NetworkOwner>
              <v1:TerminalId>${baseParams['X-TerminalId']}</v1:TerminalId>
              <v1:BankId>${baseParams['X-CompanyId']}</v1:BankId>
           </v1:NetworkTrnInfo>
           <v1:ClientDt>${dateFormat(
    new Date(),
    'yyyy-mm-dd"T"HH:MM:ss"-05:00"'
  )}</v1:ClientDt>
           ${methodService.accountsItemsIdentification === true ? accountsItemsIdentification : ''}
           ${additionalItems}
        </even:${methodService.requestName}>
     </ser:${method}>
  </soapenv:Body>
</soapenv:Envelope>
  `;
  return requestXML;
};

const setInternalsArray = (resultService: any, structure: IStructurePropertiesModel): any => { // NOSONAR
  if (structure.objectsRequiredAsArray && structure.objectsRequiredAsArray.length > 0) {
    const attributesToArray = structure.objectsRequiredAsArray;
    const objectRoot = structure.objectName;
    const array = Array.isArray(resultService[objectRoot]) ?
      resultService[objectRoot] : new Array(resultService[objectRoot]); // NOSONAR
    resultService[objectRoot] = array;
    array.forEach((balance: any, key: any) => {
      attributesToArray.forEach((attribute: any) => {
        if (balance[attribute] && !balance[attribute].length) {
          const value = balance[attribute];
          const responseOc: any = [];
          responseOc.push(value);
          resultService[structure.objectName][key][attribute] = responseOc;
        }
      });
    });
  }
};

const isValidResponse = (result: any): any => {
  try {
    const statusCode = +result.Status?.StatusCode;
    if (typeof (result.Status) === 'undefined' || statusCode === 0) {
      return true;
    } else {
      return false;
    }
  } catch (err) {
    return true;
  }
};


export const requestBalanceContingecy = (acctId: string, request: RequestHeadersModel): IBalanceRequestModel => {
  return new BalanceRequestModelBuilder()
    .setRqUID(request['X-RqUID'])
    .setNetworkOwner(BalancesManagerMapper.mapperNetwrkOwner(request) as string)
    .setTerminalId(request['X-TerminalId'] ?? '')
    .setTypeId(request['X-CustIdentType'] ?? '')
    .setBankId('')
    .setAcctId(acctId)
    .build();
};
