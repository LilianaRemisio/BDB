import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';
import { Options } from 'opossum';
import config from '../../config';
import { IBalanceRequestModel } from '../../model/IBalanceRequestModel';
import getLogger from '../../utils/GetLogger';
import { ResponseFetchModel } from '../../model/ResponseFetchModel';
import BdbCircuitBreaker from '../circuitbreaker/bdbCircuitBreaker';
import app from '../../app';
import https from 'https';
import { performance } from 'perf_hooks';
import LoadFile from '../../utils/LoadFile';
import { url } from 'inspector';

const logger = getLogger('bdb:RequestService');

export class RequestService extends BdbCircuitBreaker {
  private static instances: { [key: string]: RequestService } = {};
  private static cachedCertificate: { cert: string, key: string } | null = null;


  public static getInstance(
    reqId: string,
    endpoint: string,
    options: Options
  ): RequestService {
    if (!RequestService.instances[endpoint]) {
      logger.debug(reqId, '****CREATE INSTANCE REQUEST SERVICE**** -> endpoint:', endpoint);
      return RequestService.instances[endpoint] = new RequestService(options);
    }
    return RequestService.instances[endpoint];
  }

  public static async getCertificate() {
    if (!this.cachedCertificate) {
      this.cachedCertificate = await LoadFile.getCertificate();
    }
    return this.cachedCertificate;
  }

  public constructor(options: Options) {
    super(options);
  }

  protected getPrincipalService() {
    return async <T>() => {
      const options = this.getPrincipalServiceOptions().options;
      const params = this.getPrincipalServiceOptions().params;
      logger.info(params.reqId, `[POST REQUEST PRINCIPAL CONTINGENCY ON]: ${JSON.stringify({url: params.url, body: params.body, headers: params.headers})}`);
      return axios
        .post(`${params.url}`, params.body || {}, options)
        .then((r: AxiosResponse) => {
          const rpFetch = new ResponseFetchModel(
            r.data as T,
            r.status,
            'OK',
            true,
            this.circuitBreakerState
          );
          logger.info(
            params.reqId,
            `[POST RESPONSE PRINCIPAL CONTINGENCY ON]: ${JSON.stringify(rpFetch)}`,
            params.headers
          );
          app.locals.fallbackServiceCalled = false;
          logger.debug(params.reqId, `[ STATUS_CIRCUITBREAKER ]: ${JSON.stringify({
            'useCircuitBreaker':true,
            'resource:': params.url,
            'tracePoint': 'POST_PRINCIPAL_CTG_ON'
          })}`);
          return rpFetch;
        }).catch((err: any) => {
          logger.error(params.reqId, `[ STATUS_CIRCUITBREAKER_ERR ]: ${JSON.stringify({
            'useCircuitBreaker':true,
            'resource:': params.url,
            'tracePoint': 'POST_ERR_PRINCIPAL_CTG_ON'
          })}`);
          const error = err.response?.data ? err.response.data : err.message;
          logger.error(params.reqId, '[POST RESPONSE ERROR PRINCIPAL CONTINGENCY ON]: ', JSON.stringify({ 'Error': error }));
          return Promise.reject(err);
        });
    };
  }

  protected getFallbackService() {
    return async <T>() => {
      const { fallbackOptions: params } = this.getFallbackServiceOptions().params;
      const { rqUID, acctId, networkOwner } = params.balanceRq;
      try {
        const data = { AcctId: acctId };
        const options: AxiosRequestConfig = {
          headers: {
            'X-RQUID': rqUID,
            'X-NetworkOwner': networkOwner,
            'Content-Type': 'application/json',
            'Accept': 'application/json',
          },
          timeout: Number(config.TIMEOUT_SERVICE),
        };

        if (config.USE_HTTPS_AGENT) {
          options.httpsAgent =  new https.Agent({
            cert: (await RequestService.getCertificate()).cert,
            key: (await RequestService.getCertificate()).key,
            rejectUnauthorized: false
          });
        }

        logger.info(
          rqUID,
          `[POST REQUEST FALLBACK CONTINGENCY ON]: ${JSON.stringify({
            HEADERS_CTG: options.headers,
            BODY_CTG: data,
            URL: params.fallbackUrl
          })}`);
        const response: AxiosResponse = await axios.post(`${params.fallbackUrl}`, data, options);
        const rpFetch = new ResponseFetchModel(
          response.data as T,
          response.status,
          'OK',
          false,
          this.circuitBreakerState
        );
        logger.debug(rqUID, `[ STATUS_CIRCUITBREAKER ]: ${JSON.stringify({
          'useCircuitBreaker':true,
          'resource:': params.url,
          'tracePoint': 'POST_FALLBACK_CTG_ON'
        })}`);
        logger.info(rqUID, `[POST RESPONSE FALLBACK CONTINGENCY ON]: ${JSON.stringify(rpFetch)}`, params.headers);
        app.locals.fallbackServiceCalled = true;
        return rpFetch;
      } catch (err: any) {
        logger.error(params.reqId, `[ STATUS_CIRCUITBREAKER_ERR ]: ${JSON.stringify({
          'useCircuitBreaker':true,
          'resource:': params.url,
          'tracePoint': 'POST_ERR_FALLBACK_CTG_ON'
        })}`);
        const error = err.response?.data ? err.response.data : err.message;
        logger.error(rqUID, '[POST RESPONSE FALLBACK ERROR CONTINGENCY ON]: ', JSON.stringify({ 'Error': error }));
        console.log('entro.FalbackCatch');
        throw err;
      }
    };
  }

  public async callGetFallbackService(params: any, options: Options): Promise<any> {
    return this.getFallbackService();
  }

  public get = async <T>(
    params: {
      url: string,
      queryParams?: { [key: string]: string },
      headers?: { [key: string]: string }
    }
  ): Promise<ResponseFetchModel<T>> => {
    const options: AxiosRequestConfig = {
      headers: {
        'Content-Type': 'application/json',
        ...params.headers,
      },
      params: params.queryParams
    };
    return axios.get(`${params.url}`, options)
      .then((r: AxiosResponse) => {
        return new ResponseFetchModel(r.data as T, r.status, 'OK', true, 'circuit breaker not used');
      }).catch((err: any) => {
        return Promise.reject(err.response.data);
      });
  }

  public postCircuitBreaker = async <T>(params: {
    url: string;
    reqId: string;
    body?: any;
    queryParams?: { [key: string]: string };
    headers?: { [key: string]: string };
    fallbackOptions: {
      fallbackUrl: string;
      balanceRq?: IBalanceRequestModel;
    };
  }, vars: Options): Promise<ResponseFetchModel<T>> => {
    const options: AxiosRequestConfig = {
      headers: {
        'Content-Type': 'application/json',
        ...params.headers,
      },
      params: params.queryParams,
      timeout: Number(config.TIMEOUT_SERVICE),
    };

    this.setFallbackServiceOptions({ params }, params.reqId);
    this.principalServiceOptions = { options, params };
    this.setOptions(vars);
    return this.execute(params.reqId, params.url).catch((err: any) => {
      logger.error(params.reqId, `[ STATUS_CIRCUITBREAKER_ERR ]: ${JSON.stringify({
        'useCircuitBreaker':true,
        'resource:': params.url,
        'tracePoint': 'ERROR_POST_CIRCUITBREAKER'
      })}`);
      const error = err.response?.data ? err.response.data : err.message;
      logger.error(params.reqId, '[ERROR POSTCIRCUITBREAKER ]: ', JSON.stringify(error));
      throw err;
    });
  }

  public post = async <T>(
    params: {
      url: string,
      reqId: string,
      body?: any,
      queryParams?: { [key: string]: string },
      headers?: { [key: string]: string }
    },
    timeoutParam = Number(config.TIMEOUT_SERVICE)
  ): Promise<ResponseFetchModel<T>> => {
    const options: AxiosRequestConfig = {
      headers: {
        'Content-Type': 'application/json',
        ...params.headers
      },
      params: params.queryParams, timeout: timeoutParam,
    };
    logger.info(
      params.reqId,
      `[POST REQUEST PRINCIPAL CONTINGENCY OFF]: ${JSON.stringify({
        url: params.url,
        headers: params.headers,
        body: params.body
      })}`);
    return axios.post(`${params.url}`, params.body || {}, options)
      .then((r: AxiosResponse) => {
        const rpFetch = new ResponseFetchModel(r.data as T, r.status, 'OK', true, 'circuit breaker not used');
        logger.info(
          params.reqId,
          `[POST RESPONSE PRINCIPAL CONTINGENCY OFF]: ${JSON.stringify({
            data: rpFetch.data,
            status: rpFetch.status,
            code: rpFetch.code,
          })}`,
          params.headers
        );
        logger.debug(params.reqId, `[ STATUS_CIRCUITBREAKER ]: ${JSON.stringify({
          'useCircuitBreaker':false,
          'resource:': params.url,
          'tracePoint': 'POST_CTG_OFF'
        })}`);
        return rpFetch;
      }).catch((err: any) => {
        logger.error(params.reqId, `[ STATUS_CIRCUITBREAKER_ERR ]: ${JSON.stringify({
          'useCircuitBreaker':false,
          'resource:': params.url,
          'tracePoint': 'POST_ERR_CTG_OFF'
        })}`);
        const error = err.response?.data ? err.response.data : err.message;
        logger.error(params.reqId, '[POST RESPONSE ERROR PRINCIPAL CONTINGENCY OFF]: ', JSON.stringify({ 'Error': error }));
        return Promise.reject(err);
      });
  }
}
