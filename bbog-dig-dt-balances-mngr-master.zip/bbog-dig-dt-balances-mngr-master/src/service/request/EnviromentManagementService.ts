import { Request } from 'express';
import config from '../../config';
import getLogger from '../../utils/GetLogger';
const logger = getLogger('bdb:EnviromentManagementService');

const uuid = 'b64c4cac-e757-41bb-8fe6-61762c35b750';

export default class EnviromentManagementService {

  public static getStatusOfEnvVars() {
    logger.info(uuid, 'Status of environment variables:', this.getEnvVars());
    return this.getEnvVars();
  }

  public static updateEnvVars(req: Request) {
    const oldVars = this.getEnvVars();
    logger.info(uuid, 'Init updateEnvVars - Old environment variables:', this.getEnvVars());

    const useCircuitBreakerSavings = req.header('UseCircuitBreakerSavings');
    if (useCircuitBreakerSavings !== undefined) {
      logger.info(uuid, 'se actualiza la variable UseCircuitBreakerSavings a :', useCircuitBreakerSavings);
      config.USE_CIRCUIT_BREAKER_SAVINGS = String(useCircuitBreakerSavings);
    }
    const principalEndpointSavings = req.header('PrincipalEndpointSavings');
    if (principalEndpointSavings !== undefined) {
      logger.info(uuid, 'se actualiza la variable principalEndpointSavings a :', principalEndpointSavings);
      config.SAVING_BALANCES_ENDPOINT = String(principalEndpointSavings);
    }
    const contingencyEndpointSavings = req.header('ContingencyEndpointSavings');
    logger.info(uuid, 'se actualiza la variable contingencyEndpointSavings a :', contingencyEndpointSavings);
    if (contingencyEndpointSavings !== undefined) {
      config.SAVING_FALLBACK_URL = String(contingencyEndpointSavings);
    }

    const useCircuitBreakerDemands = req.header('UseCircuitBreakerDemands');
    if (useCircuitBreakerDemands !== undefined) {
      logger.info(uuid, 'se actualiza la variable useCircuitBreaker a :', useCircuitBreakerDemands);
      config.USE_CIRCUIT_BREAKER_DEMANDS = String(useCircuitBreakerDemands);
    }
    const principalEndpointDemands = req.header('PrincipalEndpointDemands');
    if (principalEndpointDemands !== undefined) {
      logger.info(uuid, 'se actualiza la variable principalEndpointDemands a :', principalEndpointDemands);
      config.DEMAND_BALANCES_ENDPOINT = String(principalEndpointDemands);
    }
    const contingencyEndpointDemands = req.header('ContingencyEndpointDemands');
    logger.info(uuid, 'se actualiza la variable contingencyEndpointDemands a :', contingencyEndpointDemands);
    if (contingencyEndpointDemands !== undefined) {
      config.DEMAND_FALLBACK_URL = String(contingencyEndpointDemands);
    }

    const newVars = this.getEnvVars();
    logger.info(uuid, 'End updateEnvVars - New environment variables:', newVars);
    return { oldVars, newVars };
  }

  private static getEnvVars() {
    return {
      EnvironmentVariables:[{SavingsBalance:{
        UseCircuitBreaker: config.USE_CIRCUIT_BREAKER_SAVINGS,
        PrincipalEndpointSavings: config.SAVING_BALANCES_ENDPOINT,
        ContingencyEndpointSavings: config.SAVING_FALLBACK_URL
      }},
      {DemandsBalance:{
        UseCircuitBreaker: config.USE_CIRCUIT_BREAKER_DEMANDS,
        PrincipalEndpointDemands: config.DEMAND_BALANCES_ENDPOINT,
        ContingencyEndpointDemands: config.DEMAND_FALLBACK_URL
      }}]
    };
  }
}
