
import config from '../../config';
import { RequestService } from '../request/RequestService';
import { RequestHeadersModel } from '../../model/RequestHeadersModel';
import { IStructureBalanceDefinition } from '../../model/IStructureBalanceDefinition';
import { generateXml, requestBalanceContingecy } from '../CommonService';
import { ResponseFetchModel } from '../../model/ResponseFetchModel';
import { Options } from 'opossum';
import { IDefaultStatusModel } from '../../model/IDefaultStatusModel';
import genericUtilities from '../../utils/GenericUtilities';
import { DefaultResponseModel } from '../../model/DefaultResponseModel';
import getLogger from '../../utils/GetLogger';
import { IBalanceRequestModel } from '../../model/IBalanceRequestModel';
import BalancesManagerMapper from '../../mapper/BalancesManagerMapper';

const logger = getLogger('bdb:SavingsBalanceService');

export class SavingsBalanceService {
  public static addAccounts = (acctId: string): string => {
    return `
              <v11:AcctBasicInfo>
              <v1:AcctId>${acctId}</v1:AcctId>
              <v1:AcctType>SDA</v1:AcctType>
          </v11:AcctBasicInfo>`;
  }

  public static async invokeSavingBalanceService<T>(request: string, baseParams: RequestHeadersModel, timeout?: number): Promise<any> {
    const reqId = baseParams['X-RqUID'];
    try {
      logger.info(reqId, `INIT SavignsBalanceService ${JSON.stringify({ HEADERS_IN: baseParams, PARAMS_IN: request })}`);
      const circuitBreakerOptions: Options = JSON.parse(config.CIRCUIT_BREAKER_OPTIONS.replace(/(['"])?([a-zA-Z0-9_]+)(['"])?:/g, '"$2":'));
      const useCircuitBreaker = config.USE_CIRCUIT_BREAKER_SAVINGS;
      const fallbackUrl = config.SAVING_FALLBACK_URL;
      const balanceRq: IBalanceRequestModel = requestBalanceContingecy(request, baseParams);
      const xmlAccounts = this.addAccounts(request);
      const xmlRequest = generateXml(baseParams, IStructureBalanceDefinition.SAVING_BALANCE, xmlAccounts);
      const requestService = RequestService.getInstance(reqId, 'idInstanceReqSerSavingsBal', circuitBreakerOptions);
      let responseService: ResponseFetchModel<T>;
      const headers = { 'Content-Type': 'application/xml' };
      const url = config.SAVING_BALANCES_ENDPOINT;
      if (useCircuitBreaker === 'true') {
        logger.info(reqId, 'REQ SavignsBalanceService Principal Service CTG ON', JSON.stringify(
          { URL: url, HEADERS_OUT: headers, BODY_OUT: xmlRequest, fallbackOptions: { fallbackUrl, balanceRq } }));
        responseService = await requestService.postCircuitBreaker({
          body: xmlRequest,
          headers,
          reqId,
          url,
          fallbackOptions: { fallbackUrl, balanceRq }
        }, circuitBreakerOptions);
        logger.info(reqId, 'PRINCIPAL_SERVICE SAVINGS USED: ', responseService.principalServiceUsed);

        if (responseService.principalServiceUsed) {
          logger.info(reqId, ' [ RES SavignsBalanceService Principal Service CTG ON]: ', JSON.stringify(responseService));
          return  await BalancesManagerMapper.mapperXmlToRestRsBalance(reqId,IStructureBalanceDefinition.SAVING_BALANCE, responseService);
        } else {
          logger.info(reqId, ' [ RES SavignsBalanceService Contigency Service]: ', JSON.stringify(responseService));
          return BalancesManagerMapper.mapperRestToRestRsBalance(reqId, IStructureBalanceDefinition.SAVING_BALANCE_CONTINGENCY, responseService);
        }
      } else {
        logger.debug(reqId, '[ REQ SavignsBalanceService Principal Service CTG OFF ]: ', JSON.stringify({ URL: url, HEADERS_OUT: headers, BODY_OUT: xmlRequest }));
        const responseXml = await requestService.post({
          url: `${config.SAVING_BALANCES_ENDPOINT}`,
          reqId,
          body: xmlRequest,
          headers
        });
        logger.debug(reqId, ' [ RES SavignsBalanceService Principal Service CTG OFF ]: ', JSON.stringify(responseXml));
        return await BalancesManagerMapper.mapperXmlToRestRsBalance(reqId, IStructureBalanceDefinition.SAVING_BALANCE, responseXml);
      }
    } catch (error) {
      const statusResponse: IDefaultStatusModel = genericUtilities.handlerErrorRestService(reqId, 'getSavignsBalanceService', error);
      throw new DefaultResponseModel(statusResponse, reqId);
    }
  }
}
