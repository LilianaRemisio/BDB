import config from '../../config';
import { RequestService } from '../request/RequestService';
import { IStructureBalanceDefinition } from '../../model/IStructureBalanceDefinition';
import { generateXml } from '../CommonService';
import { IDefaultStatusModel } from '../../model/IDefaultStatusModel';
import genericUtilities from '../../utils/GenericUtilities';
import { DefaultResponseModel } from '../../model/DefaultResponseModel';
import getLogger from '../../utils/GetLogger';
import BalancesManagerMapper from '../../mapper/BalancesManagerMapper';
import { Options } from 'opossum';
import { RequestHeadersModel } from '../../model/RequestHeadersModel';
import dateFormat from 'dateformat';


const logger = getLogger('bdb:ProductInquiryService');

export class ProductInquiryService {
  public static async invokeProductInquiryService<T>(parametersDetailCredit: {}, baseParams: RequestHeadersModel, timeout?: number): Promise<any> {
    const reqId = baseParams['X-RqUID'];
    try {
      logger.info(reqId, `INIT ProductInquiryService ${JSON.stringify({ HEADERS_IN: baseParams, PARAMS_IN: parametersDetailCredit })}`);
      const circuitBreakerOptions: Options = JSON.parse(config.CIRCUIT_BREAKER_OPTIONS.replace(/(['"])?([a-zA-Z0-9_]+)(['"])?:/g, '"$2":'));
      const urlService = config.CUSTOMER_PRODUCT_ENDPOINT;
      const headers = { 'Content-Type': 'application/xml' };
      const xmlCredit = addCreditDetail(parametersDetailCredit);
      const requestXml = generateXml(baseParams, IStructureBalanceDefinition.CUSTOMER_PRODUCT, xmlCredit);
      const requestService = RequestService.getInstance(reqId, 'idInstanceReqSerBalance', circuitBreakerOptions);
      logger.debug(reqId, '[ REQ ProductInquiryService ]: ', JSON.stringify({ URL: urlService, HEADERS_OUT: headers, BODY_OUT: requestXml }));
      const responseXml = await requestService.post({ url: urlService, reqId, body: requestXml, headers });
      logger.debug(reqId, ' [ RES ProductInquiryService ]: ', JSON.stringify(responseXml));
      return await BalancesManagerMapper.mapperXmlToRestRsBalance(reqId, IStructureBalanceDefinition.CUSTOMER_PRODUCT, responseXml);
    }
    catch (error) {
      const statusResponse: IDefaultStatusModel = genericUtilities.handlerErrorRestService(reqId, 'getProductInquiryService', error);
      throw new DefaultResponseModel(statusResponse, reqId);
    }
  }
}

export const addCreditDetail = (parametersDetailCredit: any): string => {
  return `
      <v1:BaseEnvr>
      <v1:Desc>${parametersDetailCredit.baseEnvr}</v1:Desc>
    </v1:BaseEnvr>
    <v1:CreditDetailId>
      <v1:TrnType>${parametersDetailCredit.trnType}</v1:TrnType>
      <v1:LoanAcctId>
      <v1:AcctId>${parametersDetailCredit.acctId}</v1:AcctId>
      <v1:AcctType>${parametersDetailCredit.acctType}</v1:AcctType>
      <v1:BankInfo>
          <v1:BranchId></v1:BranchId>
      </v1:BankInfo>
      </v1:LoanAcctId>
      <v1:BranchId></v1:BranchId>
      <v1:EffDt>${dateFormat(
        new Date(),
        'yyyy-mm-dd"T"HH:MM:ss"-05:00"')}</v1:EffDt>
    </v1:CreditDetailId>`;
};

