import { RequestHeadersModel } from '../../model/RequestHeadersModel';
import { IDefaultStatusModel } from '../../model/IDefaultStatusModel';
import genericUtilities from '../../utils/GenericUtilities';
import { DefaultResponseModel } from '../../model/DefaultResponseModel';
import getLogger from '../../utils/GetLogger';
import BalancesManagerMapper from '../../mapper/BalancesManagerMapper';
import { IAcctBasicInfo } from 'model/IAcctBasicInfo';
import { SavingsBalanceService } from '../../service/savings/SavingsBalanceService';
import { DemandBalanceService } from '../../service/demands/DemandBalanceService';
import { TrustBalanceService } from '../../service/trust/TrustBalanceService';
import { ReqHeadersAdditionalRest } from '../../model/ReqHeadersAdditionalRest';
import { CertificateBalanceService } from '../../service/certificate/CertificateBalanceService';
import { LoanBalanceService } from '../../service/loan/LoanBalanceService';
import { CreditCardBalanceService } from '../../service/creditcard/CreditCardBalanceService';


const logger = getLogger('bdb:GroupBalanceService');

export class GroupBalanceService {
  public static async invokeGroupBalanceService<T>(accounts: IAcctBasicInfo[], baseParams: RequestHeadersModel): Promise<any> {
    const reqId = baseParams['X-RqUID'];
    try {
      logger.info(reqId, `INIT GroupBalanceService ${JSON.stringify({ HEADERS_IN: baseParams, PARAMS_IN: 'N/A', BODY_IN: accounts })}`);
      const balances = await Promise.allSettled(
        accounts.map(async (account: IAcctBasicInfo) => {
          try {
            const result = await this.executeMethod(account, baseParams);
            return {
              AcctType: account.AcctType,
              AcctId: account.AcctId,
              result
            };
          } catch (error: any) {
              const customError = new Error(`Error processing account ${account.AcctId}`);
              // Agregar propiedades adicionales
              (customError as any).AcctType = account.AcctType;
              (customError as any).AcctId = account.AcctId;
              (customError as any).error = error;
              (customError as any).errorType = error.Status.StatusCode ?? 500;
              throw customError;
          }
        })
      );
      logger.debug(reqId, ' [ RES GroupBalanceService ]: ', JSON.stringify(balances));
      return BalancesManagerMapper.mapperRestToRestGroupRsBalance(reqId, balances);
    }
    catch (error) {
      const statusResponse: IDefaultStatusModel = genericUtilities.handlerErrorRestService(reqId, 'GroupBalanceService', error);
      throw new DefaultResponseModel(statusResponse, reqId);
    }
  }

  public static async executeMethod(account: IAcctBasicInfo, baseParams: RequestHeadersModel): Promise<any> {
    const rqUID = baseParams['X-RqUID'];
    try {
      let result: any;
      switch (account.AcctType) {
        case 'SDA':{
          result = await SavingsBalanceService.invokeSavingBalanceService(account.AcctId, baseParams);
          break;
        }
        case 'DDA':{
          result = await DemandBalanceService.invokeDemandBalanceService(account.AcctId, baseParams);
          break;
        }
        case 'FDA': {
          const requestAdditionalsHeadersDto = new ReqHeadersAdditionalRest(baseParams, account.AcctType, account.AcctSubType, account.BankInfo.BranchId);
          result = await TrustBalanceService.invokeTrustBalanceService(account.AcctId, requestAdditionalsHeadersDto);
          break;
        }
        case 'CCA': {
          result = await CreditCardBalanceService.invokeCreditCardBalanceService(account.AcctId, baseParams);
          break;
        }
        case 'CDA':{
          const requestAdditionalsHeadersDto = new ReqHeadersAdditionalRest(baseParams, account.AcctType, account.AcctSubType, account.BankInfo.BranchId);
          result= await CertificateBalanceService.invokeCertificateBalanceService(account.AcctId, requestAdditionalsHeadersDto);
          break;
        }
        case 'LOC': {
          result = await LoanBalanceService.invokeLoanBalanceService(account.AcctId, baseParams);
          break;
        }
        default:{
          throw new Error(`Unsupported account type: ${account.AcctType}`);
        }
      }
      return result;
    } catch (error) {
      logger.error(rqUID, ` [ Execute GrouBalanceService ]: Failed get response for ${account.AcctType}`, JSON.stringify(error));
      return Promise.reject(error);
    }
  }
}
