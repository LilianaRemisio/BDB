import circuitBreaker, { Options } from 'opossum';
import getLogger from '../../utils/GetLogger';
import { IDetails, IReportData, IRequest, IResponse, ReportService } from '@npm-bbta/bbog-dig-dt-report-interceptor-lib';
import config from '../../config';
import { ICircuitBreakerEvent } from '@npm-bbta/bbog-dig-dt-report-interceptor-lib/model/CircuitBreaker/ICircuitBreakerEvent';
import moment from 'moment-timezone';

const timestampFormat = 'YYYY-MM-DD[T]HH:mm:ss.SSSZ';
const timeZone = 'America/Bogota';
const logger = getLogger('bdb:BdbCircuitBreaker');
export const reportService = new ReportService();
class BdbCircuitBreaker {
  protected config: Options;
  protected principalServiceOptions: any;
  protected circuitBreakerState = 'close';
  protected circuitBreakerInstance: circuitBreaker<any> | null = null;
  protected serviceOrigin = '';
  private fallbackServiceOptions: any;
  private principalServiceOptionsChanged = false;
  private rqUID: string = '';
  private apiName = 'API_BALANCE_MANAGEMENT_CTG';

  constructor(options: Options) {
    this.config = { ...options };
  }

  // Method to get the principal service data (to be implemented by subclasses)
  protected getPrincipalService(): any {
    throw new Error('getPrincipalService method not implemented');
  }

  getPrincipalServiceOptions(): any {
    return this.principalServiceOptions;
  }

  getFallbackServiceOptions(): any {
    return this.fallbackServiceOptions;
  }

  setPrincipalServiceOptions(principalServiceOptions: any): void {
    if (this.principalServiceOptions !== principalServiceOptions) {
      this.principalServiceOptions = principalServiceOptions;
      this.principalServiceOptionsChanged = true;
    }
  }

  setFallbackServiceOptions(fallbackServiceOptions: any, rqUID: string): void {
    this.fallbackServiceOptions = fallbackServiceOptions;
  }

  // Method to get the fallback service data (to be implemented by subclasses)
  protected getFallbackService(): any {
    throw new Error('getFallbackService method not implemented');
  }

  public getOptions() {
    return this.config;
  }
  public setOptions(options: Options) {
    this.config = { ...options };
  }
  // Method to execute the circuit breaker
  async execute(rqUID: string, endpoint: string): Promise<any> {
    this.rqUID = rqUID;
    this.serviceOrigin = endpoint;
    if (!this.circuitBreakerInstance) {
      logger.info(rqUID, '[******CREATE INSTANCE CIRCUIT-BREAKER******]: ');
      this.circuitBreakerInstance = new circuitBreaker(this.getPrincipalService(), this.config);
      await this.initializeCircuitBreaker(this.circuitBreakerInstance, rqUID);
      this.principalServiceOptionsChanged = false;
    }
    logger.info(rqUID, '[******PARAMS CIRCUIT BREAKER - 1******]: ', this.config);
    logger.info(rqUID, '[******INIT******]: ');
    if (!this.circuitBreakerInstance.opened) {
      logger.info(rqUID, '[******CALL PRINCIPAL SERVICE******]: ', this.getPrincipalServiceOptions());
      return this.circuitBreakerInstance.fire();
    } else {
      logger.info(rqUID, '[******INIT CONTINGENCY ******]: ', this.getFallbackServiceOptions());
      logger.info(rqUID, '[******CALL FUNCTION FALLBACK ******]: ', this.getFallbackServiceOptions());
      const fallbackFunction = this.getFallbackService();
      const eventCircuitBreaker: ICircuitBreakerEvent = {
        apiName: this.apiName,
        path: '',
        description: 'The circuit is open. contingency function invoked',
        circuitBreakerState: 'open',
        percentageError: this.failPercentage(this.circuitBreakerInstance.stats),// NOSONAR,
        event: 'open',
        stats: this.extractStats(this.rqUID, this.circuitBreakerInstance.stats),
        serviceOrigin: this.serviceOrigin,
        rqUID: this.rqUID,
      };
      logger.info(this.rqUID, `[ EVENT_CIRCUITBREAKER: ${eventCircuitBreaker.circuitBreakerState} ]: ${JSON.stringify(eventCircuitBreaker)}`);
      this.reportElastic(eventCircuitBreaker);
      return fallbackFunction();
    }
  }
  private async initializeCircuitBreaker(circuitBreakerInstance: circuitBreaker<any>, rqUUID: string): Promise<any> {
    circuitBreakerInstance.on('fallback', () => {
      const eventCircuitBreaker: ICircuitBreakerEvent = {
        apiName: this.apiName,
        path: '',
        description: 'Fuction fallback active',
        circuitBreakerState: 'fallback',
        percentageError: this.failPercentage(circuitBreakerInstance.stats),// NOSONAR,
        event: 'fallback',
        stats: this.extractStats(this.rqUID, circuitBreakerInstance.stats),
        serviceOrigin: this.serviceOrigin,
        rqUID: this.rqUID,
      };
      this.reportElastic(eventCircuitBreaker);
      logger.info(this.rqUID, `[ EVENT_CIRCUITBREAKER: ${eventCircuitBreaker.circuitBreakerState} ]: ${JSON.stringify(eventCircuitBreaker)}`);
    });

    circuitBreakerInstance.on('success', () => {
      const eventCircuitBreaker: ICircuitBreakerEvent = {
        apiName: this.apiName,
        path: '',
        description: 'The circuit is closed. Principal function invoked succesfuly',
        circuitBreakerState: 'close',
        percentageError: this.failPercentage(circuitBreakerInstance.stats),// NOSONAR,
        event: 'success',
        stats: this.extractStats(this.rqUID, circuitBreakerInstance.stats),
        serviceOrigin: this.serviceOrigin,
        rqUID: this.rqUID,
      };
      logger.info(this.rqUID, `[ EVENT_CIRCUITBREAKER: ${eventCircuitBreaker.circuitBreakerState} ]: ${JSON.stringify(eventCircuitBreaker)}`);
      this.reportElastic(eventCircuitBreaker);
      this.circuitBreakerState = 'close';// NOSONAR
    });

    circuitBreakerInstance.on('failure', () => {
      const eventCircuitBreaker: ICircuitBreakerEvent = {
        apiName: this.apiName,
        path: '',
        description: 'Principal function failed',
        circuitBreakerState: 'close',
        percentageError: this.failPercentage(circuitBreakerInstance.stats),// NOSONAR,
        event: 'failure',
        stats: this.extractStats(this.rqUID, circuitBreakerInstance.stats),
        serviceOrigin: this.serviceOrigin,
        rqUID: this.rqUID,
      };
      logger.info(this.rqUID, `[ EVENT_CIRCUITBREAKER: ${eventCircuitBreaker.circuitBreakerState} ]: ${JSON.stringify(eventCircuitBreaker)}`);
      this.reportElastic(eventCircuitBreaker);
    });

    circuitBreakerInstance.on('timeout', () => {
      const eventCircuitBreaker: ICircuitBreakerEvent = {
        apiName: this.apiName,
        path: '',
        description: 'Principal function timeout',
        circuitBreakerState: 'close',
        percentageError: this.failPercentage(circuitBreakerInstance.stats),// NOSONAR,
        event: 'timeout',
        stats: this.extractStats(this.rqUID, circuitBreakerInstance.stats),
        serviceOrigin: this.serviceOrigin,
        rqUID: this.rqUID,
      };
      logger.info(this.rqUID, `[ EVENT_CIRCUITBREAKER: ${eventCircuitBreaker.circuitBreakerState} ]: ${JSON.stringify(eventCircuitBreaker)}`);
      this.reportElastic(eventCircuitBreaker);
    });

    circuitBreakerInstance.on('reject', () => {
      const eventCircuitBreaker: ICircuitBreakerEvent = {
        apiName: this.apiName,
        path: '',
        description: 'Rejected',
        circuitBreakerState: 'open',
        percentageError: this.failPercentage(circuitBreakerInstance.stats),// NOSONAR,
        event: 'reject',
        stats: this.extractStats(this.rqUID, circuitBreakerInstance.stats),
        serviceOrigin: this.serviceOrigin,
        rqUID: this.rqUID,
      };
      logger.info(this.rqUID, `[ EVENT_CIRCUITBREAKER: ${eventCircuitBreaker.circuitBreakerState} ]: ${JSON.stringify(eventCircuitBreaker)}`);
      this.reportElastic(eventCircuitBreaker);
    });

    circuitBreakerInstance.on('open', () => {
      const eventCircuitBreaker: ICircuitBreakerEvent = {
        apiName: this.apiName,
        path: '',
        description: 'The circuit is open. contingency function invoked',
        circuitBreakerState: 'open',
        percentageError: this.failPercentage(circuitBreakerInstance.stats),// NOSONAR,
        event: 'open',
        stats: this.extractStats(this.rqUID, circuitBreakerInstance.stats),
        serviceOrigin: this.serviceOrigin,
        rqUID: this.rqUID,
      };
      logger.info(this.rqUID, `[ EVENT_CIRCUITBREAKER: ${eventCircuitBreaker.circuitBreakerState} ]: ${JSON.stringify(eventCircuitBreaker)}`);
      this.reportElastic(eventCircuitBreaker);
      this.circuitBreakerState = 'open';
    });

    circuitBreakerInstance.on('halfOpen', () => {
      const eventCircuitBreaker: ICircuitBreakerEvent = {
        apiName: this.apiName,
        path: '',
        description: 'The circuit is halfOpen',
        circuitBreakerState: 'halfOpen',
        percentageError: this.failPercentage(circuitBreakerInstance.stats),// NOSONAR,
        event: 'halfOpen',
        stats: this.extractStats(this.rqUID, circuitBreakerInstance.stats),
        serviceOrigin: this.serviceOrigin,
        rqUID: this.rqUID,
      };
      logger.info(this.rqUID, `[ EVENT_CIRCUITBREAKER: ${eventCircuitBreaker.circuitBreakerState} ]: ${JSON.stringify(eventCircuitBreaker)}`);
      this.reportElastic(eventCircuitBreaker);
      this.circuitBreakerState = 'halfOpen';
    });

    circuitBreakerInstance.on('close', () => {
      const eventCircuitBreaker: ICircuitBreakerEvent = {
        apiName: this.apiName,
        path: '',
        description: 'closed',
        circuitBreakerState: 'close',
        percentageError: this.failPercentage(circuitBreakerInstance.stats),// NOSONAR,
        event: 'close',
        stats: this.extractStats(this.rqUID, circuitBreakerInstance.stats),
        serviceOrigin: this.serviceOrigin,
        rqUID: this.rqUID,
      };
      logger.info(this.rqUID, `[ EVENT_CIRCUITBREAKER: ${eventCircuitBreaker.circuitBreakerState} ]: ${JSON.stringify(eventCircuitBreaker)}`);
      this.reportElastic(eventCircuitBreaker);
    });
  }

  private failPercentage(snapshot: any): number { // NOSONAR
    if (snapshot.fires > 0) { // NOSONAR
      return (snapshot.failures / snapshot.fires) * 100; // NOSONAR
    } else {
      return 0;
    }
  } // NOSONAR

  private extractStats(rqUUID: string, metricsCB: any): any {
    const { failures, fallbacks, successes, rejects, fires, timeouts } = metricsCB;
    const stats = {
      'failures': failures,
      'fallbacks': fallbacks,
      'successes': successes,
      'rejects': rejects,
      'fires': fires,
      'timeouts': timeouts
    };
    logger.debug(rqUUID, 'Extrac metrics: ', JSON.stringify(stats));
    return stats;
  }

  private reportElastic(circuitBreakerEvent: ICircuitBreakerEvent) {
    logger.debug(circuitBreakerEvent.rqUID, 'Ingreso funcion reporte elastic');
    /* istanbul ignore else */
    const elasticsearch = {
      apiName: 'API_BALANCE_MANAGEMENT_CTG',
      path: '/Enterprise/'
    };
    const detailsReport: IDetails = {
      elasticsearch_report: true,
      pentagono_report: false,
      pentagono: {
        eventClientId: config.EVENT_CLIENT_ID,
        eventSessionId: config.EVENT_SESSION_ID,
      }
    };
    const request: IRequest = {
      body: {},
      headers: {
        'x-rquid': circuitBreakerEvent.rqUID,
        'x-custom-index-elastic': 'bbog-dig-dt-contingency-balances'
      }
    };
    const response: IResponse = {
      details: detailsReport,
      infoDetails: elasticsearch,
      responseBody: {},
      responseStatus: 200
    };
    const reportData: IReportData = {
      req: request,
      res: response,
      uuid: circuitBreakerEvent.rqUID,
      circuitBreakerEvent,
      timestamp: moment(new Date().getTime()).tz(timeZone).format(timestampFormat)
    };
    logger.debug(circuitBreakerEvent.rqUID, 'Reporting Data: ', JSON.stringify(reportData));
    reportService.onlyPublishInSnsCircuitBreakerEvent(reportData)
      .then((data) => {
        logger.debug(circuitBreakerEvent.rqUID, 'Elastic report sent', JSON.stringify(data));
      })
      .catch((err: any) => {
        const error = err.response?.data ? err.response.data : err.message;
        logger.error(circuitBreakerEvent.rqUID, 'Fail to send elastic report ', JSON.stringify(error));
      });
  }
}


export default BdbCircuitBreaker;
