
import config from '../../config';
import { RequestService } from '../request/RequestService';
import { IStructureBalanceDefinition } from '../../model/IStructureBalanceDefinition';
import { generateXml } from '../CommonService';
import { IDefaultStatusModel } from '../../model/IDefaultStatusModel';
import genericUtilities from '../../utils/GenericUtilities';
import { DefaultResponseModel } from '../../model/DefaultResponseModel';
import getLogger from '../../utils/GetLogger';
import BalancesManagerMapper from '../../mapper/BalancesManagerMapper';
import { ReqHeadersAdditionalRest } from 'model/ReqHeadersAdditionalRest';
import { Options } from 'opossum';

const logger = getLogger('bdb:TrustBalanceService');

export class TrustBalanceService {
  public static async invokeTrustBalanceService<T>(request: string, baseParams: ReqHeadersAdditionalRest, timeout?: number): Promise<any> {
    const reqId = baseParams.GeneralHeaders['X-RqUID'];
    try {
      logger.info(reqId, `INIT TrustBalanceService ${JSON.stringify({ HEADERS_IN: baseParams, PARAMS_IN: request })}`);
      const circuitBreakerOptions: Options = JSON.parse(config.CIRCUIT_BREAKER_OPTIONS.replace(/(['"])?([a-zA-Z0-9_]+)(['"])?:/g, '"$2":'));
      const urlService = config.TRUST_BALANCES_ENDPOINT;
      const headers = { 'Content-Type': 'application/xml' };
      const accountsXml = BalancesManagerMapper.mapperAddAccounts(request, baseParams);
      const xmlRequest = generateXml(baseParams.GeneralHeaders, IStructureBalanceDefinition.TRUST_BALANCE, accountsXml);
      const requestService = RequestService.getInstance(reqId, 'idInstanceReqSerBalance', circuitBreakerOptions);
      logger.debug(reqId, '[ REQ TrustBalanceService ]: ', JSON.stringify({ URL: urlService, HEADERS_OUT: headers, BODY_OUT: xmlRequest }));
      const responseXml = await requestService.post({url: urlService, reqId, body: xmlRequest, headers});
      logger.debug(reqId, ' [ RES TrustBalanceService ]: ', JSON.stringify(responseXml));
      return await BalancesManagerMapper.mapperXmlToRestRsBalance(reqId, IStructureBalanceDefinition.TRUST_BALANCE, responseXml);
      }
     catch (error) {
      const statusResponse: IDefaultStatusModel = genericUtilities.handlerErrorRestService(reqId, 'getTrustBalanceService', error);
      throw new DefaultResponseModel(statusResponse, reqId);
    }
  }
}
