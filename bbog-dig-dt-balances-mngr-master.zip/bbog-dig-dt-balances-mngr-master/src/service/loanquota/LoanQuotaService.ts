
import config from '../../config';
import { RequestService } from '../request/RequestService';
import { IStructureBalanceDefinition } from '../../model/IStructureBalanceDefinition';
import { generateXml } from '../CommonService';
import { IDefaultStatusModel } from '../../model/IDefaultStatusModel';
import genericUtilities from '../../utils/GenericUtilities';
import { DefaultResponseModel } from '../../model/DefaultResponseModel';
import getLogger from '../../utils/GetLogger';
import BalancesManagerMapper from '../../mapper/BalancesManagerMapper';
import { Options } from 'opossum';
import { RequestHeadersModel } from '../../model/RequestHeadersModel';
import { LoanQuotaHeadersModel } from '../../model/loanquota-headers.model';

const logger = getLogger('bdb:LoanQuotaService');

export class LoanQuotaService {
  public static async invokeLoanQuotaService<T>(baseParams: RequestHeadersModel, loanQuotaParams: LoanQuotaHeadersModel, timeout?: number): Promise<any> {
    const reqId = baseParams['X-RqUID'];
    try {
      logger.info(reqId, `INIT LoanQuotaService ${JSON.stringify({ HEADERS_IN: baseParams, PARAMS_IN: loanQuotaParams })}`);
      const circuitBreakerOptions: Options = JSON.parse(config.CIRCUIT_BREAKER_OPTIONS.replace(/(['"])?([a-zA-Z0-9_]+)(['"])?:/g, '"$2":'));
      const urlService = config.LOAN_QUOTA_ENDPOINT;
      const headers = { 'Content-Type': 'application/xml' };
      const itemsXml = addItemsXmlToRetrieveLoanQuota(loanQuotaParams);
      const requestXml = generateXml(baseParams, IStructureBalanceDefinition.LOAN_QUOTA, itemsXml);
      const requestService = RequestService.getInstance(reqId, 'idInstanceReqSerBalance', circuitBreakerOptions);
      logger.debug(reqId, '[ REQ LoanQuotaService ]: ', JSON.stringify({ URL: urlService, HEADERS_OUT: headers, BODY_OUT: requestXml }));
      const responseXml = await requestService.post({ url: urlService, reqId, body: requestXml, headers });
      logger.debug(reqId, ' [ RES LoanQuotaService ]: ', JSON.stringify(responseXml));
      return await BalancesManagerMapper.mapperXmlToRestLoanQuotaRsBalance(reqId, IStructureBalanceDefinition.LOAN_QUOTA, responseXml);
    }
    catch (error) {
      const statusResponse: IDefaultStatusModel = genericUtilities.handlerErrorRestService(reqId, 'getLoanQuotaService', error);
      throw new DefaultResponseModel(statusResponse, reqId);
    }
  }
}

export const addItemsXmlToRetrieveLoanQuota = (loanQuotaParams: LoanQuotaHeadersModel): string => {
  return `
  <v1:AcctBal>
  <v1:CurAmt>
     <v1:Amt>${loanQuotaParams.rate}</v1:Amt>
  </v1:CurAmt>
  <v1:CurAmt>
     <v1:Amt>${loanQuotaParams.amount}</v1:Amt>
  </v1:CurAmt>
  </v1:AcctBal>
  <v1:RefInfo>
      <v1:RefId>${loanQuotaParams.term}</v1:RefId>
  </v1:RefInfo>
  <v1:RefInfo>
      <v1:RefId>${loanQuotaParams.increase}</v1:RefId>
  </v1:RefInfo>
  <v1:RefInfo>
      <v1:RefId>${loanQuotaParams.frequency}</v1:RefId>
  </v1:RefInfo>
  <v1:RefInfo>
      <v1:RefId>${loanQuotaParams.accrualBase}</v1:RefId>
  </v1:RefInfo>
  <v1:RefInfo>
      <v1:RefId>${loanQuotaParams.accrualMethod}</v1:RefId>
  </v1:RefInfo>
  <v1:OpenDt>${loanQuotaParams.disbursementDate}</v1:OpenDt>
  <v1:DueDt>${loanQuotaParams.firstPaymentDate}</v1:DueDt>`;
};

