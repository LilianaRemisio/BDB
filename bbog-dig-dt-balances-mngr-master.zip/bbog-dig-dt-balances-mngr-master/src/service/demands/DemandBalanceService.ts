
import config from '../../config';
import { RequestService } from '../request/RequestService';
import { RequestHeadersModel } from '../../model/RequestHeadersModel';
import { IStructureBalanceDefinition } from '../../model/IStructureBalanceDefinition';
import { generateXml, requestBalanceContingecy } from '../CommonService';
import { ResponseFetchModel } from '../../model/ResponseFetchModel';
import { Options } from 'opossum';
import { IDefaultStatusModel } from '../../model/IDefaultStatusModel';
import genericUtilities from '../../utils/GenericUtilities';
import { DefaultResponseModel } from '../../model/DefaultResponseModel';
import getLogger from '../../utils/GetLogger';
import { IBalanceRequestModel } from '../../model/IBalanceRequestModel';
import BalancesManagerMapper from '../../mapper/BalancesManagerMapper';

const logger = getLogger('bdb:DemandBalanceService');

export class DemandBalanceService {
  public static addDemandAccounts = (acctId: string): string => {
    return `<v11:AcctBasicInfo>
              <v1:AcctId>${acctId}</v1:AcctId>
              <v1:AcctType>DDA</v1:AcctType>
           </v11:AcctBasicInfo>`;
  }

  public static async invokeDemandBalanceService<T>(request: string, baseParams: RequestHeadersModel, timeout?: number): Promise<any> {
    const reqId = baseParams['X-RqUID'];
    try {
      logger.info(reqId, `INIT DemandBalanceService ${JSON.stringify({ HEADERS_IN: baseParams, PARAMS_IN: request })}`);
      const circuitBreakerOptions: Options = JSON.parse(config.CIRCUIT_BREAKER_OPTIONS.replace(/(['"])?([a-zA-Z0-9_]+)(['"])?:/g, '"$2":'));
      const useCircuitBreaker = config.USE_CIRCUIT_BREAKER_DEMANDS;
      const fallbackUrl = config.DEMAND_FALLBACK_URL;
      const balanceRq: IBalanceRequestModel = requestBalanceContingecy(request, baseParams);
      const xmlAccounts = this.addDemandAccounts(request);
      const xmlRequest = generateXml(baseParams, IStructureBalanceDefinition.DEMAND_BALANCE, xmlAccounts);
      const requestService = RequestService.getInstance(reqId, 'idInstanceReqSerDemandBal', circuitBreakerOptions);
      let responseServiceDemand: ResponseFetchModel<T>;
      const headers = { 'Content-Type': 'application/xml' };
      const url = config.DEMAND_BALANCES_ENDPOINT;
      if (useCircuitBreaker === 'true') {
        logger.debug(reqId, 'REQ DemandBalanceService Principal Service CTG ON', JSON.stringify(
          { URL: url, HEADERS_OUT: headers, BODY_OUT: xmlRequest, fallbackOptions: { fallbackUrl, balanceRq } }));
          responseServiceDemand = await requestService.postCircuitBreaker({
          body: xmlRequest,
          headers,
          reqId,
          url,
          fallbackOptions: { fallbackUrl, balanceRq }
        }, circuitBreakerOptions);
        logger.info(reqId, 'PRINCIPAL_SERVICE DEMAND BALANCE USED: ', responseServiceDemand.principalServiceUsed);

        if (responseServiceDemand.principalServiceUsed) {
          logger.info(reqId, ' [ RES DemandBalanceService Principal Service CTG ON]: ', JSON.stringify(responseServiceDemand));
          return  await BalancesManagerMapper.mapperXmlToRestRsBalance(reqId,IStructureBalanceDefinition.DEMAND_BALANCE, responseServiceDemand);
        } else {
          logger.info(reqId, ' [ RES DemandBalanceService Contigency Service]: ', JSON.stringify(responseServiceDemand));
          return BalancesManagerMapper.mapperRestToRestRsBalance(reqId, IStructureBalanceDefinition.SAVING_BALANCE_CONTINGENCY, responseServiceDemand);
        }
      } else {
        logger.debug(reqId, '[ REQ DemandBalanceService Principal Service CTG OFF ]: ', JSON.stringify({ URL: url, HEADERS_OUT: headers, BODY_OUT: xmlRequest }));
        const responseXml = await requestService.post({
          url: `${config.DEMAND_BALANCES_ENDPOINT}`,
          reqId,
          body: xmlRequest,
          headers
        });
        logger.debug(reqId, ' [ RES DemandBalanceService Principal Service CTG OFF ]: ', JSON.stringify(responseXml));
        return await BalancesManagerMapper.mapperXmlToRestRsBalance(reqId, IStructureBalanceDefinition.DEMAND_BALANCE, responseXml);
      }
    } catch (error) {
      const statusResponse: IDefaultStatusModel = genericUtilities.handlerErrorRestService(reqId, 'getDemandBalanceService', error);
      throw new DefaultResponseModel(statusResponse, reqId);
    }
  }
}
