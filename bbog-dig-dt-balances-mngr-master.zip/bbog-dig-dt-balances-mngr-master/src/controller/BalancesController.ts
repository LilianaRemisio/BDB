import { Request, Response } from 'express';
import { RequestHeadersModel } from '../model/RequestHeadersModel';
import { SavingsBalanceService } from '../service/savings/SavingsBalanceService';
import getLogger from '../utils/GetLogger';
import { constants } from 'http2';
import { DemandBalanceService } from '../service/demands/DemandBalanceService';
import { ReqHeadersAdditionalRest } from '../model/ReqHeadersAdditionalRest';
import { TrustBalanceService } from '../service/trust/TrustBalanceService';
import { GroupBalanceService } from '../service/group/GroupBalanceService';
import { IAccountsInfoRestModel } from '../model/IAccountsInfoRestModel';
import { CreditCardBalanceService } from '../service/creditcard/CreditCardBalanceService';
import { CertificateBalanceService } from '../service/certificate/CertificateBalanceService';
import { LoanBalanceService } from '../service/loan/LoanBalanceService';
import { ProductInquiryService } from '../service/product/ProductInquiryService';
import { LoanQuotaHeadersModel } from '../model/loanquota-headers.model';
import { LoanQuotaService } from '../service/loanquota/LoanQuotaService';
import { OverdraftHeadersModel } from '../model/Overdraft-headers.model';
import { OverdraftService } from '../service/overdraft/OverdraftService';
const logBdb = getLogger('bdb:BalancesController');

const STATUS_200 = 200;
const ERROR_MESSAGE = 'An error has occurred getting balances to accounts';

export class BalancesController {

  public async retrieveGroupBalances(req: Request, res: Response, next: any) {
    const rqUID = req.headers['x-rquid'] as string;
    try {
      const requestHeadersDto = new RequestHeadersModel(req);
      const accounts = req.body as IAccountsInfoRestModel;
      logBdb.info(rqUID, `INIT BalancesController - retrieveGroupBalances`);
      const response = await GroupBalanceService.invokeGroupBalanceService(accounts.AccountsInfo, requestHeadersDto);
      logBdb.info(rqUID, `END BalancesController - retrieveGroupBalances Response`);
      return res.status(response.Status.StatusCode || 200).json(response);
    } catch (error: any) {
      logBdb.error(rqUID, 'END FAILED BalancesController Response retrieveGroupBalances Controller: ', error);
      return res.status(error?.Status?.StatusCode || constants.HTTP_STATUS_INTERNAL_SERVER_ERROR).json(error);
    }
  }

  public async retrieveSavingBalance(req: Request, res: Response, next: any) {
    const rqUID = req.headers['x-rquid'] as string;
    try {
      const requestHeadersDto = new RequestHeadersModel(req);
      const acctId = req.params.acctId;
      logBdb.info(rqUID, `INIT BalancesController - retrieveSavingBalance`);
      const response = await SavingsBalanceService.invokeSavingBalanceService(acctId, requestHeadersDto);
      logBdb.info(rqUID, `END BalancesController - retrieveSavingBalance Response`);
      res.locals.isPrincipalServiceUsed = response.isPrincipalServiceUsed;
      res.locals.circuitBreakerState = response.circuitBreakerState;
      return res.status(STATUS_200).json(response);
    } catch (error: any) {
      logBdb.error(rqUID, 'END FAILED BalancesController Response retrieveSavingBalance Controller: ', error);
      return res.status(error?.Status?.StatusCode || constants.HTTP_STATUS_INTERNAL_SERVER_ERROR).json(error);
    }
  }

  public async retrieveDemandBalance(req: Request, res: Response, next: any) {
    const rqUID = req.headers['x-rquid'] as string;
    try {
      const requestHeadersDto = new RequestHeadersModel(req);
      const acctId = req.params.acctId;
      logBdb.info(rqUID, `INIT BalancesController - retrieveDemandBalance`);
      const response = await DemandBalanceService.invokeDemandBalanceService(acctId, requestHeadersDto);
      logBdb.info(rqUID, `END BalancesController - retrieveDemandBalance Response`);
      res.locals.isPrincipalServiceUsed = response.isPrincipalServiceUsed;
      res.locals.circuitBreakerState = response.circuitBreakerState;
      return res.status(STATUS_200).json(response);
    } catch (error: any) {
      logBdb.error(rqUID, 'END FAILED BalancesController Response retrieveDemandBalance Controller: ', error);
      return res.status(error?.Status?.StatusCode || constants.HTTP_STATUS_INTERNAL_SERVER_ERROR).json(error);
    }
  }

  public async retrieveTrustBalance(req: Request, res: Response, next: any) {
    const rqUID = req.headers['x-rquid'] as string;
    try {
      const acctId = req.params.acctId;
      const acctType = String(req.query.acctType || '');
      const acctSubType = String(req.query.acctSubType || '');
      const branchId = String(req.query.branchId || '');
      const requestHeadersDto = new RequestHeadersModel(req);
      const requestAdditionalsHeadersDto = new ReqHeadersAdditionalRest(requestHeadersDto, acctType, acctSubType, branchId);
      logBdb.info(rqUID, `INIT BalancesController - retrieveTrustBalance`);
      const response = await TrustBalanceService.invokeTrustBalanceService(acctId, requestAdditionalsHeadersDto);
      logBdb.info(rqUID, `END BalancesController - retrieveTrustBalance Response`);
      return res.status(STATUS_200).json(response);
    } catch (error: any) {
      logBdb.error(rqUID, 'END FAILED BalancesController Response retrieveTrustBalance Controller: ', error);
      return res.status(error?.Status?.StatusCode || constants.HTTP_STATUS_INTERNAL_SERVER_ERROR).json(error);
    }
  }

  public async retrieveCreditCardBalance(req: Request, res: Response, next: any) {
    const rqUID = req.headers['x-rquid'] as string;
    try {
      const requestHeadersDto = new RequestHeadersModel(req);
      const acctId = req.params.acctId;
      logBdb.info(rqUID, `INIT BalancesController - retrieveCreditCardBalance`);
      const response = await CreditCardBalanceService.invokeCreditCardBalanceService(acctId, requestHeadersDto);
      logBdb.info(rqUID, `END BalancesController - retrieveCreditCardBalance Response`);
      return res.status(STATUS_200).json(response);
    } catch (error: any) {
      logBdb.error(rqUID, 'END FAILED BalancesController Response retrieveCreditCardBalance Controller: ', error);
      return res.status(error?.Status?.StatusCode || constants.HTTP_STATUS_INTERNAL_SERVER_ERROR).json(error);
    }
  }

  public async retrieveCertificateBalance(req: Request, res: Response, next: any) {
    const rqUID = req.headers['x-rquid'] as string;
    try {
      const acctId = req.params.acctId;
      const branchId = String(req.query.branchId || '');
      const requestHeadersDto = new RequestHeadersModel(req);
      const requestAdditionalsHeadersDto = new ReqHeadersAdditionalRest(requestHeadersDto, branchId);
      logBdb.info(rqUID, `INIT BalancesController - retrieveCertificateBalance`);
      const response = await CertificateBalanceService.invokeCertificateBalanceService(acctId, requestAdditionalsHeadersDto);
      logBdb.info(rqUID, `END BalancesController - retrieveCertificateBalance Response`);
      return res.status(STATUS_200).json(response);
    } catch (error: any) {
      logBdb.error(rqUID, 'END FAILED BalancesController Response retrieveCertificateBalance Controller: ', error);
      return res.status(error?.Status?.StatusCode || constants.HTTP_STATUS_INTERNAL_SERVER_ERROR).json(error);
    }
  }

  public async retrieveLoanBalance(req: Request, res: Response, next: any) {
    const rqUID = req.headers['x-rquid'] as string;
    try {
      const requestHeadersDto = new RequestHeadersModel(req);
      const acctId = req.params.acctId;
      logBdb.info(rqUID, `INIT BalancesController - retrieveLoanBalance`);
      const response = await LoanBalanceService.invokeLoanBalanceService(acctId, requestHeadersDto);
      logBdb.info(rqUID, `END BalancesController - retrieveLoanBalance Response`);
      return res.status(STATUS_200).json(response);
    } catch (error: any) {
      logBdb.error(rqUID, 'END FAILED BalancesController Response retrieveLoanBalance Controller: ', error);
      return res.status(error?.Status?.StatusCode || constants.HTTP_STATUS_INTERNAL_SERVER_ERROR).json(error);
    }
  }

  public async retrieveDetailCreditInfo(req: Request, res: Response, next: any) {
    const rqUID = req.headers['x-rquid'] as string;
    try {
      const requestHeadersDto = new RequestHeadersModel(req);
      const parametersDetailCredit = {
        acctId: req.params.acctId || '',
        trnType: req.query.trnType || '',
        acctType: req.query.acctType || '',
        baseEnvr: req.query.BaseEnvr || ''
      };
      logBdb.info(rqUID, `INIT BalancesController - retrieveDetailCreditBalance`);
      const response = await ProductInquiryService.invokeProductInquiryService(parametersDetailCredit, requestHeadersDto);
      logBdb.info(rqUID, `END BalancesController - retrieveDetailCreditBalance Response`);
      return res.status(STATUS_200).json(response);
    } catch (error: any) {
      logBdb.error(rqUID, 'END FAILED BalancesController Response retrieveDetailCreditBalance Controller: ', error);
      return res.status(error?.Status?.StatusCode || constants.HTTP_STATUS_INTERNAL_SERVER_ERROR).json(error);
    }
  }

  public async retrieveLoanQuota(req: Request, res: Response, next: any) {
    const rqUID = req.headers['x-rquid'] as string;
    try {
      const requestHeadersDto = new RequestHeadersModel(req);
      const loanQuotaHeadersDto = new LoanQuotaHeadersModel(req);
      logBdb.info(rqUID, `INIT BalancesController - retrieveLoanQuota`);
      const response = await LoanQuotaService.invokeLoanQuotaService(requestHeadersDto,loanQuotaHeadersDto);
      logBdb.info(rqUID, `END BalancesController - retrieveLoanQuota Response`);
      return res.status(STATUS_200).json(response);
    } catch (error: any) {
      logBdb.error(rqUID, 'END FAILED BalancesController Response retrieveLoanQuota Controller: ', error);
      return res.status(error?.Status?.StatusCode || constants.HTTP_STATUS_INTERNAL_SERVER_ERROR).json(error);
    }
  }

  public async retrieveOverdraft(req: Request, res: Response, next: any) {
    const rqUID = req.headers['x-rquid'] as string;
    try {
      const requestHeadersDto = new RequestHeadersModel(req);
      const overdraftHeadersModel = new OverdraftHeadersModel(req);
      logBdb.info(rqUID, `INIT BalancesController - retrieveOverdraft`);
      const response = await OverdraftService.invokeOverdraftService(requestHeadersDto, overdraftHeadersModel);
      logBdb.info(rqUID, `END BalancesController - retrieveOverdraft Response`);
      return res.status(STATUS_200).json(response);
    } catch (error: any) {
      logBdb.error(rqUID, 'END FAILED BalancesController Response retrieveOverdraft Controller: ', error);
      return res.status(error?.Status?.StatusCode || constants.HTTP_STATUS_INTERNAL_SERVER_ERROR).json(error);
    }
  }
}

const balanceController = new BalancesController();
export default balanceController;
