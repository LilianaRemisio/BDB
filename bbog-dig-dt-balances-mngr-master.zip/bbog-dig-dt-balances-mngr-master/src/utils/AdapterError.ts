export class AdapterErrorN extends Error {
    public statusCode: number;
    public details?: any;

    /**
     * Constructor para crear un error específico de negocio.
     * @param message - El mensaje descriptivo del error.
     * @param statusCode - El código HTTP asociado al error.
     * @param details - Información adicional sobre el error (opcional).
     */
    constructor(message: string, statusCode: number, details?: any) {
      super(message); // Llama al constructor de Error con el mensaje
      this.name = 'AdapterErrorN'; // Establece el nombre del error
      this.statusCode = statusCode; // Asigna el código de estado HTTP
      this.details = details; // Guarda detalles adicionales, si existen

      // Esto asegura que instanceof funcione correctamente en entornos que compilen a ES5 o anterior.
      Object.setPrototypeOf(this, AdapterErrorN.prototype);
    }

    /**
     * Método estático para crear un AdapterError de forma más concisa.
     * @param message - El mensaje descriptivo del error.
     * @param statusCode - El código HTTP asociado al error.
     * @param details - Información adicional sobre el error (opcional).
     * @returns Una instancia de AdapterError.
     */
    static getErrorFromMessage(
      message: string,
      statusCode: number,
      details?: any
    ): AdapterErrorN {
      return new AdapterErrorN(message, statusCode, details);
    }
  }
