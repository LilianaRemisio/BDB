import config from '../config';
import getLogger from '../utils/GetLogger';

const logger = getLogger('bdb:LoadFile');
const AWS = require('aws-sdk');
AWS.config.update({ region: 'us-east-1' });

const s3 = new AWS.S3();

export default class LoadFile {
  public  static async downloadFile(key: string, bucketName: string) {
    const params = { Bucket: bucketName, Key: key };
    try {
      const { Body } = await s3.getObject(params).promise();
      logger.info(`Downloading file from S3 - Bucket: ${bucketName}​​, Key: ${key}​​`);

      return Body;
    } catch (error) {
      logger.error('Error downloading file from S3:', error);
      throw error;
    }
  }

  public static async getCertificate() {
    try {
      const [strCert, strKey] = await Promise.all([
        this.downloadFile(config.CERTIFICATE_BANBTA, config.CERTIFICATE_BUCKET_NAME),
        this.downloadFile(config.KEYSTORE_CERTIFICATE_BANBTA, config.CERTIFICATE_BUCKET_NAME)
      ]);

      const decoder = new TextDecoder('utf-8');
      const loadCertificate = strCert ? decoder.decode(strCert) : '';
      const loadJksKey = strKey ? decoder.decode(strKey) : '';

      return { cert: loadCertificate, key: loadJksKey };
    } catch (error) {
      throw error;
    }
  }

}
