import { OpenApiValidator } from 'express-openapi-validate';
import * as fs from 'fs';
import path from 'path';

export const OpenApiValidatorProvider = async (): Promise< OpenApiValidator> => {
    const openApiSpecificationFile = path.join(__dirname, '../../static/balances_management_v2_OAS.json');
    const openApiSpecification = fs.readFileSync(openApiSpecificationFile, 'utf-8');
    const openApiDocument = JSON.parse(openApiSpecification);
    return new OpenApiValidator(openApiDocument);
};
