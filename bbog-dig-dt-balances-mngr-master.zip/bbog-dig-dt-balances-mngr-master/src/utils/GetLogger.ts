import { BdBLogger, TLogLevelName } from '@npm-bbta/bbog-dig-dt-tslog-lib';
import config from '../config';
export default function getLogger(name: string): BdBLogger {
    return new BdBLogger(
        config.LOGS.CLOUD !== 'false',
        name,
        config.LOGS.LEVEL as TLogLevelName
    );
}
