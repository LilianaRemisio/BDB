import { NextFunction, Request, Response } from 'express';
import getLogger from '../../utils/GetLogger';
import { DefaultResponseModel } from '../../model/DefaultResponseModel';
import { IDefaultStatusModel } from '../../model/IDefaultStatusModel';

const logger = getLogger('bdb:ErrorHandler');
export class ErrorHandler {
    public handlerError404Response(_request: Request, response: Response, _next: NextFunction): void {
        const rquid = _request.headers['x-rquid'] as string;
        logger.info(rquid, 'ErrorResponse', `Route '${_request.url}' Not found.`);
        const statusResponse: IDefaultStatusModel = {
            StatusCode: '404',
            StatusDesc: 'Not found.',
            Severity: 'Error',
            ServerStatusCode: '404',
            ServerStatusDesc: `Route '${_request.url}' Not found.`
        };
        const responseError: DefaultResponseModel = new DefaultResponseModel(statusResponse, rquid);
        response.status(404).json(responseError);
    }

    public handlerErrorResponse(error: any, _request: Request, response: Response, _next: NextFunction): void {
        const rquid = _request.headers['x-rquid'] as string;
        const status = error.status || error.statusCode || 500;
        logger.info(rquid, 'ErrorResponse', error.message);
        const statusResponse: IDefaultStatusModel = {
            StatusCode: status,
            StatusDesc: error.name,
            Severity: 'Error',
            ServerStatusCode: status,
            ServerStatusDesc: error.message
        };
        const responseError: DefaultResponseModel = new DefaultResponseModel(statusResponse, rquid);
        response.status(status).json(responseError);
    }
}
const errorHandler = new ErrorHandler();
export default errorHandler;
