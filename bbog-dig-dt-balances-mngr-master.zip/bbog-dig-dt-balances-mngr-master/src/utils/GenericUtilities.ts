import axios from 'axios';
import { constants } from 'http2';
import dateFormat from 'dateformat';
import { format, toZonedTime } from 'date-fns-tz';
import { DefaultStatusModelBuilder, IDefaultStatusModel } from '../model/IDefaultStatusModel';
import debugLib from 'debug';
import { AdapterErrorN } from './AdapterError';
import getLogger from './GetLogger';
import { parse, isValid } from 'date-fns';

const debug = debugLib('bdb:GenericUtilities');
const logger = getLogger('bdb:GenericUtilities');

const FORMAT_DATE_YYYY_MM_DD = 'yyyy-mm-dd';
class GenericUtilities {
    private readonly GENERIC_ERROR: string = 'Internal error';
    /*
    public setOptionsAxios(rquid: string, url: string, method: string, data: any, params?: { [key: string]: string }, headers?: any, useHttpAgent = true){
        if(useHttpAgent){
            return {
                rquid,
                url,
                method,
                data,
                params: params,
                headers: headers,
                timeout: Number(config.SERVICES_TIMEOUT),
                agent: {
                    bucketName: config.CERTIFICATE_BUCKET_NAME,
                    certificateKeyFile: config.CERTIFICATE_BANBTA,
                    backupKeyFile: config.KEYSTORE_CERTIFICATE_BANBTA,
                    useHttpAgent: useHttpAgent,
                    rejectUnauthorized: false
                }
            }
        } else {
            return {
                rquid,
                url,
                method,
                data,
                params: params,
                headers: headers,
                timeout: Number(config.SERVICES_TIMEOUT)
            }
        }
    }
    */

    public handlerErrorRestService(rquid: string, serviceName: string, reason: any): IDefaultStatusModel {
        // Manejo Timeout Error
        if (axios.isAxiosError(reason) && reason.code === 'ECONNABORTED') {
            const statusResponse: IDefaultStatusModel = new DefaultStatusModelBuilder().setStatusCode(constants.HTTP_STATUS_REQUEST_TIMEOUT)
                .setStatusDesc(reason.message || 'Request Timeout')
                .setSeverity('Error')
                .setServerStatusCode(String(constants.HTTP_STATUS_REQUEST_TIMEOUT))
                .setServerStatusDesc(`Error calling service ${serviceName} - Timeout`)
                .build();
            logger.error(rquid, `Error calling service ${serviceName} - Timeout`, reason.message);
            return statusResponse;
            // Manejo Bussinness Error
        } else if ((reason instanceof AdapterErrorN)) {
            const statusResponse: IDefaultStatusModel = new DefaultStatusModelBuilder()
                .setStatusCode(reason.details?.Status?.StatusCode || constants.HTTP_STATUS_INTERNAL_SERVER_ERROR)
                .setStatusDesc(reason.details?.Status?.StatusDesc || this.GENERIC_ERROR)
                .setSeverity('Error')
                .setServerStatusCode(reason.details?.Status?.ServerStatusCode || String(constants.HTTP_STATUS_INTERNAL_SERVER_ERROR))
                .setServerStatusDesc(reason.details?.Status?.ServerStatusDesc || this.GENERIC_ERROR)
                .setAdditionalStatus(reason.details?.Status?.AdditionalStatus)
                .build();
            logger.error(rquid, `Error calling service ${serviceName}`,JSON.stringify({'Error':reason}));
            return statusResponse;
            // Manejo Technical Error
        } else {
            const error = reason.response?.data ? reason.response.data : reason.message;
            const statusResponse: IDefaultStatusModel = new DefaultStatusModelBuilder()
                .setStatusCode(reason.response?.status || constants.HTTP_STATUS_INTERNAL_SERVER_ERROR)
                .setStatusDesc(reason.response?.statusText || this.GENERIC_ERROR)
                .setSeverity('Error')
                .setServerStatusCode(reason.code || constants.HTTP_STATUS_INTERNAL_SERVER_ERROR)
                .setServerStatusDesc(reason.response?.data?.error?.mensaje || reason.message || this.GENERIC_ERROR)
                .build();
            logger.error(rquid, `Error calling service ${serviceName}`,JSON.stringify({'Error':error}));
            return statusResponse;
        }
    }

    public currentDateWithTimezone(offset: number): Date {
        const d = new Date();
        const utc = d.getTime() + (d.getTimezoneOffset() * 60000);
        return new Date(utc + (3600000 * offset));
    }

    public getCurrentDateStringFormat(formatDate: string): string {
        const currentDate: Date = genericUtilities.currentDateWithTimezone(-5);
        const currentDateFormat: string = dateFormat(currentDate, formatDate);
        return currentDateFormat;
    }

    public formatDate(date: string, originFormat: string, destFormat: string): string {
        const originDate = new Date(date.substring(0, 10));
        const dateUTC = toZonedTime(originDate, 'UTC');
        return format(dateUTC, destFormat, { timeZone: 'UTC' });
    }

    public formatDateString(dateString: string): string {
        if (!dateString) {
            return '';
        }
        let parsedDate;
        parsedDate = parse(dateString, FORMAT_DATE_YYYY_MM_DD, new Date());
        if (!isValid(parsedDate)) {
            // Si falla, intentar parsear como "dd-MM-yyyy"
            parsedDate = parse(dateString, 'dd-MM-yyyy', new Date());
        }

        // Verificar si la fecha es válida después del segundo intento
        if (!isValid(parsedDate)) {
            throw new Error('Invalid date format');
        }

        // Convertir la fecha a UTC
        const zonedDate = toZonedTime(parsedDate, 'UTC');

        // Formatear la fecha al formato "yyyy-MM-dd"
        return format(zonedDate,FORMAT_DATE_YYYY_MM_DD, { timeZone: 'UTC' });
    }


    public stringToBoolean(str: string): boolean | undefined {
        if (str.toLowerCase() === 'true') {
            return true;
        } else if (str.toLowerCase() === 'false') {
            return false;
        }
    }

    public formatDateOut(date: string, originFormat: string): string {
        if (!date) {
            return date;
        }
        if (date.length >= 10) {
            const partsDate = date.substring(0, 10).split(/[/\\-]/);
            let dateFormated = '';
            if (originFormat === 'dd/MM/yyyy') {
                dateFormated = `${partsDate[2]}-${partsDate[1]}-${partsDate[0]}`;
            } else if (originFormat === 'yyyy-MM-dd') {
                dateFormated = `${partsDate[2]}/${partsDate[1]}/${partsDate[0]}`;
            }
            return dateFormated;
        } else {
            return date;
        }
    }

    public transformDocumentType(identityType: any): string {
        let convertedIdentityType = '';
        if (identityType === 'CC') {
            convertedIdentityType = 'C';
        } else if (identityType === 'NI') {
            convertedIdentityType = 'L';
        } else if (identityType === 'CE') {
            convertedIdentityType = 'E';
        } else if (identityType === 'NJ') {
            convertedIdentityType = 'N';
        } else if (identityType === 'NE') {
            convertedIdentityType = 'I';
        } else if (identityType === 'PA') {
            convertedIdentityType = 'P';
        } else if (identityType === 'RC') {
            convertedIdentityType = 'R';
        } else if (identityType === 'TI') {
            convertedIdentityType = 'T';
        } else {
            throw new Error(`Documento no expecificado: ${identityType}`);
        }
        return convertedIdentityType;
    }

    public validateChannel(channel: any): string {
        switch (channel) {
            case 'BancaMovil':
                return 'SMP';
            case 'BancaVirtual':
                return 'PB';
            case 'BdB Empresas':
                return 'BEP001';
            default:
                return 'DIG482';
        }
    }

    public safeStringify(obj: any, replacer = null, space = 2) {
        const cache = new Set();
        const result = JSON.stringify(obj, (key, value) => {
            if (typeof value === 'object' && value !== null) {
                if (cache.has(value)) {
                    return '[Circular]';
                }
                cache.add(value);
            }// NOSONAR
            return value;
        }, space);
        cache.clear();
        return result;
    }

    public getValueOrNull(value: any): any {
        return value ? value : null;
    }
}

const genericUtilities = new GenericUtilities();
export default genericUtilities;
