import * as process from 'process';

export default {
  CERTIFICATE_BALANCES_ENDPOINT: process.env.CERTIFICATE_BALANCES_ENDPOINT || 'https://10.86.154.122:3088/accounts/product/CertificateBalancesInquiry',
  CREDITCARD_BALANCES_ENDPOINT: process.env.CREDITCARD_BALANCES_ENDPOINT || 'https://10.86.154.122:3088/accounts/product/CreditCardBalancesInquiry',
  CUSTOMER_PRODUCT_ENDPOINT: process.env.CUSTOMER_PRODUCT_ENDPOINT || 'https://10.86.154.122:3088/customers/CustomerProductInquiry',
  DEMAND_BALANCES_ENDPOINT: process.env.DEMAND_BALANCES_ENDPOINT || 'https://10.86.154.119:3088/accounts/product/DemandBalancesInquiry',
  LOAN_BALANCES_ENDPOINT: process.env.LOAN_BALANCES_ENDPOINT || 'https://10.86.154.122:3088/accounts/product/LoanBalancesInquiry',
  LOAN_QUOTA_ENDPOINT: process.env.LOAN_QUOTA_ENDPOINT || 'https://10.86.154.122:3088/customers/product/LoanQuotaInq',
  PORT: process.env.PORT || '9050',
  LOGS: {
    CLOUD: process.env.CLOUD_LOGS || 'true',
    LEVEL: process.env.LEVEL_LOGS || 'debug',
  },
  SAVING_BALANCES_ENDPOINT: process.env.SAVING_BALANCES_ENDPOINT || 'https://10.86.154.119:3088/accounts/product/SavingsBalancesInquiry',
  TIMEOUT_SERVICE: process.env.TIMEOUT_SERVICE || '25000',
  TRUST_BALANCES_ENDPOINT: process.env.TRUST_BALANCES_ENDPOINT || 'https://10.86.154.122:3088/accounts/product/TrustBalancesInquiry',
  topicArn: process.env.TOPIC_ARN || 'arn',
  SAVING_FALLBACK_URL: process.env.SAVING_FALLBACK_URL || 'https://10.86.154.119:4701/ods/ods_stag/pr_ws_consul_ah',
  // 'http://localhost:5701/ods/ods_stag/pr_ws_consul_ah',
  DEMAND_FALLBACK_URL: process.env.DEMAND_FALLBACK_URL || 'https://10.86.154.119:4701/ods/ods_stag/pr_ws_consul_cc',
  CIRCUIT_BREAKER_OPTIONS: process.env.CIRCUIT_BREAKER_OPTIONS ||
   '{\"volumeThreshold\": 4, \"errorThresholdPercentage\": 50, \"rollingCountTimeout\": 600000, \"rollingCountBuckets\": 120, \"resetTimeout\": 240000, \"timeout\": 28000}',
  USE_CIRCUIT_BREAKER_SAVINGS: process.env.USE_CIRCUIT_BREAKER_SAVINGS || 'true',
  USE_CIRCUIT_BREAKER_DEMANDS: process.env.USE_CIRCUIT_BREAKER_DEMANDS || 'true',
  USE_HTTPS_AGENT: process.env.USE_HTTPS_AGENT || 'false',
  fallbackServiceCalled: false,
  circuitBreakerState: 'close',
  CERTIFICATE_BANBTA: process.env.CERTIFICATE_BANBTA || 'Bus/AperturaDigital.banbta.net.pem',
  KEYSTORE_CERTIFICATE_BANBTA: process.env.KEYSTORE_CERTIFICATE_BANBTA || 'Bus/AperturaDigitalkey.banbta.net.pem',
  CERTIFICATE_BUCKET_NAME: process.env.CERTIFICATE_BUCKET_NAME || 'qa-certificates-tvs-s3',
  EVENT_CLIENT_ID: '00000',
  EVENT_SESSION_ID: '00000'
 };
