#!/bin/bash
curl -H "Authorization: token $GITHUB_TOKEN_CURL_OAS" -o static/balances_management_v2_OAS.json https://raw.githubusercontent.com/bancodebogota/bbog-dig-dt-aws-tvs-clients-iac/"$GITHUB_REPO_BRANCH_OAS"/components/backend/definitions/apis/balances_management_v2_OAS.json
cat static/balances_management_v2_OAS.json
