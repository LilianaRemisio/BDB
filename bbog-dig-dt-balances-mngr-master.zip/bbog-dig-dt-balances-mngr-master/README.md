# bbog-dig-dt-balances-mngr
[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=bbog-dig-dt-balances-mngr&metric=alert_status&token=cc5161365de194b1887bb42055ed1a6df84a646e)](https://sonarcloud.io/summary/new_code?id=bbog-dig-dt-balances-mngr)

Manager tipo ECS que permite hacer la consulta de saldos de los diferentes productos.
