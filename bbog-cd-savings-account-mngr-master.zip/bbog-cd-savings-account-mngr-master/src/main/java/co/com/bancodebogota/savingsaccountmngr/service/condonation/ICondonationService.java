package co.com.bancodebogota.savingsaccountmngr.service.condonation;

public interface ICondonationService {
    Boolean condonationProcess(String identityNumber, String identityType, String rqUid, String branchId, boolean holiday, String channel, String userIp);
}
