package co.com.bancodebogota.savingsaccountmngr.service.customer;

import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountDto;

public interface IParticipantService {

    CreateAccountDto getParticipantInfo (String uuid);
}
