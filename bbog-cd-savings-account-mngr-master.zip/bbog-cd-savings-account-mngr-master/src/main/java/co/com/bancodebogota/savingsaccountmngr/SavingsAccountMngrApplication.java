package co.com.bancodebogota.savingsaccountmngr;

import co.com.bancodebogota.AsymmetricCryptography;
import co.com.bancodebogota.TokenHandlerInterceptor;
import co.com.bancodebogota.interceptors.realtime.Interceptor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.crypto.NoSuchPaddingException;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
@EntityScan("co.com.bancodebogota")
@ComponentScan("co.com.bancodebogota")
@EnableJpaRepositories("co.com.bancodebogota")
public class SavingsAccountMngrApplication implements WebMvcConfigurer {

    public static void main(String[] args) {
        SpringApplication.run(SavingsAccountMngrApplication.class);
    }

    @Bean
    public AsymmetricCryptography asymmetricCryptography() throws NoSuchAlgorithmException, NoSuchPaddingException {
        return new AsymmetricCryptography();
    }

    @Bean
    @Qualifier("tokenValidator")
    public TokenHandlerInterceptor pageTokenHandlerInterceptor() {
        return new TokenHandlerInterceptor();
    }

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**").allowedMethods("GET", "PUT", "POST");
            }
        };
    }

    @Bean
    public Interceptor realTimeInterceptorBean() {
        return new Interceptor();
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(pageTokenHandlerInterceptor());
        registry.addInterceptor(realTimeInterceptorBean());
    }
}
