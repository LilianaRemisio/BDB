package co.com.bancodebogota.savingsaccountmngr.service.inquiryholders;

import co.com.bancodebogota.dto.products.LimitsAccountRq;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.rest.RestExchangeV2;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.util.UriComponentsBuilder;

@Slf4j
@Service
@RequiredArgsConstructor
public class InquiryHoldersImpl implements IInquiryHolders {

    @Value("${endpoint.accounts.adapter}")
    private String endpointAccountsAdapter;

    private final RestExchangeV2 restExchange;

    private static final String GET_INQUIRY_HOLDERS = "/holders/inquiry";
    private static final String OWNERSHIP = "ownership";

    @Override
    public String getOwnership(LimitsAccountRq accountInfo, String rqUID) throws AbsBdbServiceException {
        String identityNumber = accountInfo.getCustomer().getIdentificationNumber();
        log.info(">>> ({}) INQUIRY HOLDERS PROCESS. NEW CALL >>>", identityNumber);

        UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromHttpUrl(endpointAccountsAdapter).path(GET_INQUIRY_HOLDERS);

        HttpHeaders headers = new HttpHeaders();
        headers.set("rqUID", rqUID);

        ResponseEntity<JsonNode> response = restExchange.exchange(urlBuilder.toUriString(),
                accountInfo, HttpMethod.POST, headers, JsonNode.class);
        JsonNode responseBody = response.getBody();

        if (response.getStatusCode().isError() || ObjectUtils.isEmpty(responseBody)) {
            log.info("<<< ({}) INQUIRY HOLDERS PROCESS. FAIL <<<", identityNumber);
            throw BdbExceptionFactory.createExcepcion(response.getStatusCode(), identityNumber, "Error getOwnerShip");
        }

        log.info("<<< ({}) INQUIRY HOLDERS PROCESS. SUCCESS <<<", identityNumber);

        return responseBody.get(OWNERSHIP).asText();
    }
}
