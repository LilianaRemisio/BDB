package co.com.bancodebogota.savingsaccountmngr.service.dispersioncodes;

import co.com.bancodebogota.dto.custcatteredinqrs.CustCatteredInqRsDto;
import co.com.bancodebogota.dto.payrolldispersions.GetInfoByNitDto;
import co.com.bancodebogota.dto.payrolldispersions.PayrollDispersionsRsDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import org.springframework.http.HttpHeaders;

public interface IDispersionCodesService {

    PayrollDispersionsRsDto getPayrollDispersionsRsDto(
            String dispersionCode, String idType, String idNum, String channel, String rqUID)
            throws AbsBdbServiceException;
    CustCatteredInqRsDto getCompaniesByCode(
            String dispersionCode, String idType, String idNum, String channel, String rqUID)
            throws AbsBdbServiceException;
    GetInfoByNitDto getNitInfo(HttpHeaders httpHeaders, String nit) throws AbsBdbServiceException;

}
