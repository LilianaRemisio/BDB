package co.com.bancodebogota.savingsaccountmngr.service.accounts;

import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountResponseDto;
import co.com.bancodebogota.dto.account.AccountData;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import org.springframework.http.HttpHeaders;

public interface IAccountService {

    CreateAccountResponseDto accountOpening(HttpHeaders httpHeaders, AccountData accountData)
            throws AbsBdbServiceException;

    CreateAccountResponseDto accountOpening(HttpHeaders httpHeaders, AccountData accountData,
                                            DispatcherDto dispatcherDto) throws AbsBdbServiceException;

    CreateAccountResponseDto accountOpeningV4(HttpHeaders httpHeaders, AccountData accountData, DispatcherDto dispatcherDto) throws AbsBdbServiceException;
}
