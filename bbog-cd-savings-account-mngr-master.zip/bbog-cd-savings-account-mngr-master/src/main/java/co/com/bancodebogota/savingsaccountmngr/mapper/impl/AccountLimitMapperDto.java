package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.db.savings.dto.jpa.AccountLimitsDto;
import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.enums.EAccountType;
import co.com.bancodebogota.enums.EIdentificationType;

public class AccountLimitMapperDto {

	public AccountLimitsDto createAccountLimitDto(BankAccountDto bankAccountDto, String accountNumber){
		AccountLimitsDto accountLimitsDto = new AccountLimitsDto();
		accountLimitsDto.setAcctId(accountNumber);
		accountLimitsDto.setAcctType(EAccountType.SDA.name());
		accountLimitsDto.setDocumentType(EIdentificationType.CEDULA_CIUDADANIA.getBdbType());
		accountLimitsDto.setNumberDocument(bankAccountDto.getIdentityNumber());
		accountLimitsDto.setListAcctLimitsDesc(bankAccountDto.getAccountLimit());
		return accountLimitsDto;
	}
}
