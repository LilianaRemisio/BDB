package co.com.bancodebogota.savingsaccountmngr.service.accounts;

import co.com.bancodebogota.db.savings.dto.jpa.AccountLimitsDto;
import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountResponseDto;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.products.AccountHierarchyReqDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface ISavingsAccountService {

    ResponseEntity<JsonNode> createAccountByUuid(JsonNode data, HttpHeaders httpHeaders) throws AbsBdbServiceException;

    ResponseEntity<CreateAccountResponseDto> createAccountByDto(BankAccountDto bankAccountDto, HttpHeaders httpHeaders) throws AbsBdbServiceException;

    JsonNode getAccountsByCard(HttpHeaders httpHeaders, String cardNumber) throws AbsBdbServiceException;

    ResponseEntity<JsonNode> setAccountHierarchy(AccountHierarchyReqDto accountHierarchyReqDto, HttpHeaders httpHeaders) throws AbsBdbServiceException, JsonProcessingException;

    ResponseEntity<JsonNode> getPayloadInfo(String identityNumber, String authUuid) throws AbsBdbServiceException;

    ResponseEntity<String> saveParticipantInfo(BankAccountDto bankAccountDto, HttpHeaders httpHeaders) throws AbsBdbServiceException;

    ResponseEntity<String> saveParticipantInfo(BankAccountDto bankAccountDto) throws AbsBdbServiceException;

    ResponseEntity<JsonNode> saveSessionRedis(JsonNode sessionRedis, HttpHeaders httpHeaders) throws AbsBdbServiceException;

    ResponseEntity<JsonNode> getSessionRedis(String identityNumber, String authUuid) throws AbsBdbServiceException;

    ResponseEntity<JsonNode> getAccountLimits() throws AbsBdbServiceException;

    CreateAccountResponseDto callAccountService(BankAccountDto bankAccountDto, HttpHeaders httpHeaders,
                                                String rqUuid, DispatcherDto dispatcherDto);

    void runAsyncTasks(BankAccountDto bankAccountDto, CreateAccountResponseDto createAccountResponseDto, String userIp, String rqUid);

    boolean updateAccountLimit(AccountLimitsDto accountLimitsDto);

    void saveNewModel(BankAccountDto bankAccountDto, CreateAccountResponseDto createAccountResponseDto) throws AbsBdbServiceException;

    void saveModel(List<List<String>> request);
}
