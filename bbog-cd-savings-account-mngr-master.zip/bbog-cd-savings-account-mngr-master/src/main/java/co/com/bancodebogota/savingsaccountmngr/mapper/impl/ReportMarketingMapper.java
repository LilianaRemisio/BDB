package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.utils.JacksonUtilsV2;
import co.com.bancodebogota.dto.account.AccountData;
import co.com.bancodebogota.dto.reportmarketing.ReportMarketingPayLoadDto;
import co.com.bancodebogota.dto.reportmarketing.ReportMarketingReqDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.http.HttpHeaders;

import java.util.Base64;

public abstract class ReportMarketingMapper {

    private ReportMarketingMapper() {
        // Default constructor
    }

    private static final String PROVIDER_WEB = "website";

    public static ObjectNode mapReportMarketingReq(AccountData accountData, HttpHeaders httpHeaders) {

        ReportMarketingPayLoadDto reportMarketingPayLoadDto = payloadFacebook(accountData, httpHeaders);
        ReportMarketingReqDto reportMarketingReqDto = baseConverted(reportMarketingPayLoadDto);

        ObjectMapper objectMapper = new ObjectMapper();
        ObjectNode jsonReportMarketingReq = objectMapper.createObjectNode();
        jsonReportMarketingReq.putPOJO("reportMarketingReq", reportMarketingReqDto);

        return jsonReportMarketingReq;
    }

    private static ReportMarketingPayLoadDto payloadFacebook(AccountData accountData, HttpHeaders httpHeaders) {
        ReportMarketingPayLoadDto reportMarketingPayLoadDto = new ReportMarketingPayLoadDto();
        reportMarketingPayLoadDto.setFirstName(accountData.getOpeningAccount().getFirstName());
        reportMarketingPayLoadDto.setLastName(accountData.getOpeningAccount().getFirstLastName());
        reportMarketingPayLoadDto.setEmail(accountData.getOpeningAccount().getEmailAddr());
        reportMarketingPayLoadDto.setCellPhoneNumber(Long.parseLong(accountData.getOpeningAccount().getPhoneNumber()));
        reportMarketingPayLoadDto.setPurchaseValue(0L);
        reportMarketingPayLoadDto.setEventSource(PROVIDER_WEB);
        reportMarketingPayLoadDto.setEventUrl(httpHeaders.getOrigin());
        reportMarketingPayLoadDto.setClientUserAgent(accountData.getClientUserAgent());
        return reportMarketingPayLoadDto;
    }

    private static ReportMarketingReqDto baseConverted(ReportMarketingPayLoadDto reportMarketingPayLoadDto) {
        ReportMarketingReqDto reportMarketingReqDto = new ReportMarketingReqDto();
        reportMarketingReqDto.setPayload(Base64.getEncoder()
                .encodeToString(JacksonUtilsV2.getPlainJson(reportMarketingPayLoadDto).getBytes()));
        return reportMarketingReqDto;
    }
}
