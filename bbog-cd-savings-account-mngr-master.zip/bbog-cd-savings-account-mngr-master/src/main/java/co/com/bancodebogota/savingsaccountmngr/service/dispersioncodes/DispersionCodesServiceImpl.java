package co.com.bancodebogota.savingsaccountmngr.service.dispersioncodes;

import co.com.bancodebogota.dto.custcatteredinqrs.CustCatteredInqRsDto;
import co.com.bancodebogota.dto.custcatteredinqrs.establishacctinfo.EstablishAcctInfoDto;
import co.com.bancodebogota.dto.payrolldispersions.GetInfoByNitDto;
import co.com.bancodebogota.dto.payrolldispersions.PayrollDispersionsRsDto;
import co.com.bancodebogota.enums.EPayrollCodes;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.savingsaccountmngr.mapper.PayrollDispersionsMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;
import org.springframework.web.util.UriUtils;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class DispersionCodesServiceImpl implements IDispersionCodesService {

    @Value("${endpoint.accounts.adapter}")
    private String endpointAccountsAdapter;

    private final RestExchangeV2 restExchange;
    private final PayrollDispersionsMapper payrollDispersionsMapper;

    private static final String DISPERSION_RESOURCE = "/dispersion-code-info";
    private static final String NIT_INFO = "/nit-info";

    @Override
    public PayrollDispersionsRsDto getPayrollDispersionsRsDto(
            String dispersionCode, String idType, String idNum, String channel, String rqUID) throws AbsBdbServiceException {
        EPayrollCodes ePayrollCodes = EPayrollCodes.findByCode(dispersionCode == null ? "" :
                new String(Base64.getDecoder().decode(dispersionCode),
                StandardCharsets.UTF_8));
        CustCatteredInqRsDto custCatteredInqRsDto = ePayrollCodes.getCode().isEmpty() ?
                getCompaniesByCode(dispersionCode, idType, idNum, channel, rqUID) :
                payrollDispersionsMapper.mapDispersionCode(ePayrollCodes);
        List<EstablishAcctInfoDto> establishAcctInfoDto = custCatteredInqRsDto.getEstablishAcctInfo();
        PayrollDispersionsRsDto payrollDispersionsRsDto = new PayrollDispersionsRsDto();

        payrollDispersionsRsDto.setEstablishAcctInfoDtoList(ObjectUtils.isEmpty(establishAcctInfoDto) ?
                Collections.emptyList() : establishAcctInfoDto);

        return payrollDispersionsRsDto;
    }

    @Override
    public CustCatteredInqRsDto getCompaniesByCode(
            String dispersionCode, String idType, String idNum, String channel, String rqUID)
            throws AbsBdbServiceException {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("rqUID", rqUID);
        httpHeaders.add("channel", channel);

        UriComponents urlBuilder = UriComponentsBuilder.fromUriString(endpointAccountsAdapter)
                .path(DISPERSION_RESOURCE)
                .queryParamIfPresent("dispersionCode", Optional.ofNullable(dispersionCode == null ? null : UriUtils.encode(
                        new String(Base64.getDecoder().decode(dispersionCode)),
                        "UTF-8")))
                .queryParamIfPresent("idType", Optional.ofNullable(idType))
                .queryParamIfPresent("idNum", Optional.ofNullable(idNum))
                .build();

        ResponseEntity<CustCatteredInqRsDto> response = restExchange.exchange(urlBuilder.toUriString(), null,
                HttpMethod.GET, httpHeaders, CustCatteredInqRsDto.class);
        CustCatteredInqRsDto responseBody = response.getBody();

        if (response.getStatusCode().isError() || ObjectUtils.isEmpty(responseBody)) {
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, rqUID, "Error " +
                    "getCompaniesByCode " + dispersionCode);
        }

        return responseBody;
    }

    @Override
    public GetInfoByNitDto getNitInfo(HttpHeaders httpHeaders, String nit) throws AbsBdbServiceException {
        nit = nit.length() > 9 ? nit : nit + calculateVerifyDigit(nit);

        UriComponents urlBuilder = UriComponentsBuilder.fromUriString(endpointAccountsAdapter)
                .path(NIT_INFO)
                .queryParam("nit", nit)
                .build();

        ResponseEntity<GetInfoByNitDto> response = restExchange.exchange(urlBuilder.toUriString(), null,
                HttpMethod.GET, httpHeaders, GetInfoByNitDto.class);

        GetInfoByNitDto responseBody = response.getBody();
        if (ObjectUtils.isEmpty(responseBody) || response.getStatusCode().isError()) {
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, null,
                    "Error retrieving companies names by nit");
        }
        return responseBody;
    }

    public String calculateVerifyDigit(String nit) {
        final int[] arrayVerifyDigit = {3, 7, 13, 17, 19, 23, 29, 37, 41, 43, 47, 53, 59, 67, 71};
        final char[] arrayNit = nit.toCharArray();
        final int arrayNitLength = arrayNit.length;
        int verifyDigit = 0;

        for (int index = 0; index < arrayNitLength; index++) {
            verifyDigit += (Character.getNumericValue(arrayNit[index]) * arrayVerifyDigit[arrayNitLength - (index + 1)]);
        }

        verifyDigit = verifyDigit % 11;
        return String.valueOf(verifyDigit > 1 ? 11 - verifyDigit : verifyDigit);
    }
}
