package co.com.bancodebogota.savingsaccountmngr.controller;

import co.com.bancodebogota.annotations.DisableAuthToken;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountResponseDto;
import co.com.bancodebogota.dto.account.AccountData;
import co.com.bancodebogota.dto.openapi.AccountDto;
import co.com.bancodebogota.dto.openapi.ProductDto;
import co.com.bancodebogota.enums.EIdentificationType;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.savingsaccountmngr.service.accounts.IAccountService;
import co.com.bancodebogota.savingsaccountmngr.service.openapi.IOpenApiService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("account")
public class AccountController {

    private static final String X_CUST_IDENT_TYPE = "X-CustIdentType";

    private final IOpenApiService openApiService;
    private final IAccountService accountService;

    @DisableAuthToken
    @PostMapping("")
    public ResponseEntity<ProductDto> createAccountByOpenApi(@RequestHeader HttpHeaders headers,
                                                             @RequestBody AccountDto accountDto) throws AbsBdbServiceException {

        ProductDto result = openApiService.create(headers, accountDto);
        return new ResponseEntity<>(result, result.getNumber() == null ? HttpStatus.INTERNAL_SERVER_ERROR :
                HttpStatus.CREATED);
    }

    @PostMapping("/v2")
    public ResponseEntity<CreateAccountResponseDto> accountOpening(@RequestHeader HttpHeaders httpHeaders,
                                                                   @RequestBody AccountData accountData) throws AbsBdbServiceException {

        CreateAccountResponseDto result = accountService.accountOpening(httpHeaders, accountData);
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }

    @PostMapping("/v3")
    public ResponseEntity<ProductDto> createAccountV3(@RequestHeader HttpHeaders httpHeaders,
                                                      @RequestBody AccountDto accountDto) throws AbsBdbServiceException {

        httpHeaders.set(X_CUST_IDENT_TYPE, EIdentificationType
                .findApiByBdbType(httpHeaders.getFirst(X_CUST_IDENT_TYPE)));
        return createAccountByOpenApi(httpHeaders, accountDto);
    }

    @PostMapping("/v4")
    public ResponseEntity<CreateAccountResponseDto> createAccountV4(@RequestHeader HttpHeaders httpHeaders,
                                                                    @RequestBody AccountData accountData) throws AbsBdbServiceException {

        CreateAccountResponseDto result = accountService.accountOpeningV4(httpHeaders, accountData, null);
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }
}