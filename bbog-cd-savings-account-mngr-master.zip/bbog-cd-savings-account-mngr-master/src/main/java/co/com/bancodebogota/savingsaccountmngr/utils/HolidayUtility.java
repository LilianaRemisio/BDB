package co.com.bancodebogota.savingsaccountmngr.utils;

import co.com.bancodebogota.enums.DayEnum;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

@Getter
@Setter
public class HolidayUtility {
    private int year;
    private int easterMonth;
    private int easterDay;

    private List<String> holidays;

    public HolidayUtility() {
        this.calculateHolidays(LocalDateTime.now().getYear());
    }

    public HolidayUtility(int year) {
        this.calculateHolidays(year);
    }

    private void calculateHolidays(int year) {
        this.year = year;
        this.holidays = new ArrayList<>();
        int a = year % 19;
        int b = year / 100;
        int c = year % 100;
        int d = b / 4;
        int e = b % 4;
        int g = (8 * b + 13) / 25;
        int h = (19 * a + b - d - g + 15) % 30;
        int j = c / 4;
        int k = c % 4;
        int m = (a + 11 * h) / 319;
        int r = (2 * e + 2 * j - k - h + m + 32) % 7;
        this.easterMonth = (h - m + r + 90) / 25;
        this.easterDay = (h - m + r + this.easterMonth + 19) % 32;
        this.easterMonth--;

        this.holidays.add("0:1");   // Primero de Enero
        this.holidays.add("4:1");   // Dia del trabajo 1 de mayo
        this.holidays.add("6:20");  // Independencia 20 de Julio
        this.holidays.add("7:7");   // Batalla de boyaca 7 de agosto
        this.holidays.add("11:8");  // Maria inmaculada 8 de diciembre
        this.holidays.add("11:25"); // Navidad 25 de diciembre

        this.calculateEmilianiDate(0, 6);   // Reyes magos 6 de enero
        this.calculateEmilianiDate(2, 19);  // San jose 19 de marzo
        this.calculateEmilianiDate(5, 29);  // San pedro y san pablo 29 de junio
        this.calculateEmilianiDate(7, 15);  // Asuncion 15 de agosto
        this.calculateEmilianiDate(9, 12);  // Descubrimiento de america 12 de octubre
        this.calculateEmilianiDate(10, 1);  // Todos los santos 1 de noviembre
        this.calculateEmilianiDate(10, 11); // Independencia de cartagena 11 de noviembre

        this.calculateOtherHoliday(-3, false);  // Jueves santos
        this.calculateOtherHoliday(-2, false);  // Viernes santo
        this.calculateOtherHoliday(43, true);   // Ascención del señor de pascua
        this.calculateOtherHoliday(60, true);   // Corpus cristi
        this.calculateOtherHoliday(68, true);   // Sagrado corazon

        this.calculateSaturdayHoliday();

        this.formattedMonths();
    }

    private void formattedMonths() {
        ArrayList<String> holidaysWithFormattedMonths = new ArrayList<>();

        for (String date : holidays) {
            String[] dateSplit = date.split(":");

            String month = String.valueOf(Integer.parseInt(dateSplit[0]) + 1);
            String day = dateSplit[1];

            holidaysWithFormattedMonths.add(this.year + "-" + (month.length() == 1 ? "0" + month : month) + "-" + (day.length() == 1 ? "0" + day : day));
        }

        this.holidays = holidaysWithFormattedMonths;
    }

    private void calculateOtherHoliday(int days, boolean emiliani) {
        Calendar date = Calendar.getInstance();
        date.set(this.year, this.easterMonth, this.easterDay);
        date.add(Calendar.DATE, days);

        if (emiliani) this.calculateEmilianiDate(date.get(Calendar.MONTH), date.get(Calendar.DATE));
        else this.holidays.add(date.get(Calendar.MONTH) + ":" + date.get(Calendar.DATE));
    }

    private void calculateSaturdayHoliday() {
        ArrayList<String> saturdays = new ArrayList<>();

        for (String holiday : this.holidays) {
            Calendar calendar = getCalendarFromHoliday(holiday);
            if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY) {
                calendar.add(Calendar.DATE, 1);
                saturdays.add(calendar.get(Calendar.MONTH) + ":" + calendar.get(Calendar.DATE));
            }
        }

        this.holidays.addAll(saturdays);
    }

    private Calendar getCalendarFromHoliday(String holiday) {
        String[] split = holiday.split(":");
        int month = Integer.parseInt(split[0]);
        int day = Integer.parseInt(split[1]);

        Calendar calendar = Calendar.getInstance();
        calendar.set(this.year, month, day);

        return calendar;
    }

    private void calculateEmilianiDate(int month, int day) {
        Calendar date = Calendar.getInstance();
        date.set(this.year, month, day);
        switch (date.get(Calendar.DAY_OF_WEEK)) {
            case 1 -> date.add(Calendar.DATE, DayEnum.ONE.getValueDay());
            case 3 -> date.add(Calendar.DATE, DayEnum.SIX.getValueDay());
            case 4 -> date.add(Calendar.DATE, DayEnum.FIVE.getValueDay());
            case 5 -> date.add(Calendar.DATE, DayEnum.FOUR.getValueDay());
            case 6 -> date.add(Calendar.DATE, DayEnum.THREE.getValueDay());
            case 7 -> date.add(Calendar.DATE, DayEnum.TWO.getValueDay());
            default -> { // Default case
            }
        }

        this.holidays.add(date.get(Calendar.MONTH) + ":" + date.get(Calendar.DATE));
    }
}
