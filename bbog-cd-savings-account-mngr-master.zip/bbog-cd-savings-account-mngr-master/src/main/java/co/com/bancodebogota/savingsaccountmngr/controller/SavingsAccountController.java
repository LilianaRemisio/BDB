package co.com.bancodebogota.savingsaccountmngr.controller;

import co.com.bancodebogota.annotations.DisableAuthToken;
import co.com.bancodebogota.db.savings.dto.jpa.AccountLimitsDto;
import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.db.savings.dto.jpa.CheckTypeLogListDto;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountResponseDto;
import co.com.bancodebogota.dto.monitorplus.MonitorAccountCreateDto;
import co.com.bancodebogota.dto.pentagon.EventDataDto;
import co.com.bancodebogota.dto.products.AccountHierarchyReqDto;
import co.com.bancodebogota.dto.request.RequestCheckDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.proxy.CheckLogsProxy;
import co.com.bancodebogota.savingsaccountmngr.service.accounts.ISavingsAccountService;
import co.com.bancodebogota.savingsaccountmngr.service.monitorplus.IMonitorService;
import co.com.bancodebogota.savingsaccountmngr.service.pentagon.IEventPentagonService;
import co.com.bancodebogota.savingsaccountmngr.service.request.ICheckLogService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.CompletableFuture;

@RestController
@RequiredArgsConstructor
@RequestMapping("savings")
public class SavingsAccountController {

    private final ISavingsAccountService savingsAccountService;
    private final CheckLogsProxy checkLogsProxy;
    private final IMonitorService monitorService;
    private final ICheckLogService checkLogService;
    private final IEventPentagonService eventPentagonService;

    @PostMapping("/account/create")
    public ResponseEntity<JsonNode> createAccountByUuid(@RequestHeader HttpHeaders httpHeaders,
                                                        @RequestBody JsonNode data) throws AbsBdbServiceException {
        return savingsAccountService.createAccountByUuid(data, httpHeaders);
    }

    @PostMapping("/account/create/v2")
    public ResponseEntity<CreateAccountResponseDto> createAccountByDto(@RequestHeader HttpHeaders httpHeaders,
                                                                       @RequestBody BankAccountDto bankAccountDto) throws AbsBdbServiceException {
        return savingsAccountService.createAccountByDto(bankAccountDto, httpHeaders);
    }

    @PostMapping("/account/limit")
    public void updateAccountLimitAsync(@RequestBody AccountLimitsDto accountLimitsDto) {
        CompletableFuture.runAsync(() -> savingsAccountService.updateAccountLimit(accountLimitsDto));
    }

    @PostMapping("/account/monitor-plus")
    public void sendAccountToMonitorPlusAsync(@RequestHeader HttpHeaders httpHeaders,
                                              @RequestBody MonitorAccountCreateDto monitorAccountCreateDto) {

        CompletableFuture.runAsync(() -> monitorService.sendAccountToMonitorPlus(httpHeaders, monitorAccountCreateDto));
    }

    @DisableAuthToken
    @PostMapping("/check-type-log")
    public boolean saveCheckTypeLog(@RequestBody CheckTypeLogListDto checkTypeDto) {
        return checkLogsProxy.saveCheckType(checkTypeDto);
    }

    @PostMapping("/request-check")
    public ResponseEntity<Boolean> saveCheck(@RequestBody RequestCheckDto requestCheck) {

        boolean result = checkLogService.saveRequestCheckLog(requestCheck);
        return new ResponseEntity<>(result, result ? HttpStatus.OK : HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @GetMapping("/account/list-by-card")
    public ResponseEntity<JsonNode> getAccountsByCard(@RequestHeader HttpHeaders httpHeaders,
                                                      @RequestParam("numberCard") String cardNumber) throws AbsBdbServiceException {

        JsonNode response = savingsAccountService.getAccountsByCard(httpHeaders, cardNumber);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/account/hierarchy")
    public ResponseEntity<JsonNode> setAccountHierarchy(@RequestHeader HttpHeaders httpHeaders,
                                                        @RequestBody AccountHierarchyReqDto accountHierarchyReqDto)
            throws AbsBdbServiceException, JsonProcessingException {

        return savingsAccountService.setAccountHierarchy(accountHierarchyReqDto, httpHeaders);
    }

    @PostMapping("/participant/save")
    public ResponseEntity<String> saveParticipantInfo(@RequestBody BankAccountDto bankAccountDto,
                                                      @RequestHeader HttpHeaders httpHeaders)
            throws AbsBdbServiceException {

        return savingsAccountService.saveParticipantInfo(bankAccountDto, httpHeaders);
    }

    @GetMapping("/account/payload")
    public ResponseEntity<JsonNode> getPayloadInfo(@RequestParam("identityNumber") String identityNumber,
                                                   @RequestHeader("X-AuthUuid") String authUuid) throws AbsBdbServiceException {
        return savingsAccountService.getPayloadInfo(identityNumber, authUuid);
    }

    @PostMapping("account/redis-session")
    public ResponseEntity<JsonNode> saveSessionRedis(@RequestHeader HttpHeaders httpHeaders,
                                                     @RequestBody JsonNode sessionRedis)
            throws AbsBdbServiceException {

        return savingsAccountService.saveSessionRedis(sessionRedis, httpHeaders);
    }

    @GetMapping("/account/redis-session")
    public ResponseEntity<JsonNode> getSessionRedis(@RequestParam("identityNumber") String identityNumber,
                                                    @RequestHeader("X-AuthUuid") String authUuid) throws AbsBdbServiceException {

        return savingsAccountService.getSessionRedis(identityNumber, authUuid);
    }

    @DisableAuthToken
    @GetMapping("/account/limits")
    public ResponseEntity<JsonNode> getAccountLimits() throws AbsBdbServiceException {

        return savingsAccountService.getAccountLimits();
    }

    @DisableAuthToken
    @PostMapping("/account/pentagon")
    public ResponseEntity<Boolean> sendPentagonEvent(@RequestHeader HttpHeaders httpHeaders,
                                                     @RequestBody EventDataDto eventDataDto) {

        boolean result = eventPentagonService.sendEvent(httpHeaders, eventDataDto);
        return new ResponseEntity<>(result, result ? HttpStatus.OK : HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @DisableAuthToken
    @PostMapping("/account/save-model")
    public void saveModel(@RequestBody List<List<String>> request) {
        CompletableFuture.runAsync(() -> savingsAccountService.saveModel(request));
    }
}
