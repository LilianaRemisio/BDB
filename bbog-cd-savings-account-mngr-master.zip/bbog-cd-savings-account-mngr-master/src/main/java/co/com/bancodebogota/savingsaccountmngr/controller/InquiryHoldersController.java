package co.com.bancodebogota.savingsaccountmngr.controller;

import co.com.bancodebogota.dto.products.LimitsAccountRq;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.savingsaccountmngr.service.inquiryholders.IInquiryHolders;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("inquiry-holders")
@RequiredArgsConstructor
public class InquiryHoldersController {

    private final IInquiryHolders inquiryHolders;

    @PostMapping("/ownership")
    public ResponseEntity<String> getOwnership(@RequestBody LimitsAccountRq accountInfo, @RequestHeader("X-RqUID") String rqUID) throws AbsBdbServiceException {
        String ownership = inquiryHolders.getOwnership(accountInfo, rqUID);

        return new ResponseEntity<>(ownership, ownership == null ? org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR : org.springframework.http.HttpStatus.OK);
    }
}
