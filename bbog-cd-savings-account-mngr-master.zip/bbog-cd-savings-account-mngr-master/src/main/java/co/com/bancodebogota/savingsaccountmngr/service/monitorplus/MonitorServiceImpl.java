package co.com.bancodebogota.savingsaccountmngr.service.monitorplus;

import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.dto.monitorplus.AccountOpenTramaBMonitorImpl;
import co.com.bancodebogota.dto.monitorplus.DirectMQRequest;
import co.com.bancodebogota.dto.monitorplus.MonitorAccountCreateDto;
import co.com.bancodebogota.enums.EChannel;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.tramautilities.mapper.BeanMapperToTramaImpl;
import co.com.bancodebogota.utils.TimeUtilities;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.nio.ByteBuffer;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class MonitorServiceImpl implements IMonitorService {

    @Value("${security.monitoring.api.endpoint}")
    private String securityMonitoringApiEndpoint;
    @Value("${tvs.api.key}")
    private String tvsApiKey;

    private final RestExchangeV2 restExchange;

    private static final String YYYY_MM_MDD = "yyyyMMdd";

    private static final String SECURITY_MONITORING_RESOURCE = "/V2/Enterprise/MonitorPlus/sendMessage";

    @Override
    public void sendAccountCreate(BankAccountDto bankAccountDto, String accountNumber, String xForwardedFor, String rqUid) throws AbsBdbServiceException {

        try {
            String userIp = StringUtils.defaultIfEmpty(xForwardedFor, "").split(",")[0];

            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.add("X-CustIdentType", "CC");
            httpHeaders.add("X-CustIdentNum", bankAccountDto.getIdentityNumber());
            httpHeaders.add("X-IPAddr", userIp);
            httpHeaders.add("X-RqUID", rqUid);
            httpHeaders.add("X-Channel", EChannel.getWithoutSpace(bankAccountDto.getChannel()));
            httpHeaders.add("X-Name", "CuentaDeAhorros");
            httpHeaders.add("X-Api-Key", tvsApiKey);

            AccountOpenTramaBMonitorImpl tramaObject = setData(bankAccountDto, accountNumber, userIp);

            String trama = BeanMapperToTramaImpl.mapper(tramaObject, true);
            DirectMQRequest directMQRequest = new DirectMQRequest(trama, "DIRECT");

            UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromUriString(securityMonitoringApiEndpoint)
                    .path(SECURITY_MONITORING_RESOURCE);

            restExchange.exchange(urlBuilder.toUriString(), directMQRequest, HttpMethod.POST, httpHeaders, String.class);

        } catch (Exception e) {
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR,
                    bankAccountDto.getIdentityNumber(), "Error generando trama: " + e.getMessage());
        }
    }

    @Override
    public boolean sendAccountToMonitorPlus(HttpHeaders httpHeaders, MonitorAccountCreateDto monitorAccountCreateDto) {

        String identityNumber = monitorAccountCreateDto.getIdentityNumber();
        log.info(">>> ({}) SEND ACCOUNT TO MONITOR PLUS. NEW CALL >>>", identityNumber);

        String accountNumber = monitorAccountCreateDto.getAccountNumber();

        BankAccountDto bankAccountDto = new BankAccountDto();
        bankAccountDto.setIdentityNumber(monitorAccountCreateDto.getIdentityNumber());
        bankAccountDto.setChannel(monitorAccountCreateDto.getChannel());
        bankAccountDto.setChannelToMonitor(monitorAccountCreateDto.getChannel());
        bankAccountDto.setEmail(monitorAccountCreateDto.getEmail());
        bankAccountDto.setFirstName(monitorAccountCreateDto.getFirstName());
        bankAccountDto.setMiddleName(monitorAccountCreateDto.getMiddleName());
        bankAccountDto.setLastName(monitorAccountCreateDto.getLastName());
        bankAccountDto.setSecondLastName(monitorAccountCreateDto.getSecondLastName());
        bankAccountDto.setGender(monitorAccountCreateDto.getGender());
        bankAccountDto.setCellphone(monitorAccountCreateDto.getCellphone());
        bankAccountDto.setOfficeCode(monitorAccountCreateDto.getOfficeCode());
        bankAccountDto.setCodNomina(monitorAccountCreateDto.getPayrollCode());
        bankAccountDto.setUserAgent(httpHeaders.getFirst("User-Agent"));
        bankAccountDto.setTxInWeb(monitorAccountCreateDto.isTxInWeb());
        bankAccountDto.setSellerId(monitorAccountCreateDto.getSellerId());

        try {
            sendAccountCreate(bankAccountDto, accountNumber, httpHeaders.getFirst("X-FORWARDED-FOR"),
                    StringUtils.defaultIfEmpty(httpHeaders.getFirst("X-RqUID"), httpHeaders.getFirst("X-AuthUuid")));

            log.info("<<< ({}) SEND ACCOUNT TO MONITOR PLUS. SUCCESSFUL END <<<", identityNumber);
            return true;
        } catch (Exception e) {
            log.error("({}) Error sending account to monitor plus: {}", identityNumber, e.getMessage());
            return false;
        }
    }

    private AccountOpenTramaBMonitorImpl setData(BankAccountDto bankAccountDto, String accountNumber, String userIp) {

        AccountOpenTramaBMonitorImpl trama = new AccountOpenTramaBMonitorImpl();

        trama.setVWJEFECHAD(TimeUtilities.getCurrentDateInFormat("dd"));
        trama.setVWJEFECHAM(TimeUtilities.getCurrentDateInFormat("MM"));
        trama.setVWJEFECHAA(TimeUtilities.getCurrentDateInFormat("yyyy"));
        trama.setVWJEHORA(TimeUtilities.getCurrentDateInFormat("HH"));
        trama.setSISTEMINUTE(TimeUtilities.getCurrentDateInFormat("mm"));
        trama.setVWJEUSER((bankAccountDto.isTxInWeb()) ? AccountOpenTramaBMonitorImpl.OrigenTransaccion.AUTOGESWEB : AccountOpenTramaBMonitorImpl.OrigenTransaccion.MODOFICINA);

        tramaCliente(bankAccountDto, trama);
        tramaCuenta(bankAccountDto.getOfficeCode(), accountNumber, trama);
        trama.setCUENTA_REGISTRADA_INTERNET(defineChannel(bankAccountDto.getChannelToMonitor()));
        trama.setCANAL((bankAccountDto.isTxInWeb()) ? AccountOpenTramaBMonitorImpl.Canal.IT : AccountOpenTramaBMonitorImpl.Canal.BCO);
        trama.setDIRECCION_IP(userIp);
        trama.setCODIGO_BROWSER(getBrowser(bankAccountDto.getUserAgent()));
        trama.setRELEASE_BROWSER("00");
        trama.setSECUENCIA_TRX(shortUUID());
		/*
		Trama Step 1: accountNumber:492488507 ipForwarder:200.124.125.195, 10.88.4.20, 10.88.4.118 userAgent:Mozilla/5.0 
		(Macintosh; Intel Mac OS X 10_12_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.113 Safari/537.36
		*/

        trama.setVERSION_BROWSER("00000");
        trama.setSISTEMA_OPERATIVO(getOperatingSystem(bankAccountDto.getUserAgent()));
        trama.setUSUARIO_TRANSACCION(" ");
        trama.setCOD_NOMINA((bankAccountDto.getCodNomina() != null) ? bankAccountDto.getCodNomina() : "   ");

        return trama;
    }

    private String defineChannel(String channelToMonitor) {

        return switch (channelToMonitor.toUpperCase()) {
            case "1", "5", "OFICINA", "MFZ" -> AccountOpenTramaBMonitorImpl.Canal.OFFICE.getCanal();
            case "4", "FMV" -> AccountOpenTramaBMonitorImpl.Canal.FUERZA_MOVIL.getCanal();
            default -> AccountOpenTramaBMonitorImpl.Canal.IT.getCanal();
        };
    }


    private void tramaCliente(BankAccountDto bankAccountDto, AccountOpenTramaBMonitorImpl trama) {
        trama.setACTIVIDAD_ECONOMICA((bankAccountDto.getOccupationId() != null) ? bankAccountDto.getOccupationId().toString() : " ");
        trama.setCIUDAD_PRINCIPAL((bankAccountDto.getLivingCityId() != null) ? bankAccountDto.getLivingCityId() : "");
        trama.setCORREO_ELECTRONICO(bankAccountDto.getEmail());
        trama.setESTADO_CIVIL(AccountOpenTramaBMonitorImpl.EstadoCivil.CASADO);
        trama.setFECHA_VINCULACION_CLIENTE(TimeUtilities.getCurrentDateInFormat(YYYY_MM_MDD));
        trama.setID_EMPLEADO((bankAccountDto.getSellerId() != null) ? bankAccountDto.getSellerId() : " ");
        String bornCity = String.valueOf(bankAccountDto.getBornCityId());
        trama.setLUGAR_NACIMIENTO((Integer.valueOf(bornCity) != null) ? bornCity : "-");
        trama.setNOMBRE_CLIENTE(bankAccountDto.getFirstName() + " " + ((bankAccountDto.getMiddleName() != null) ? bankAccountDto.getMiddleName() : " ") + " " + bankAccountDto.getLastName()
                + " " + ((bankAccountDto.getSecondLastName() != null) ? bankAccountDto.getSecondLastName() : " "));
        trama.setGENERO(((bankAccountDto.getGender() != null && bankAccountDto.getGender().equals("M")) ? AccountOpenTramaBMonitorImpl.Genero.MASCULINO : AccountOpenTramaBMonitorImpl.Genero.FEMENINO));
        trama.setTELEFONO_CELULAR(bankAccountDto.getCellphone() != null ? bankAccountDto.getCellphone() : "00");
        tramaIdentificacion(bankAccountDto.getIdentityNumber(), trama);
        trama.setCODIGO_CLIENTE(trama.getTIPO_IDENTIFICACION() != null ? trama.getTIPO_IDENTIFICACION() + trama.getNUMERO_IDENTIFICACION() : " ");
    }

    private void tramaIdentificacion(String identityNumber, AccountOpenTramaBMonitorImpl trama) {
        trama.setTIPO_IDENTIFICACION(AccountOpenTramaBMonitorImpl.TipoIdentificacion.CEDULA);
        trama.setNUMERO_IDENTIFICACION(identityNumber);
    }

    private void tramaCuenta(String officeCode, String accountNumber, AccountOpenTramaBMonitorImpl trama) {
        trama.setFECHA_APERTURA_CUENTA(TimeUtilities.getCurrentDateInFormat(YYYY_MM_MDD));
        trama.setNUMERO_CUENTA(accountNumber);
        trama.setTIPO_PRODUCTO("AHS");
        trama.setFECHA_HORA_AUT_TRX(TimeUtilities.getCurrentDateInFormat("yyyyMMddHHmmss"));
        trama.setFECHA_TRX(TimeUtilities.getCurrentDateInFormat(YYYY_MM_MDD));
        trama.setHORA_TRX(TimeUtilities.getCurrentDateInFormat("HHmmss"));
        trama.setCOD_OFICINA(officeCode);
    }

    private String shortUUID() {
        UUID uuid = UUID.randomUUID();
        long l = ByteBuffer.wrap(uuid.toString().getBytes()).getLong();
        String shortUuid = Long.toString(l, Character.MAX_RADIX);

        if (shortUuid.length() >= 15)
            shortUuid = shortUuid.substring(0, 15);
        return shortUuid;
    }

    private String getOperatingSystem(String userAgent) {
        String os;
        if (userAgent.toLowerCase().contains("windows")) {
            os = "Windows";
        } else if (userAgent.toLowerCase().contains("mac")) {
            os = "Mac";
        } else if (userAgent.toLowerCase().contains("x11")) {
            os = "Unix";
        } else if (userAgent.toLowerCase().contains("android")) {
            os = "Android";
        } else if (userAgent.toLowerCase().contains("iphone")) {
            os = "IPhone";
        } else {
            os = "UnKnown, More-Info: " + userAgent;
        }
        return os;
    }

    private String getBrowser(String userAgent) {
        String user = userAgent.toLowerCase();
        String browser = "";

        if (user.contains("msie")) {
            String substring = userAgent.substring(userAgent.indexOf("MSIE")).split(";")[0];
            browser = substring.split(" ")[0].replace("MSIE", "IE") + "-" + substring.split(" ")[1];
        } else if (user.contains("safari") && user.contains("version")) {
            browser = (userAgent.substring(userAgent.indexOf("Safari")).split(" ")[0]).split("/")[0] + "-" + (userAgent.substring(userAgent.indexOf("Version")).split(" ")[0]).split("/")[1];
        } else if (user.contains("opr") || user.contains("opera")) {
            if (user.contains("opera"))
                browser = (userAgent.substring(userAgent.indexOf("Opera")).split(" ")[0]).split("/")[0] + "-" + (userAgent.substring(userAgent.indexOf("Version")).split(" ")[0]).split("/")[1];
            else if (user.contains("opr"))
                browser = ((userAgent.substring(userAgent.indexOf("OPR")).split(" ")[0]).replace("/", "-")).replace("OPR", "Opera");
        } else if (user.contains("chrome")) {
            browser = (userAgent.substring(userAgent.indexOf("Chrome")).split(" ")[0]).replace("/", "-");
        } else if ((user.contains("mozilla/7.0")) || (user.contains("netscape6")) || (user.contains("mozilla/4.7")) || (user.contains("mozilla/4.78")) || (user.contains("mozilla/4.08")) || (user.contains("mozilla/3"))) {
            browser = "Netscape-?";
        } else if (user.contains("firefox")) {
            browser = (userAgent.substring(userAgent.indexOf("Firefox")).split(" ")[0]).replace("/", "-");
        } else if (user.contains("rv")) {
            browser = "IE-" + user.substring(user.indexOf("rv") + 3, user.indexOf(')'));
        } else {
            browser = "UnKnown, More-Info: " + userAgent;
        }
        return browser;
    }

}
