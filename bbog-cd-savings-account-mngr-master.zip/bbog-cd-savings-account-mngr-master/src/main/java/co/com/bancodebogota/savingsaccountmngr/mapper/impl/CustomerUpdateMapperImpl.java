package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.savingsaccountmngr.mapper.CustomerUpdateMapper;
import co.com.bancodebogota.savingsaccountmngr.mapper.IPojoMapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerUpdateMapperImpl implements CustomerUpdateMapper {

    private final IPojoMapper custInfoPojoMapper;

    @Override
    public ObjectNode mapCreateCustomerRequestByCreate(BankAccountDto bankAccountDto, String authUuid) throws AbsBdbServiceException {
        log.info(">>> ({}) MAP CUSTOMER REQUEST. NEW CALL >>>", bankAccountDto.getIdentityNumber());
        ObjectNode jsonRequest = mapCustomerUpdateRequestOpenApi(bankAccountDto, authUuid);
        log.info("<<< ({}) MAP CUSTOMER REQUEST. SUCCESSFUL END <<<", bankAccountDto.getIdentityNumber());
        return jsonRequest;
    }

    private ObjectNode mapCustomerUpdateRequestOpenApi(BankAccountDto bankAccountDto, String authUuid) throws AbsBdbServiceException {
        log.info(">>> ({}) MAP UPDATE CUSTOMER OPEN API. NEW CALL >>>", bankAccountDto.getIdentityNumber());
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectNode jsonRequest = objectMapper.createObjectNode();

        ObjectNode jsonCustomerCreateReq = objectMapper.createObjectNode();
        jsonCustomerCreateReq.putPOJO("CustInfo", custInfoPojoMapper.mapCustInfoPojo(bankAccountDto, authUuid));
        jsonCustomerCreateReq.put("UpdSafeInfo", bankAccountDto.getProductId().equals("068AH") || !bankAccountDto.isCustomOtpAuth());

        jsonRequest.putPOJO("customerUpdateReq", jsonCustomerCreateReq);

        log.info("<<< ({}) MAP UPDATE CUSTOMER OPEN API. SUCCESSFUL END <<<", bankAccountDto.getIdentityNumber());
        return jsonRequest;
    }
}
