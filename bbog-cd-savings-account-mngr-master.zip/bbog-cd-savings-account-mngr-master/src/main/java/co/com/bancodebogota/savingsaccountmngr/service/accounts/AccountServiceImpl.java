package co.com.bancodebogota.savingsaccountmngr.service.accounts;

import co.com.bancodebogota.db.savings.dto.jpa.AccountLimitsDto;
import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountDto;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountResponseDto;
import co.com.bancodebogota.dto.account.AccountData;
import co.com.bancodebogota.dto.account.OpeningAccountDto;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.fatca.FatcaDto;
import co.com.bancodebogota.dto.gmf.GmfDto;
import co.com.bancodebogota.dto.monitorplus.MonitorAccountCreateDto;
import co.com.bancodebogota.dto.pentagon.EventDataDto;
import co.com.bancodebogota.dto.pentagon.EventIdentityDto;
import co.com.bancodebogota.enums.EAccount;
import co.com.bancodebogota.enums.EChannel;
import co.com.bancodebogota.enums.EClientType;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.model.entities.FatcaEntity;
import co.com.bancodebogota.proxy.AccountLogProxy;
import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.savingsaccountmngr.mapper.IAccountMapper;
import co.com.bancodebogota.savingsaccountmngr.service.condonation.ICondonationService;
import co.com.bancodebogota.savingsaccountmngr.service.customer.ICustomerServiceV2;
import co.com.bancodebogota.savingsaccountmngr.service.facebookconvertions.IReportMarketingService;
import co.com.bancodebogota.savingsaccountmngr.service.fatca.IFatcaService;
import co.com.bancodebogota.savingsaccountmngr.service.monitorplus.IMonitorService;
import co.com.bancodebogota.savingsaccountmngr.utils.HolidayUtility;
import co.com.bancodebogota.service.pentagon.IPentagonService;
import co.com.bancodebogota.service.redis.IRedisApiService;
import co.com.bancodebogota.utils.DataUtilities;
import co.com.bancodebogota.utils.JacksonUtilsV2;
import co.com.bancodebogota.utils.Utilities;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Service
@RequiredArgsConstructor
public class AccountServiceImpl implements IAccountService {

    @Value("${endpoint.accounts.adapter}")
    private String endpointAccountsAdapter;

    private final ISavingsAccountService savingsAccountService;
    private final RestExchangeV2 restExchange;
    private final IAccountMapper accountMapper;
    private final IPentagonService pentagonService;
    private final IMonitorService monitorService;
    private final IFatcaService fatcaService;
    private final IGMFService gmfService;
    private final AccountLogProxy accountLogProxy;
    private final ICustomerServiceV2 customerServiceV2;
    private final ICondonationService condonationService;
    private final IRedisApiService redisApiService;
    private final IReportMarketingService facebookConversions;
    private static final String CREATE_RESOURCE = "/createSavingAccount";
    private static final String CREATE_BUS_RESOURCE = "/account";
    private static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";
    private static final String X_AUTH_UUID = "X-AuthUuid";
    private static final String DISPATCHER_KEY = "DispatcherKey";
    private static final String X_JOURNEY = "X-Journey";
    private static final String X_NAME = "X-Name";
    private static final String X_SEND_EMAIL_NOTIFICATION = "X-SendEmailNotification";

    @Override
    public CreateAccountResponseDto accountOpening(HttpHeaders httpHeaders, AccountData accountData)
            throws AbsBdbServiceException {

        String authUuid = httpHeaders.getFirst(X_AUTH_UUID);
        DispatcherDto dispatcherDto = redisApiService
                .getHash("CC", authUuid, DISPATCHER_KEY, authUuid, DispatcherDto.class);

        return accountOpening(httpHeaders, accountData, dispatcherDto);
    }

    @Override
    public CreateAccountResponseDto accountOpening(HttpHeaders httpHeaders, AccountData accountData,
                                                   DispatcherDto dispatcherDto) throws AbsBdbServiceException {

        String identityType = dispatcherDto.getIdentityType();
        String identityNumber = dispatcherDto.getIdentityNumber();

        log.info(">>> ({}) ACCOUNT OPENING. NEW CALL >>>", identityNumber);

        String authUuid = httpHeaders.getFirst(X_AUTH_UUID);

        OpeningAccountDto openingAccountDto = accountData.getOpeningAccount();

        openingAccountDto.setRqUid(authUuid);
        openingAccountDto.setIdentityType(identityType);
        openingAccountDto.setIdentityNumber(identityNumber);
        openingAccountDto.setAcctType(EAccount.getTypeByCode(openingAccountDto.getAcctSubType()));
        openingAccountDto.setHoliday(this.isHoliday());

        log.info("({}) accountData: {}", identityNumber, JacksonUtilsV2.getPlainJson(accountData));

        String resourcePath;
        Object requestBody;

        if (EAccount.isDDA(openingAccountDto.getAcctSubType())) {
            resourcePath = CREATE_BUS_RESOURCE;
            requestBody = openingAccountDto;
        } else {
            resourcePath = CREATE_RESOURCE;
            requestBody = accountMapper.mapOpeningAccountDto(openingAccountDto,
                    identityNumber, identityType, authUuid, dispatcherDto.getChannel());
        }

        UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromUriString(endpointAccountsAdapter)
                .path(resourcePath);

        ResponseEntity<CreateAccountResponseDto> response = restExchange
                .exchange(urlBuilder.toUriString(), requestBody, HttpMethod.POST, CreateAccountResponseDto.class);

        CreateAccountResponseDto responseBody = response.getBody();
        if (response.getStatusCode().isError() || responseBody == null) {

            ObjectNode pentagonBody = buildPentagonBody(new ObjectMapper().valueToTree(response),
                    null, null, null,
                    null, null, null);
            CompletableFuture.runAsync(() -> sendProductCreationEvent(openingAccountDto, dispatcherDto, httpHeaders, pentagonBody));

            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, identityNumber, "Error accountOpeningAdd");
        }

        CompletableFuture.runAsync(() ->
                postCreationFunctions(httpHeaders, accountData, dispatcherDto, openingAccountDto, responseBody));

        log.info("<<< ({}) ACCOUNT OPENING. SUCCESSFUL END <<<", identityNumber);
        return responseBody;
    }

    @Override
    public CreateAccountResponseDto accountOpeningV4(HttpHeaders httpHeaders, AccountData accountData, DispatcherDto dispatcherDto) throws AbsBdbServiceException {
        String authUuid = httpHeaders.getFirst(X_AUTH_UUID);

        DispatcherDto finalDispatcherDto = dispatcherDto != null ? dispatcherDto : redisApiService.getHash("CC", authUuid, DISPATCHER_KEY, authUuid, DispatcherDto.class);
        String identityType = finalDispatcherDto.getIdentityType();
        String identityNumber = finalDispatcherDto.getIdentityNumber();

        log.info(">>> ({}) ACCOUNT OPENING V4. NEW CALL >>>", identityNumber);

        OpeningAccountDto openingAccountDto = accountData.getOpeningAccount();

        openingAccountDto.setRqUid(authUuid);
        openingAccountDto.setIdentityType(identityType);
        openingAccountDto.setIdentityNumber(identityNumber);
        openingAccountDto.setAcctType(EAccount.getTypeByCode(openingAccountDto.getAcctSubType()));
        openingAccountDto.setHoliday(this.isHoliday());

        String ceoCode = StringUtils.defaultIfEmpty(openingAccountDto.getCeoCode(), "0000");
        openingAccountDto.setCeoCode(ceoCode.substring(0, 4));

        log.info("({}) accountDataV4: {}", identityNumber, JacksonUtilsV2.getPlainJson(accountData));

        String resourcePathV4;
        Object requestBodyV4;

        resourcePathV4 = CREATE_BUS_RESOURCE;
        UriComponentsBuilder urlBuilderEndpoint = UriComponentsBuilder.fromUriString(endpointAccountsAdapter).path(resourcePathV4);
        requestBodyV4 = openingAccountDto;

        ResponseEntity<CreateAccountResponseDto> responseV4 = restExchange
                .exchange(urlBuilderEndpoint.toUriString(), requestBodyV4, HttpMethod.POST, CreateAccountResponseDto.class);

        CreateAccountResponseDto responseBodyV4 = responseV4.getBody();

        if (responseV4.getStatusCode().isError() || responseBodyV4 == null) {

            ObjectNode pentagonBody = buildPentagonBody(new ObjectMapper().valueToTree(responseV4),
                    null, null, null,
                    null, null, null);
            CompletableFuture.runAsync(() -> sendProductCreationEvent(openingAccountDto, finalDispatcherDto, httpHeaders, pentagonBody));

            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, identityNumber, "Error accountOpeningAdd");
        }

        CompletableFuture.runAsync(() ->
                postCreationFunctions(httpHeaders, accountData, finalDispatcherDto, openingAccountDto, responseBodyV4));

        log.info("<<< ({}) ACCOUNT OPENING_V4. SUCCESSFUL END <<<", identityNumber);
        return responseBodyV4;
    }

    private boolean isHoliday() {
        HolidayUtility holidayUtilityCurrent = new HolidayUtility();
        return holidayUtilityCurrent.getHolidays().contains(LocalDateTime.now().toString());
    }

    private void postCreationFunctions(HttpHeaders httpHeaders, AccountData accountData, DispatcherDto dispatcherDto,
                                       OpeningAccountDto openingAccountDto, CreateAccountResponseDto createAccountResponseDto) {

        String identityType = dispatcherDto.getIdentityType();
        String identityNumber = dispatcherDto.getIdentityNumber();
        String accountNumber = createAccountResponseDto.getAccountNumber();
        String clientName = Utilities.getFullName(openingAccountDto.getFirstName(), openingAccountDto.getSecondName(),
                openingAccountDto.getFirstLastName(), openingAccountDto.getSecondLastName());
        Boolean isEmailNotification = Boolean.parseBoolean(StringUtils.defaultIfEmpty(httpHeaders.getFirst(X_SEND_EMAIL_NOTIFICATION), "true"));

        saveInDB(accountData, dispatcherDto, createAccountResponseDto, openingAccountDto.getInputCeo());

        CompletableFuture.runAsync(() -> customerServiceV2.sendNotificationForCreatedAccount(identityNumber,
                httpHeaders.getFirst(X_AUTH_UUID), isEmailNotification, accountNumber, openingAccountDto, clientName, dispatcherDto.getChannel()));

        CompletableFuture<Boolean> updateAccountLimitsAsync = CompletableFuture.supplyAsync(() ->
                updateAccountLimits(identityType, identityNumber, accountNumber, openingAccountDto.getAcctType())
        );

        CompletableFuture<Boolean> monitorPlusAsync = CompletableFuture.supplyAsync(() ->
                sendAccountToMonitorPlus(openingAccountDto, httpHeaders, accountNumber, dispatcherDto.getChannel())
        );

        CompletableFuture<Boolean> sendFatcaAsync = CompletableFuture.supplyAsync(() ->
                sendFatca(accountData.getFatca(), identityType, identityNumber, clientName, openingAccountDto.getOfficeCode())
        );

        CompletableFuture<Boolean> sendGmfAsync = CompletableFuture.supplyAsync(() ->
                sendGmf(identityType, identityNumber, accountNumber, clientName, accountData.getGmf(),
                        openingAccountDto.getOfficeCode(), openingAccountDto.getAcctType())
        );

        CompletableFuture<Boolean> condonateDebts = CompletableFuture.supplyAsync(() ->
                requestForgivenDebts(identityType, identityNumber, openingAccountDto, dispatcherDto,
                        httpHeaders.getFirst(X_FORWARDED_FOR), httpHeaders.getFirst(X_AUTH_UUID))
        );

        CompletableFuture<Boolean> facebookConvertion = CompletableFuture.supplyAsync(() ->
                saveFacebookConvertions(accountData, dispatcherDto, httpHeaders)
        );

        try {
            CompletableFuture.allOf(monitorPlusAsync, updateAccountLimitsAsync, sendFatcaAsync, sendGmfAsync, condonateDebts, facebookConvertion).get();

            ObjectNode pentagonBody = buildPentagonBody(new ObjectMapper().valueToTree(createAccountResponseDto), updateAccountLimitsAsync.get(),
                    monitorPlusAsync.get(), sendFatcaAsync.get(), sendGmfAsync.get(), condonateDebts.get(), facebookConvertion.get());

            sendProductCreationEvent(openingAccountDto, dispatcherDto, httpHeaders, pentagonBody);
        } catch (Exception e) {
            log.error("({}) Error call parallel services: {}", identityNumber, e.getMessage());
            Thread.currentThread().interrupt();
        }
    }

    private ObjectNode buildPentagonBody(ObjectNode response, Boolean accountLimitsIsSuccessful,
                                         Boolean monitorPlusIsSuccessful, Boolean fatcaIsSuccessful, Boolean gmfIsSuccessful,
                                         Boolean condonation, Boolean facebookConvertion) {

        ObjectNode body = JsonNodeFactory.instance.objectNode();
        body.set("createAccount", response);
        body.put("accountLimits", accountLimitsIsSuccessful);
        body.put("monitorPlus", monitorPlusIsSuccessful);
        body.put("fatca", fatcaIsSuccessful);
        body.put("gmf", gmfIsSuccessful);
        body.put("condonation", condonation);
        body.put("facebookConvertion", facebookConvertion);

        return body;
    }

    private void sendProductCreationEvent(OpeningAccountDto openingAccountDto, DispatcherDto dispatcherDto,
                                          HttpHeaders httpHeaders, ObjectNode body) {

        String journey = "FlujoWeb";
        if (!EChannel.findByDescription(dispatcherDto.getChannel()).isWeb()) {
            journey = "FlujoAsistido";
        }

        EventDataDto eventDataDto = new EventDataDto();
        eventDataDto.setEventName("Event-CuentaDeAhorros-%s-Contrato-CreacionDelProducto".formatted(journey));
        eventDataDto.setMilestone("Contrato");
        eventDataDto.setStep("CreacionDelProducto");
        eventDataDto.setDigRequest(httpHeaders.getFirst("X-DigRequest"));
        eventDataDto.setFront(false);
        eventDataDto.setIsClient(EClientType.valueOf(dispatcherDto.getCustomerState()).getApiName());
        eventDataDto.setJourney(StringUtils.defaultIfEmpty(httpHeaders.getFirst(X_JOURNEY), journey));

        body.put("sourceTeam",
                StringUtils.defaultIfEmpty(httpHeaders.getFirst(X_NAME), "CuentaDeAhorros"));
        eventDataDto.setPayload(JacksonUtilsV2.getPlainJson(body));

        EventIdentityDto eventIdentityDto = new EventIdentityDto();
        eventIdentityDto.setIdentityType(openingAccountDto.getIdentityType());
        eventIdentityDto.setIdentityNumber(openingAccountDto.getIdentityNumber());
        eventIdentityDto.setRqUuid(dispatcherDto.getSpecificProductInfoUuid());
        eventIdentityDto.setChannel(dispatcherDto.getChannel());
        eventIdentityDto.setUserIp(httpHeaders.getFirst(X_FORWARDED_FOR));
        eventIdentityDto.setAccessToken(dispatcherDto.getAccessToken());

        if ("AE_SolucionesDigitales".equalsIgnoreCase(DataUtilities.getNodeAsText(dispatcherDto.getUtmInfo(), "utm_campaign"))) {
            eventIdentityDto.setMedium(DataUtilities.getNodeAsText(dispatcherDto.getUtmInfo(), "utm_medium"));
            eventIdentityDto.setSourceChannel(DataUtilities.getNodeAsText(dispatcherDto.getUtmInfo(), "utm_source"));
        }

        pentagonService.publish(eventDataDto, eventIdentityDto);
    }

    private void saveInDB(AccountData accountData, DispatcherDto dispatcherDto, CreateAccountResponseDto createAccountResponseDto, String inputCeo) {

        saveAccountLog(accountData, dispatcherDto, createAccountResponseDto.getAccountNumber(), inputCeo);

        CompletableFuture.runAsync(() -> {
            try {
                BankAccountDto bankAccountDto = accountMapper.mapBankAccountForDB(accountData, dispatcherDto);
                savingsAccountService.saveNewModel(bankAccountDto, createAccountResponseDto);
            } catch (Exception e) {
                log.error("({}) Error saving sarlaft data in DB: {}", dispatcherDto.getIdentityNumber(), e.toString());
            }
        });
    }

    private void saveAccountLog(AccountData accountData, DispatcherDto dispatcherDto, String accountNumber, String inputCeo) {
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setProductid(accountData.getOpeningAccount().getAcctSubType());
        createAccountDto.setNewClient("NOT_CLIENT".equals(dispatcherDto.getCustomerState()));
        createAccountDto.setBbcodofi(accountData.getOpeningAccount().getOfficeCode());
        createAccountDto.setTxInOffice(!EChannel.isTxInWeb(dispatcherDto.getChannel()));
        createAccountDto.setNewCard(accountData.isClientWithDebitCards() ? 0 : 1);
        createAccountDto.setGmf(accountData.getGmf().isCheckGmf() ? 1 : 0);
        createAccountDto.setPostalAddress(accountData.getPostalAddress());

        accountLogProxy.saveAccountLog(createAccountDto, accountNumber, dispatcherDto.getChannel(), inputCeo);
    }

    private Boolean sendGmf(String identityType, String identityNumber, String accountNumber, String clientName,
                            GmfDto gmf, String officeCode, String acctType) {

        Boolean operationResult = null;

        if (gmf.isCheckGmf()) {
            operationResult = gmfService.callGMF(accountNumber, officeCode, identityType, identityNumber,
                    clientName, gmf.getCellphone(), acctType);
        }

        return operationResult;
    }

    private boolean updateAccountLimits(String identityType, String identityNumber, String accountNumber,
                                        String accountType) {
        AccountLimitsDto accountLimitsDto = new AccountLimitsDto(accountNumber, accountType,
                identityType, identityNumber);

        return savingsAccountService.updateAccountLimit(accountLimitsDto);
    }

    private boolean sendAccountToMonitorPlus(OpeningAccountDto openingAccountDto, HttpHeaders httpHeaders,
                                             String accountNumber, String channel) {
        MonitorAccountCreateDto monitorAccountCreateDto = accountMapper
                .mapMonitorAccountCreate(openingAccountDto, accountNumber, channel);

        return monitorService.sendAccountToMonitorPlus(httpHeaders, monitorAccountCreateDto);
    }

    private Boolean sendFatca(FatcaDto fatca, String identityType, String identityNumber, String clientName,
                              String officeCode) {

        Boolean operationResult = null;

        if (StringUtils.isNotEmpty(fatca.getFiscalResidence1())) {
            FatcaEntity fatcaEntity = accountMapper.mapFatcaEntity(fatca, identityType, identityNumber, clientName, officeCode);
            operationResult = fatcaService.saveFatcaInfo(fatcaEntity);
        }
        return operationResult;
    }

    private Boolean requestForgivenDebts(String identityType, String identityNumber, OpeningAccountDto openingAccountDto, DispatcherDto dispatcherDto, String ip, String rqUid) {

        return (EAccount.isPayroll(openingAccountDto.getAcctSubType()) && "ACTIVE".equals(dispatcherDto.getCustomerState())) ?
                condonationService.condonationProcess(identityNumber, identityType, rqUid, openingAccountDto.getOfficeCode(), openingAccountDto.isHoliday(), dispatcherDto.getChannel(), ip) : null;
    }

    private Boolean saveFacebookConvertions(AccountData accountData, DispatcherDto dispatcherDto, HttpHeaders httpHeaders) {

        String utmInfo = DataUtilities.getNodeAsText(dispatcherDto.getUtmInfo(), "utm_source");
        String fbclid = DataUtilities.getNodeAsText(dispatcherDto.getUtmInfo(), "fbclid");

        if ("facebook".equalsIgnoreCase(utmInfo) || fbclid != null) {
            return facebookConversions.sendNewAccountCreateFacebook(accountData, dispatcherDto, httpHeaders);
        }

        return false;
    }
}
