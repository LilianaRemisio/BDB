package co.com.bancodebogota.savingsaccountmngr.mapper;

import co.com.bancodebogota.dto.custcatteredinqrs.CustCatteredInqRsDto;
import co.com.bancodebogota.enums.EPayrollCodes;

public interface PayrollDispersionsMapper {
    CustCatteredInqRsDto mapDispersionCode(EPayrollCodes ePayrollCodes);
}
