package co.com.bancodebogota.savingsaccountmngr.service.openapi;

import co.com.bancodebogota.enums.EChannel;
import co.com.bancodebogota.savingsaccountmngr.utils.RequestUtilities;
import co.com.bancodebogota.utils.JacksonUtilsV2;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountResponseDto;
import co.com.bancodebogota.dto.account.AccountData;
import co.com.bancodebogota.dto.customer.CustomerManagementRs;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.openapi.AccountDto;
import co.com.bancodebogota.dto.openapi.ProductDto;
import co.com.bancodebogota.dto.request.AccountRequestRsDto;
import co.com.bancodebogota.dto.request.CreateRequestDto;
import co.com.bancodebogota.enums.EAccount;
import co.com.bancodebogota.enums.EIdentificationType;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.savingsaccountmngr.mapper.IDispatcherMapper;
import co.com.bancodebogota.savingsaccountmngr.mapper.IOpenApiMapper;
import co.com.bancodebogota.savingsaccountmngr.service.accounts.IAccountService;
import co.com.bancodebogota.savingsaccountmngr.service.request.IRequestService;
import co.com.bancodebogota.service.customer.ICustomerApiService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class OpenApiServiceImpl implements IOpenApiService {

    private final IOpenApiMapper openApiMapper;
    private final IDispatcherMapper dispatcherMapper;
    private final ICustomerApiService customerApiService;
    private final IAccountService accountService;
    private final IRequestService requestService;
    private final RequestUtilities requestUtilities;

    private static final String X_CUST_IDENT_TYPE = "X-CustIdentType";
    private static final String X_CUST_IDENT_NUM = "X-CustIdentNum";
    private static final String X_AUTH_UUID = "X-AuthUuid";
    private static final String X_RQUID = "x-rquid";
    private static final String X_IPADDR = "x-ipaddr";
    private static final String X_CHANNEL = "x-channel";

    @Override
    public ProductDto create(HttpHeaders httpHeaders, AccountDto accountDto) throws AbsBdbServiceException {

        String identityNumber = httpHeaders.getFirst(X_CUST_IDENT_NUM);
        log.info(">>> ({}) CREATE ACCOUNT BY OPEN API. NEW CALL >>>", identityNumber);

        String rqUuid = httpHeaders.getFirst(X_RQUID);
        String userIp = httpHeaders.getFirst(X_IPADDR);
        String channel = requestUtilities.validateOpbChannel(httpHeaders.getFirst(X_CHANNEL), EChannel.WEB);

        httpHeaders.set("X-FORWARDED-FOR", userIp);
        httpHeaders.set("access-token", httpHeaders.getFirst("x-accesstoken"));
        httpHeaders.set(X_AUTH_UUID, httpHeaders.getFirst(X_RQUID));
        httpHeaders.set(X_CUST_IDENT_TYPE, EIdentificationType
                .findBdbByApiType(httpHeaders.getFirst(X_CUST_IDENT_TYPE)));

        CustomerManagementRs customerManagementRs = customerApiService.getInfo(identityNumber,
                rqUuid, channel, userIp);
        log.info("({}) [1/5. customerManagementRs]: {}", identityNumber,
                JacksonUtilsV2.getPlainJson(customerManagementRs));

        DispatcherDto dispatcherDto = openApiMapper.mapDispatcher(httpHeaders, accountDto.getOfficeCode());
        log.info("({}) [2/5. DispatcherDto]: {}", identityNumber, JacksonUtilsV2.getPlainJson(dispatcherDto));

        AccountRequestRsDto accountRequestRsDto = saveRequest(httpHeaders, dispatcherDto, accountDto.getProductCode(),
                accountDto.getRequestId());
        log.info("({}) [3/5. accountRequestRsDto]: {}", identityNumber, JacksonUtilsV2.getPlainJson(accountRequestRsDto));

        AccountData accountData = openApiMapper.mapAccountData(accountRequestRsDto.getRequestId(), accountDto,
                customerManagementRs, httpHeaders);
        log.info("({}) [4/5. accountData]: {}", identityNumber, JacksonUtilsV2.getPlainJson(accountData));

        dispatcherDto.setChannel(requestUtilities.validateOpbChannel(channel, EChannel.WEB));
        CreateAccountResponseDto createAccountResponseDto = accountService.accountOpeningV4(httpHeaders,
                accountData, dispatcherDto);
        log.info("({}) [5/5. createAccountResponseDto]: {}", identityNumber,
                JacksonUtilsV2.getPlainJson(createAccountResponseDto));

        String accountNumber = createAccountResponseDto.getAccountNumber();

        ProductDto productDto = new ProductDto();
        productDto.setNumber(accountNumber);
        productDto.setRequestId(accountRequestRsDto.getRequestId());

        log.info("<<< ({}) CREATE ACCOUNT BY OPEN API. SUCCESSFUL END <<<", identityNumber);
        return productDto;
    }

    private AccountRequestRsDto saveRequest(HttpHeaders headers, DispatcherDto dispatcherDto, String accountCode,
                                            Long requestId) throws AbsBdbServiceException {

        AccountRequestRsDto response = new AccountRequestRsDto();
        String digitalRequest = headers.getFirst("x-digrequest");

        if (requestId == null) {
            CreateRequestDto createRequestDto = dispatcherMapper.mapCreateRequest(headers, dispatcherDto);
            createRequestDto.setSourceTeamId(openApiMapper.getSourceTeam(headers.getFirst("x-name")));
            createRequestDto.setProductId(EAccount.isSDA(accountCode) ? 1 : 2);

            createRequestDto.setCreateDigitalRequest(StringUtils.isEmpty(digitalRequest));

            response = requestService.createRequest(createRequestDto,
                    headers.getFirst(X_IPADDR), dispatcherDto);
        } else {
            response.setRequestId(requestId);
        }

        response.setDigitalId(StringUtils.isEmpty(digitalRequest) ? response.getDigitalId() :
                Long.valueOf(digitalRequest));

        return response;
    }
}
