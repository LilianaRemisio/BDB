package co.com.bancodebogota.savingsaccountmngr.controller;

import co.com.bancodebogota.annotations.DisableAuthToken;
import co.com.bancodebogota.db.savings.dto.jpa.DisperserInformationDto;
import co.com.bancodebogota.db.savings.dto.jpa.DisperserRqDto;
import co.com.bancodebogota.dto.payrolldispersions.GetInfoByNitDto;
import co.com.bancodebogota.dto.payrolldispersions.PayrollDispersionsRsDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.savingsaccountmngr.service.accounts.IPayrollService;
import co.com.bancodebogota.savingsaccountmngr.service.dispersioncodes.IDispersionCodesService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("savings")
public class PayrollController {

    private final IPayrollService payrollService;
    private final IDispersionCodesService dispersionCodesService;

    /**
     * deprecated (Se usaba desde bbog-cd-account-opening-web-ui/app/components/nomina/account-agreement.service.js)
     */
    @DisableAuthToken
    @GetMapping("/account/disperser")
    public DisperserInformationDto getAccountAgreement(DisperserRqDto getDisperserRequest) {
        return payrollService.getAccountInformation(getDisperserRequest);
    }

    @DisableAuthToken
    @GetMapping("/account/paysheet/company")
    public ResponseEntity<PayrollDispersionsRsDto> getCompanyNamesByCode(@RequestParam(required = false) String dispersionCode,
                                                                         @RequestParam(required = false) String idType,
                                                                         @RequestParam(required = false) String idNum,
                                                                         @RequestHeader("X-RqUID") String rqUID,
                                                                         @RequestHeader("X-channel") String channel) throws AbsBdbServiceException {

        PayrollDispersionsRsDto response = dispersionCodesService.getPayrollDispersionsRsDto(dispersionCode, idType, idNum, channel, rqUID);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DisableAuthToken
    @GetMapping("/account/paysheet/nit-info")
    public GetInfoByNitDto getNitInfo(@RequestHeader HttpHeaders httpHeaders,
                                      @RequestParam String nit) throws AbsBdbServiceException {
        return dispersionCodesService.getNitInfo(httpHeaders, nit);
    }
}
