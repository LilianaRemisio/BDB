package co.com.bancodebogota.savingsaccountmngr.service.accounts;

public interface IGMFService {

    boolean callGMF(String accountNumber, String officeCode, String identityType,
                    String identityNumber, String clientName, String cellphone, String acctType);

    boolean sendNewAccountToGMFService(String accountNumber, String officeCode, String identityType,
                                       String identityNumber, String clientName, String cellphone, Long requestId);
}
