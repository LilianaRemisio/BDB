package co.com.bancodebogota.savingsaccountmngr.service.inquiryholders;

import co.com.bancodebogota.dto.products.LimitsAccountRq;
import co.com.bancodebogota.exception.AbsBdbServiceException;

public interface IInquiryHolders {
    public String getOwnership(LimitsAccountRq accountInfo, String rqUID) throws AbsBdbServiceException;
}
