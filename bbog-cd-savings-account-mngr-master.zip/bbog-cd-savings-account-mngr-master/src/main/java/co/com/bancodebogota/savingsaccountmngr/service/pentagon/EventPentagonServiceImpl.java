package co.com.bancodebogota.savingsaccountmngr.service.pentagon;

import co.com.bancodebogota.dto.pentagon.EventDataDto;
import co.com.bancodebogota.dto.pentagon.EventIdentityDto;
import co.com.bancodebogota.service.pentagon.IPentagonService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import java.util.Base64;

@Service
@RequiredArgsConstructor
public class EventPentagonServiceImpl implements IEventPentagonService {

    private final IPentagonService pentagonService;

    private static final String X_RQ_UID = "X-RqUID";
    private static final String X_ACCESS_TOKEN = "access-token";
    private static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";
    private static final String X_IDENTIFICATION_NUMBER = "Identification-Number";
    private static final String X_CHANNEL = "X-Channel";
    private static final String X_MEDIUM = "X-Medium";
    private static final String X_SOURCE_CHANNEL = "X-SourceChannel";

    public boolean sendEvent(HttpHeaders httpHeaders, EventDataDto eventDataDto) {

        String identificationNumberEncode = httpHeaders.getFirst(X_IDENTIFICATION_NUMBER);
        String identificationNumberDecode = new String(Base64.getDecoder().decode(identificationNumberEncode));
        String identityNumber = identificationNumberDecode.substring(0, identificationNumberDecode.length() - 1);
        String identityType = identificationNumberDecode.substring(identificationNumberDecode.length() - 1);

        EventIdentityDto eventIdentityDto = new EventIdentityDto();
        eventIdentityDto.setRqUuid(httpHeaders.getFirst(X_RQ_UID));
        eventIdentityDto.setAccessToken(httpHeaders.getFirst(X_ACCESS_TOKEN));
        eventIdentityDto.setUserIp(StringUtils.defaultIfEmpty(httpHeaders.getFirst(X_FORWARDED_FOR), "").split(",")[0]);
        eventIdentityDto.setChannel(httpHeaders.getFirst(X_CHANNEL));
        eventIdentityDto.setIdentityType(identityType);
        eventIdentityDto.setIdentityNumber(identityNumber);
        eventIdentityDto.setMedium(httpHeaders.getFirst(X_MEDIUM));
        eventIdentityDto.setSourceChannel(httpHeaders.getFirst(X_SOURCE_CHANNEL));

        try {
            pentagonService.publish(eventDataDto, eventIdentityDto);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
