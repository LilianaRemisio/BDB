package co.com.bancodebogota.savingsaccountmngr.mapper;

import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.request.AuthFlagsDto;
import co.com.bancodebogota.dto.request.CreateRequestDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import org.springframework.http.HttpHeaders;

public interface IDispatcherMapper {

    CreateRequestDto mapCreateRequest(HttpHeaders httpHeaders, DispatcherDto dispatcherDto);

    AuthFlagsDto handleFlags(DispatcherDto dispatcherDto, boolean isPayroll, boolean isNewClient, String identityNumber) throws AbsBdbServiceException;
}
