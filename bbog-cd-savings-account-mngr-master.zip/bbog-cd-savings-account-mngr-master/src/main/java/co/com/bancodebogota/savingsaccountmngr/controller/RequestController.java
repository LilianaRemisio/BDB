package co.com.bancodebogota.savingsaccountmngr.controller;

import co.com.bancodebogota.annotations.DisableAuthToken;
import co.com.bancodebogota.dto.request.*;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.savingsaccountmngr.service.request.IRequestService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.concurrent.CompletableFuture;

@RestController
@RequiredArgsConstructor
@RequestMapping("savings")
public class RequestController {

    private final IRequestService requestService;

    @PostMapping("account/request")
    public ResponseEntity<String> createRequest(
            @RequestHeader(name = "X-FORWARDED-FOR") String userIp,
            @RequestBody CreateRequestDto createRequestDto) throws AbsBdbServiceException {

        AccountRequestRsDto accountRequestRsDto = requestService.createRequest(createRequestDto,
                StringUtils.defaultIfEmpty(userIp, "").split(",")[0], null);
        return new ResponseEntity<>(String.valueOf(accountRequestRsDto.getRequestId()), HttpStatus.OK);
    }

    @DisableAuthToken
    @PostMapping("account/request/v2")
    public ResponseEntity<AccountRequestV2RsDto> createRequestV2(@RequestHeader HttpHeaders httpHeaders)
            throws AbsBdbServiceException {

        AccountRequestV2RsDto accountRequestRsDto = requestService.createRequestV2(httpHeaders);
        return new ResponseEntity<>(accountRequestRsDto, HttpStatus.OK);
    }

    @DisableAuthToken
    @PostMapping("account/request/v3")
    public ResponseEntity<AccountRequestV3RsDto> createRequestV3(@RequestHeader HttpHeaders httpHeaders)
            throws AbsBdbServiceException {

        AccountRequestV3RsDto accountRequestRsDto = requestService.createRequestV3(httpHeaders);
        return new ResponseEntity<>(accountRequestRsDto, HttpStatus.OK);
    }

    @DisableAuthToken
    @PostMapping("account/reactivate/request")
    public ResponseEntity<AccountRequestRsDto> createRequestId(@RequestHeader HttpHeaders httpHeaders)
            throws AbsBdbServiceException {

        AccountRequestRsDto accountRequestRsDto = requestService.createRequestId(httpHeaders);
        return new ResponseEntity<>(accountRequestRsDto, HttpStatus.CREATED);
    }

    @DisableAuthToken
    @PostMapping("account/request/digital/close")
    public ResponseEntity<Boolean> closeDigitalByDispatcher(@RequestHeader HttpHeaders httpHeaders) {
        CompletableFuture.runAsync(() -> requestService.closeDigitalBySession(httpHeaders));
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @DisableAuthToken
    @PostMapping("account/request/digital/close/{date}")
    public void closeDigitalByDateAsync(@PathVariable(value = "date") @DateTimeFormat(pattern = "yyyy-MM-dd") Date date) {
        CompletableFuture.runAsync(() -> requestService.closeDigitalByDate(date));
    }

    @DisableAuthToken
    @PostMapping("account/request/digital/close/v2")
    public void closeDigitalByIdAsync(@RequestHeader(name = "X-FORWARDED-FOR") String xForwardedFor,
                                      @RequestBody CloseDigitalRequestDto closeDigitalRequestDto) {
        CompletableFuture.runAsync(() -> requestService.closeDigitalById(xForwardedFor, closeDigitalRequestDto));
    }

    @DisableAuthToken
    @GetMapping("account/flow-type")
    public ResponseEntity<FlowTypeDto> getFlowType(@RequestHeader HttpHeaders httpHeaders) throws AbsBdbServiceException {

        FlowTypeDto response = requestService.getFlowType(httpHeaders);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
