package co.com.bancodebogota.savingsaccountmngr.service.customer;

import co.com.bancodebogota.dto.account.OpeningAccountDto;
import co.com.bancodebogota.dto.customer.CustomerStatusDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import org.springframework.http.HttpHeaders;

public interface ICustomerServiceV2 {
    CustomerStatusDto getProductsStatus(HttpHeaders httpHeaders, String accountType) throws AbsBdbServiceException;

    void sendNotificationForCreatedAccount(String identityNumber, String rqUid, Boolean isEmailNotification, String accountNumber,
                                           OpeningAccountDto openingAccountDto, String fullName, String channel);
}
