package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.dto.NetworkTrnInfoDto;
import co.com.bancodebogota.dto.gmf.*;
import co.com.bancodebogota.savingsaccountmngr.mapper.IGMFMapper;
import co.com.bancodebogota.utils.TimeUtilities;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class GMFMapperImpl implements IGMFMapper {

    private static final String COP = "COP";
    private static final String YYYY_MM_DD = "yyyy-MM-dd'T'hh:mm:ss";
    private static final String SEQUENCE = "000";
    private static final String NET_OWNER = "DIG482";
    private static final String NET_NAME = "09999993";
    private static final String NET_TERMINAL = "0221";
    private static final String ACCT_STATUS = "01";
    private static final String PHONE_TYPE = "12";
    private static final String INDIVIDUAL_ACCT_TYPE = "03";
    private static final int EXEMPT_TYPE = 4;

    @Override
    public GMFTaxExemptionMarkAddRqDTO mapGmfRequestDto(String accountNumber, String officeCode, String identityType,
                                                        String identityNumber, String clientName, String cellphone,
                                                        String acctType) {

        GMFTaxExemptionMarkAddRqDTO gmfTaxExemptionMarkAddRqDTO = new GMFTaxExemptionMarkAddRqDTO();

        gmfTaxExemptionMarkAddRqDTO.setRqUID(UUID.randomUUID());
        gmfTaxExemptionMarkAddRqDTO.setTrnSeqCntr(SEQUENCE);

        NetworkTrnInfoDto networkTrnInfoDto = new NetworkTrnInfoDto();
        networkTrnInfoDto.setName(NET_NAME);
        networkTrnInfoDto.setNetworkOwner(NET_OWNER);
        networkTrnInfoDto.setTerminalId(NET_TERMINAL);
        gmfTaxExemptionMarkAddRqDTO.setNetworkTrnInfo(networkTrnInfoDto);

        AcctBasicInfoDTO acctBasicInfoDTO = new AcctBasicInfoDTO();
        acctBasicInfoDTO.setAcctId(accountNumber);
        acctBasicInfoDTO.setAccType(INDIVIDUAL_ACCT_TYPE);
        acctBasicInfoDTO.setAcctSubType(acctType);
        acctBasicInfoDTO.setAcctCur(COP);
        acctBasicInfoDTO.setAcctStatus(ACCT_STATUS);

        BankInfoDTO bankInfo = new BankInfoDTO();
        bankInfo.setBranchId(officeCode);
        acctBasicInfoDTO.setBankInfo(bankInfo);

        gmfTaxExemptionMarkAddRqDTO.setAcctBasicInfo(acctBasicInfoDTO);

        OtherIdentDocDTO otherIdentDoc = new OtherIdentDocDTO();
        otherIdentDoc.setTypeId(identityType);
        otherIdentDoc.setParticipantId(identityNumber);
        gmfTaxExemptionMarkAddRqDTO.setOtherIdentDoc(otherIdentDoc);

        gmfTaxExemptionMarkAddRqDTO.setFullName(clientName);

        String today = TimeUtilities.getCurrentDateInFormat(YYYY_MM_DD);
        gmfTaxExemptionMarkAddRqDTO.setEffDt(today);
        gmfTaxExemptionMarkAddRqDTO.setStartDt(today);
        gmfTaxExemptionMarkAddRqDTO.setClientDt(today);
        gmfTaxExemptionMarkAddRqDTO.setOpenDt(today);

        AddressDTO addressDTO = new AddressDTO();
        gmfTaxExemptionMarkAddRqDTO.setHomeAddr(addressDTO);
        gmfTaxExemptionMarkAddRqDTO.setBusinessAddr(addressDTO);

        PhoneDTO phoneNum = new PhoneDTO();
        phoneNum.setPhone(cellphone);
        phoneNum.setPhoneType(PHONE_TYPE);

        gmfTaxExemptionMarkAddRqDTO.setPhoneNum(phoneNum);
        gmfTaxExemptionMarkAddRqDTO.setTrnType(EXEMPT_TYPE);

        return gmfTaxExemptionMarkAddRqDTO;
    }
}
