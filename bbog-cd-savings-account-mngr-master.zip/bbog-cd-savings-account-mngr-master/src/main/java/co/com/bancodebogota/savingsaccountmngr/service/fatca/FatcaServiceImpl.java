package co.com.bancodebogota.savingsaccountmngr.service.fatca;

import co.com.bancodebogota.utils.JacksonUtilsV2;
import co.com.bancodebogota.model.entities.FatcaEntity;
import co.com.bancodebogota.model.repositories.FatcaRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class FatcaServiceImpl implements IFatcaService {

    private final FatcaRepository fatcaRepository;

    @Override
    public boolean saveFatcaInfo(FatcaEntity fatcaEntity) {
        try {
            log.info(">>> SAVING FATCA INFO NEW CALL >>> {} {}", fatcaEntity.getIdentityNumber(),
                    JacksonUtilsV2.getPlainJson(fatcaEntity));
            fatcaRepository.save(fatcaEntity);
            return true;
        } catch (Exception e) {
            log.error("ERROR SAVING FATCA INFO {}", e.getMessage());
            return false;
        }
    }
}
