package co.com.bancodebogota.savingsaccountmngr.service.customer;

import co.com.bancodebogota.JacksonUtils;
import co.com.bancodebogota.debitcards.CardInfoDto;
import co.com.bancodebogota.dto.account.OpeningAccountDto;
import co.com.bancodebogota.dto.customer.CustomerStatusDto;
import co.com.bancodebogota.dto.notifications.ParameterTypeDto;
import co.com.bancodebogota.dto.notifications.RequestNotificationEmail;
import co.com.bancodebogota.dto.notifications.RequestNotificationMessage;
import co.com.bancodebogota.dto.pentagon.EventDataDto;
import co.com.bancodebogota.dto.pentagon.EventIdentityDto;
import co.com.bancodebogota.dto.products.ProductAccountDto;
import co.com.bancodebogota.dto.products.ProductDto;
import co.com.bancodebogota.dto.products.ProductsHandledDto;
import co.com.bancodebogota.enums.*;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.model.entitiesold.AccountLog;
import co.com.bancodebogota.model.repositories.AccountLogRepository;
import co.com.bancodebogota.savingsaccountmngr.service.products.IProductsService;
import co.com.bancodebogota.service.notifications.INotificationApiService;
import co.com.bancodebogota.service.pentagon.IPentagonService;
import co.com.bancodebogota.service.product.IProductService;
import co.com.bancodebogota.utils.DataUtilities;
import co.com.bancodebogota.utils.ProductUtilities;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerServiceV2Impl implements ICustomerServiceV2 {

    @Value("${card.activation.endpoint}")
    private String cardActivationLink;

    private final IProductService productService;
    private final IProductsService productsService;
    private final AccountLogRepository accountLogRepository;
    private final INotificationApiService notificationApiService;
    private final IPentagonService pentagonService;

    private static final String X_RQ_UID = "X-RqUID";
    private static final String X_IDENTIFICATION_NUMBER = "Identification-Number";
    private static final String X_CHANNEL = "X-Channel";
    private static final String X_FORWARDED_FOR = "X-Forwarded-For";
    private static final String X_DIG_REQUEST = "X-DigRequest";
    private static final String X_ACCESS_TOKEN = "Access-Token";
    private static final String X_JOURNEY = "X-Journey";
    private static final String X_MEDIUM = "X-Medium";
    private static final String X_SOURCE_CHANNEL = "X-SourceChannel";

    @Override
    public CustomerStatusDto getProductsStatus(HttpHeaders httpHeaders, String accountType) throws AbsBdbServiceException {

        String identification = httpHeaders.getFirst(X_IDENTIFICATION_NUMBER);

        String identificationNumberDecode = new String(Base64.getDecoder().decode(identification));
        String identityNumber = identificationNumberDecode.substring(0, identificationNumberDecode.length() - 1);
        String identityType = identificationNumberDecode.substring(identificationNumberDecode.length() - 1);

        log.info(">>> ({}) GET CUSTOMER STATUS. NEW CALL >>>", identityNumber);

        String rqUID = httpHeaders.getFirst(X_RQ_UID);
        String channel = httpHeaders.getFirst(X_CHANNEL);
        String userIp = httpHeaders.getFirst(X_FORWARDED_FOR);

        ProductAccountDto productAccountDto;
        List<ProductDto> accounts;

        try {
            productAccountDto = productService.getProducts(rqUID, channel, identityType, identityNumber, userIp);

            List<String> activeAccounts = new ArrayList<>();
            accounts = getActiveAccounts(productAccountDto);
            accounts.forEach(res -> activeAccounts.add(res.getAcctSubType()));

            sendProductsEvent(identityType, identityNumber, httpHeaders, HttpStatus.OK, activeAccounts);
        } catch (AbsBdbServiceException e) {
            sendProductsEvent(identityType, identityNumber, httpHeaders, e.getCode(), null);
            throw e;
        }

        List<AccountLog> accountLogs = getDigitalAccountsInDb(accounts);

        boolean hasDigitalAccounts;

        try {
            long requiredCount = EAccount.PENSIONADO.getCode().equalsIgnoreCase(accountType) ? 1 : 2;
            hasDigitalAccounts = accountLogs.stream()
                    .filter(data -> accountType.equalsIgnoreCase(data.getAccountType()))
                    .collect(Collectors.groupingBy(AccountLog::getAccountType, Collectors.counting()))
                    .getOrDefault(accountType, 0L) >= requiredCount;
        } catch (Exception e) {
            hasDigitalAccounts = false;
        }

        ProductsHandledDto productsHandledDto = productsService.getFilteredCards(productAccountDto);

        List<CardInfoDto> activeCards = productsHandledDto.getActiveCards();
        List<CardInfoDto> tempCards = productsHandledDto.getTempCards();
        boolean clientWithActiveCards = !activeCards.isEmpty();
        boolean clientWithTempCards = !tempCards.isEmpty();

        CustomerStatusDto customerStatusDto = new CustomerStatusDto();
        customerStatusDto.setHasDigitalAccount(hasDigitalAccounts);
        customerStatusDto.setHasPinUniversal(ProductUtilities.checkUniversalPin(productAccountDto));
        customerStatusDto.setHasDebitCards(clientWithActiveCards);
        customerStatusDto.setHasElectronCard(productsHandledDto.isClientWithElectron());
        customerStatusDto.setActiveCards(activeCards);

        if (clientWithTempCards && !clientWithActiveCards) {
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, identityNumber, "Customer with locks");
        }

        log.info("Customer ({}) has an active digital account ({})", identityNumber, hasDigitalAccounts);
        log.info("<<< ({}) GET CUSTOMER STATUS. SUCCESSFUL END <<<", identityNumber);
        return customerStatusDto;
    }

    private void sendProductsEvent(String identityType, String identityNumber, HttpHeaders httpHeaders, HttpStatus httpStatus,
                                   List<String> activeAccounts) {

        String journey = httpHeaders.getFirst(X_JOURNEY);

        try {
            EventDataDto eventDataDto = new EventDataDto();

            eventDataDto.setEventName(String.format("Event-CuentaDeAhorros-%s-ConocimientoDeCliente-ConsultaProductosBanco",
                    EJourney.getJourneyName(journey)));
            eventDataDto.setMilestone("ConocimientoDeCliente");
            eventDataDto.setStep("ConsultaProductosBanco");
            eventDataDto.setDigRequest(httpHeaders.getFirst(X_DIG_REQUEST));
            eventDataDto.setFront(false);
            eventDataDto.setIsClient(EClientType.ACTIVE.getApiName());
            eventDataDto.setJourney(journey);
            eventDataDto.setPayload(String.format("{\"status\":\"%s\",\"description\":\"%s\",\"activeAccounts\":%s}",
                    httpStatus.value(), httpStatus.getReasonPhrase(), JacksonUtils.getPlainJson(activeAccounts)));
            EventIdentityDto eventIdentityDto = new EventIdentityDto();
            eventIdentityDto.setIdentityType(identityType);
            eventIdentityDto.setIdentityNumber(identityNumber);
            eventIdentityDto.setRqUuid(httpHeaders.getFirst(X_RQ_UID));
            eventIdentityDto.setChannel(httpHeaders.getFirst(X_CHANNEL));
            eventIdentityDto.setUserIp(httpHeaders.getFirst(X_FORWARDED_FOR));
            eventIdentityDto.setAccessToken(httpHeaders.getFirst(X_ACCESS_TOKEN));
            eventIdentityDto.setMedium(httpHeaders.getFirst(X_MEDIUM));
            eventIdentityDto.setSourceChannel(httpHeaders.getFirst(X_SOURCE_CHANNEL));

            pentagonService.publish(eventDataDto, eventIdentityDto);
        } catch (Exception e) {
            log.error("({}). Error sending event to pentagon: {}", identityNumber, e.getMessage());
        }
    }

    private List<AccountLog> getDigitalAccountsInDb(List<ProductDto> activeAccounts) {
        List<AccountLog> digitalAccounts = new ArrayList<>();
        for (ProductDto account : activeAccounts) {

            String accountNumber = account.getProductId().startsWith("0") ? account.getProductId().substring(1) : account.getProductId();
            AccountLog accountLogInDB = accountLogRepository.findByAccountNumber(accountNumber);

            if (accountLogInDB != null) digitalAccounts.add(accountLogInDB);
        }

        return digitalAccounts;
    }

    private List<ProductDto> getActiveAccounts(ProductAccountDto productAccountDto) {

        return productAccountDto.getProductAccount().stream()
                .filter(account -> account.getProductStatusCode().equals("A")
                        && Arrays.stream(EAccount.values()).anyMatch(e -> e.getCode().equals(account.getAcctSubType())))
                .collect(Collectors.toList());
    }

    @Override
    public void sendNotificationForCreatedAccount(String identityNumber, String rqUid, Boolean isEmailNotification, String accountNumber,
                                                  OpeningAccountDto openingAccountDto, String fullName, String channel) {

        String account = "DDA".equals(openingAccountDto.getAcctType()) ? "cuenta corriente" : "cuenta de ahorros";

        String msgTemplate = String.format(ESmsMessage.WELCOME_TO_BDB.getDescription(), account, accountNumber);
        RequestNotificationMessage requestNotificationMessage = new RequestNotificationMessage(msgTemplate, openingAccountDto.getPhoneNumber());
        notificationApiService.sendSMS(identityNumber, rqUid, requestNotificationMessage);

        List<ParameterTypeDto> emailParameters = new ArrayList<>();

        emailParameters.add(new ParameterTypeDto("nombre_cliente", fullName));
        emailParameters.add(new ParameterTypeDto("ID", DataUtilities.getLastNCharacters(identityNumber, 4)));
        emailParameters.add(new ParameterTypeDto("primer_nombre", openingAccountDto.getFirstName()));
        emailParameters.add(new ParameterTypeDto("num_cuenta", accountNumber));
        emailParameters.add(new ParameterTypeDto("activar_tarjeta", cardActivationLink));

        EEmailTemplate emailTemplate = EEmailTemplate.CREACION_OFICINA;
        if (EChannel.isTxInWeb(channel)) {
            emailTemplate = openingAccountDto.isCardDelivery() ? EEmailTemplate.CREACION_WEB_ENVIO : EEmailTemplate.CREACION_WEB_RECLAMAR;
        }

        RequestNotificationEmail requestNotificationEmail = new RequestNotificationEmail(
                openingAccountDto.getEmailAddr(), emailTemplate, emailParameters);

        if (isEmailNotification && !"DDA".equals(openingAccountDto.getAcctType())) {
            notificationApiService.sendEmail(identityNumber, rqUid, requestNotificationEmail);
        }
    }
}
