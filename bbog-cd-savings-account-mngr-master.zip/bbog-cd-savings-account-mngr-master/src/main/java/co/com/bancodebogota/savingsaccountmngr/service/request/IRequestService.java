package co.com.bancodebogota.savingsaccountmngr.service.request;

import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.request.*;
import co.com.bancodebogota.enums.EEventType;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import org.springframework.http.HttpHeaders;

import java.util.Date;

public interface IRequestService {

    AccountRequestRsDto createRequest(CreateRequestDto createRequestDto, String userIp, DispatcherDto dispatcherDto) throws AbsBdbServiceException;

    AccountRequestV2RsDto createRequestV2(HttpHeaders httpHeaders) throws AbsBdbServiceException;

    AccountRequestV3RsDto createRequestV3(HttpHeaders httpHeaders) throws AbsBdbServiceException;

    AccountRequestRsDto createRequestId(HttpHeaders httpHeaders) throws AbsBdbServiceException;

    void saveRequestEvent(Long requestId, EEventType evenType, String identityNumber);

    void updateRequestEvent(long requestId, EEventType newEventType, EEventType oldEventType) throws AbsBdbServiceException;

    void saveFailedRequest(String authUuid);

    void closeDigitalBySession(HttpHeaders httpHeaders);

    void closeDigitalByDate(Date date);

    void closeDigitalById(String xForwardedFor, CloseDigitalRequestDto closeDigitalRequestDto);

    FlowTypeDto getFlowType(HttpHeaders httpHeaders) throws AbsBdbServiceException;
}
