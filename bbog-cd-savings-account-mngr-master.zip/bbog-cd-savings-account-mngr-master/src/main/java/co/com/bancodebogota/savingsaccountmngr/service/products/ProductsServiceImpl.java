package co.com.bancodebogota.savingsaccountmngr.service.products;

import co.com.bancodebogota.debitcards.CardInfoDto;
import co.com.bancodebogota.debitcards.CardStatusType;
import co.com.bancodebogota.debitcards.DebitCardStatus;
import co.com.bancodebogota.dto.products.*;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.service.product.IProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductsServiceImpl implements IProductsService {

    private final IProductService productService;

    @Override
    public ProductAccountDto getClientProducts(String identityType, String identityNumber, String rqUid,
                                               String channel, String userIp) throws AbsBdbServiceException {
        return productService.getProducts(rqUid, channel, identityType, identityNumber, userIp);
    }

    @Override
    public List<AcctBasicInfoDto> getFilteredAccountsList(String identityNumber, String rqUid,
                                                          String channel, String userIp, String numberCard) throws AbsBdbServiceException {

        ProductAccountDto clientProducts = getClientProducts("CC", identityNumber, rqUid, channel, userIp);
        List<ProductDto> clientCards = clientProducts.getProductAccount().stream()
                .filter(product -> "DEB".equals(product.getProductType())).collect(Collectors.toList());

        return validateAcctBasicInfo(numberCard, clientCards);
    }

    private List<AcctBasicInfoDto> validateAcctBasicInfo(String numberCard, List<ProductDto> clientCards) {
        List<AcctBasicInfoDto> accountsList = new ArrayList<>();

        clientCards.forEach(card -> {
            if (numberCard.equals(card.getProductId())) {
                List<AcctBasicInfoType> cardAccounts = card.getAcctBasicInfo();
                if (!cardAccounts.isEmpty()) {
                    cardAccounts.forEach(account -> {
                        AcctBasicInfoDto acctBasicInfoDto = new AcctBasicInfoDto();
                        acctBasicInfoDto.setAcctId(account.getAcctId());
                        acctBasicInfoDto.setAcctSubType(account.getAcctSubType());
                        acctBasicInfoDto.setAcctType(account.getAcctType());
                        accountsList.add(acctBasicInfoDto);
                    });
                }
            }
        });

        return accountsList;
    }

    @Override
    public ProductsHandledDto getFilteredCards(ProductAccountDto productAccountDto) {

        List<ProductDto> clientCards = productAccountDto.getProductAccount().stream()
                .filter(product -> "DEB".equals(product.getProductType())).collect(Collectors.toList());

        ProductsHandledDto productsHandledDto = new ProductsHandledDto();
        Pattern preferentPattern = Pattern.compile("^(457603|457604)");
        Pattern electronPattern = Pattern.compile("^491511");
        Pattern unicefPattern = Pattern.compile("^457602");
        Pattern amazoniaPattern = Pattern.compile("^457605");

        List<String> activeCodes = filterByType(CardStatusType.ACTIVE);
        List<String> tempLockCodes = filterByType(CardStatusType.TEMP_LOCK);
        List<String> definitiveLockCodes = filterByType(CardStatusType.DEFINITIVE_LOCK);

        clientCards.forEach(card -> {
            CardInfoDto cardInfoDto = new CardInfoDto();
            String cardId = card.getProductId();

            cardInfoDto.setNumber(cardId);
            cardInfoDto.setFi(card.getCardVrfyData());
            cardInfoDto.setStatusCode(card.getProductStatusCode());

            boolean isPreferent = preferentPattern.matcher(cardId).find();
            boolean isElectron = electronPattern.matcher(cardId).find();
            boolean isUnicef = unicefPattern.matcher(cardId).find();
            boolean isAmazonia = amazoniaPattern.matcher(cardId).find();

            if (isPreferent || isElectron || isUnicef || isAmazonia) {
                classificateCard(productsHandledDto, activeCodes, tempLockCodes, definitiveLockCodes, cardInfoDto,
                        cardId, isElectron);
            }
        });

        return productsHandledDto;
    }

    private List<String> filterByType(CardStatusType cardStatusType) {
        String type = cardStatusType.getCode();
        return findAll().stream().filter(u -> type.equals(u.getType())).map(DebitCardStatus::getId).collect(Collectors.toList());
    }

    private List<DebitCardStatus> findAll() {
        List<DebitCardStatus> data = new ArrayList<>();

        String normal = CardStatusType.ACTIVE.getCode();
        String bloqueoDefinitivo = CardStatusType.DEFINITIVE_LOCK.getCode();
        String bloqueoTemporal = CardStatusType.TEMP_LOCK.getCode();

        data.add(new DebitCardStatus("N", "NORMAL", normal));

        data.add(new DebitCardStatus("F", "FALLECIDO", bloqueoDefinitivo));
        data.add(new DebitCardStatus("G", "TARJETA DESTRUIDA", bloqueoDefinitivo));
        data.add(new DebitCardStatus("0", "PREVENTIVO PERSONA", bloqueoDefinitivo));
        data.add(new DebitCardStatus("1", "SIN PLASTICO CON DESBLOQUEO", bloqueoDefinitivo));
        data.add(new DebitCardStatus("C", "CANCELACION MAL MANEJO", bloqueoDefinitivo));
        data.add(new DebitCardStatus("D", "CANCELACION VOLUNTARIA", bloqueoDefinitivo));
        data.add(new DebitCardStatus("O", "TARJETA DESTRUIDA", bloqueoDefinitivo));
        data.add(new DebitCardStatus("U", "FRAUDE", bloqueoDefinitivo));
        data.add(new DebitCardStatus("R", "ROBO/EXTRAVIO", bloqueoDefinitivo));

        data.add(new DebitCardStatus("P", "PIN ERRADO", bloqueoTemporal));
        data.add(new DebitCardStatus("E", "NO RECLAMADA", bloqueoTemporal));
        data.add(new DebitCardStatus("B", "PREVENTIVO POR SERVIILINEA", bloqueoTemporal));

        return data;
    }

    private void classificateCard(ProductsHandledDto productsHandledDto, List<String> activeCodes,
                                  List<String> tempLockCodes, List<String> definitiveLockCodes, CardInfoDto cardInfoDto, String cardId,
                                  boolean isElectron) {

        ProductClassification classification = getClassification(definitiveLockCodes, activeCodes,
                tempLockCodes, cardInfoDto);
        if (!classification.isUnknowClassification()) {
            if (isElectron && (classification.isActive() || classification.isTemp())) {
                productsHandledDto.setClientWithElectron(true);
            }
            cardInfoDto.setNumber(cardId);
            if (classification.isActive()) {
                productsHandledDto.getActiveCards().add(cardInfoDto);
            }
            if (classification.isTemp()) {
                productsHandledDto.getTempCards().add(cardInfoDto);
            }
            if (classification.isLocked()) {
                productsHandledDto.getLockedCards().add(cardInfoDto);
            }
        }
    }

    private ProductClassification getClassification(List<String> definitiveLockCodes, List<String> activeCodes,
                                                    List<String> tempLockCodes, CardInfoDto cardInfoDto) {
        ProductClassification classification = new ProductClassification();
        boolean active = isStateInList(cardInfoDto.getStatusCode(), activeCodes);
        if (active) {
            classification.setActive(true);
            return classification;
        }
        boolean temp = isStateInList(cardInfoDto.getStatusCode(), tempLockCodes);
        if (temp) {
            classification.setTemp(true);
            return classification;
        }
        boolean locked = isStateInList(cardInfoDto.getStatusCode(), definitiveLockCodes);
        if (locked) {
            classification.setLocked(true);
            return classification;
        }
        classification.setUnknowClassification(true);
        return classification;
    }

    private boolean isStateInList(String cardStatus, List<String> statusList) {
        boolean matchState = statusList.isEmpty();
        for (String status : statusList) {
            if (status.equals(cardStatus)) {
                matchState = true;
                break;
            }
        }
        return matchState;
    }
}
