package co.com.bancodebogota.savingsaccountmngr.mapper;

import co.com.bancodebogota.dto.gmf.GMFTaxExemptionMarkAddRqDTO;


public interface IGMFMapper {

    GMFTaxExemptionMarkAddRqDTO mapGmfRequestDto(String accountNumber, String officeCode, String identityType,
                                                 String identityNumber, String clientName, String cellphone,
                                                 String acctType);
}
