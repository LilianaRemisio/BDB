package co.com.bancodebogota.savingsaccountmngr.service.condonation;

import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.dto.condonation.ForgivenDebtsDto;
import co.com.bancodebogota.dto.condonation.GetSavingsInfoRequestDto;
import co.com.bancodebogota.dto.condonation.SetDebitOrderRequestDto;
import co.com.bancodebogota.dto.products.ProductAccountDto;
import co.com.bancodebogota.dto.products.ProductDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.service.product.IProductService;
import com.bancodebogota.ifx.base.v1.AcctBalType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.web.util.UriComponentsBuilder;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CondonationServiceImpl implements ICondonationService {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${endpoint.accounts.adapter}")
    private String endpointAccountsAdapter;

    private final RestExchangeV2 restExchange;
    private final IProductService productService;

    private static final String GET_SAVINGS_ACCOUNT_INFO_RESOURCE = "/condonation/savings-info";
    private static final String DEBIT_ORDER_RESOURCE = "/condonation/debit-order";
    private static final String FORGIBEN_DEBTS_RESOURCE = "/condonation/forgive-debts";

    public Boolean condonationProcess(String identityNumber, String identityType, String rqUid, String branchId,
                                      boolean holiday, String channel, String userIp) {

        log.info(">>> ({}) CONDONATION PROCESS. NEW CALL >>>", identityNumber);

        boolean callForgivenDebts = false;
        List<ProductDto> productDtos;

        try {
            productDtos = getSavingsAccount(identityNumber, identityType, rqUid, channel, userIp);
        } catch (Exception e) {
            log.info("<<< ({}) CONDONATION PROCESS. FAIL CALL <<<", identityNumber);
            return false;
        }

        for (ProductDto productDto : productDtos) {
            try {
                List<AcctBalType> acctBalListType = getSavingsAccountInfo(identityNumber, identityType, rqUid, branchId,
                        holiday, productDto.getProductId());

                BigDecimal accountDebts = acctBalListType.get(2).getCurAmt().get(0).getAmt().add(acctBalListType.get(3).getCurAmt().get(0).getAmt());

                boolean accountHasDebts = (new BigDecimal(0).compareTo(accountDebts)) != 0;

                if (accountHasDebts) {
                    callForgivenDebts = true;
                    setDebitOrder(identityNumber, productDto.getProductId(), accountDebts, branchId, rqUid);
                }
            } catch (Exception e) {
                log.info("<<< ({}) Process Account Info ({}). FAIL ({}) <<<", identityNumber, productDto.getProductId(), e.getMessage());
            }
        }

        Boolean response = callForgivenDebts ? forgivenDebts(identityNumber, identityType) : callForgivenDebts;

        log.info("<<< ({}) CONDONATION PROCESS. SUCCESSFUL CALL <<<", identityNumber);
        return response;
    }

    public List<ProductDto> getSavingsAccount(String identityNumber, String identityType, String rqUid, String channel,
                                              String userIp) throws AbsBdbServiceException {
        ProductAccountDto productAccountDto = productService.getProducts(rqUid, channel, identityType, identityNumber, userIp);

        return productAccountDto.getProductAccount().stream()
                .filter(x -> "SDA".equals(x.getProductType()) || "DDA".equals(x.getProductType()))
                .collect(Collectors.toList());
    }

    private List<AcctBalType> getSavingsAccountInfo(String identityNumber, String identityType, String rqUid,
                                                    String branchId, boolean holiday, String acctId) throws AbsBdbServiceException {

        log.info("({}) [1] CONDONATION - getSavingsAccountInfo ({})", identityNumber, acctId);
        GetSavingsInfoRequestDto getSavingsInfoRequestDto = new GetSavingsInfoRequestDto();
        getSavingsInfoRequestDto.setIdentityNumber(identityNumber);
        getSavingsInfoRequestDto.setIdentityType(identityType);
        getSavingsInfoRequestDto.setRqUid(rqUid);
        getSavingsInfoRequestDto.setBranchId(branchId);
        getSavingsInfoRequestDto.setHoliday(holiday);
        getSavingsInfoRequestDto.setAcctId(acctId);

        UriComponentsBuilder urlBuilder =
                UriComponentsBuilder.fromUriString(endpointAccountsAdapter).path(GET_SAVINGS_ACCOUNT_INFO_RESOURCE);

        ResponseEntity<JsonNode> response = restExchange.exchange(urlBuilder.toUriString(),
                getSavingsInfoRequestDto, HttpMethod.POST, JsonNode.class);
        JsonNode responseBody = response.getBody();

        if (response.getStatusCode().isError() || ObjectUtils.isEmpty(responseBody)) {
            throw BdbExceptionFactory.createExcepcion(response.getStatusCode(), identityNumber, "Error " +
                    "getSavingsAccountInfo " + acctId);
        }

        List<AcctBalType> childList = new ArrayList<>();

        for (Object obj : responseBody) {
            childList.add(objectMapper.convertValue(obj, AcctBalType.class));
        }

        return childList;
    }

    private void setDebitOrder(String identityNumber, String acctId, BigDecimal amountDebts, String branchId, String rqUid) throws AbsBdbServiceException {
        log.info("({}) [2] CONDONATION - setDebitOrder ({})", identityNumber, acctId);
        SetDebitOrderRequestDto setDebitOrderRequestDto = new SetDebitOrderRequestDto();
        setDebitOrderRequestDto.setAcctId(acctId);
        setDebitOrderRequestDto.setAmt(amountDebts);
        setDebitOrderRequestDto.setBranchId(branchId);
        setDebitOrderRequestDto.setRqUid(rqUid);

        UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromUriString(endpointAccountsAdapter).path(DEBIT_ORDER_RESOURCE);

        ResponseEntity<JsonNode> response = restExchange.exchange(urlBuilder.toUriString(), setDebitOrderRequestDto,
                HttpMethod.POST, JsonNode.class);

        if (response.getStatusCode().isError()) {
            throw BdbExceptionFactory.createExcepcion(response.getStatusCode(), identityNumber, "Error " +
                    "setDebitOrder " + acctId);
        }
    }

    private boolean forgivenDebts(String identityNumber, String identityType) {
        log.info("({}) [3] CONDONATION - Forgiven Debs", identityNumber);
        ForgivenDebtsDto forgivenDebtsDto = new ForgivenDebtsDto();
        forgivenDebtsDto.setDate(DateTimeFormatter.ofPattern("dd/MM/yyyy").format(LocalDateTime.now()));
        forgivenDebtsDto.setIdentityNumber(identityNumber);
        forgivenDebtsDto.setIdentityType(identityType);

        UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromUriString(endpointAccountsAdapter).path(FORGIBEN_DEBTS_RESOURCE);

        ResponseEntity<JsonNode> response = restExchange.exchange(urlBuilder.toUriString(), forgivenDebtsDto, HttpMethod.POST, JsonNode.class);

        if (response.getStatusCode().isError()) {
            log.info("({}) [3] CONDONATION - Forgiven Debs. FAIL <<<", identityNumber);
        }

        return response.getStatusCode().is2xxSuccessful();
    }
}
