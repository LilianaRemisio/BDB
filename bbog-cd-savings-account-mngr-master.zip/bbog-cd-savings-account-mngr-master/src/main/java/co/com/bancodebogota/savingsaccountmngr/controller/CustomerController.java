package co.com.bancodebogota.savingsaccountmngr.controller;

import co.com.bancodebogota.dto.balanceinquiry.AccInfoDto;
import co.com.bancodebogota.dto.customer.CustomerStatusDto;
import co.com.bancodebogota.dto.customer.DigitalAccountRsDto;
import co.com.bancodebogota.dto.products.AcctBasicInfoType;
import co.com.bancodebogota.dto.products.ProductDto;
import co.com.bancodebogota.dto.responsereactivation.ReactivationRsDto;
import co.com.bancodebogota.dto.responsereactivation.ReactivationRspDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.savingsaccountmngr.service.customer.ICustomerService;
import co.com.bancodebogota.savingsaccountmngr.service.customer.ICustomerServiceV2;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("savings")
@RequiredArgsConstructor
public class CustomerController {

    private final ICustomerService customerService;
    private final ICustomerServiceV2 customerServiceV2;

    @GetMapping("/participant/info")
    public ResponseEntity<JsonNode> customerInfo(@RequestHeader HttpHeaders httpHeaders)
            throws AbsBdbServiceException {

        JsonNode response = customerService.getCustomerInfo(httpHeaders);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/products")
    public ResponseEntity<List<ProductDto>> getProduct(@RequestHeader HttpHeaders httpHeaders) throws AbsBdbServiceException {
        List<ProductDto> productDto = customerService.getProducts(httpHeaders);
        return new ResponseEntity<>(productDto, HttpStatus.OK);
    }

    @GetMapping("/products/status")
    public ResponseEntity<CustomerStatusDto> productsStatus(@RequestHeader HttpHeaders httpHeaders,
                                                            @RequestParam String accountType) throws AbsBdbServiceException {

        CustomerStatusDto customerStatusDto = customerServiceV2.getProductsStatus(httpHeaders, accountType);
        return new ResponseEntity<>(customerStatusDto, HttpStatus.OK);
    }

    @GetMapping("/participant/digital")
    public ResponseEntity<DigitalAccountRsDto> customerHasDigitalAccount(@RequestHeader HttpHeaders httpHeaders)
            throws AbsBdbServiceException {

        DigitalAccountRsDto response = customerService.hasDigitalAccount(httpHeaders);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping("/products/inactive")
    public ResponseEntity<List<ProductDto>> getProductsInactive(@RequestHeader HttpHeaders httpHeaders) throws AbsBdbServiceException {
        List<ProductDto> productDto = customerService.getInactiveProducts(httpHeaders);
        return new ResponseEntity<>(productDto, HttpStatus.OK);
    }

    @PostMapping("/products/balance-inquiry")
    public ResponseEntity<AccInfoDto> getBalanceInquiry(@RequestHeader HttpHeaders httpHeaders, @RequestBody AcctBasicInfoType acctId) throws AbsBdbServiceException {
        AccInfoDto productDto = customerService.getBalanceInquiry(httpHeaders, acctId.getAcctId());
        return new ResponseEntity<>(productDto, HttpStatus.OK);
    }

    @PostMapping("/products/account/reactivation")
    public ResponseEntity<ReactivationRsDto> productReactivateAccount(@RequestHeader HttpHeaders httpHeaders, @RequestBody ReactivationRspDto reactivationRspDto) throws AbsBdbServiceException {
        ReactivationRsDto reactivateAccount = customerService.reactivateAccount(httpHeaders, reactivationRspDto);
        return new ResponseEntity<>(reactivateAccount, HttpStatus.CREATED);
    }
}
