package co.com.bancodebogota.savingsaccountmngr.service.accounts;

import co.com.bancodebogota.db.savings.dto.jpa.DisperserInformationDto;
import co.com.bancodebogota.db.savings.dto.jpa.DisperserRqDto;

public interface IPayrollService {

    DisperserInformationDto getAccountInformation(DisperserRqDto getDisperserRequest);
}
