package co.com.bancodebogota.savingsaccountmngr.service.customer;

import co.com.bancodebogota.dto.balanceinquiry.AccInfoDto;
import co.com.bancodebogota.dto.customer.ConsultCustomerRespDto;
import co.com.bancodebogota.dto.customer.DigitalAccountRsDto;
import co.com.bancodebogota.dto.products.ProductDto;
import co.com.bancodebogota.dto.responsereactivation.ReactivationRsDto;
import co.com.bancodebogota.dto.responsereactivation.ReactivationRspDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.http.HttpHeaders;

import java.util.List;

public interface ICustomerService {

    JsonNode getCustomerInfo(HttpHeaders httpHeaders) throws AbsBdbServiceException;

    ConsultCustomerRespDto getCustomerInfoFromBackend(String identityNumber, String rqUID, String channel, String userIp) throws AbsBdbServiceException;

    DigitalAccountRsDto hasDigitalAccount(String identityNumber, String rqUid, String channel, String xForwardedFor) throws AbsBdbServiceException;

    DigitalAccountRsDto hasDigitalAccount(HttpHeaders httpHeaders) throws AbsBdbServiceException;

    List<ProductDto> getProducts(HttpHeaders httpHeaders) throws AbsBdbServiceException;

    List<ProductDto> getInactiveProducts(HttpHeaders httpHeaders) throws AbsBdbServiceException;
    AccInfoDto getBalanceInquiry(HttpHeaders httpHeaders, String acctId) throws AbsBdbServiceException;
    ReactivationRsDto reactivateAccount(HttpHeaders httpHeaders, ReactivationRspDto reactivationRspDto) throws AbsBdbServiceException;
}
