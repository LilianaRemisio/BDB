package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.db.savings.dto.jpa.AddressDto;
import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountDto;
import co.com.bancodebogota.dto.account.AccountData;
import co.com.bancodebogota.dto.account.OpeningAccountDto;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.dispatcher.SellerDto;
import co.com.bancodebogota.dto.fatca.FatcaDto;
import co.com.bancodebogota.dto.masterdata.TutorOfficeDef;
import co.com.bancodebogota.dto.monitorplus.MonitorAccountCreateDto;
import co.com.bancodebogota.enums.EAccount;
import co.com.bancodebogota.enums.EChannel;
import co.com.bancodebogota.model.entities.FatcaEntity;
import co.com.bancodebogota.savingsaccountmngr.mapper.IAccountMapper;
import co.com.bancodebogota.savingsaccountmngr.service.masterdata.IMasterdataService;
import co.com.bancodebogota.savingsaccountmngr.utils.RequestUtilities;
import co.com.bancodebogota.utils.DataUtilities;
import co.com.bancodebogota.utils.TimeUtilities;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
@Service
public class AccountMapperImpl implements IAccountMapper {

    private final IMasterdataService masterdataService;
    private final RequestUtilities requestUtilities;

    @Override
    public CreateAccountDto mapOpeningAccountDto(OpeningAccountDto openingAccountDto, String identityNumber,
                                                 String identityType, String rqUuid, String channel) {

        CreateAccountDto createAccountDto = new CreateAccountDto();

        createAccountDto.setBbtipodoc(identityType);
        createAccountDto.setAanit(identityNumber);

        createAccountDto.setFirstname(openingAccountDto.getFirstName());
        createAccountDto.setMiddlename(openingAccountDto.getSecondName());
        createAccountDto.setLastname(openingAccountDto.getFirstLastName());
        createAccountDto.setSecondlastname(openingAccountDto.getSecondLastName());

        createAccountDto.setBirthdate(openingAccountDto.getBirthDt().substring(0, 10));
        createAccountDto.setSex(openingAccountDto.getGender());
        createAccountDto.setAacodciiu(openingAccountDto.getEconomicActivity());

        createAccountDto.setProductid(openingAccountDto.getAcctSubType());
        createAccountDto.setBbcodofi(openingAccountDto.getOfficeCode());
        createAccountDto.setBbcodoficinahs(openingAccountDto.getOfficeCode());
        createAccountDto.setBbcodctanom(openingAccountDto.getPayrollCode());

        createAccountDto.setTxInOffice(!EChannel.isTxInWeb(channel));
        createAccountDto.setChannel(channel);

        List<TutorOfficeDef> domicilesByPremiumOffice = new ArrayList<>();
        if (openingAccountDto.getSegCommercial() != null && openingAccountDto.getSegCommercial().equals("1578")) {
            domicilesByPremiumOffice = masterdataService.getDomicilesByPremiumOffice(openingAccountDto.getOfficeCode());
        }

        if (domicilesByPremiumOffice.isEmpty()) {
            createAccountDto.setBbcodceo("0000");
            createAccountDto.setBbcodoficinahs(openingAccountDto.getOfficeCode());
            createAccountDto.setBbcodofi(openingAccountDto.getOfficeCode());
        } else {
            createAccountDto.setBbcodceo(requestUtilities.getNextCeoCode(domicilesByPremiumOffice));
            createAccountDto.setBbcodoficinahs(domicilesByPremiumOffice.get(0).getCode());
            createAccountDto.setBbcodofi(domicilesByPremiumOffice.get(0).getCode());
        }

        createAccountDto.setBbcodvendedor(openingAccountDto.getOfficeCodeSeller());

        String ceoCode = StringUtils.defaultIfEmpty(openingAccountDto.getCeoCode(), "0000");
        createAccountDto.setBbcodceo(ceoCode.substring(0, 4));

        createAccountDto.setBbnumterm("DIGITAL");
        createAccountDto.setBbenvioextracto("M");

        createAccountDto.setBbtitularidad("");
        createAccountDto.setBbtiporetencion("3");

        // Unused in adapter
        AddressDto addressDto = new AddressDto();
        addressDto.setAddress1("a1");
        addressDto.setBbpurposedir1("32");
        addressDto.setCity("5001000");
        createAccountDto.setA1(addressDto);
        createAccountDto.setNewClient(false);
        createAccountDto.setNewCard(0);
        createAccountDto.setGmf(0);

        return createAccountDto;
    }

    @Override
    public MonitorAccountCreateDto mapMonitorAccountCreate(OpeningAccountDto openingAccountDto, String accountNumber, String channel) {

        MonitorAccountCreateDto monitorAccountCreateDto = new MonitorAccountCreateDto();

        monitorAccountCreateDto.setAccountNumber(accountNumber);
        monitorAccountCreateDto.setIdentityNumber(openingAccountDto.getIdentityNumber());
        monitorAccountCreateDto.setChannel(channel);
        monitorAccountCreateDto.setEmail(openingAccountDto.getEmailAddr());
        monitorAccountCreateDto.setFirstName(openingAccountDto.getFirstName());
        monitorAccountCreateDto.setMiddleName(openingAccountDto.getSecondName());
        monitorAccountCreateDto.setLastName(openingAccountDto.getFirstLastName());
        monitorAccountCreateDto.setSecondLastName(openingAccountDto.getSecondLastName());
        monitorAccountCreateDto.setGender(openingAccountDto.getGender());
        monitorAccountCreateDto.setCellphone(openingAccountDto.getPhoneNumber());
        monitorAccountCreateDto.setOfficeCode(openingAccountDto.getOfficeCode());
        monitorAccountCreateDto.setTxInWeb(EChannel.isTxInWeb(channel));
        monitorAccountCreateDto.setPayrollCode(openingAccountDto.getPayrollCode());
        monitorAccountCreateDto.setSellerId(openingAccountDto.getOfficeCodeSeller());

        return monitorAccountCreateDto;
    }

    @Override
    public FatcaEntity mapFatcaEntity(FatcaDto fatca, String identityType, String identityNumber, String clientName, String officeCode) {
        FatcaEntity fatcaEntity = new FatcaEntity();

        fatcaEntity.setIdentityType(identityType);
        fatcaEntity.setIdentityNumber(identityNumber);
        fatcaEntity.setClientName(clientName);
        fatcaEntity.setNationality("Colombiano");
        fatcaEntity.setProductCreationDate(TimeUtilities.actualDate());

        fatcaEntity.setBirthPlace(fatca.getBirthPlace());
        fatcaEntity.setFiscalResidence1(fatca.getFiscalResidence1());
        fatcaEntity.setTin1(fatca.getTin1());
        fatcaEntity.setFiscalResidence2(fatca.getFiscalResidence2());
        fatcaEntity.setTin2(fatca.getTin2());
        fatcaEntity.setBranchId(officeCode);

        return fatcaEntity;
    }

    @Override
    public BankAccountDto mapBankAccountForDB(AccountData accountData, DispatcherDto dispatcherDto) {

        BankAccountDto bankAccountDto = new BankAccountDto();
        OpeningAccountDto openingAccountDto = accountData.getOpeningAccount();
        JsonNode specificProductInfo = dispatcherDto.getSpecificProductInfo();

        bankAccountDto.setRequestId(accountData.getGmf().getRequestId());
        bankAccountDto.setFirstName(openingAccountDto.getFirstName());
        bankAccountDto.setMiddleName(openingAccountDto.getSecondName());
        bankAccountDto.setLastName(openingAccountDto.getFirstLastName());
        bankAccountDto.setSecondLastName(openingAccountDto.getSecondLastName());
        bankAccountDto.setGender(openingAccountDto.getGender());
        bankAccountDto.setCellphone(openingAccountDto.getPhoneNumber());
        bankAccountDto.setEmail(openingAccountDto.getEmailAddr());
        bankAccountDto.setCrmAddress(accountData.getPostalAddress());
        bankAccountDto.setJobActivityId(openingAccountDto.getEconomicActivity());
        bankAccountDto.setOccupationId(NumberUtils.createInteger(openingAccountDto.getOccupationId()));
        bankAccountDto.setMonthlyIncome(openingAccountDto.getMonthlyIncome());
        bankAccountDto.setMonthlyOutcome(openingAccountDto.getMonthlyOutcome());
        bankAccountDto.setFatca(accountData.getFatca().getFiscalResidence1());
        bankAccountDto.setLivingCityId(accountData.getFatca().getBirthPlace());
        bankAccountDto.setOfficeCode(accountData.getOpeningAccount().getOfficeCode());
        bankAccountDto.setEthnicGroup(accountData.getOpeningAccount().getEthnicGroup());

        bankAccountDto.setCeoCode(accountData.getOpeningAccount().getCeoCode());

        bankAccountDto.setDeliveryAddress(accountData.getPostalAddress());
        bankAccountDto.setAddressForCRM(accountData.getPostalAddress());
        bankAccountDto.setCodCity(accountData.getFatca().getBirthPlace());

        bankAccountDto.setCheckGmf(accountData.getGmf().isCheckGmf());
        bankAccountDto.setCheckPensioner(EAccount.PENSIONADO.getCode().equals(openingAccountDto.getAcctSubType()));

        bankAccountDto.setTxInWeb(EChannel.isTxInWeb(dispatcherDto.getChannel()));
        bankAccountDto.setProductId(openingAccountDto.getAcctSubType());
        bankAccountDto.setCodNomina(openingAccountDto.getPayrollCode());
        bankAccountDto.setEmployeeNit(DataUtilities.getNodeAsText(specificProductInfo, "companyNitPayroll"));
        bankAccountDto.setNameCompany(DataUtilities.getNodeAsText(specificProductInfo, "companyNamePayroll"));

        SellerDto sellerDto = dispatcherDto.getSeller();
        bankAccountDto.setSellerId(ObjectUtils.isEmpty(sellerDto) ?
                accountData.getOpeningAccount().getOfficeCodeSeller() : sellerDto.getSellerIdentityNumber());

        return bankAccountDto;
    }
}
