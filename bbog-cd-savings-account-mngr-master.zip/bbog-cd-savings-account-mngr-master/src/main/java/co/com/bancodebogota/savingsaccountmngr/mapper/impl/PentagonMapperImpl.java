package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.dto.pentagon.EventDataDto;
import co.com.bancodebogota.dto.products.ProductDto;
import co.com.bancodebogota.savingsaccountmngr.mapper.IPentagonMapper;
import co.com.bancodebogota.utils.JacksonUtilsV2;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PentagonMapperImpl implements IPentagonMapper {
    private static final String IS_CLIENT = "Active Client";
    private static final String JOURNEY = "ReactivacionWeb";
    private static final String CONOCIMIENTO_DE_CLIENTE = "ConocimientoDeCliente";

    @Override
    public EventDataDto mapCreateDigitalRequest(Long digitalId, int status, String message) {
        ObjectNode payload = JsonNodeFactory.instance.objectNode();
        payload.put("digitalRequest", digitalId);
        payload.put("status", status);
        payload.put("message", message);

        return mapEventData("CreacionDigRequest", CONOCIMIENTO_DE_CLIENTE, payload);
    }

    @Override
    public EventDataDto mapInactiveProducts(List<ProductDto> inactiveProducts){
        List<ObjectNode> accountsInfo = inactiveProducts.stream().map(inactiveProduct -> {
            ObjectNode accountInfo = JsonNodeFactory.instance.objectNode();
            accountInfo.put("accountNumber", inactiveProduct.getProductId());
            accountInfo.put("accountType", inactiveProduct.getAcctSubType());
            return accountInfo;
        }).toList();

        ObjectNode payload = JsonNodeFactory.instance.objectNode();
        ArrayNode inactiveAccounts = payload.putArray("inactiveAccounts");
        inactiveAccounts.addAll(accountsInfo);

        return mapEventData("ConsultaProductosBanco", CONOCIMIENTO_DE_CLIENTE, payload);
    }

    @Override
    public EventDataDto mapReactivateAccount(boolean isReactivated){
        ObjectNode payload = JsonNodeFactory.instance.objectNode();
        payload.put("isReactivated", isReactivated);

        return mapEventData("ReactivacionDelProducto", "Contrato", payload);
    }

    private EventDataDto mapEventData(String step, String milestone, ObjectNode payload){
        EventDataDto eventData = new EventDataDto();

        eventData.setEventName(String.format("Event-CuentaDeAhorros-%s-%s-%s", JOURNEY, milestone, step));
        eventData.setPayload(JacksonUtilsV2.getPlainJson(payload));
        eventData.setMilestone(milestone);
        eventData.setIsClient(IS_CLIENT);
        eventData.setJourney(JOURNEY);
        eventData.setStep(step);
        return eventData;
    }
}
