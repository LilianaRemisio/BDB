package co.com.bancodebogota.savingsaccountmngr.utils.impl;

import co.com.bancodebogota.dto.masterdata.TutorOfficeDef;
import co.com.bancodebogota.enums.EChannel;
import co.com.bancodebogota.model.repositories.AccountLogRepository;
import co.com.bancodebogota.model.repositories.ChannelRepository;
import co.com.bancodebogota.savingsaccountmngr.utils.RequestUtilities;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class RequestUtilitiesImpl implements RequestUtilities {

	private final AccountLogRepository accountLogRepository;
	private final ChannelRepository channelRepository;

	@Override
	public String getNextCeoCode(List<TutorOfficeDef> tutorOfficeDefList) {
		String newCeoCode = null;

		String lastCeoCode = accountLogRepository.findLastCeoCode(tutorOfficeDefList.get(0).getCode());

		if (lastCeoCode == null || tutorOfficeDefList.get(tutorOfficeDefList.size() - 1).getDomicileCode().equals(lastCeoCode)) {
			log.info("There is not an account with that code or it is the last. Domicile code {} will be used", tutorOfficeDefList.get(0).getDomicileCode());
			return tutorOfficeDefList.get(0).getDomicileCode();
		}

		for (TutorOfficeDef tutorOfficeDef : tutorOfficeDefList) {
			if (tutorOfficeDef.getDomicileCode().equals(lastCeoCode)) {
				log.info("{} matched. Next domicile code is {}", tutorOfficeDef.getDomicileCode(), tutorOfficeDefList.get(tutorOfficeDefList.indexOf(tutorOfficeDef) + 1).getDomicileCode());
				newCeoCode = tutorOfficeDefList.get(tutorOfficeDefList.indexOf(tutorOfficeDef) + 1).getDomicileCode();
			}
		}
		return newCeoCode;
	}

	public int getChannelFromLauncher(String mediumType, String channel) {
		int result;

		if (channel.equals("BM") || channel.equals("WEB") || channel.equals("OPB001") || channel.equals("MFZ") || channel.equals("BancaVirtual") || mediumType == null) {
			result = channelRepository.findChannelIdByDescription(channel).getId();
		} else {
			result = mediumType.equals("3") ? 4 : 1;
		}

		return result;
	}

    public String validateOpbChannel(String channel, EChannel channelType) {
        return EChannel.isOPB(channel) ? channelType.getDescription() : channel;
    }
}
