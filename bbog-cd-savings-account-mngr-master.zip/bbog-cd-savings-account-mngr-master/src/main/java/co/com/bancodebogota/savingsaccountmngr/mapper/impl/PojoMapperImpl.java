package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.enums.EIdentificationType;
import co.com.bancodebogota.utils.JacksonUtilsV2;
import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.dto.customer.*;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.savingsaccountmngr.mapper.IPojoMapper;
import co.com.bancodebogota.utils.DataUtilities;
import co.com.bancodebogota.utils.TimeUtilities;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class PojoMapperImpl implements IPojoMapper {

    private static final String MVP_NATIONALITY = "COL";
    private static final String MVP_STATE_PROV = "BOG";
    private static final String MVP_CUR_CODE = "COP";
    private static final String MVP_ADDR_TYPE = "34"; //Tipo de direccion 34-Residencia
    private static final String MVP_EDU_LEVEL = "2"; //Nivel de educacion 2-Secundaria
    private static final String MVP_MARITAL_STATUS = "S"; //Estado civil S: Soltero
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public ConsultCustomerRespDto mapConsultCustomerRespDto(CustomerManagementRs response) {
        ConsultCustomerRespDto consultCustomerRespDto = new ConsultCustomerRespDto();

        CustInfo custInfo = response.getCustInfo();
        Identification custId = custInfo.getCustId().get(0);

        PersonInfo personInfo = custInfo.getPersonInfo();
        PersonName personName = personInfo.getPersonName();
        String expDt = custId.getIssDt();
        FinancialData financialData = custInfo.getFinancialData();
        ContactInfo contactInfo = personInfo.getContactInfo().get(0);
        PostAddr postAddr = contactInfo.getPostAddr();
        Employment employment = personInfo.getEmployment().get(0);

        consultCustomerRespDto.setFirstName(StringUtils.defaultString(personName.getFirstName(), ""));
        consultCustomerRespDto.setMiddleName(StringUtils.defaultString(personName.getMiddleName(), ""));
        consultCustomerRespDto.setLastName(StringUtils.defaultString(personName.getLastName(), ""));
        consultCustomerRespDto.setSecondLastName(StringUtils.defaultString(personName.getSecondLastName(), ""));
        consultCustomerRespDto.setBirthDate(StringUtils.defaultString(personInfo.getBirthDt(), ""));

        consultCustomerRespDto.setExpeditionDate(expDt != null ? expDt : "");
        consultCustomerRespDto.setExpeditionCityId(StringUtils.defaultString(custId.getExpeditionPlace(), ""));

        consultCustomerRespDto.setEmail(StringUtils.defaultString(contactInfo.getEmailAddr(), ""));
        consultCustomerRespDto.setCellphone(StringUtils.defaultString(contactInfo.getPhoneNum().getPhone(), ""));
        consultCustomerRespDto.setSex(personInfo.getGender() != null ? personInfo.getGender() : "");
        consultCustomerRespDto.setNationality(StringUtils.defaultString(personInfo.getNationality(), ""));
        consultCustomerRespDto.setCodOcupation(employment.getOccupationCode() != null ? employment.getOccupationCode() : 0);
        consultCustomerRespDto.setCodCiuu(StringUtils.defaultString(employment.getEmploymentId(), ""));
        consultCustomerRespDto.setValActivos(financialData.getTotalAssests().getCurAmt().getAmt() != null ?
                financialData.getTotalAssests().getCurAmt().getAmt().toString() : "");
        consultCustomerRespDto.setValEgresos(financialData.getExpenses() != null ? financialData.getExpenses().toString() : "");
        consultCustomerRespDto.setValIngresos(financialData.getIncome() != null ? financialData.getIncome().toString() : "");

        consultCustomerRespDto.setValPasivos(financialData.getTotalLiabilities().getCurAmt().getAmt() != null ?
                financialData.getTotalLiabilities().getCurAmt().getAmt().toString() : "");
        consultCustomerRespDto.setCodCity(StringUtils.defaultString(postAddr.getCityId(), ""));
        consultCustomerRespDto.setRepCostos(StringUtils.defaultString(financialData.getCostsReport(), ""));
        consultCustomerRespDto.setAddress1(StringUtils.defaultString(postAddr.getAddr1(), ""));
        consultCustomerRespDto.setPurposeAddress1(StringUtils.defaultString(postAddr.getAddrType(), ""));
        consultCustomerRespDto.setSegComercial(StringUtils.defaultString(custInfo.getComercialSeg(), "620"));

        return consultCustomerRespDto;
    }

    @Override
    public ObjectNode mapCustInfoPojo(BankAccountDto bankAccountDto, String authUuid) throws AbsBdbServiceException {
        ObjectNode jsonCustInfo;
        try {
            log.info(">>> ({}) MAP CUST INFO POJO. NEW CALL >>>", bankAccountDto.getIdentityNumber());

            jsonCustInfo = objectMapper.createObjectNode();

            jsonCustInfo.putPOJO("PersonInfo", mapPersonInfoPojo(bankAccountDto));

            jsonCustInfo.putPOJO("FinancialData", mapFinancialDataPojo(bankAccountDto));

            jsonCustInfo.put("Effdt", TimeUtilities.getCurrentDateInFormat("yyyy-MM-dd"));
            jsonCustInfo.put("Bbblock", "0");
            jsonCustInfo.put("ComercialSeg", bankAccountDto.getSegcomercial());

            jsonCustInfo.putPOJO("CustId", mapIdentificationPojo(EIdentificationType.CEDULA_CIUDADANIA.getBdbType(), bankAccountDto.getIdentityNumber(), bankAccountDto.getExpeditionCityId()));

            log.info("<<< ({}) MAP CUST INFO POJO. SUCCESSFUL END <<<", bankAccountDto.getIdentityNumber());
        } catch (Exception e) {
            log.info("<<< ({}) MAP CUST INFO POJO. ERROR - {} <<<", bankAccountDto.getIdentityNumber(), JacksonUtilsV2.getPlainJson(bankAccountDto));
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, "", "Error mapping custInfo from bankAccountDto");
        }
        return jsonCustInfo;
    }

    private PersonInfo mapPersonInfoPojo(BankAccountDto bankAccountDto) {
        PersonInfo personInfo = new PersonInfo();

        personInfo.setPersonName(mapPersonNamePojo(bankAccountDto));

        personInfo.setContactInfo(mapContactInfoPojo(bankAccountDto));

        personInfo.setTinInfo(mapTinInfoPojo());

        personInfo.setBirthDt(TimeUtilities.changeFrontToBackFormat(bankAccountDto.getBirthDate()));
        Integer bornCityId = bankAccountDto.getBornCityId();
        personInfo.setBirthPlace(bornCityId != null ? bornCityId.toString() : "");

        personInfo.setDriversLicense(mapDriversLicensePojo());

        personInfo.setSpouseName("");
        personInfo.setGender(bankAccountDto.getGender());
        personInfo.setMaritalStatus(MVP_MARITAL_STATUS);
        personInfo.setDependents(0);
        personInfo.setTaxPayerInd(false);
        personInfo.setNationality(MVP_NATIONALITY);
        personInfo.setEducationalLevel(MVP_EDU_LEVEL);
        personInfo.setFatca(StringUtils.defaultString(bankAccountDto.getFatca(), MVP_NATIONALITY));

        personInfo.setEmployment(mapEmploymentPojo(bankAccountDto.getOccupationId(), bankAccountDto.getJobActivityId()));
        return personInfo;
    }

    private PersonName mapPersonNamePojo(BankAccountDto bankAccountDto) {
        PersonName personName = new PersonName();

        personName.setFirstName(DataUtilities.removeAccents(bankAccountDto.getFirstName()));
        personName.setMiddleName(DataUtilities.removeAccents(bankAccountDto.getMiddleName()));
        personName.setLastName(DataUtilities.removeAccents(bankAccountDto.getLastName()));
        personName.setSecondLastName(DataUtilities.removeAccents(bankAccountDto.getSecondLastName()));
        personName.setTitlePrefix("");
        personName.setNameSuffix("");
        personName.setNickname("");
        personName.setLegalName("");
        personName.setFullName("");

        return personName;
    }

    private List<ContactInfo> mapContactInfoPojo(BankAccountDto bankAccountDto) {

        List<ContactInfo> contactInfos = new ArrayList<>();

        ContactInfo contactInfo = new ContactInfo();
        contactInfo.setContactPref("");
        contactInfo.setPrefTimeStart("");
        contactInfo.setPrefTimeEnd("");

        contactInfo.setPhoneNum(mapPhoneNumPojo("12", "", "",
                DataUtilities.removeCellphoneMask(bankAccountDto.getCellphone())));

        contactInfo.setContactName(DataUtilities.removeAccents(bankAccountDto.getFirstName()) + " " +
                DataUtilities.removeAccents(bankAccountDto.getLastName()));

        contactInfo.setEmailAddr(bankAccountDto.getEmail() != null && !bankAccountDto.getEmail().equals("") ?
                bankAccountDto.getEmail() : " ");
        contactInfo.setUrl("");

        contactInfo.setActivationPhone(mapActivationPhonePojo("12", "", "",
                DataUtilities.removeCellphoneMask(bankAccountDto.getCellphone())));

        contactInfo.setPostAddr(mapPostAddrPojo(StringUtils.defaultString(bankAccountDto.getCrmAddress(),
                        bankAccountDto.getAddressForCRM()),
                StringUtils.defaultString(bankAccountDto.getLivingCityId(), bankAccountDto.getCodCity()),
                MVP_NATIONALITY));

        contactInfo.setContactStatus("");

        contactInfos.add(contactInfo);
        return contactInfos;
    }

    private PhoneNum mapPhoneNumPojo(String phoneType, String dialingCode, String areaDialingCode, String phone) {
        PhoneNum phoneNum = new PhoneNum();

        phoneNum.setPhoneType(phoneType);
        phoneNum.setDialingCode(dialingCode);
        phoneNum.setAreaDialingCode(areaDialingCode);
        phoneNum.setPhone(StringUtils.defaultString(phone, ""));

        return phoneNum;
    }

    private ActivationPhone mapActivationPhonePojo(String phoneType, String dialingCode, String areaDialingCode,
                                                   String phone) {
        ActivationPhone activationPhone = new ActivationPhone();

        activationPhone.setPhoneNum(mapPhoneNumPojo(phoneType, dialingCode, areaDialingCode, phone));

        return activationPhone;
    }

    private PostAddr mapPostAddrPojo(String addr1, String cityId, String country) {
        PostAddr postAddr = new PostAddr();
        postAddr.setAddr1(addr1);
        postAddr.setCity("");
        postAddr.setCityId(cityId.substring(2, 5));
        postAddr.setStateProv(cityId.substring(0, 2));
        postAddr.setPostalCode("");
        postAddr.setCountry(country);
        postAddr.setAddrType(MVP_ADDR_TYPE);

        return postAddr;
    }

    private TINInfo mapTinInfoPojo() {
        TINInfo tinInfo = new TINInfo();
        tinInfo.setCertCode("");
        tinInfo.setTaxId("");
        tinInfo.setTinType("");

        return tinInfo;
    }

    private DriversLicense mapDriversLicensePojo() {
        DriversLicense driversLicense = new DriversLicense();
        driversLicense.setLicenseNum("");
        driversLicense.setStateProv(MVP_STATE_PROV);
        driversLicense.setCountry(MVP_NATIONALITY);

        return driversLicense;
    }

    private List<Employment> mapEmploymentPojo(Integer occupationId, String employmentId) {
        List<Employment> employments = new ArrayList<>();

        Employment employment = new Employment();
        employment.setOccupation("");
        employment.setOccupationCode(occupationId);
        employment.setEmploymentId(employmentId);

        employments.add(employment);
        return employments;
    }

    private FinancialData mapFinancialDataPojo(BankAccountDto bankAccountDto) {
        FinancialData financialData = new FinancialData();

        financialData.setEconomicStatus("");
        financialData.setEconomicActivity("");
        financialData.setDescEconomicActivity("");
        financialData.setExpenses(getBigDecimalValue(bankAccountDto.getMonthlyOutcome()));
        financialData.setIncome(getBigDecimalValue(bankAccountDto.getMonthlyIncome()));
        financialData.setTotalLiabilities(mapTotalLiabilitiesPojo(Integer.parseInt(bankAccountDto.getTotalDebts())));
        financialData.setTotalAssests(mapTotalAssetsPojo(Integer.parseInt(bankAccountDto.getTotalAssets())));
        financialData.setCostsReport("0");

        return financialData;
    }

    private CurAmt mapCurAmtPojo(int atm) {
        CurAmt curAmt = new CurAmt();
        curAmt.setAmt(BigDecimal.valueOf(atm));
        curAmt.setCurCode(MVP_CUR_CODE);
        curAmt.setCurRate(BigDecimal.valueOf(0));
        curAmt.setCurConvertRule("");

        return curAmt;
    }

    private TotalLiabilities mapTotalLiabilitiesPojo(int atm) {
        TotalLiabilities totalLiabilities = new TotalLiabilities();
        totalLiabilities.setCurAmt(mapCurAmtPojo(atm));

        return totalLiabilities;
    }

    private TotalAssests mapTotalAssetsPojo(int atm) {
        TotalAssests totalAssests = new TotalAssests();
        totalAssests.setCurAmt(mapCurAmtPojo(atm));

        return totalAssests;
    }

    private List<ObjectNode> mapIdentificationPojo(String identType, String identNumber, Integer expeditionPlace) {
        List<ObjectNode> custIds = new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode jsonRequest = mapper.createObjectNode();

        CustIdentType custIdentType = new CustIdentType();
        custIdentType.setValue(CustIdentType.ValueEnum.fromValue(identType));
        jsonRequest.putPOJO("CustIdentType", custIdentType);

        CustIdentNum custIdentNum = new CustIdentNum();
        custIdentNum.setValue(identNumber);
        jsonRequest.putPOJO("CustIdentNum", custIdentNum);

        jsonRequest.put("PassportCountry", "");
        jsonRequest.put("IssueLoc", "");
        jsonRequest.put("IssDt", TimeUtilities.getCurrentDateInFormat("yyyy-MM-dd"));
        if (expeditionPlace != null) {
            jsonRequest.put("ExpeditionPlace", expeditionPlace.toString());
        }
        custIds.add(jsonRequest);

        return custIds;
    }

    private BigDecimal getBigDecimalValue(String value) {
        return new BigDecimal(value);
    }
}
