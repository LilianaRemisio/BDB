package co.com.bancodebogota.savingsaccountmngr.service.request;

import co.com.bancodebogota.db.savings.dto.jpa.CheckTypeLogListDto;
import co.com.bancodebogota.dto.request.RequestCheckDto;
import co.com.bancodebogota.model.entitiesold.CheckType;

public interface ICheckLogService {

    boolean saveCheckLog(String documentType, String identityNumber, String accountNumber, Long requestId, String uuid, CheckTypeLogListDto checkTypeLogListDto);

    CheckType getCheckTypeById(Integer idCheckType);

    boolean saveRequestCheckLog(RequestCheckDto requestCheck);
}
