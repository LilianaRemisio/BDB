package co.com.bancodebogota.savingsaccountmngr.service.fatca;

import co.com.bancodebogota.model.entities.FatcaEntity;

public interface IFatcaService {

    boolean saveFatcaInfo(FatcaEntity fatcaEntity);
}
