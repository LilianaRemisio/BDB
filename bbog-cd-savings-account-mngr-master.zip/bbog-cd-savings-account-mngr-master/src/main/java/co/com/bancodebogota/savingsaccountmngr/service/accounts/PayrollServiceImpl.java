package co.com.bancodebogota.savingsaccountmngr.service.accounts;

import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.db.savings.dto.jpa.DisperserInformationDto;
import co.com.bancodebogota.db.savings.dto.jpa.DisperserRqDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

@Slf4j
@Service
@RequiredArgsConstructor
public class PayrollServiceImpl implements IPayrollService {

    private final RestExchangeV2 restExchange;

    @Value("${endpoint.accounts.adapter}")
    private String endpointAccountsAdapter;

    private static final String DISPERSER_ACCOUNT_RESOURCE = "/disperser-accounts";

    @Override
    public DisperserInformationDto getAccountInformation(DisperserRqDto getDisperserRequest) {
        UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromUriString(endpointAccountsAdapter)
                .path(DISPERSER_ACCOUNT_RESOURCE)
                .queryParam("accountOffice", getDisperserRequest.getAccountOffice())
                .queryParam("identityNumber", getDisperserRequest.getIdentityNumber())
                .queryParam("identityType", getDisperserRequest.getIdentityType())
                .queryParam("accountType", getDisperserRequest.getAccountType())
                .queryParam("accountNumber", getDisperserRequest.getAccountNumber());

        ResponseEntity<DisperserInformationDto> response = restExchange.exchange(urlBuilder.toUriString(), null,
                HttpMethod.GET, DisperserInformationDto.class);
        return response.getBody();
    }
}
