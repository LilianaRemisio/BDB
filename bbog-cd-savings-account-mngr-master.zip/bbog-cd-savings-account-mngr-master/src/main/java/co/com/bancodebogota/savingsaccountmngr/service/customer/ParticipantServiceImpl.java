package co.com.bancodebogota.savingsaccountmngr.service.customer;

import co.com.bancodebogota.utils.JacksonUtilsV2;
import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountDto;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class ParticipantServiceImpl implements IParticipantService {

    private static final String DISPATCHER_RESOURCE = "/participant/dispatcher";

    @Value("${customer.mngr.endpoint}")
    private String customerMngrEndpoint;

    private final RestExchangeV2 restExchange;

    @Override
    public CreateAccountDto getParticipantInfo(String uuid) {
        CreateAccountDto createAccountDto = null;
        ObjectMapper mapper = new ObjectMapper();

        UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromUriString(customerMngrEndpoint)
                .path(DISPATCHER_RESOURCE)
                .queryParam("uuid", uuid);
        ResponseEntity<JsonNode> restResponse = restExchange.exchange(urlBuilder.toUriString(), null, HttpMethod.GET, JsonNode.class);

        JsonNode responseBody = Objects.requireNonNull(restResponse).getBody();

        if (responseBody != null && !"NOT_FOUND".equals(responseBody.get("statusCode").asText())) {
            createAccountDto = mapper.convertValue(responseBody.get("participantDispatcherDto"), CreateAccountDto.class);
            log.info("PARTICIPANT INFO {}", JacksonUtilsV2.getPlainJson(createAccountDto));
        }

        return createAccountDto;
    }
}
