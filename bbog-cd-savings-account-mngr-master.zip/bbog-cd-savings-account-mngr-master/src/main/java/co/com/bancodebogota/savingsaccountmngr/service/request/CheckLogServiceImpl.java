package co.com.bancodebogota.savingsaccountmngr.service.request;

import co.com.bancodebogota.db.savings.dto.jpa.CheckTypeLogListDto;
import co.com.bancodebogota.dto.request.RequestCheckDto;
import co.com.bancodebogota.enums.EEventType;
import co.com.bancodebogota.model.entities.RequestCheckEntity;
import co.com.bancodebogota.model.entitiesold.CheckType;
import co.com.bancodebogota.model.repositories.CheckTypeRepository;
import co.com.bancodebogota.model.repositories.RequestCheckRepository;
import co.com.bancodebogota.proxy.CheckLogsProxy;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class CheckLogServiceImpl implements ICheckLogService {

    private final CheckTypeRepository checkTypeRepository;
    private final CheckLogsProxy checkLogsProxy;
    private final IRequestService requestService;
    private final RequestCheckRepository requestCheckRepository;

    @Override
    public boolean saveCheckLog(String documentType, String identityNumber, String accountNumber, Long requestId,
                                String uuid, CheckTypeLogListDto checkTypeLogListDto) {

        checkTypeLogListDto.setIdentityNumber(identityNumber);
        checkLogsProxy.saveCheckType(checkTypeLogListDto);
        checkTypeLogListDto.setIdentityNumber(accountNumber);
        checkLogsProxy.saveCheckAccountType(checkTypeLogListDto);
        requestService.saveRequestEvent(requestId, EEventType.CHECK_CHECK_LOG_EXITOSO, identityNumber);
        return true;
    }

    @Override
    public CheckType getCheckTypeById(Integer idCheckType) {
        return checkTypeRepository.findById(idCheckType).orElse(new CheckType());
    }

    @Override
    public boolean saveRequestCheckLog(RequestCheckDto requestCheck) {
        long requestId = requestCheck.getRequestId();
        log.info(">>> ({}) SAVE REQUEST CHECK. NEW CALL >>>", requestId);

        RequestCheckEntity requestCheckEntity = requestCheckRepository.findByRequestId(requestId);

        if (Objects.isNull(requestCheckEntity)) {
            requestCheckEntity = new RequestCheckEntity();
            requestCheckEntity.setRequestId(requestCheck.getRequestId());
        }

        requestCheckEntity.setChecks(requestCheck.getChecks());
        try {
            requestCheckRepository.save(requestCheckEntity);
            log.info("<<< ({}) SAVE REQUEST CHECK. END <<<", requestId);
            return true;
        } catch (Exception e) {
            log.error("<<< ({}) ERROR SAVING REQUEST CHECKS {} <<<", requestId, e.getMessage());
        }
        return false;
    }
}
