package co.com.bancodebogota.savingsaccountmngr.service.pentagon;

import co.com.bancodebogota.dto.pentagon.EventDataDto;
import org.springframework.http.HttpHeaders;

public interface IEventPentagonService {
    boolean sendEvent(HttpHeaders httpHeaders, EventDataDto eventDataDto);
}
