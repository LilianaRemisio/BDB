package co.com.bancodebogota.savingsaccountmngr.service.facebookconvertions;

import co.com.bancodebogota.dto.account.AccountData;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import org.springframework.http.HttpHeaders;

public interface IReportMarketingService {

    Boolean sendNewAccountCreateFacebook(AccountData accountData, DispatcherDto dispatcherDto, HttpHeaders httpHeaders);
}
