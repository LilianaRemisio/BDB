package co.com.bancodebogota.savingsaccountmngr.mapper;

import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.dto.customer.ConsultCustomerRespDto;
import co.com.bancodebogota.dto.customer.CustomerManagementRs;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import com.fasterxml.jackson.databind.node.ObjectNode;

public interface IPojoMapper {

    ConsultCustomerRespDto mapConsultCustomerRespDto(CustomerManagementRs response);

    ObjectNode mapCustInfoPojo(BankAccountDto bankAccountDto, String authUuid) throws AbsBdbServiceException;
}