package co.com.bancodebogota.savingsaccountmngr.service.masterdata;

import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.dto.masterdata.TutorOfficeDef;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class MasterdataServiceImpl implements IMasterdataService {

    @Value("${masterdata.public.api.endpoint}")
    private String masterdataPublicApiEndpoint;

    private final RestExchangeV2 restExchange;

    private static final String GET_TUTOR_OFFICES = "/V1/Utilities/mdm/premiumOffices/%s/tutorOffices";

    @Override
    public List<TutorOfficeDef> getDomicilesByPremiumOffice(String premiumCode) {

        List<TutorOfficeDef> tutorOfficeDtoList = new ArrayList<>();

        try {
            HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.add("X-Name", "CuentaDeAhorros");

            UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromUriString(masterdataPublicApiEndpoint)
                            .path(String.format(GET_TUTOR_OFFICES, premiumCode));

            ResponseEntity<TutorOfficeDef[]> response = restExchange.exchange(urlBuilder.toUriString(), null, HttpMethod.GET, httpHeaders, TutorOfficeDef[].class);
            tutorOfficeDtoList.addAll(Arrays.stream(Objects.requireNonNull(response.getBody())).collect(Collectors.toList()));

        } catch (Exception e) {
            log.error("Error consumiendo getDomicilesByPremiumOffice");
        }

        return tutorOfficeDtoList;
    }
}
