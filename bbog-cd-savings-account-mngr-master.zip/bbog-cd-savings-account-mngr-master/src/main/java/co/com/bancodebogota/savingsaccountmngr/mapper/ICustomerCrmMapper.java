package co.com.bancodebogota.savingsaccountmngr.mapper;

import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.dto.customer.ConsultCustomerRespDto;
import co.com.bancodebogota.dto.customer.RequestCustomerInquiry;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import com.fasterxml.jackson.databind.JsonNode;

public interface ICustomerCrmMapper {

    RequestCustomerInquiry mapCreateCustomerDto(BankAccountDto bankAccountDto);

    JsonNode mapUpdateCustomerDto(BankAccountDto bankAccountDto, ConsultCustomerRespDto consultCustomerRespDto) throws AbsBdbServiceException;
}
