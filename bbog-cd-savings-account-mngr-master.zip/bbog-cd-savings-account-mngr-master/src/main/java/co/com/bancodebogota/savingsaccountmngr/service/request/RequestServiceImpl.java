package co.com.bancodebogota.savingsaccountmngr.service.request;

import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.pentagon.EventDataDto;
import co.com.bancodebogota.dto.pentagon.EventIdentityDto;
import co.com.bancodebogota.dto.request.*;
import co.com.bancodebogota.enums.*;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.model.entities.ParticipantDto;
import co.com.bancodebogota.model.entities.*;
import co.com.bancodebogota.model.repositories.*;
import co.com.bancodebogota.savingsaccountmngr.mapper.IDispatcherMapper;
import co.com.bancodebogota.savingsaccountmngr.mapper.IPentagonMapper;
import co.com.bancodebogota.savingsaccountmngr.mapper.RequestMapper;
import co.com.bancodebogota.savingsaccountmngr.utils.RequestUtilities;
import co.com.bancodebogota.service.pentagon.IPentagonService;
import co.com.bancodebogota.service.redis.IRedisApiService;
import co.com.bancodebogota.service.request.IRequestApiService;
import co.com.bancodebogota.utils.DataUtilities;
import co.com.bancodebogota.utils.JacksonUtilsV2;
import co.com.bancodebogota.utils.TimeUtilities;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Service
@RequiredArgsConstructor
public class RequestServiceImpl implements IRequestService {

    private final IRequestApiService requestApiService;
    private final ObjectMapper objectMapper;
    private final IDispatcherMapper dispatcherMapper;
    private final RequestRepository requestRepository;
    private final ParticipantRepository participantRepository;
    private final RequestAuthenticationRepository requestAuthenticationRepository;
    private final ParticipantInfoRepository participantInfoRepository;
    private final LocationRepository locationRepository;
    private final RequestEventRepository requestEventRepository;
    private final RequestUtilities requestUtilities;
    private final IPentagonService pentagonService;
    private final RequestMapper requestMapper;
    private final IRedisApiService redisApiService;
    private final IPentagonMapper pentagonMapper;

    private static final String EPLUSE_SITE = "33";
    private static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";
    private static final String X_JOURNEY = "X-Journey";
    private static final String X_AUTH_UUID = "X-AuthUuid";
    private static final String DISPATCHER_KEY = "DispatcherKey";
    private static final String X_IDENTITYNUMBER = "X-IdentityNumber";
    private static final String X_RQUID = "X-RqUID";

    @Override
    public AccountRequestV2RsDto createRequestV2(HttpHeaders httpHeaders) throws AbsBdbServiceException {
        DispatcherDto dispatcherDto = redisApiService.getHash("CC", httpHeaders.getFirst(X_AUTH_UUID),
                DISPATCHER_KEY, httpHeaders.getFirst(X_AUTH_UUID), DispatcherDto.class);

        String identityNumber = dispatcherDto.getIdentityNumber();
        log.info(">>> ({}) CREATE REQUEST V2. NEW CALL >>>", identityNumber);

        AccountRequestV2RsDto response = new AccountRequestV2RsDto();
        ObjectMapper mapper = new ObjectMapper();
        response.setAuthDispatcher(mapper.valueToTree(dispatcherDto));

        AccountRequestV3RsDto accountRequestV3RsDto = createRequestV3(httpHeaders, dispatcherDto);
        response.setAccountRequest(accountRequestV3RsDto.getAccountRequest());
        response.setAuthFlags(accountRequestV3RsDto.getAuthFlags());

        log.info("<<< ({}) CREATE REQUEST V2. SUCCESSFUL END <<<", identityNumber);

        return response;
    }

    @Override
    public AccountRequestV3RsDto createRequestV3(HttpHeaders httpHeaders) throws AbsBdbServiceException {
        DispatcherDto dispatcherDto = redisApiService.getHash("CC", httpHeaders.getFirst(X_AUTH_UUID),
                DISPATCHER_KEY, httpHeaders.getFirst(X_AUTH_UUID), DispatcherDto.class);

        return createRequestV3(httpHeaders, dispatcherDto);
    }

    @Override
    public AccountRequestRsDto createRequestId(HttpHeaders httpHeaders) {
        AccountRequestRsDto accountRequestRsDto = new AccountRequestRsDto();
        Long digitalId = createDigitalId(httpHeaders);
        accountRequestRsDto.setDigitalId(digitalId);

        return accountRequestRsDto;
    }

    private AccountRequestV3RsDto createRequestV3(HttpHeaders httpHeaders, DispatcherDto dispatcherDto) throws AbsBdbServiceException {
        String userIp = httpHeaders.getFirst(X_FORWARDED_FOR);
        String journey = httpHeaders.getFirst(X_JOURNEY);
        String identityNumber = dispatcherDto.getIdentityNumber();

        log.info(">>> ({}) CREATE REQUEST V3. NEW CALL >>>", identityNumber);

        AccountRequestV3RsDto response = new AccountRequestV3RsDto();
        Long digitalId;

        try {
            boolean isNewClient = !StringUtils.equalsIgnoreCase(dispatcherDto.getCustomerState(), EClientType.ACTIVE.getDescription());

            if (dispatcherDto.getSpecificProductInfo() == null) {
                throw BdbExceptionFactory.createExcepcion(HttpStatus.LOCKED, identityNumber, "Error specific product " +
                        "info null");
            }

            if (StringUtils.isEmpty(dispatcherDto.getAccessType()) && isNewClient) {
                dispatcherDto.setAccessType("1");
            }

            CreateRequestDto createRequestDto = dispatcherMapper.mapCreateRequest(httpHeaders, dispatcherDto);

            AccountRequestRsDto accountRequestRsDto = createRequest(createRequestDto, userIp, dispatcherDto);
            digitalId = accountRequestRsDto.getDigitalId();

            response.setAccountRequest(accountRequestRsDto);

            String productId = DataUtilities.getNodeAsText(dispatcherDto.getSpecificProductInfo(), "productId");

            response.setAuthFlags(dispatcherMapper.handleFlags(dispatcherDto,
                    EAccount.NOMINA.getCode().equals(productId), isNewClient, identityNumber));

        } catch (Exception e) {
            log.error("({}) Error creating request v3", identityNumber);
            sendAuthEvent(dispatcherDto, "", userIp, journey);
            throw e;
        }

        sendAuthEvent(dispatcherDto, digitalId.toString(), userIp, journey);
        log.info("<<< ({}) CREATE REQUEST V3. SUCCESSFUL END <<<", identityNumber);
        return response;
    }

    private void sendAuthEvent(DispatcherDto dispatcherDto, String digitalId, String userIp, String journey) {

        EventIdentityDto eventIdentityDto = new EventIdentityDto();
        eventIdentityDto.setAccessToken(dispatcherDto.getAccessToken());
        eventIdentityDto.setUserIp(userIp);
        eventIdentityDto.setChannel(dispatcherDto.getChannel());
        eventIdentityDto.setRqUuid(dispatcherDto.getSpecificProductInfoUuid());
        eventIdentityDto.setIdentityNumber(dispatcherDto.getIdentityNumber());
        eventIdentityDto.setIdentityType(dispatcherDto.getIdentityType());

        if ("AE_SolucionesDigitales".equalsIgnoreCase(DataUtilities.getNodeAsText(dispatcherDto.getUtmInfo(), "utm_campaign"))) {
            eventIdentityDto.setMedium(DataUtilities.getNodeAsText(dispatcherDto.getUtmInfo(), "utm_medium"));
            eventIdentityDto.setSourceChannel(DataUtilities.getNodeAsText(dispatcherDto.getUtmInfo(), "utm_source"));
        }

        EventDataDto eventDataDto = new EventDataDto();
        eventDataDto.setEventName(String.format("Event-CuentaDeAhorros-%s-ConocimientoDeCliente-PostAutenticacion",
                EJourney.getJourneyName(journey)));
        eventDataDto.setJourney(journey);
        eventDataDto.setMilestone("ConocimientoDeCliente");
        eventDataDto.setStep("PostAutenticacion");
        eventDataDto.setDigRequest(digitalId);

        Map<String, String> clientTypes = new HashMap<>();
        clientTypes.put("LEAD", "Lead");
        clientTypes.put(EClientType.ACTIVE.getDescription(), EClientType.ACTIVE.getApiName());
        clientTypes.put("NOT_CLIENT", "No Client");

        eventDataDto.setIsClient(clientTypes.get(dispatcherDto.getCustomerState()));

        eventDataDto.setFront(false);

        eventDataDto.setPayload(JacksonUtilsV2.getPlainJson(dispatcherDto));

        CompletableFuture.runAsync(() -> pentagonService.publish(eventDataDto, eventIdentityDto));
    }

    @Override
    public AccountRequestRsDto createRequest(CreateRequestDto createRequestDto, String userIp, DispatcherDto dispatcherDto) throws AbsBdbServiceException {

        AccountRequestRsDto accountRequestRsDto = new AccountRequestRsDto();

        String identityNumber = createRequestDto.getParticipant().getIdentificationNumber();

        try {
            log.info(">>> ({}) CREATE REQUEST. NEW CALL >>>", identityNumber);
            log.info("[CREATE REQUEST DATA] {}", JacksonUtilsV2.getPlainJson(createRequestDto));

            ParticipantDto participant = createRequestDto.getParticipant();

            RequestDto requestDto = new RequestDto();
            requestDto.setProductId(createRequestDto.getProductId());
            requestDto.setDate(TimeUtilities.getCurrentTimestampGMTMinus5());
            requestDto.setClient(createRequestDto.isClient());

            String response = null;

            if (dispatcherDto != null) {
                response = objectMapper.writeValueAsString(dispatcherDto);

                FlowTypeDto requestFlowDto = getFlowType(dispatcherDto);
                if (createRequestDto.getSourceTeamId() == 1 && requestFlowDto.isAssistedSarlaft()) {
                    requestDto.setNode("SARLAFT");
                }
            }

            String channel = createRequestDto.getChannelId();
            int channelId = requestUtilities.getChannelFromLauncher(createRequestDto.getMediumType(), channel);

            if (createRequestDto.getAuthTypeId() != null && createRequestDto.getAuthTypeId().equals("5"))
                requestDto.setResume(false);

            requestDto.setChannelId(channelId);
            requestDto.setMedium(getMediumId(channel));
            requestDto.setSourceTeamId(createRequestDto.getSourceTeamId());
            requestDto.setCustomOtp(createRequestDto.getCustomOtp());
            log.info("({}) [1/4. SavingRequest] {}", identityNumber, JacksonUtilsV2.getPlainJson(requestDto));
            requestDto = requestRepository.save(requestDto);
            long requestId = requestDto.getId();

            createRequestDto.setChannelId(requestUtilities.validateOpbChannel(channel, EChannel.WEB));
            if (createRequestDto.isCreateDigitalRequest()) {
                Long digitalId = saveDigitalRequest(requestId, createRequestDto, userIp);

                if (digitalId == null) throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR,
                        identityNumber, "Error creating digital request");

                requestDto.setDigitalId(digitalId);
                requestRepository.save(requestDto);
                accountRequestRsDto.setDigitalId(digitalId);
            }

            ParticipantDto participantFromDB = saveParticipant(participant);
            ParticipantInfoDto participantInfoDto = new ParticipantInfoDto(participantFromDB.getId(), requestId);
            log.info("({}) [2/4. SavingParticipantInfo] {}", identityNumber,
                    JacksonUtilsV2.getPlainJson(participantInfoDto));
            participantInfoRepository.save(participantInfoDto);

            RequestAuthenticationDto requestAuthenticationDto = new RequestAuthenticationDto();
            requestAuthenticationDto.setRequestId(requestId);
            requestAuthenticationDto.setAuthTypeId(Integer.parseInt(createRequestDto.getAuthTypeId()));

            requestAuthenticationDto.setResponse(response);
            requestAuthenticationDto.setSpiUuid(createRequestDto.getSpiUuid());
            requestAuthenticationDto.setIdentityNumber(identityNumber);
            requestAuthenticationDto.setCellphone(createRequestDto.getCellphone());
            log.info("({}) [3/4. SavingRequestAuth] {}", identityNumber,
                    JacksonUtilsV2.getPlainJson(requestAuthenticationDto));
            requestAuthenticationRepository.save(requestAuthenticationDto);

            LocationDto locationDto = createRequestDto.getLocationInfo();
            if (locationDto.getOfficeCode() == null || locationDto.getOfficeCode().equals("undefined"))
                locationDto.setOfficeCode("WEB");
            log.info("({}) [4/4. SavingLocation] {}", identityNumber, JacksonUtilsV2.getPlainJson(locationDto));
            locationDto = locationRepository.save(locationDto);
            log.info("Saving RequestLocation for request {}", requestId);
            requestRepository.saveRequestLocation(requestId, locationDto.getId(),
                    TimeUtilities.getCurrentTimestampGMTMinus5());

            RequestUtmDto requestUtmDto = createRequestDto.getUtmInfo();
            if (requestUtmDto != null) {
                requestUtmDto.setRequestId(requestId);
                log.info("({}) [5/5. SavingRequestUtm] {}", identityNumber,
                        JacksonUtilsV2.getPlainJson(requestUtmDto));
                requestRepository.saveRequestUtm(requestUtmDto.getRequestId(), requestUtmDto.getSource(),
                        requestUtmDto.getMedium(), requestUtmDto.getCampaign(), requestUtmDto.getTerm(),
                        requestUtmDto.getContent(), requestUtmDto.getRefer());
            } else {
                log.info("({}) UtmInfo not found", identityNumber);
            }

            accountRequestRsDto.setRequestId(requestId);

        } catch (Exception e) {
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR,
                    createRequestDto.getParticipant().getIdentificationNumber(), "Error al crear la solicitud", e);
        }

        log.info("<<< ({}) CREATE REQUEST. SUCCESSFUL END <<<", identityNumber);
        return accountRequestRsDto;
    }

    private ParticipantDto saveParticipant(ParticipantDto participant) {
        ParticipantDto participantFromDB =
                participantRepository.findByIdentificationNumber(participant.getIdentificationNumber());
        if (participantFromDB == null) participantFromDB = participantRepository.save(participant);
        return participantFromDB;
    }

    private int getMediumId(String channel) {
        return switch (channel.toUpperCase()) {
            case "OFICINA", "MFZ" -> 2;
            case "WEB", "BM", "OPB001" -> 3;
            default -> 1;
        };
    }

    private Long saveDigitalRequest(long requestId, CreateRequestDto createRequestDto, String userIp) {
        String identityNumber = createRequestDto.getParticipant().getIdentificationNumber();
        String identityType = createRequestDto.getParticipant().getIdentificationType();
        String spiUuid = createRequestDto.getSpiUuid();
        String channel = createRequestDto.getChannelId();
        Long digitalId = null;

        try {
            CreateDigitalRequestDto createDigitalRequestDto = new CreateDigitalRequestDto();
            createDigitalRequestDto.setRqUID(spiUuid);
            createDigitalRequestDto.setIpAddress(userIp);
            createDigitalRequestDto.setIdentityNumber(identityNumber);
            createDigitalRequestDto.setIdentityType(identityType);
            createDigitalRequestDto.setChannel(channel);
            createDigitalRequestDto.setOfficeCode(createRequestDto.getLocationInfo().getOfficeCode());
            createDigitalRequestDto.setIsClient(String.valueOf(createRequestDto.isClient()));
            createDigitalRequestDto.setXName(EXName.CuentaDeAhorros);

            digitalId = requestApiService.createDigitalRequest(createDigitalRequestDto);

            if (EChannel.MFZ != EChannel.findByDescription(channel)) {
                closeDigitalRequest(digitalId, identityType, identityNumber, spiUuid, userIp, channel);
            }

        } catch (Exception e) {
            log.error("({}) Error saving digital request", identityNumber);
        } finally {
            saveRequestEvent(requestId, digitalId == null ? EEventType.CHECK_DIGITAL_REQUEST_FALLIDO :
                    EEventType.CHECK_DIGITAL_REQUEST_EXITOSO, identityNumber);
        }

        return digitalId;
    }

    public Long createDigitalId(HttpHeaders httpHeaders) {
        String identityNumber = httpHeaders.getFirst(X_IDENTITYNUMBER);
        String identityType = EIdentificationType.CEDULA_CIUDADANIA.getApiType();
        String spiUuid = httpHeaders.getFirst(X_RQUID);
        String channel = EChannel.WEB.getNotSpaced();
        String userIp = httpHeaders.getFirst(X_FORWARDED_FOR);
        Long digitalId = null;

        log.info(">>> ({}) CREATE DIGITAL ID FOR ACCOUNT REACTIVATION. NEW CALL >>>", identityNumber);

        try {
            CreateDigitalRequestDto createDigitalRequestDto = new CreateDigitalRequestDto();
            createDigitalRequestDto.setRqUID(spiUuid);
            createDigitalRequestDto.setIpAddress(userIp);
            createDigitalRequestDto.setIdentityNumber(identityNumber);
            createDigitalRequestDto.setIdentityType(identityType);
            createDigitalRequestDto.setChannel(channel);
            createDigitalRequestDto.setOfficeCode("0000");
            createDigitalRequestDto.setIsClient(EClientType.ACTIVE.getDescription());
            createDigitalRequestDto.setXName(EXName.CuentaDeAhorros);

            digitalId = requestApiService.createDigitalRequest(createDigitalRequestDto);

            closeDigitalRequest(digitalId, identityType, identityNumber, spiUuid, userIp, channel);

            pentagonService.publishSns(httpHeaders, pentagonMapper.mapCreateDigitalRequest(digitalId, 200, "SUCCESS"), identityNumber);
        } catch (AbsBdbServiceException e) {
            log.error("({}) Error saving digital request for account reactivation", identityNumber);

            pentagonService.publishSns(httpHeaders, pentagonMapper.mapCreateDigitalRequest(digitalId, e.getStatus(), e.getMessage()), identityNumber);
        }

        log.info("<<< ({}) CREATE DIGITAL ID FOR ACCOUNT REACTIVATION. SUCCESSFUL END <<<", identityNumber);

        return digitalId;
    }

    @Override
    public void saveRequestEvent(Long requestId, EEventType evenType, String identityNumber) {

        RequestEventDto requestEventDto = new RequestEventDto();
        requestEventDto.setRequestId(requestId);
        requestEventDto.setEventId(evenType.getIdCheck());
        requestEventDto.setDate(TimeUtilities.getCurrentTimestampGMTMinus5());

        try {
            log.info("[SavingRequestEvent][Evento] ::: {} [identityNumber/accountNumber] ::: {} >>> {}",
                    evenType.getDescription(), identityNumber, JacksonUtilsV2.getPlainJson(requestEventDto));
            requestRepository.saveRequestEvent(requestEventDto.getRequestId(), requestEventDto.getEventId(),
                    requestEventDto.getDate());
        } catch (Exception e) {
            log.error("[Error saving event]", e);
        }
    }

    @Override
    public void updateRequestEvent(long requestId, EEventType newEventType, EEventType oldEventType) throws AbsBdbServiceException {
        RequestEventDto requestEventDto = new RequestEventDto();
        try {
            requestEventDto.setRequestId(requestId);
            requestEventDto.setEventId(newEventType.getIdCheck());
            requestEventDto.setDate(TimeUtilities.getCurrentTimestampGMTMinus5());

            RequestEventDto requestEventDB = requestEventRepository.findByRequestIdAndEventId(requestId,
                    oldEventType.getIdCheck());
            log.info("[{}. RequestEventFromDB] {}", requestId, JacksonUtilsV2.getPlainJson(requestEventDB));

            requestEventDB.setEventId(requestEventDto.getEventId());
            requestEventDB.setRequestId(requestEventDto.getRequestId());
            requestEventDB.setDate(requestEventDto.getDate());

            log.info("[{}. SavingRequestEvent] {}", requestEventDto.getRequestId(),
                    JacksonUtilsV2.getPlainJson(requestEventDB));
            requestEventRepository.save(requestEventDB);
        } catch (Exception e) {
            log.info("ERROR savingRequestEvent {}", JacksonUtilsV2.getPlainJson(requestEventDto));
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, String.valueOf(requestId),
                    "Error updating event");
        }
    }

    @Override
    public void saveFailedRequest(String authUuid) {
        try {
            RequestDto requestDto = new RequestDto();
            requestDto.setProductId(1);
            requestDto.setSourceTeamId(1);
            requestDto.setMedium(3);
            requestDto.setChannelId(2);
            requestDto.setDate(TimeUtilities.getCurrentTimestampGMTMinus5());

            log.info("[1/2. SavingFailedRequest] {}", JacksonUtilsV2.getPlainJson(requestDto));
            requestDto = requestRepository.save(requestDto);

            RequestAuthenticationDto requestAuthenticationDto = new RequestAuthenticationDto();
            requestAuthenticationDto.setRequestId(requestDto.getId());
            requestAuthenticationDto.setAuthTypeId(1);
            requestAuthenticationDto.setSpiUuid(authUuid);

            log.info("[2/2. SavingFailedRequestAuth] {}", JacksonUtilsV2.getPlainJson(requestAuthenticationDto));
            requestAuthenticationRepository.save(requestAuthenticationDto);

        } catch (Exception e) {
            log.error("({}). Error saving failed request. {}", authUuid, e.getMessage());
        }
    }

    @Override
    public void closeDigitalBySession(HttpHeaders httpHeaders) {
        String uuid = httpHeaders.getFirst(X_AUTH_UUID);
        try {
            DispatcherDto dispatcherDto = redisApiService.getHash("CC", uuid, DISPATCHER_KEY, uuid, DispatcherDto.class);

            if (dispatcherDto.getIdentityNumber() == null || dispatcherDto.getSpecificProductInfoUuid() == null) {
                throw BdbExceptionFactory.createExcepcion(HttpStatus.UNPROCESSABLE_ENTITY, uuid, "Error getting from Redis");
            }

            RequestDto requestDto = requestRepository.findByIdentityNumberAndRqUuid(dispatcherDto.getIdentityNumber(),
                    dispatcherDto.getSpecificProductInfoUuid());

            if (!Objects.isNull(requestDto)) {
                closeDigitalRequest(requestDto.getDigitalId(), dispatcherDto.getIdentityType(),
                        dispatcherDto.getIdentityNumber(), dispatcherDto.getSpecificProductInfoUuid(),
                        StringUtils.defaultIfEmpty(dispatcherDto.getNetwork(), "0.0.0.0"), dispatcherDto.getChannel());
            }
        } catch (Exception e) {
            log.error("({}). Error closing digital by session. {}", uuid, e.getMessage());
        }
    }

    @Override
    public void closeDigitalByDate(Date date) {

        String dateFormatted = new SimpleDateFormat("yyyy-MM-dd").format(date);
        log.info(">>> ({}) CLOSE DIGITAL REQUEST BY DATE. NEW CALL >>>", dateFormatted);

        List<Object[]> requestList = requestRepository.findAllOpenRequestsByDate(dateFormatted);
        log.info("[Requests Found] {}", requestList.size());

        List<DispatcherDto> requestsClosed = new ArrayList<>();
        List<DispatcherDto> requestsMFZ = new ArrayList<>();

        requestList.forEach(request -> {
            DispatcherDto dispatcherDto = requestMapper.mapDispatcherByRequestAuth(request[1].toString());
            String channel = dispatcherDto.getChannel();

            log.info("[dispatcherDto] {}", JacksonUtilsV2.getPlainJson(dispatcherDto));

            if (EChannel.MFZ == EChannel.findByDescription(channel)) {
                requestsMFZ.add(dispatcherDto);
            } else {
                requestsClosed.add(dispatcherDto);

                closeDigitalRequest(Long.parseLong(request[0].toString()), dispatcherDto.getIdentityType(),
                        dispatcherDto.getIdentityNumber(), dispatcherDto.getSpecificProductInfoUuid(),
                        dispatcherDto.getNetwork(), channel);
            }
        });

        log.info("[Requests Closed] {}", requestsClosed.size());
        log.info("[Requests MFZ Found] {}", requestsMFZ.size());
    }

    @Override
    public void closeDigitalById(String xForwardedFor, CloseDigitalRequestDto closeDigitalRequestDto) {

        closeDigitalRequest(closeDigitalRequestDto.getDigRequestId(), closeDigitalRequestDto.getIdentityType(),
                closeDigitalRequestDto.getIdentityNumber(), closeDigitalRequestDto.getRqUID(), xForwardedFor,
                closeDigitalRequestDto.getChannel());
    }

    private void closeDigitalRequest(long digitalId, String identityType, String identityNumber, String rqUid,
                                     String userIp, String channel) {
        try {
            CloseDigitalRequestDto closeDigitalRequestDto = new CloseDigitalRequestDto();
            closeDigitalRequestDto.setRqUID(rqUid);
            closeDigitalRequestDto.setIpAddress(userIp);
            closeDigitalRequestDto.setIdentityNumber(identityNumber);
            closeDigitalRequestDto.setIdentityType(identityType);
            closeDigitalRequestDto.setChannel(channel);
            closeDigitalRequestDto.setXName(EXName.CuentaDeAhorros);
            closeDigitalRequestDto.setDigRequestId(digitalId);

            requestApiService.closeDigitalRequest(closeDigitalRequestDto);
        } catch (Exception e) {
            log.error("({}) Error closing digital request", identityNumber);
        }
    }

    @Override
    public FlowTypeDto getFlowType(HttpHeaders httpHeaders) throws AbsBdbServiceException {
        DispatcherDto dispatcherDto = redisApiService.getHash("CC", httpHeaders.getFirst(X_AUTH_UUID),
                DISPATCHER_KEY, httpHeaders.getFirst(X_AUTH_UUID), DispatcherDto.class);

        return getFlowType(dispatcherDto);
    }

    private FlowTypeDto getFlowType(DispatcherDto dispatcherDto) {
        String identityNumber = dispatcherDto.getIdentityNumber();
        FlowTypeDto requestFlowDto = new FlowTypeDto();

        log.info(">>> ({}) GET FLOW TYPE. NEW CALL >>>", identityNumber);

        requestFlowDto.setEpluse(EPLUSE_SITE.equals(dispatcherDto.getSite()));

        boolean isCardActivationFlow = DataUtilities
                .getNodeAsBoolean(dispatcherDto.getSpecificProductInfo(), "redirectToCardActivation");

        if (isCardActivationFlow) {
            requestFlowDto.setCardActivation(true);
        } else {
            List<String> officesEnabledForSarlaft = requestRepository.findOfficesEnabledForSarlaft(dispatcherDto.getChannel().toUpperCase());
            requestFlowDto.setAssistedSarlaft(officesEnabledForSarlaft.contains(dispatcherDto.getOfficeCode()));
        }

        log.info("<<< ({}) GET FLOW TYPE. END: {} <<<", identityNumber, JacksonUtilsV2.getPlainJson(requestFlowDto));
        return requestFlowDto;
    }
}
