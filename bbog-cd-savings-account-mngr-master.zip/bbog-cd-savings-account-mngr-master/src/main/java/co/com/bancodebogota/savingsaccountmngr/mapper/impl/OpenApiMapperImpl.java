package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.dto.account.AccountData;
import co.com.bancodebogota.dto.account.BankInfoType;
import co.com.bancodebogota.dto.account.OpeningAccountDto;
import co.com.bancodebogota.dto.customer.*;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.fatca.FatcaDto;
import co.com.bancodebogota.dto.gmf.GmfDto;
import co.com.bancodebogota.dto.openapi.AccountDto;
import co.com.bancodebogota.enums.EAccount;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.model.entities.SourceTeamDto;
import co.com.bancodebogota.model.repositories.SourceTeamRepository;
import co.com.bancodebogota.savingsaccountmngr.mapper.IOpenApiMapper;
import co.com.bancodebogota.savingsaccountmngr.utils.HolidayUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class OpenApiMapperImpl implements IOpenApiMapper {

    private static final String X_RQUID = "x-rquid";
    private static final String X_IPADDR = "x-ipaddr";
    private static final String X_CHANNEL = "x-channel";
    private static final String X_CUSTTYPE = "x-custtype";
    private static final String X_CUSTIDENTNUM = "x-custidentnum";
    private static final String X_CUSTIDENTTYPE = "x-custidenttype";

    private final SourceTeamRepository sourceTeamRepository;

    @Override
    public DispatcherDto mapDispatcher(HttpHeaders headers, String officeCode) throws AbsBdbServiceException {
        DispatcherDto dispatcherDto = new DispatcherDto();

        try {
            dispatcherDto.setNetwork(headers.getFirst(X_IPADDR));
            dispatcherDto.setChannel(headers.getFirst(X_CHANNEL));
            dispatcherDto.setIdentityType(headers.getFirst(X_CUSTIDENTTYPE));
            dispatcherDto.setIdentityNumber(headers.getFirst(X_CUSTIDENTNUM));
            dispatcherDto.setOfficeCode(officeCode);
            dispatcherDto.setAccessType("6");
            dispatcherDto.setCustomerState(headers.getFirst(X_CUSTTYPE));
            dispatcherDto.setSpecificProductInfoUuid(headers.getFirst(X_RQUID));
        } catch (Exception exception) {
            throw BdbExceptionFactory.createExcepcion(HttpStatus.BAD_REQUEST, headers.getFirst(X_RQUID),
                    "Failed mapping dispatcher");
        }
        return dispatcherDto;
    }

    @Override
    public Integer getSourceTeam(String appName) throws AbsBdbServiceException {
        SourceTeamDto sourceTeamDto = sourceTeamRepository.findByApiName(appName);
        if (sourceTeamDto == null) {
            log.warn("Failed getting team from app name. ({})", appName);
            throw BdbExceptionFactory.createExcepcion(HttpStatus.NOT_FOUND, "", "Failed getting team");
        }

        return sourceTeamDto.getId();
    }

    @Override
    public AccountData mapAccountData(long requestId, AccountDto accountDto, CustomerManagementRs customerManagementRs,
                                      HttpHeaders httpHeaders) {

        AccountData accountData = new AccountData();
        OpeningAccountDto openingAccountDto = new OpeningAccountDto();

        openingAccountDto.setIdentityType(httpHeaders.getFirst(X_CUSTIDENTTYPE));
        openingAccountDto.setIdentityNumber(httpHeaders.getFirst(X_CUSTIDENTNUM));

        CustInfo custInfo = customerManagementRs.getCustInfo();
        PersonInfo personInfo = custInfo.getPersonInfo();
        PersonName personName = personInfo.getPersonName();
        ContactInfo contactInfo = personInfo.getContactInfo().get(0);

        openingAccountDto.setFirstName(personName.getFirstName());
        openingAccountDto.setSecondName(personName.getMiddleName());
        openingAccountDto.setFirstLastName(personName.getLastName());
        openingAccountDto.setSecondLastName(personName.getSecondLastName());

        openingAccountDto.setBirthDt(personInfo.getBirthDt());
        openingAccountDto.setGender(personInfo.getGender());

        openingAccountDto.setPhoneNumber(contactInfo.getPhoneNum().getPhone());
        openingAccountDto.setEmailAddr(contactInfo.getEmailAddr());

        openingAccountDto.setEconomicActivity(personInfo.getEmployment().get(0).getEmploymentId());
        openingAccountDto.setSegCommercial(custInfo.getComercialSeg());

        openingAccountDto.setAcctSubType(accountDto.getProductCode());
        openingAccountDto.setAcctType(EAccount.getTypeByCode(accountDto.getProductCode()));
        openingAccountDto.setOfficeCode(accountDto.getOfficeCode());
        openingAccountDto.setPayrollCode(accountDto.getDispersionCode());
        openingAccountDto.setOfficeCodeSeller(accountDto.getSeller());

        String ceoCode = StringUtils.defaultIfEmpty(accountDto.getCeoCode(), "0000");
        openingAccountDto.setCeoCode(ceoCode.substring(0, 4));

        openingAccountDto.setCardDelivery(false);
        openingAccountDto.setHoliday(isHoliday());

        openingAccountDto.setEthnicGroup(StringUtils.defaultIfEmpty(accountDto.getEthnicGroup(), null));

        accountData.setOpeningAccount(openingAccountDto);

        accountData.setPostalAddress(contactInfo.getPostAddr().getAddr1());
        accountData.setClientWithDebitCards(false);
        accountData.setClientUserAgent(httpHeaders.getFirst(HttpHeaders.USER_AGENT));

        GmfDto gmfDto = new GmfDto();
        gmfDto.setRequestId(requestId);
        gmfDto.setCheckGmf(accountDto.isGmf());
        gmfDto.setCellphone(contactInfo.getPhoneNum().getPhone());
        accountData.setGmf(gmfDto);

        FatcaDto fatcaDto = getFatcaInfo(accountDto.getFatca(), personInfo.getBirthPlace());
        accountData.setFatca(fatcaDto);

        if (EAccount.CORRIENTE_COBA.getCode().equalsIgnoreCase(accountDto.getProductCode())) {
            BankInfoType bankInfoType = new BankInfoType();
            bankInfoType.setCobaOfficeCode(accountDto.getBankInfo().getCobaOfficeCode());
            openingAccountDto.setBankInfo(bankInfoType);
            openingAccountDto.setOverdraftDays(accountDto.getOverdraftDays());
        }

        return accountData;
    }

    private boolean isHoliday() {
        HolidayUtility holidayUtilityCurrent = new HolidayUtility();
        return holidayUtilityCurrent.getHolidays().contains(LocalDateTime.now().toString());
    }

    private FatcaDto getFatcaInfo(List<co.com.bancodebogota.dto.openapi.FatcaDto> fatca, String birthPlace) {
        FatcaDto fatcaDto = new FatcaDto();

        if (ObjectUtils.isEmpty(fatca)) return fatcaDto;

        if (ObjectUtils.isNotEmpty(fatca.get(0))) {
            fatcaDto.setFiscalResidence1(fatca.get(0).getCountry());
            fatcaDto.setTin1(fatca.get(0).getTin());

            if (fatca.size() > 1) {
                fatcaDto.setFiscalResidence2(fatca.get(1).getCountry());
                fatcaDto.setTin2(fatca.get(1).getTin());
            }
        }

        fatcaDto.setBirthPlace(birthPlace);
        return fatcaDto;
    }
}
