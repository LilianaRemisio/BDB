package co.com.bancodebogota.savingsaccountmngr.mapper;

import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountDto;
import co.com.bancodebogota.dto.account.AccountData;
import co.com.bancodebogota.dto.account.OpeningAccountDto;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.fatca.FatcaDto;
import co.com.bancodebogota.dto.monitorplus.MonitorAccountCreateDto;
import co.com.bancodebogota.model.entities.FatcaEntity;

public interface IAccountMapper {
    CreateAccountDto mapOpeningAccountDto(OpeningAccountDto openingAccountDto, String identityNumber, String identityType, String rqUuid, String channel);

    MonitorAccountCreateDto mapMonitorAccountCreate(OpeningAccountDto openingAccountDto, String accountNumber, String channel);

    FatcaEntity mapFatcaEntity(FatcaDto fatca, String identityType, String identityNumber, String clientName, String officeCode);

    BankAccountDto mapBankAccountForDB(AccountData accountData, DispatcherDto dispatcherDto);
}
