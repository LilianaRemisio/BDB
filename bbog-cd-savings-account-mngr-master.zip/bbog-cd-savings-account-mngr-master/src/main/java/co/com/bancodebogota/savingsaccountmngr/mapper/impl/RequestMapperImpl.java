package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.db.savings.dto.jpa.AcctLimitsDescDto;
import co.com.bancodebogota.db.savings.dto.jpa.AddressDto;
import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountDto;
import co.com.bancodebogota.dto.customer.ConsultCustomerRespDto;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.masterdata.TutorOfficeDef;
import co.com.bancodebogota.dto.products.AccountHierarchyReqDto;
import co.com.bancodebogota.dto.products.AcctBasicInfoDto;
import co.com.bancodebogota.enums.EAccount;
import co.com.bancodebogota.enums.EIdentificationType;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.model.entities.*;
import co.com.bancodebogota.savingsaccountmngr.mapper.RequestMapper;
import co.com.bancodebogota.savingsaccountmngr.service.masterdata.IMasterdataService;
import co.com.bancodebogota.savingsaccountmngr.utils.RequestUtilities;
import co.com.bancodebogota.service.redis.IRedisApiService;
import co.com.bancodebogota.utils.DataUtilities;
import co.com.bancodebogota.utils.TimeUtilities;
import co.com.bancodebogota.utils.Utilities;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@RequiredArgsConstructor
@Service
public class RequestMapperImpl implements RequestMapper {

    private static final String MVP_EMAIL_PURPOSE = "20002";
    private static final String BB_ENVIO_EXTRACTO = "M";
    private static final String KEY_CELLPHONE_AUTHENTICATED = "KEY_CELLPHONE_AUTHENTICATED";
    private static final String CUSTOMER_INFORMATION = "CUSTOMER_INFO";

    //hierarchyAccount
    private static final String RQUID = "a18eafa0-ce60-11e0-9572-000010867937";
    private static final String SPNAME = "urn://gov.co/C";
    private static final String NETWORKOWNER = "DIG482";
    private static final String TERMINALID = "IN01";
    private static final String NAME = "0121";
    private static final String OFFICE_CHANNEL = "OFICINA";
    private static final String FMV_CHANNEL = "FMV";

    private final IMasterdataService masterdataService;
    private final RequestUtilities requestUtilities;
    private final IRedisApiService redisApiService;

    @Override
    public CreateAccountDto mapCreateAccountDtoRequest(BankAccountDto bankAccountDto, String rqUuid) {
        String documentNumber = DataUtilities.removeIdentificationMask(bankAccountDto.getIdentityNumber());
        CreateAccountDto createAccountDto = new CreateAccountDto();
        ConsultCustomerRespDto clientNode = null;
        String cellPhoneAutheticated = null;

        try {
            clientNode = redisApiService.getHash(EIdentificationType.CEDULA_CIUDADANIA.getBdbType(), documentNumber, CUSTOMER_INFORMATION,
                    rqUuid, ConsultCustomerRespDto.class);
            cellPhoneAutheticated = redisApiService.getHash(EIdentificationType.CEDULA_CIUDADANIA.getBdbType(), documentNumber,
                    KEY_CELLPHONE_AUTHENTICATED, rqUuid, String.class);
        } catch (AbsBdbServiceException e) {
            log.error("<<< ({}) ERROR GETTING INFO FROM REDIS {} <<<", documentNumber, e.getMessage());
        }

        String addressCustomerCRM = StringUtils.defaultString(bankAccountDto.getCrmAddress(), bankAccountDto.getAddressForCRM());
        if (clientNode != null) {
            createAccountDto.setSex(clientNode.getSex());
            createAccountDto.setAacodciiu(clientNode.getCodCiuu());
            if (bankAccountDto.isCustomerExistsInCrm() && Utilities.validateForCrm(clientNode.getAddress1())) {
                addressCustomerCRM = clientNode.getAddress1();
            }
        }

        List<TutorOfficeDef> domicilesByPremiumOffice = new ArrayList<>();
        if (bankAccountDto.getSegcomercial() != null && bankAccountDto.getSegcomercial().equals("1578")) {
            domicilesByPremiumOffice = masterdataService.getDomicilesByPremiumOffice(bankAccountDto.getOfficeCode());
        }

        if (domicilesByPremiumOffice.isEmpty()) {
            createAccountDto.setBbcodceo("0000");
            createAccountDto.setBbcodoficinahs(bankAccountDto.getOfficeCode());
            createAccountDto.setBbcodofi(bankAccountDto.getOfficeCode());
        } else {
            createAccountDto.setBbcodceo(requestUtilities.getNextCeoCode(domicilesByPremiumOffice));
            createAccountDto.setBbcodoficinahs(domicilesByPremiumOffice.get(0).getCode());
            createAccountDto.setBbcodofi(domicilesByPremiumOffice.get(0).getCode());
        }

        String ceoCode = StringUtils.defaultIfEmpty(bankAccountDto.getCeoCode(), "0000");
        createAccountDto.setBbcodceo(ceoCode.substring(0, 4));

        createAccountDto.setBbnumterm("DIGITAL");
        createAccountDto.setAanit(documentNumber);
        createAccountDto.setBbtitularidad("");
        createAccountDto.setBbtiporetencion("3");
        createAccountDto.setBbenvioextracto(BB_ENVIO_EXTRACTO);
        createAccountDto.setDeliveryAddress(bankAccountDto.getDeliveryAddress());

        AddressDto a1 = new AddressDto();
        a1.setAddress1(addressCustomerCRM);
        a1.setAddress11("");
        a1.setBbpurposeeml1(MVP_EMAIL_PURPOSE);
        a1.setBbpurposetel1("12");
        a1.setBbpurposetel2("11");
        a1.setBbpurposetel5("15");
        a1.setBbpurposedir1("32");
        a1.setBbpurposedir2("");
        a1.setCity("5001000");
        a1.setCity2("");
        a1.setEmailaddr(bankAccountDto.getEmail());
        a1.setPhone(DataUtilities.removeCellphoneMask(StringUtils.defaultString(cellPhoneAutheticated, bankAccountDto.getCellphone())));
        createAccountDto.setA1(a1);

        //FRONT PARAMETERS
        createAccountDto.setProductid(bankAccountDto.getProductId());
        createAccountDto.setBbcodctanom(StringUtils.isEmpty(bankAccountDto.getCodNomina()) ? null : bankAccountDto.getCodNomina());
        createAccountDto.setBbtipodoc(EIdentificationType.CEDULA_CIUDADANIA.getBdbType());
        createAccountDto.setLastname(bankAccountDto.getLastName());
        createAccountDto.setSecondlastname(bankAccountDto.getSecondLastName());
        createAccountDto.setFirstname(bankAccountDto.getFirstName());
        createAccountDto.setMiddlename(bankAccountDto.getMiddleName());
        createAccountDto.setBirthdate(getDateFormat(bankAccountDto.getBirthDate()));
        createAccountDto.setBbcodvendedor(bankAccountDto.getOfficeCodeSeller());
        createAccountDto.setTxInOffice(!bankAccountDto.isTxInWeb());
        createAccountDto.setNewClient(!bankAccountDto.isCustomerExistsInCrm());
        createAccountDto.setNewCard(bankAccountDto.isClientWithDebitCards() ? 0 : 1);
        createAccountDto.setGmf(bankAccountDto.isCheckGmf() ? 1 : 0);
        createAccountDto.setFatca(bankAccountDto.getFatca());
        createAccountDto.setPostalAddress(bankAccountDto.getPostalAddress());
        createAccountDto.setSex(bankAccountDto.getGender());
        createAccountDto.setAacodciiu(bankAccountDto.getJobActivityId());
        createAccountDto.setChannel(StringUtils.defaultString(bankAccountDto.getChannel(), ""));

        return createAccountDto;
    }

    @Override
    public ObjectNode mapAccountHierarchy(AccountHierarchyReqDto accountHierarchyReqDto) {
        ObjectMapper objectMapper = new ObjectMapper();

        ObjectNode accountHierarchyAddRqDtoRes = objectMapper.createObjectNode();
        ObjectNode accountHierarchyAddRqDto = objectMapper.createObjectNode();

        accountHierarchyAddRqDto.put("rqUID", RQUID);

        ObjectNode custId = objectMapper.createObjectNode();
        custId.put("spName", SPNAME);
        custId.put("custPermId", accountHierarchyReqDto.getIdentificationNumber());
        accountHierarchyAddRqDto.putPOJO("custId", custId);

        ObjectNode networkTrnInfo = objectMapper.createObjectNode();
        networkTrnInfo.put("networkOwner", NETWORKOWNER);
        networkTrnInfo.put("terminalId", TERMINALID);
        networkTrnInfo.put("name", NAME);
        accountHierarchyAddRqDto.putPOJO("networkTrnInfo", networkTrnInfo);

        accountHierarchyAddRqDto.put("clientDt", TimeUtilities.actualDate());
        accountHierarchyAddRqDto.put("productId", accountHierarchyReqDto.getProductId());
        accountHierarchyAddRqDto.put("fiDebitTrnNum", accountHierarchyReqDto.getFiDebitTrnNum());
        accountHierarchyAddRqDto.put("trnCount", accountHierarchyReqDto.getTrnCount());

        ArrayNode acctBasicInfo = accountHierarchyAddRqDto.putArray("acctBasicInfo");
        for (AcctBasicInfoDto acctBasicInfoDto : accountHierarchyReqDto.getAcctBasicInfo()) {
            ObjectNode acctBasicInfoNode = objectMapper.createObjectNode();
            acctBasicInfoNode.put("acctId", acctBasicInfoDto.getAcctId());
            acctBasicInfoNode.put("acctType", acctBasicInfoDto.getAcctType());
            acctBasicInfoNode.put("acctSubType", acctBasicInfoDto.getAcctSubType());

            acctBasicInfo.add(acctBasicInfoNode);
        }
        accountHierarchyAddRqDtoRes.putPOJO("accountHierarchyAddRqDto", accountHierarchyAddRqDto);

        return accountHierarchyAddRqDtoRes;
    }

    @Override
    public BankAccountDto mapCreateBankAccountDto(CreateAccountDto createAccountDto, ConsultCustomerRespDto consultCustomerRespDto, String productId) {
        BankAccountDto bankAccountDto = new BankAccountDto();

        // Info from createAccountDto
        bankAccountDto.setLastName(createAccountDto.getLastname());
        bankAccountDto.setSecondLastName(createAccountDto.getSecondlastname());
        bankAccountDto.setFirstName(createAccountDto.getFirstname());
        bankAccountDto.setMiddleName(createAccountDto.getMiddlename());
        bankAccountDto.setGender(createAccountDto.getSex());
        bankAccountDto.setIdentityNumber(createAccountDto.getAanit());
        bankAccountDto.setBirthDate(TimeUtilities.changeBackToFrontFormat(createAccountDto.getBirthdate()));
        bankAccountDto.setCustomerExistsInCrm(!createAccountDto.isNewClient());
        bankAccountDto.setOfficeCode(createAccountDto.getBbcodofi());
        bankAccountDto.setOfficeCodeSeller(createAccountDto.getBbcodvendedor());
        bankAccountDto.setSellerId(createAccountDto.getBbcodvendedor());
        bankAccountDto.setCheckGmf(createAccountDto.getGmf() == 1);
        bankAccountDto.setDeliveryAddress(createAccountDto.getDeliveryAddress());

        bankAccountDto.setTxInWeb(!determinePersonalLoanInOffice(createAccountDto.isTxInOffice(), createAccountDto.getSourceTeamId(), createAccountDto.getChannel()));

        bankAccountDto.setFatca(createAccountDto.getFatca());
        bankAccountDto.setClientWithDebitCards(createAccountDto.getNewCard() == 0);
        bankAccountDto.setPostalAddress(createAccountDto.getPostalAddress());
        bankAccountDto.setCodNomina(createAccountDto.getBbcodctanom());
        bankAccountDto.setLivingCityId(createAccountDto.getCityCode());
        bankAccountDto.setChannel(StringUtils.defaultString(createAccountDto.getChannel(), ""));
        bankAccountDto.setProductId(productId);

        // Info from consultCustomerRespDto
        bankAccountDto.setExpeditionDate(consultCustomerRespDto.getExpeditionDate());
        bankAccountDto.setEmail(consultCustomerRespDto.getEmail());
        bankAccountDto.setCellphone(consultCustomerRespDto.getCellphone());
        bankAccountDto.setOccupationId(consultCustomerRespDto.getCodOcupation());
        bankAccountDto.setMonthlyIncome(consultCustomerRespDto.getValIngresos());
        bankAccountDto.setMonthlyOutcome(consultCustomerRespDto.getValEgresos());
        bankAccountDto.setTotalAssets(consultCustomerRespDto.getValActivos());
        bankAccountDto.setTotalDebts(consultCustomerRespDto.getValPasivos());
        bankAccountDto.setJobActivityId(consultCustomerRespDto.getCodCiuu());
        bankAccountDto.setAddressForCRM(consultCustomerRespDto.getAddress1());
        bankAccountDto.setAccountType(EAccount.findByCode(productId).getDescription());

        return bankAccountDto;
    }

    @Override
    public List<AcctLimitsDescDto> mapAccountLimits(List<Object[]> accountLimits) {

        return accountLimits.stream().map(accountLimit ->
                new AcctLimitsDescDto((String) accountLimit[1], (Integer) accountLimit[2], (Float) accountLimit[3], (String) accountLimit[4])
        ).collect(Collectors.toList());
    }

    @Override
    public DispatcherDto mapDispatcherByRequestAuth(String response) {
        DispatcherDto dispatcherDto = null;
        try {
            dispatcherDto = new ObjectMapper().readValue(response, DispatcherDto.class);
        } catch (IOException e) {
            log.error("<<< DISPATCHER MAPPER ERROR {} <<<", e.getMessage());
        }
        return dispatcherDto;
    }

    @Override
    public SavingConditionDto mapSavingCondition(BankAccountDto bankAccountDto, int savingTypeId, Boolean facialValidated) {
        SavingConditionDto savingConditionDto = new SavingConditionDto();

        savingConditionDto.setConditionId(bankAccountDto.getRequestId());
        savingConditionDto.setSavingTypeId(savingTypeId);
        savingConditionDto.setOfficeCode("undefined".equals(bankAccountDto.getOfficeCode()) ? "WEB" : bankAccountDto.getOfficeCode());
        savingConditionDto.setGmf(bankAccountDto.isCheckGmf());
        savingConditionDto.setFacialValidated(facialValidated);

        return savingConditionDto;
    }

    @Override
    public RequestOperationDto mapRequestOperation(long requestId, int operation) {
        RequestOperationDto requestOperationDto = new RequestOperationDto();

        requestOperationDto.setRequestId(requestId);
        requestOperationDto.setOperationTypeId(operation);

        return requestOperationDto;
    }

    @Override
    public RequestSellerDto mapRequestSeller(String node, String seller, long requestId) {
        RequestSellerDto requestSellerDto = new RequestSellerDto();

        requestSellerDto.setRequestId(requestId);
        requestSellerDto.setSeller(seller);
        requestSellerDto.setNode(node);

        return requestSellerDto;
    }

    @Override
    public RequestPayrollAccountDto mapRequestPayrollAccount(String dispersionCode, String companyNit, long requestId, String companyName) {
        RequestPayrollAccountDto requestPayrollAccountDto = new RequestPayrollAccountDto();

        requestPayrollAccountDto.setRequestId(requestId);
        requestPayrollAccountDto.setDispersionCode(dispersionCode);
        requestPayrollAccountDto.setCompanyNit(companyNit);
        requestPayrollAccountDto.setCompanyName(companyName);

        return requestPayrollAccountDto;
    }

    @Override
    public ParticipantInfoDto mapParticipantInfo(BankAccountDto bankAccountDto) {
        ParticipantInfoDto participantInfoDto = new ParticipantInfoDto();

        participantInfoDto.setRequestId(bankAccountDto.getRequestId());
        participantInfoDto.setFirstName(bankAccountDto.getFirstName());
        participantInfoDto.setSecondName(bankAccountDto.getMiddleName());
        participantInfoDto.setFirstSurname(bankAccountDto.getLastName());
        participantInfoDto.setSecondSurname(bankAccountDto.getSecondLastName());
        participantInfoDto.setSex(bankAccountDto.getGender());
        participantInfoDto.setPhone(bankAccountDto.getCellphone());
        participantInfoDto.setEmail(bankAccountDto.getEmail());
        participantInfoDto.setAddress(StringUtils.defaultString(bankAccountDto.getCrmAddress(), bankAccountDto.getAddressForCRM()));
        participantInfoDto.setActivityCode(bankAccountDto.getJobActivityId());
        participantInfoDto.setOccupation(bankAccountDto.getOccupationId() != null ? bankAccountDto.getOccupationId().toString() : null);
        participantInfoDto.setIncome(bankAccountDto.getMonthlyIncome());
        participantInfoDto.setOutcome(bankAccountDto.getMonthlyOutcome());
        participantInfoDto.setTaxCountry(bankAccountDto.getFatca());
        participantInfoDto.setCity(bankAccountDto.getLivingCityId());
        participantInfoDto.setEthnicGroup(StringUtils.defaultString(bankAccountDto.getEthnicGroup(), null));

        return participantInfoDto;
    }

    @Override
    public DomicileInfoDto mapDomicileInfo(BankAccountDto bankAccountDto) {
        DomicileInfoDto domicileInfoDto = new DomicileInfoDto();

        domicileInfoDto.setRequestId(bankAccountDto.getRequestId());
        domicileInfoDto.setAddress(getAddressForDomicileInfo(bankAccountDto));
        domicileInfoDto.setCity(StringUtils.defaultString(bankAccountDto.getLivingCityId(), bankAccountDto.getCodCity()));

        return domicileInfoDto;
    }

    private String getAddressForDomicileInfo(BankAccountDto bankAccountDto) {
        String mainAddress = StringUtils.defaultString(bankAccountDto.getDeliveryAddress(), bankAccountDto.getAddressForCRM());
        return StringUtils.defaultString(mainAddress, bankAccountDto.getCrmAddress());
    }

    @Override
    public List<RequestArrangementDto> mapRequestArrangement(BankAccountDto bankAccountDto) {
        List<RequestArrangementDto> requestArrangementDtoList = new ArrayList<>();

        RequestArrangementDto gmfArrangement = new RequestArrangementDto();
        RequestArrangementDto pensionerArrangement = new RequestArrangementDto();
        RequestArrangementDto termsArrangement = new RequestArrangementDto();

        if (bankAccountDto.isCheckGmf()) {
            gmfArrangement.setRequestId(bankAccountDto.getRequestId());
            gmfArrangement.setArrangementTypeId(2);
            requestArrangementDtoList.add(gmfArrangement);
        }
        if (bankAccountDto.isCheckPensioner()) {
            pensionerArrangement.setRequestId(bankAccountDto.getRequestId());
            pensionerArrangement.setArrangementTypeId(5);
            requestArrangementDtoList.add(pensionerArrangement);
        }

        termsArrangement.setRequestId(bankAccountDto.getRequestId());
        termsArrangement.setArrangementTypeId(3);
        requestArrangementDtoList.add(termsArrangement);

        return requestArrangementDtoList;
    }

    private boolean determinePersonalLoanInOffice(boolean isTxInOffice, int sourceTeamId, String channel) {

        boolean isOfficeOrFmv = StringUtils.isNotEmpty(channel) && (channel.equals(OFFICE_CHANNEL) || channel.equals(FMV_CHANNEL));
        boolean isTeam5 = sourceTeamId == 5;
        return isTxInOffice || (isTeam5 && isOfficeOrFmv);
    }

    private String getDateFormat(String date) {
        String dateFormatted = TimeUtilities.changeFrontToBackFormat(date);
        return StringUtils.isEmpty(dateFormatted) ? date : dateFormatted;
    }
}
