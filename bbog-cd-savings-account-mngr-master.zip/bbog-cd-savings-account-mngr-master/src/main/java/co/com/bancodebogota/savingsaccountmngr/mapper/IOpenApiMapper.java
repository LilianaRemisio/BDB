package co.com.bancodebogota.savingsaccountmngr.mapper;

import co.com.bancodebogota.dto.account.AccountData;
import co.com.bancodebogota.dto.customer.CustomerManagementRs;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.openapi.AccountDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import org.springframework.http.HttpHeaders;

public interface IOpenApiMapper {

    DispatcherDto mapDispatcher(HttpHeaders headers, String officeCode) throws AbsBdbServiceException;

    Integer getSourceTeam(String appName) throws AbsBdbServiceException;

    AccountData mapAccountData(long requestId, AccountDto accountDto, CustomerManagementRs customerManagementRs,
                               HttpHeaders httpHeaders);
}
