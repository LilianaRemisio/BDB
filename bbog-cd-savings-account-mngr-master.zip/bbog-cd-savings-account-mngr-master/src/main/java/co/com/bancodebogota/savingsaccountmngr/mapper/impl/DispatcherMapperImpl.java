package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.request.AuthFlagsDto;
import co.com.bancodebogota.dto.request.CreateRequestDto;
import co.com.bancodebogota.enums.EClientType;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.model.entities.LocationDto;
import co.com.bancodebogota.model.entities.ParticipantDto;
import co.com.bancodebogota.model.entities.RequestUtmDto;
import co.com.bancodebogota.savingsaccountmngr.mapper.IDispatcherMapper;
import co.com.bancodebogota.utils.DataUtilities;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import java.util.HashMap;
import java.util.Map;

@Service
public class DispatcherMapperImpl implements IDispatcherMapper {

    private static final String UNSAFE_SIM = "unsafeSim";
    private static final String CUSTOM_OTP = "customOtp";
    private static final String FAIL_QUESTIONS = "failQuestions";
    private static final String POTENTIAL_RISK = "potentialRisk";
    private static final String X_JOURNEY = "X-Journey";

    @Override
    public CreateRequestDto mapCreateRequest(HttpHeaders httpHeaders, DispatcherDto dispatcherDto) {

        String journey = httpHeaders.getFirst(X_JOURNEY);
        CreateRequestDto createRequestDto = new CreateRequestDto();

        createRequestDto.setProductId("CorrienteAsistido".equals(journey) ? 2 : 1);
        createRequestDto.setClient(StringUtils.equalsIgnoreCase(dispatcherDto.getCustomerState(), EClientType.ACTIVE.getDescription()));
        createRequestDto.setChannelId(dispatcherDto.getChannel());
        createRequestDto.setAuthTypeId(dispatcherDto.getAccessType());
        createRequestDto.setSourceTeamId(1);
        createRequestDto.setCreateDigitalRequest(true);
        createRequestDto.setSpiUuid(dispatcherDto.getSpecificProductInfoUuid());
        createRequestDto.setCellphone(dispatcherDto.getCellphoneUsedForAuthentication());

        JsonNode specificProductInfo = dispatcherDto.getSpecificProductInfo();

        if (specificProductInfo != null) {
            String mediumType = DataUtilities.getNodeAsText(specificProductInfo, "mediumType");
            createRequestDto.setMediumType(mediumType);

            String authMethod = DataUtilities.getNodeAsText(specificProductInfo, "authMethod");
            createRequestDto.setCustomOtp(StringUtils.equalsIgnoreCase(authMethod, "validateCustomOtp") ? 1 : 0);
        }

        ParticipantDto participantDto = new ParticipantDto(dispatcherDto.getIdentityType(),
                dispatcherDto.getIdentityNumber());
        createRequestDto.setParticipant(participantDto);

        createRequestDto.setLocationInfo(buildLocationDto(dispatcherDto));

        buildUtmInfo(dispatcherDto, createRequestDto);

        return createRequestDto;
    }

    private LocationDto buildLocationDto(DispatcherDto dispatcherDto) {
        LocationDto locationDto = new LocationDto();
        // TODOS: Validar cual debe ser el default ("undefined" para cuando se cree el digital request y se guarde el
        // modelo quede como "WEB"?)
        locationDto.setOfficeCode(StringUtils.defaultIfEmpty(dispatcherDto.getOfficeCode(), "0000"));
        locationDto.setLatitude(0d);
        locationDto.setLongitude(0d);
        locationDto.setIp(dispatcherDto.getNetwork());
        return locationDto;
    }

    private void buildUtmInfo(DispatcherDto dispatcherDto, CreateRequestDto createRequestDto) {

        JsonNode utmInfo = dispatcherDto.getUtmInfo();
        if (!ObjectUtils.isEmpty(utmInfo) && utmInfo.size() > 0) {

            String utmFbclid = DataUtilities.getNodeAsText(dispatcherDto.getUtmInfo(), "fbclid");
            String utmSource = DataUtilities.getNodeAsText(dispatcherDto.getUtmInfo(), "utm_source");
            String utmMedium = DataUtilities.getNodeAsText(dispatcherDto.getUtmInfo(), "utm_medium");
            String utmCampaign = DataUtilities.getNodeAsText(dispatcherDto.getUtmInfo(), "utm_campaign");
            String utmRefer = DataUtilities.getNodeAsText(dispatcherDto.getUtmInfo(), "utm_refer");
            String utmTerm = DataUtilities.getNodeAsText(dispatcherDto.getUtmInfo(), "utm_term");
            String utmContent = DataUtilities.getNodeAsText(dispatcherDto.getUtmInfo(), "utm_content");

            if (StringUtils.isNotEmpty(utmFbclid)) {
                utmSource = "facebook";
                utmMedium = "cpc";
                utmCampaign = "fbclid";

                ((ObjectNode) dispatcherDto.getUtmInfo()).put("utm_campaign", utmCampaign);
            }

            if (!StringUtils.isAllEmpty(utmSource, utmMedium, utmCampaign, utmRefer, utmTerm, utmContent)) {

                RequestUtmDto requestUtmDto = new RequestUtmDto();
                requestUtmDto.setSource(utmSource);
                requestUtmDto.setMedium(utmMedium);
                requestUtmDto.setCampaign(utmCampaign);
                requestUtmDto.setRefer(utmRefer);
                requestUtmDto.setTerm(utmTerm);
                requestUtmDto.setContent(utmContent);

                createRequestDto.setUtmInfo(requestUtmDto);
            }
        }
    }

    @Override
    public AuthFlagsDto handleFlags(DispatcherDto dispatcherDto, boolean isPayroll, boolean isNewClient,
                                    String identityNumber) throws AbsBdbServiceException {

        Map<String, Boolean> flags = isNewClient ? setFlags(dispatcherDto) : new HashMap<>();

        boolean enableFullFlow = true;
        if (flags.size() > 0) {
            enableFullFlow = enableFullFlow(flags, isPayroll, identityNumber);
        }

        AuthFlagsDto authFlagsDto = new AuthFlagsDto();
        authFlagsDto.setFlags(flags);
        authFlagsDto.setEnableFullFlow(enableFullFlow);

        return authFlagsDto;
    }

    private Map<String, Boolean> setFlags(DispatcherDto dispatcherDto) {
        Map<String, Boolean> flags = new HashMap<>();

        if (!ObjectUtils.isEmpty(dispatcherDto.getWasteInfo())) {
            flags.put(UNSAFE_SIM, dispatcherDto.getWasteInfo().getWaste001());
            flags.put(CUSTOM_OTP, dispatcherDto.getWasteInfo().getWaste002());
            flags.put(FAIL_QUESTIONS, dispatcherDto.getWasteInfo().getWaste003());
            flags.put(POTENTIAL_RISK, dispatcherDto.getWasteInfo().getWaste004());
        }

        return flags;
    }

    private boolean enableFullFlow(Map<String, Boolean> flags, boolean isPayroll, String identityNumber) throws AbsBdbServiceException {

        if (BooleanUtils.isTrue(flags.get(UNSAFE_SIM))) {
            throw BdbExceptionFactory.createExcepcion(HttpStatus.UNAUTHORIZED, identityNumber, UNSAFE_SIM);
        }

        if (BooleanUtils.isTrue(flags.get(FAIL_QUESTIONS))) {
            throw BdbExceptionFactory.createExcepcion(HttpStatus.UNAUTHORIZED, identityNumber, FAIL_QUESTIONS);
        }

        if (BooleanUtils.isTrue(flags.get(POTENTIAL_RISK))) {
            if (isPayroll) {
                return false;
            }

            throw BdbExceptionFactory.createExcepcion(HttpStatus.UNAUTHORIZED, identityNumber, POTENTIAL_RISK);
        }

        return BooleanUtils.isFalse(BooleanUtils.toBoolean(flags.get(CUSTOM_OTP)));
    }
}
