package co.com.bancodebogota.savingsaccountmngr.service.openapi;

import co.com.bancodebogota.dto.openapi.AccountDto;
import co.com.bancodebogota.dto.openapi.ProductDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import org.springframework.http.HttpHeaders;

public interface IOpenApiService {

    ProductDto create(HttpHeaders httpHeaders, AccountDto accountDto) throws AbsBdbServiceException;
}
