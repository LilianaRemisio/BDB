package co.com.bancodebogota.savingsaccountmngr.service.accounts;

import co.com.bancodebogota.dto.gmf.GMFTaxExemptionMarkAddRqDTO;
import co.com.bancodebogota.enums.EEventType;
import co.com.bancodebogota.savingsaccountmngr.mapper.IGMFMapper;
import co.com.bancodebogota.savingsaccountmngr.service.request.IRequestService;
import co.com.bancodebogota.rest.RestExchangeV2;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

@Slf4j
@Service
@RequiredArgsConstructor
public class GMFServiceImpl implements IGMFService {

    private static final String CHECK_GMF_RESOURCE = "/gmf/exemptionMark";

    @Value("${endpoint.accounts.adapter}")
    private String endpointAccountsAdapter;

    private final RestExchangeV2 restExchange;
    private final IGMFMapper gmfMapper;
    private final IRequestService requestService;

    @Override
    public boolean callGMF(String accountNumber, String officeCode, String identityType,
                           String identityNumber, String clientName, String cellphone, String acctType) {

        log.info(">>> ({}) SEND GMF SERVICE. NEW CALL >>>", identityNumber);
        UriComponentsBuilder urlBuilder =
                UriComponentsBuilder.fromUriString(endpointAccountsAdapter).path(CHECK_GMF_RESOURCE);
        GMFTaxExemptionMarkAddRqDTO gmfTaxExemptionMarkAddRqDTO = gmfMapper.mapGmfRequestDto(accountNumber,
                officeCode, identityType, identityNumber, clientName, cellphone, acctType);

        ResponseEntity<JsonNode> gmfResponse = restExchange.exchange(urlBuilder.toUriString(),
                gmfTaxExemptionMarkAddRqDTO,
                HttpMethod.POST, JsonNode.class);
        log.info("<<< ({}) SEND GMF SERVICE. END CALL <<<", identityNumber);

        return gmfResponse.getStatusCode() == HttpStatus.OK;
    }

    /**
     * @deprecated 11/10/22 use {{@link #callGMF}} instead
     */
    @Deprecated
    @Override
    public boolean sendNewAccountToGMFService(String accountNumber, String officeCode, String identityType, // NOSONAR
                                              String identityNumber, String clientName, String cellphone,
                                              Long requestId) {

        boolean result = callGMF(accountNumber, officeCode, identityType, identityNumber,
                clientName, cellphone, "SDA");

        requestService.saveRequestEvent(requestId, result ?
                EEventType.CHECK_GMF_ACCOUNT_EXITOSO : EEventType.CHECK_GMF_ACCOUNT_FALLIDO, identityNumber);

        return result;
    }
}
