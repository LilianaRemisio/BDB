package co.com.bancodebogota.savingsaccountmngr.service.facebookconvertions;

import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.dto.account.AccountData;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.enums.EChannel;
import co.com.bancodebogota.enums.EClientType;
import co.com.bancodebogota.savingsaccountmngr.mapper.impl.ReportMarketingMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReportMarketingServiceImpl implements IReportMarketingService {

    private static final String PROVIDER_FACEBOOK = "facebook";
    private static final String X_NAME = "CuentaDeAhorros";
    private static final String GET_CONVERTERS_FACEBOOK = "/V1/Utilities/report";
    private static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";
    private static final String X_AUTH_UUID = "X-AuthUuid";
    private static final String X_DIG_REQUEST = "X-DigRequest";
    private final RestExchangeV2 restExchange;

    @Value("${report.marketing.api.endpoint}")
    private String reportMarketingApiEndpoint;

    @Value("${tvs.api.key}")
    private String tvsApiKey;

    @Override
    public Boolean sendNewAccountCreateFacebook(AccountData accountData, DispatcherDto dispatcherDto, HttpHeaders httpHeaders) {
        String identityNumber = dispatcherDto.getIdentityNumber();
        log.info(">>> ({}) REPORT MARKETING API. NEW CALL >>>", identityNumber);

        try {
            UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromUriString(reportMarketingApiEndpoint).path(GET_CONVERTERS_FACEBOOK);

            HttpHeaders httpHeadersFace = headersFacebook(httpHeaders, identityNumber, dispatcherDto);

            ObjectNode request = ReportMarketingMapper.mapReportMarketingReq(accountData, httpHeaders);

            ResponseEntity<JsonNode> facebookResponse = restExchange.exchange(urlBuilder.toUriString(),
                    request, HttpMethod.POST, httpHeadersFace, JsonNode.class);

            log.info("<<< ({}) REPORT MARKETING API. END CALL <<<", identityNumber);

            return facebookResponse.getStatusCode().is2xxSuccessful();
        } catch (Exception e) {
            log.error("<<< ({}) REPORT MARKETING API. FAIL <<<", identityNumber);
        }
        return false;
    }

    private HttpHeaders headersFacebook(HttpHeaders httpHeaders, String identityNumber, DispatcherDto dispatcherDto) {
        HttpHeaders headersFacebook = new HttpHeaders();
        headersFacebook.add("X-Name", X_NAME);
        headersFacebook.add("X-RqUID", httpHeaders.getFirst(X_AUTH_UUID));
        headersFacebook.add("X-Channel", EChannel.getWithSpace(dispatcherDto.getChannel()));
        headersFacebook.add("X-CustidentNum", identityNumber);
        headersFacebook.add("X-CustidentType", dispatcherDto.getIdentityType());
        headersFacebook.add("X-IPAddr", StringUtils.defaultIfEmpty(httpHeaders.getFirst(X_FORWARDED_FOR),
                "").split(",")[0]);
        headersFacebook.add(X_DIG_REQUEST, httpHeaders.getFirst(X_DIG_REQUEST));
        headersFacebook.add("X-Provider", PROVIDER_FACEBOOK);
        headersFacebook.add("X-isClient", EClientType.findByDescription(dispatcherDto.getCustomerState()).getApiName());
        headersFacebook.add("X-Api-Key", tvsApiKey);
        return headersFacebook;
    }
}
