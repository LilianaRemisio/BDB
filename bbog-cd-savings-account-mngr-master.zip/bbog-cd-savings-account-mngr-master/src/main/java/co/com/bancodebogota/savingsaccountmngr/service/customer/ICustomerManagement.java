package co.com.bancodebogota.savingsaccountmngr.service.customer;

import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.dto.customer.ConsultCustomerRespDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import org.springframework.http.HttpHeaders;

public interface ICustomerManagement {

    boolean createCustomer(BankAccountDto bankAccountDto, HttpHeaders httpHeaders) throws AbsBdbServiceException;

    boolean updateCustomer(BankAccountDto bankAccountDto, ConsultCustomerRespDto consultCustomerRespDto,
                           HttpHeaders httpHeaders) throws AbsBdbServiceException;
}
