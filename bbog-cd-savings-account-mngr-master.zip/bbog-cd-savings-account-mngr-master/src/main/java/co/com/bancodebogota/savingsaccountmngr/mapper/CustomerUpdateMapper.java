package co.com.bancodebogota.savingsaccountmngr.mapper;

import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import com.fasterxml.jackson.databind.node.ObjectNode;

public interface CustomerUpdateMapper {

    ObjectNode mapCreateCustomerRequestByCreate(BankAccountDto bankAccountDto, String authUuid) throws AbsBdbServiceException;
}
