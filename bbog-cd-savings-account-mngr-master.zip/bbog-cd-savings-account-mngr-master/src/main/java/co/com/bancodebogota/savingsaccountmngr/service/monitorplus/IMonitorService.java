package co.com.bancodebogota.savingsaccountmngr.service.monitorplus;

import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.dto.monitorplus.MonitorAccountCreateDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import org.springframework.http.HttpHeaders;

public interface IMonitorService {

    void sendAccountCreate(BankAccountDto bankAccountDto, String accountNumber, String xForwardedFor, String rqUid) throws AbsBdbServiceException;

    boolean sendAccountToMonitorPlus(HttpHeaders httpHeaders, MonitorAccountCreateDto monitorAccountCreateDto);
}
