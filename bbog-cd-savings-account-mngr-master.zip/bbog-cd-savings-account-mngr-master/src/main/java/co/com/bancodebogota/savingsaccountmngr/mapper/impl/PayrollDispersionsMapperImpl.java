package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.dto.custcatteredinqrs.CustCatteredInqRsDto;
import co.com.bancodebogota.dto.custcatteredinqrs.establishacctinfo.EstablishAcctInfoDto;
import co.com.bancodebogota.dto.products.AcctBasicInfoDto;
import co.com.bancodebogota.enums.EPayrollCodes;
import co.com.bancodebogota.savingsaccountmngr.mapper.PayrollDispersionsMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PayrollDispersionsMapperImpl implements PayrollDispersionsMapper {

    @Override
    public CustCatteredInqRsDto mapDispersionCode(EPayrollCodes ePayrollCodes) {
        AcctBasicInfoDto acctBasicInfoDto = new AcctBasicInfoDto();
        EstablishAcctInfoDto establishAcctInfoDto = new EstablishAcctInfoDto();
        List<EstablishAcctInfoDto> establishAcctInfoDtoList = new ArrayList<>();

        acctBasicInfoDto.setAcctType("N");
        acctBasicInfoDto.setAcctId(ePayrollCodes.getAcctId());
        establishAcctInfoDto.setAcctBasicInfo(acctBasicInfoDto);
        establishAcctInfoDto.setLegalName(ePayrollCodes.getLegalName());
        establishAcctInfoDtoList.add(establishAcctInfoDto);

        CustCatteredInqRsDto custCatteredInqRsDto = new CustCatteredInqRsDto();
        custCatteredInqRsDto.setEstablishAcctInfo(establishAcctInfoDtoList);

        return custCatteredInqRsDto;
    }
}
