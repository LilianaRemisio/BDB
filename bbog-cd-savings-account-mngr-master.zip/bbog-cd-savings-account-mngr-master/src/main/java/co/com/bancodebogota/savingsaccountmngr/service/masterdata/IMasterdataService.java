package co.com.bancodebogota.savingsaccountmngr.service.masterdata;

import co.com.bancodebogota.dto.masterdata.TutorOfficeDef;

import java.util.List;

public interface IMasterdataService {

    List<TutorOfficeDef> getDomicilesByPremiumOffice(String premiumCode);
}
