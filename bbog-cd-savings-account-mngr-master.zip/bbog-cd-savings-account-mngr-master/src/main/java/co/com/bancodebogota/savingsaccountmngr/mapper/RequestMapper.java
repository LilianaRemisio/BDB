package co.com.bancodebogota.savingsaccountmngr.mapper;

import co.com.bancodebogota.db.savings.dto.jpa.AcctLimitsDescDto;
import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountDto;
import co.com.bancodebogota.dto.customer.ConsultCustomerRespDto;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.products.AccountHierarchyReqDto;
import co.com.bancodebogota.model.entities.*;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.List;

public interface RequestMapper {

    BankAccountDto mapCreateBankAccountDto(CreateAccountDto createAccountDto,
                                           ConsultCustomerRespDto consultCustomerRespDto, String productId);

    CreateAccountDto mapCreateAccountDtoRequest(BankAccountDto bankAccountDto, String rqUuid);

    ObjectNode mapAccountHierarchy(AccountHierarchyReqDto accountHierarchyReqDto);

    SavingConditionDto mapSavingCondition(BankAccountDto bankAccountDto, int savingTypeId, Boolean facialValidated);

    ParticipantInfoDto mapParticipantInfo(BankAccountDto bankAccountDto);

    DomicileInfoDto mapDomicileInfo(BankAccountDto bankAccountDto);

    RequestOperationDto mapRequestOperation(long requestId, int operation);

    List<RequestArrangementDto> mapRequestArrangement(BankAccountDto bankAccountDto);

    RequestSellerDto mapRequestSeller(String node, String sellerId, long requestId);

    RequestPayrollAccountDto mapRequestPayrollAccount(String dispersionCode, String companyNit, long requestId,
                                                      String companyName);

    List<AcctLimitsDescDto> mapAccountLimits(List<Object[]> accountLimits);

    DispatcherDto mapDispatcherByRequestAuth(String response);
}
