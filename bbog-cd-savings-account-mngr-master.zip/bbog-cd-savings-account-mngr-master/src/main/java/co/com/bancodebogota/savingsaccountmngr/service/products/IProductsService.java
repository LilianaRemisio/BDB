package co.com.bancodebogota.savingsaccountmngr.service.products;

import co.com.bancodebogota.dto.products.AcctBasicInfoDto;
import co.com.bancodebogota.dto.products.ProductAccountDto;
import co.com.bancodebogota.dto.products.ProductsHandledDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;

import java.util.List;

public interface IProductsService {

    ProductAccountDto getClientProducts(String identityType, String identityNumber, String rqUid,
                                        String channel, String userIp) throws AbsBdbServiceException;

    List<AcctBasicInfoDto> getFilteredAccountsList(String identityNumber, String rqUid, String channel,
                                                   String userIp, String numberCard) throws AbsBdbServiceException;

    ProductsHandledDto getFilteredCards(ProductAccountDto productAccountDto);
}
