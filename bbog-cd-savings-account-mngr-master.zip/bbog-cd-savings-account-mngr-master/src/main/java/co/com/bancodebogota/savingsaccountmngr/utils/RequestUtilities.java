package co.com.bancodebogota.savingsaccountmngr.utils;

import co.com.bancodebogota.dto.masterdata.TutorOfficeDef;
import co.com.bancodebogota.enums.EChannel;

import java.util.List;

public interface RequestUtilities {
	
	String getNextCeoCode(List<TutorOfficeDef> tutorOfficeDefList);
	int getChannelFromLauncher(String mediumType, String channel);
	String validateOpbChannel(String channel, EChannel channelType);
}
