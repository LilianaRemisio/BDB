package co.com.bancodebogota.savingsaccountmngr.service.customer;

import co.com.bancodebogota.dto.balanceinquiry.AccInfoDto;
import co.com.bancodebogota.dto.responsereactivation.ReactivationRsDto;
import co.com.bancodebogota.dto.responsereactivation.ReactivationRspDto;
import co.com.bancodebogota.enums.EChannel;
import co.com.bancodebogota.enums.EIdentificationType;
import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.savingsaccountmngr.mapper.IPentagonMapper;
import co.com.bancodebogota.service.pentagon.IPentagonService;
import co.com.bancodebogota.utils.JacksonUtilsV2;
import co.com.bancodebogota.debitcards.CardInfoDto;
import co.com.bancodebogota.dto.customer.*;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.products.ProductAccountDto;
import co.com.bancodebogota.dto.products.ProductDto;
import co.com.bancodebogota.dto.products.ProductsHandledDto;
import co.com.bancodebogota.enums.EAccount;
import co.com.bancodebogota.enums.EUnitTime;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.model.entitiesold.AccountLog;
import co.com.bancodebogota.model.repositories.AccountLogRepository;
import co.com.bancodebogota.savingsaccountmngr.mapper.IPojoMapper;
import co.com.bancodebogota.savingsaccountmngr.service.products.IProductsService;
import co.com.bancodebogota.service.customer.ICustomerApiService;
import co.com.bancodebogota.service.customerv3.ICustomerApiV3Service;
import co.com.bancodebogota.service.product.IProductService;
import co.com.bancodebogota.service.redis.IRedisApiService;
import co.com.bancodebogota.utils.ProductUtilities;
import co.com.bancodebogota.utils.DataUtilities;
import co.com.bancodebogota.utils.TimeUtilities;
import co.com.bancodebogota.utils.Utilities;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.sql.Timestamp;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements ICustomerService {

    @Value("${customer.account.product.management.endpoint:#{null}}")
    private String reactivationApiEndPoint;
    @Value("${balance.management.api.endpoint:#{null}}")
    private String balanceInquiryApiEndpoint;
    @Value("${balance.management.api.key:#{null}}")
    private String balanceManagementApiKey;
    private final RestExchangeV2 restExchange;
    private final ObjectMapper objectMapper;
    private final IRedisApiService redisApiService;
    private final ICustomerApiService customerApiService;
    private final IProductsService productsService;
    private final IPentagonService pentagonService;

    private final ICustomerApiV3Service customerApiServiceV3;
    private final IProductService productService;
    private final AccountLogRepository accountLogRepository;
    private final IPojoMapper custInfoPojoMapper;
    private final IPentagonMapper pentagonMapper;

    private static final String TYPE_IDENTIFICATION = "CC";
    private static final String X_AUTH_UUID = "X-AuthUuid";
    private static final String X_CHANNEL = "X-Channel";
    private static final String X_FORWARDED_FOR = "X-Forwarded-For";
    private static final String DISPATCHER_KEY = "DispatcherKey";
    private static final String X_RQ_UID = "X-RqUID";
    private static final String X_IDENTIFICATION_NUMBER = "Identification-Number";
    private static final String BALANCE_INQUIRY_API_RESOURCE = "/V1/Enterprise/BalanceManagement/";
    private static final String REACTIVATION_API_SOURCE = "/V1/enterprise/customer/product/modify-status";
    private static final String RETRIEVE_SAVING_BALANCE = "/retrieveSavingBalance";
    private static final String TERMINALID = "IN01";

    @Override
    public JsonNode getCustomerInfo(HttpHeaders httpHeaders) throws AbsBdbServiceException {
        String channel = httpHeaders.getFirst(X_CHANNEL);
        String userIp = httpHeaders.getFirst(X_FORWARDED_FOR);
        String rqUID = httpHeaders.getFirst(X_AUTH_UUID);

        DispatcherDto dispatcherDto = redisApiService.getHash("CC", httpHeaders.getFirst(X_AUTH_UUID),
                DISPATCHER_KEY, httpHeaders.getFirst(X_AUTH_UUID), DispatcherDto.class);
        String identityType = "CC";
        String identityNumber = dispatcherDto.getIdentityNumber();

        ObjectNode serialize;
        log.info(">>> ({}) GET CUSTOMER INFO. NEW CALL >>>", identityNumber);

        boolean validAddressToCRM;

        ConsultCustomerRespDto consultCustomerRespDto = getCustomerInfoFromBackend(identityNumber, rqUID, channel, userIp);
        if (consultCustomerRespDto != null) {
            ResponseBlacklist responseBlacklist = customerApiService.getBlacklist(identityNumber, identityType, rqUID);
            if (!responseBlacklist.isCanContinue()) {
                throw BdbExceptionFactory.createExcepcion(HttpStatus.LOCKED, identityNumber, "Client in blacklist");
            }

            validAddressToCRM = Utilities.validateForCrm(consultCustomerRespDto.getAddress1());
            consultCustomerRespDto.setExpeditionDate(TimeUtilities.changeFrontToBackFormat(consultCustomerRespDto.getExpeditionDate()));

            serialize = consultCustomerRespDto.serialize();

        } else {
            throw BdbExceptionFactory.createExcepcion(HttpStatus.NOT_FOUND, identityNumber, "Customer info not found");
        }

        ProductAccountDto productAccountDto = productsService.getClientProducts(identityType, identityNumber, rqUID, channel, userIp);
        SafeInfoDef safeInfoDef = customerApiServiceV3.getSafeData(identityNumber, rqUID, channel, userIp);

        List<AccountLog> digitalAccounts = getDigitalAccounts(productAccountDto);
        boolean customerHasDigitalAccount = !digitalAccounts.isEmpty();

        serialize.put("hasDigitalAccount", Boolean.toString(customerHasDigitalAccount));
        serialize.put("validAddressToCRM", Boolean.toString(validAddressToCRM));
        serialize.put("email", safeInfoDef.getEmailAddr());
        serialize.put("cellphone", safeInfoDef.getPhone());
        serialize.setAll(getCustomerStatus(productAccountDto));

        log.info("El cliente ({}) tiene cuenta digital activa ({})", identityNumber, customerHasDigitalAccount);
        log.info("<<< ({}) GET CUSTOMER INFO. SUCCESSFUL END <<<", identityNumber);
        return serialize;
    }

    @Override
    public ConsultCustomerRespDto getCustomerInfoFromBackend(String identityNumber, String rqUID, String channel, String userIp) throws AbsBdbServiceException {
        identityNumber = DataUtilities.sanitize(identityNumber);

        CustomerManagementRs customerManagementRs = customerApiService.getInfo(identityNumber, rqUID, channel, userIp);
        return custInfoPojoMapper.mapConsultCustomerRespDto(customerManagementRs);
    }

    @Override
    public DigitalAccountRsDto hasDigitalAccount(HttpHeaders httpHeaders) throws AbsBdbServiceException {
        DispatcherDto dispatcherDto = redisApiService.getHash("CC", httpHeaders.getFirst(X_AUTH_UUID),
                DISPATCHER_KEY, httpHeaders.getFirst(X_AUTH_UUID), DispatcherDto.class);

        return hasDigitalAccount(dispatcherDto.getIdentityNumber(), httpHeaders.getFirst(X_AUTH_UUID),
                httpHeaders.getFirst(X_CHANNEL), httpHeaders.getFirst(X_FORWARDED_FOR));
    }

    @Override
    public DigitalAccountRsDto hasDigitalAccount(String identityNumber, String rqUid, String channel, String xForwardedFor) throws AbsBdbServiceException {
        String field = "cd-running";
        identityNumber = DataUtilities.sanitize(identityNumber);
        log.info(">>> ({}) HAS DIGITAL ACCOUNT. NEW CALL >>>", identityNumber);
        DigitalAccountRsDto response = new DigitalAccountRsDto();

        String key = String.format("%s:%s:%s:%s", "CD", TYPE_IDENTIFICATION, identityNumber, field);
        Boolean serviceRunning = redisApiService.getKey(key, rqUid, Boolean.class);

        if (serviceRunning == null) {
            redisApiService.saveKey(key, "1", EUnitTime.MINUTES, rqUid, Boolean.TRUE);
        } else {
            throw BdbExceptionFactory.createExcepcion(HttpStatus.CONFLICT, identityNumber, "Service already running");
        }

        List<AccountLog> accountLogs = accountLogRepository.getAccountLogByIdentityNumber(identityNumber);
        boolean hasAccount = !accountLogs.isEmpty();

        log.info("Client {} has digital account in DB: {}", identityNumber, hasAccount);
        response.setHasAccount(hasAccount);
        validateEachAccount(accountLogs, response);

        try {
            ProductAccountDto productAccountDto = productsService
                    .getClientProducts("CC", identityNumber, rqUid, channel, xForwardedFor.split(",")[0]);

            List<AccountLog> digitalAccounts = getDigitalAccounts(productAccountDto);
            log.info("Digital Accounts for {} {}", identityNumber, JacksonUtilsV2.getPlainJson(digitalAccounts));
            response.setHasAccount(!digitalAccounts.isEmpty());
            validateEachAccount(digitalAccounts, response);
        } catch (AbsBdbServiceException e) {
            log.info("Cliente {} no tiene productos en CRM", identityNumber);
        }

        log.info("<<< ({}) HAS DIGITAL ACCOUNT. SUCCESSFUL END <<<", identityNumber);
        return response;
    }

    private List<AccountLog> getDigitalAccounts(ProductAccountDto productAccountDto) {

        List<AccountLog> digitalAccounts = new ArrayList<>();

        List<ProductDto> activeAccounts = productAccountDto.getProductAccount().stream()
                .filter(product -> "Account".equals(product.getProduct())
                        && "A".equals(product.getProductStatusCode())
                        && Arrays.stream(EAccount.values()).anyMatch(e -> e.getCode().equals(product.getAcctSubType())))
                .collect(Collectors.toList());

        activeAccounts.forEach(account -> {
            String accountNumber = account.getProductId().startsWith("0") ? account.getProductId().substring(1) : account.getProductId();
            AccountLog accountLogInDB = accountLogRepository.findByAccountNumber(accountNumber);

            if (accountLogInDB != null) digitalAccounts.add(accountLogInDB);
        });

        return digitalAccounts;
    }

    private void validateEachAccount(List<AccountLog> accountLogs, DigitalAccountRsDto response) {
        for (AccountLog account : accountLogs) {
            response.setAccountNumber(account.getAccountNumber());
            response.setDate(TimeUtilities.timestampToFormat(account.getDate(), "yyyy-MM-dd HH:mm:ss"));
            response.setRecent(verifyCreatedDate(TimeUtilities.getCurrentTimestampGMTMinus5(), account));
        }
    }

    private boolean verifyCreatedDate(Timestamp actualTime, AccountLog accountLog) {
        Timestamp time = accountLog.getDate();
        if (actualTime.getTime() - time.getTime() < 3600000) {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    private ObjectNode getCustomerStatus(ProductAccountDto productAccountDto) {

        ObjectNode response = objectMapper.createObjectNode();
        ProductsHandledDto productsHandledDto = productsService.getFilteredCards(productAccountDto);

        List<CardInfoDto> activeCards = productsHandledDto.getActiveCards();
        List<CardInfoDto> tempCards = productsHandledDto.getTempCards();
        boolean clientWithActiveCards = !activeCards.isEmpty();
        boolean clientWithTempCards = !tempCards.isEmpty();
        boolean clientWithLockedCards = !productsHandledDto.getLockedCards().isEmpty();

        response.put("clientWithPinUniversal", String.valueOf(ProductUtilities.checkUniversalPin(productAccountDto)));
        response.put("clientWithDebitCards", String.valueOf(clientWithActiveCards));
        response.put("clientWithTempLock", String.valueOf(clientWithTempCards && !clientWithActiveCards));
        response.put("clientWithDefinitiveLock", String.valueOf(clientWithLockedCards && !clientWithActiveCards));
        response.put("clientWithElectron", String.valueOf(productsHandledDto.isClientWithElectron()));

        ArrayNode activeCardsNode = objectMapper.valueToTree(activeCards);
        ArrayNode tempCardsNode = objectMapper.valueToTree(tempCards);

        if (clientWithActiveCards) {
            response.putArray("activeCards").addAll(activeCardsNode);
            if (clientWithTempCards) {
                response.putArray("_tempCards").addAll(tempCardsNode);
            }
        }

        return response;
    }

    @Override
    public List<ProductDto> getProducts(HttpHeaders httpHeaders) throws AbsBdbServiceException {
        String identification = httpHeaders.getFirst(X_IDENTIFICATION_NUMBER);

        String identificationNumberDecode = new String(Base64.getDecoder().decode(identification));
        String identityNumber = identificationNumberDecode.substring(0, identificationNumberDecode.length() - 1);
        String identityType = identificationNumberDecode.substring(identificationNumberDecode.length() - 1);

        String rqUID = httpHeaders.getFirst(X_RQ_UID);
        String channel = httpHeaders.getFirst(X_CHANNEL);
        String userIp = httpHeaders.getFirst(X_FORWARDED_FOR);

        ProductAccountDto productAccountDto = productService.getProducts(rqUID, channel, identityType, identityNumber, userIp);

        return productAccountDto.getProductAccount().stream().filter(account ->
                        (account.getProductType().equals("SDA") && account.getProductStatusCode().equals("A")) ||
                                (account.getProductType().equals("DEB") && account.getProductStatusCode().equals("N")) &&
                                        !Pattern.compile("^7777(67|68|69|70)").matcher(account.getProductId()).find())
                .collect(Collectors.toList());
    }

    @Override
    public List<ProductDto> getInactiveProducts(HttpHeaders httpHeaders) throws AbsBdbServiceException {
        String identification = httpHeaders.getFirst(X_IDENTIFICATION_NUMBER);

        String identificationNumberDecode = new String(Base64.getDecoder().decode(identification));
        String identityNumber = identificationNumberDecode.substring(0, identificationNumberDecode.length() - 1);
        String identityType = identificationNumberDecode.substring(identificationNumberDecode.length() - 1);

        String rqUID = httpHeaders.getFirst(X_RQ_UID);
        String channel = httpHeaders.getFirst(X_CHANNEL);
        String userIp = httpHeaders.getFirst(X_FORWARDED_FOR);

        ProductAccountDto productAccountDto = productService.getProducts(rqUID, channel, identityType, identityNumber, userIp);

        List<ProductDto> inactiveProducts = productAccountDto.getProductAccount().stream().filter(account ->
                        (account.getProductType().equals("SDA") && account.getProductStatusCode().equals("I")) &&
                                !Pattern.compile("^7777(67|68|69|70)").matcher(account.getProductId()).find())
                .collect(Collectors.toList());

        pentagonService.publishSns(httpHeaders, pentagonMapper.mapInactiveProducts(inactiveProducts), identityNumber);
        return inactiveProducts;
    }

    @Override
    public AccInfoDto getBalanceInquiry(HttpHeaders httpHeaders, String acctId) throws AbsBdbServiceException {

        byte[] decodedBytes = Base64.getDecoder().decode(httpHeaders.getFirst(X_IDENTIFICATION_NUMBER));
        String identityNum = new String(decodedBytes).replaceAll("[^\\d]", "");

        getHeaders(httpHeaders, identityNum);

        log.info(">>> ({}) GET BALANCE INQUIRY. NEW CALL >>>", identityNum);

        UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromUriString(balanceInquiryApiEndpoint).path(BALANCE_INQUIRY_API_RESOURCE)
                .path(acctId).path(RETRIEVE_SAVING_BALANCE);

        ResponseEntity<AccInfoDto> response = restExchange.exchange(urlBuilder.toUriString(), null,
                HttpMethod.GET, httpHeaders, AccInfoDto.class);

        if (response.getStatusCode().isError()) {
            log.info("<<< ({}) GET BALANCE INQUIRY. FAIL END <<<", identityNum);
            throw BdbExceptionFactory.createExcepcion(response.getStatusCode(), identityNum, "Error get balance inquiry");
        }

        log.info("<<< ({}) GET BALANCE INQUIRY. SUCCESSFUL END <<<", identityNum);
        return response.getBody();
    }

    @Override
    public ReactivationRsDto reactivateAccount(HttpHeaders httpHeaders, ReactivationRspDto reactivationRspDto) throws AbsBdbServiceException {
        byte[] decodedBytes = Base64.getDecoder().decode(httpHeaders.getFirst(X_IDENTIFICATION_NUMBER));
        String identityNum = new String(decodedBytes).replaceAll("[^\\d]", "");

        log.info(">>> ({}) GET REACTIVATION ACCOUNT. NEW CALL >>>", identityNum);

        getHeadersReactivation(httpHeaders, identityNum);

        UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromUriString(reactivationApiEndPoint).path(REACTIVATION_API_SOURCE);
        ResponseEntity<ReactivationRsDto> response = restExchange.exchange(urlBuilder.toUriString(), reactivationRspDto,
                HttpMethod.PUT, httpHeaders, ReactivationRsDto.class);

        if (response.getStatusCode().isError() || !response.getBody().getStatus().getServerStatusCode().equalsIgnoreCase("OK")) {
            log.info("<<< ({}) GET REACTIVATION ACCOUNT. FAIL END <<<", identityNum);
            pentagonService.publishSns(httpHeaders, pentagonMapper.mapReactivateAccount(false), identityNum);

            throw BdbExceptionFactory.createExcepcion(response.getStatusCode(), identityNum, "Error put reactivation account");
        }

        pentagonService.publishSns(httpHeaders, pentagonMapper.mapReactivateAccount(true), identityNum);

        log.info("<<< ({}) GET REACTIVATION ACCOUNT. SUCCESSFUL END <<<", identityNum);
        return response.getBody();
    }

    private HttpHeaders getHeaders(HttpHeaders httpHeaders, String identityNum) {
        httpHeaders.add("X-CustIdentType", EIdentificationType.CEDULA_CIUDADANIA.getApiType());
        httpHeaders.add("X-CustIdentNum", identityNum);
        httpHeaders.add("X-Name", "CuentaDeAhorros");
        httpHeaders.add("X-CompanyId", "860002964");
        httpHeaders.add("X-TerminalId", TERMINALID);
        httpHeaders.add("x-api-key", balanceManagementApiKey);

        return httpHeaders;
    }

    private HttpHeaders getHeadersReactivation(HttpHeaders httpHeaders, String identityNum) {
        httpHeaders.add("X-CompanyId", "860002964");
        httpHeaders.add("X-Name", "CD");
        httpHeaders.add(X_CHANNEL, EChannel.WEB.getNotSpaced());
        httpHeaders.add("X-IPAddr", httpHeaders.getFirst(X_FORWARDED_FOR).split(",")[0].trim());
        httpHeaders.add("X-GovIssueIdentType", EIdentificationType.CEDULA_CIUDADANIA.getApiType());
        httpHeaders.add("X-IdentSerialNum", identityNum);
        httpHeaders.add("x-api-key", balanceManagementApiKey);

        return httpHeaders;
    }
}
