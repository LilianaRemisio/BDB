package co.com.bancodebogota.savingsaccountmngr.mapper;

import co.com.bancodebogota.dto.pentagon.EventDataDto;
import co.com.bancodebogota.dto.products.ProductDto;

import java.util.List;

public interface IPentagonMapper {
    EventDataDto mapCreateDigitalRequest (Long digitalId, int status, String message);

    EventDataDto mapInactiveProducts(List<ProductDto> inactiveProducts);

    EventDataDto mapReactivateAccount(boolean isReactivated);
}
