package co.com.bancodebogota.savingsaccountmngr.service.customer;

import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.dto.customer.ConsultCustomerRespDto;
import co.com.bancodebogota.dto.customer.RequestCustomerInquiry;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.savingsaccountmngr.mapper.ICustomerCrmMapper;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

@Slf4j
@Service("CustomerManagementImpl")
@RequiredArgsConstructor
public class CustomerManagementImpl implements ICustomerManagement {

    @Value("${customer.api.endpoint}")
    private String customerApiEndpoint;

    @Value("${tvs.api.key}")
    private String tvsApiKey;

    private final ICustomerCrmMapper customerCrmMapper;
    private final RestExchangeV2 restExchange;
    private final ICustomerService customerService;

    private static final String X_AUTH_UUID = "X-AuthUuid";
    private static final String CUSTOMER_RESOURCE = "V2/enterprise/customer";

    @Override
    public boolean createCustomer(BankAccountDto bankAccountDto, HttpHeaders httpHeaders) throws AbsBdbServiceException {
        log.info(">>> ({}) CREATE CUSTOMER. NEW CALL >>>", bankAccountDto.getIdentityNumber());
        String authUuid = httpHeaders.getFirst(X_AUTH_UUID);
        ResponseEntity<Object> response;

        RequestCustomerInquiry iRequestCustomerInquiry = customerCrmMapper.mapCreateCustomerDto(bankAccountDto);
        response = createCustomerOpenApi(bankAccountDto, iRequestCustomerInquiry, authUuid);

        boolean customerCreatedInCrm = response.getStatusCode().is2xxSuccessful();

        if (!customerCreatedInCrm) {
            ConsultCustomerRespDto consultCustomerRespDto =
                    customerService.getCustomerInfoFromBackend(bankAccountDto.getIdentityNumber(), authUuid,
                            bankAccountDto.getChannel(), bankAccountDto.getUserIp());
            customerCreatedInCrm = consultCustomerRespDto != null;
            log.info(">>> ({}) TRACK DOUBLE VALIDATION ON API CREATION FAIL ({}) <<<",
                    bankAccountDto.getIdentityNumber(), customerCreatedInCrm);
        }

        if (response.getStatusCode().isError() && !customerCreatedInCrm) {
            throw BdbExceptionFactory.createExcepcion(response.getStatusCode(), bankAccountDto.getIdentityNumber(),
                    "Error creating customer in CRM");
        }

        log.info("<<< ({}) CREATE CUSTOMER. SUCCESSFUL END <<<", bankAccountDto.getIdentityNumber());

        return customerCreatedInCrm;
    }

    @Override
    public boolean updateCustomer(BankAccountDto bankAccountDto, ConsultCustomerRespDto consultCustomerRespDto,
                                  HttpHeaders httpHeaders) throws AbsBdbServiceException {
        log.info(">>> ({}) UPDATE CUSTOMER. NEW CALL >>>", bankAccountDto.getIdentityNumber());

        String authUuid = httpHeaders.getFirst(X_AUTH_UUID);
        ResponseEntity<Object> response;

        JsonNode requestCustomerUpdateInquiryInquiry = customerCrmMapper.mapUpdateCustomerDto(bankAccountDto,
                consultCustomerRespDto);
        response = updateCustomerOpenApi(requestCustomerUpdateInquiryInquiry, bankAccountDto, authUuid);

        log.info("<<< ({}) UPDATE CUSTOMER. SUCCESSFUL END <<<", bankAccountDto.getIdentityNumber());

        return response.getStatusCode().is2xxSuccessful();
    }

    private ResponseEntity<Object> createCustomerOpenApi(BankAccountDto bankAccountDto, RequestCustomerInquiry request, String rqUID) {

        log.info(">>> ({}) CREATE CUSTOMER BY OPEN API. NEW CALL >>>", bankAccountDto.getIdentityNumber());

        UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromUriString(customerApiEndpoint).path(CUSTOMER_RESOURCE);
        HttpHeaders headers = getCustomerOpenApiHeaders(rqUID, bankAccountDto.getChannel(),
                bankAccountDto.getIdentityNumber(), bankAccountDto.getUserIp());

        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        return restExchange.exchange(urlBuilder.toUriString(), mapper.valueToTree(request), HttpMethod.POST, headers, Object.class);
    }

    private ResponseEntity<Object> updateCustomerOpenApi(JsonNode request, BankAccountDto bankAccountDto, String rqUID) {

        log.info(">>> ({}) UPDATE CUSTOMER BY OPEN API. NEW CALL >>>", bankAccountDto.getIdentityNumber());

        UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromUriString(customerApiEndpoint).path(CUSTOMER_RESOURCE);
        HttpHeaders headers = getCustomerOpenApiHeaders(rqUID, bankAccountDto.getChannel(),
                bankAccountDto.getIdentityNumber(), bankAccountDto.getUserIp());

        return restExchange.exchange(urlBuilder.toUriString(), request, HttpMethod.PUT, headers, Object.class);
    }

    private HttpHeaders getCustomerOpenApiHeaders(String rqUID, String channel, String identityNumber, String userIp) {
        HttpHeaders headers = new HttpHeaders();

        headers.add("X-RqUID", rqUID);
        headers.add("X-Channel", channel);
        headers.add("X-CompanyId", "860002964");
        headers.add("X-GovIssueIdentType", "CC");
        headers.add("X-IdentSerialNum", identityNumber);
        headers.add("X-IPAddr", userIp);
        headers.add("X-Name", "CuentaDeAhorros");
        headers.add("X-API-KEY", tvsApiKey);

        return headers;
    }
}
