package co.com.bancodebogota.savingsaccountmngr.interceptors;

import co.com.bancodebogota.TokenException;
import co.com.bancodebogota.dto.interceptor.AuthenticationExceptionResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Date;
import java.util.UUID;

@Slf4j
@RestControllerAdvice
public class ControllerAdvice {

    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ExceptionHandler(TokenException.class)
    public AuthenticationExceptionResponse handleTokenException(TokenException e) {
        String message = String.format(
                "<Authenticacion-%s> Expired session!,Not valid token for resource %s -----> user %s",
                e.getDocumentNumber(), e.getServiceName(), e.getDocumentNumber());
        String errorId = UUID.randomUUID().toString();
        log.error("{} {}", errorId, message);
        return new AuthenticationExceptionResponse(new Date(), "Incorrect client credentials!", errorId);
    }
}
