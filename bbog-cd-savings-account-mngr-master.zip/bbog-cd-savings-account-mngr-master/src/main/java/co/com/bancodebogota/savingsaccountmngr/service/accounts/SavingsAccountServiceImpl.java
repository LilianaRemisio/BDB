package co.com.bancodebogota.savingsaccountmngr.service.accounts;

import co.com.bancodebogota.utils.JacksonUtilsV2;
import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.cipher.MD5Utilities;
import co.com.bancodebogota.db.savings.dto.jpa.*;
import co.com.bancodebogota.dto.customer.ConsultCustomerRespDto;
import co.com.bancodebogota.dto.customer.DigitalAccountRsDto;
import co.com.bancodebogota.dto.customer.ResponseBlacklist;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.notifications.ParameterTypeDto;
import co.com.bancodebogota.dto.notifications.RequestNotificationEmail;
import co.com.bancodebogota.dto.notifications.RequestNotificationMessage;
import co.com.bancodebogota.dto.pentagon.EventDataDto;
import co.com.bancodebogota.dto.pentagon.EventIdentityDto;
import co.com.bancodebogota.dto.products.AccountHierarchyReqDto;
import co.com.bancodebogota.dto.products.AcctBasicInfoDto;
import co.com.bancodebogota.enums.*;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.model.entities.*;
import co.com.bancodebogota.model.entitiesold.AccountLog;
import co.com.bancodebogota.model.repositories.*;
import co.com.bancodebogota.proxy.AccountLogProxy;
import co.com.bancodebogota.savingsaccountmngr.mapper.RequestMapper;
import co.com.bancodebogota.savingsaccountmngr.mapper.impl.AccountLimitMapperDto;
import co.com.bancodebogota.savingsaccountmngr.service.customer.ICustomerManagement;
import co.com.bancodebogota.savingsaccountmngr.service.customer.ICustomerService;
import co.com.bancodebogota.savingsaccountmngr.service.customer.IParticipantService;
import co.com.bancodebogota.savingsaccountmngr.service.fatca.IFatcaService;
import co.com.bancodebogota.savingsaccountmngr.service.monitorplus.IMonitorService;
import co.com.bancodebogota.savingsaccountmngr.service.products.IProductsService;
import co.com.bancodebogota.savingsaccountmngr.service.request.ICheckLogService;
import co.com.bancodebogota.savingsaccountmngr.service.request.IRequestService;
import co.com.bancodebogota.service.customer.ICustomerApiService;
import co.com.bancodebogota.service.notifications.INotificationApiService;
import co.com.bancodebogota.service.pentagon.IPentagonService;
import co.com.bancodebogota.service.redis.IRedisApiService;
import co.com.bancodebogota.utils.DataUtilities;
import co.com.bancodebogota.utils.TimeUtilities;
import co.com.bancodebogota.utils.Utilities;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.*;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Service
@RequiredArgsConstructor
public class SavingsAccountServiceImpl implements ISavingsAccountService {

    @Value("${endpoint.accounts.adapter}")
    private String endpointAccountsAdapter;
    @Value("${spring.redis.bankAccountDto.alive}")
    private String redisBankAccountDtoAlive;
    @Value("${card.activation.endpoint}")
    private String cardActivationEndpoint;

    private final RequestMapper requestMapper;
    private final ObjectMapper objectMapper;
    private final RestExchangeV2 restExchange;
    private final IRedisApiService redisApiService;
    private final AccountLogRepository accountLogRepository;
    private final AccountLogProxy accountLogProxy;
    private final IParticipantService participantService;
    private final IMonitorService monitorService;
    private final ICustomerService customerService;
    private final IProductsService productsService;
    private final ICheckLogService checkLogService;
    private final RequestRepository requestRepository;
    private final ParticipantRepository participantRepository;
    private final ParticipantInfoRepository participantInfoRepository;
    private final SavingConditionRepository savingConditionRepository;
    private final SavingTypeRepository savingTypeRepository;
    private final ConditionRepository conditionRepository;
    private final DomicileInfoRepository domicileInfoRepository;
    private final ICustomerApiService customerApiService;
    private final ICustomerManagement customerManagement;
    private final INotificationApiService notificationApiService;
    private final IRequestService requestService;
    private final IGMFService gmfService;
    private final IFatcaService fatcaService;
    private final ChannelRepository channelRepository;
    private final IPentagonService pentagonService;

    private static final String CUSTOMER_IS_NEW = "CUSTOMER_IS_NEW";
    private static final String ACCOUNT_LIMIT_RESOURCE = "/updateAccountLimit";
    private static final String CREATE_ACCOUNT_RESOURCE = "/createSavingAccount";
    private static final String PRODUCTID_KEY = "productId";
    private static final String GMF_KEY = "gmf";
    private static final String FATCA_KEY = "fatca";
    private static final String FATCA_COUNTRY_KEY = "fatcaCountry";
    private static final String WEB = "WEB";
    private static final String HIERARCHY_ACCOUNT_RESOURCE = "/hierarchy/account";
    private static final String SESSION_KEY = "SESSION";
    private static final String KEY_PAYLOAD_ACTIVATE_CARD = "KEY_PAYLOAD_ACTIVATE_CARD";
    private static final String IDENTITY_NUMBER = "identityNumber";
    private static final String IDENTITY_TYPE = "identityType";
    private static final String REQUEST_ID = "requestId";
    private static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";
    private static final String USER_AGENT = "User-Agent";
    private static final String ACCESS_TOKEN = "access-token";
    private static final String X_AUTH_UUID = "X-AuthUuid";
    private static final String X_CHANNEL = "X-Channel";
    private static final String DISPATCHER_KEY = "DispatcherKey";
    private static final String X_MEDIUM = "X-Medium";
    private static final String X_SOURCE_CHANNEL = "X-SourceChannel";
    private static final String X_NAME = "X-Name";

    @Override
    public ResponseEntity<JsonNode> createAccountByUuid(JsonNode data, HttpHeaders httpHeaders) throws AbsBdbServiceException {

        log.info(">>> CREATE ACCOUNT BY UUID. NEW CALL >>>");

        String userIp = StringUtils.defaultIfEmpty(httpHeaders.getFirst(X_FORWARDED_FOR), "").split(",")[0];

        if (data == null) {
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, null, "data is null ");
        }

        if (data.get(PRODUCTID_KEY) == null || data.get(PRODUCTID_KEY).asText().equals("")) {
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, null, "data.ProductId is null ");
        }

        String uuid = data.get("uuid").asText();
        CreateAccountDto createAccountDto = participantService.getParticipantInfo(uuid);
        if (createAccountDto == null) {
            throw BdbExceptionFactory.createExcepcion(HttpStatus.NOT_FOUND, null, "Error consumiendo el servicio " +
                    "getParticipantInfo");
        }

        validateGMFAndFatca(data, createAccountDto);

        long requestId;

        if (createAccountDto.getSourceTeamId() == 3) {
            log.info("Cuenta creada desde Libranza con requestId: {}", data.get(REQUEST_ID));
            httpHeaders.set(X_NAME, "Libranzas");
            requestId = data.get(REQUEST_ID).asLong();
        } else {
            httpHeaders.set(X_NAME, "LibreDestino");
            RequestDto requestDto = getRequestForUuidAccount(!createAccountDto.isNewClient(),
                    StringUtils.defaultIfEmpty(createAccountDto.getChannel(), EChannel.WEB.getSpaced()), createAccountDto.getSourceTeamId());
            requestId = requestDto.getId();
        }

        ConsultCustomerRespDto consultCustomerRespDto =
                customerService.getCustomerInfoFromBackend(createAccountDto.getAanit(), uuid,
                        StringUtils.defaultIfEmpty(createAccountDto.getChannel(), WEB), userIp);

        if (consultCustomerRespDto == null) {
            throw BdbExceptionFactory.createExcepcion(HttpStatus.NOT_FOUND, null, "Error consumiendo el servicio " +
                    "getCustomerInfo CRM");
        }

        BankAccountDto bankAccountDto = requestMapper.mapCreateBankAccountDto(createAccountDto,
                consultCustomerRespDto, data.get(PRODUCTID_KEY).asText());

        bankAccountDto.setUserAgent(httpHeaders.getFirst(USER_AGENT));
        bankAccountDto.setUserIp(userIp);
        bankAccountDto.setRequestId(requestId);

        log.info("[{}. BANK ACCOUNT DTO] {}", bankAccountDto.getIdentityNumber(),
                JacksonUtilsV2.getPlainJson(bankAccountDto));

        DigitalAccountRsDto response = customerService.hasDigitalAccount(bankAccountDto.getIdentityNumber(), uuid, bankAccountDto.getChannel(), bankAccountDto.getUserIp());
        if (response.isHasAccount()) {
            throw BdbExceptionFactory
                    .createExcepcion(HttpStatus.FORBIDDEN, createAccountDto.getAanit(), "Client already has an account");
        }

        if (createAccountDto.getSourceTeamId() != 3) {
            ParticipantDto participantDto = saveParticipant(new ParticipantDto(EIdentificationType.CEDULA_CIUDADANIA.getBdbType(),
                    bankAccountDto.getIdentityNumber()));
            saveNewParticipantInfo(participantDto.getId(), bankAccountDto.getRequestId());
        }

        CreateAccountResponseDto accountServiceResponse = callAccountService(bankAccountDto, httpHeaders, uuid, null);
        JsonNode accountResponse = objectMapper.valueToTree(accountServiceResponse);

        String accountNumber = accountServiceResponse.getAccountNumber();

        if (accountNumber != null) {
            ((ObjectNode) accountResponse).put("status", "200");
            ((ObjectNode) accountResponse).put(FATCA_COUNTRY_KEY, bankAccountDto.getFatca() != null ?
                    bankAccountDto.getFatca() : "");
        } else {
            ((ObjectNode) accountResponse).put("status", "500");
            log.error("Error creating account by uuid");
            return new ResponseEntity<>(accountResponse, HttpStatus.OK);
        }
        runAsyncTasks(bankAccountDto, accountServiceResponse, bankAccountDto.getUserIp(), uuid);

        log.info("<<< CREATE ACCOUNT BY UUID. SUCCESSFUL END <<<");
        return new ResponseEntity<>(accountResponse, HttpStatus.OK);
    }

    private void validateGMFAndFatca(JsonNode data, CreateAccountDto createAccountDto) {
        if (data.has(GMF_KEY) && data.get(GMF_KEY).asText().equals("true")) {
            createAccountDto.setGmf(1);
        }
        if (data.has(FATCA_KEY) && data.has(FATCA_COUNTRY_KEY) && data.get(FATCA_KEY).asText().equals("true") && !data.get(FATCA_COUNTRY_KEY).asText().equals("")) {
            createAccountDto.setFatca(data.get(FATCA_COUNTRY_KEY).asText());
        }
    }

    private RequestDto getRequestForUuidAccount(boolean existsInCrm, String channel, Integer sourceTeamId) {
        RequestDto requestDto = new RequestDto();
        requestDto.setProductId(1L);
        requestDto.setDate(TimeUtilities.getCurrentTimestampGMTMinus5());
        requestDto.setClient(existsInCrm);
        requestDto.setChannelId(channelRepository.findChannelIdByDescription(channel).getId());
        requestDto.setMedium(getMediumId(channel));
        requestDto.setSourceTeamId(sourceTeamId);
        requestDto.setCustomOtp(0);
        requestDto = requestRepository.save(requestDto);
        return requestDto;
    }

    @Override
    public ResponseEntity<CreateAccountResponseDto> createAccountByDto(BankAccountDto bankAccountDto,
                                                                       HttpHeaders httpHeaders) throws AbsBdbServiceException {
        DispatcherDto dispatcherDto = redisApiService.getHash("CC", httpHeaders.getFirst(X_AUTH_UUID),
                DISPATCHER_KEY, httpHeaders.getFirst(X_AUTH_UUID), DispatcherDto.class);

        log.info(">>> ({}) CREATE ACCOUNT BY DTO. NEW CALL >>>", bankAccountDto.getIdentityNumber());

        String rqUuid = "";
        if (dispatcherDto != null) {
            bankAccountDto.setIdentityNumber(dispatcherDto.getIdentityNumber());
            bankAccountDto.setCeoCode(dispatcherDto.getSpecificProductInfo().has("ceoCode") ?
                    dispatcherDto.getSpecificProductInfo().get("ceoCode").asText() : "");

            rqUuid = dispatcherDto.getSpecificProductInfoUuid();
        }

        String identityNumber = bankAccountDto.getIdentityNumber();

        bankAccountDto.setUserAgent(httpHeaders.getFirst(USER_AGENT));
        bankAccountDto.setUserIp(StringUtils.defaultIfEmpty(httpHeaders.getFirst(X_FORWARDED_FOR), "").split(",")[0]);

        HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        CreateAccountResponseDto accountResponse = new CreateAccountResponseDto();
        bankAccountDto.setAddressForCRM(mapAddress(bankAccountDto));

        if (bankAccountDto.getProductId().equals(EAccount.PENSIONADO.getCode())) {
            bankAccountDto.setJobActivityId("0010");
            bankAccountDto.setOccupationId(4);
            bankAccountDto.setNameCompany(null);
        }

        log.info("[BANK ACCOUNT DTO] {}", JacksonUtilsV2.getPlainJson(bankAccountDto));

        try {
            if (EChannel.MFZ.getDescription().equals(bankAccountDto.getChannel()) && bankAccountDto.getCeoCode().isEmpty()) {
                throw BdbExceptionFactory.createExcepcion(HttpStatus.BAD_REQUEST, identityNumber, "The CEO code is required for the MFZ channel");
            }

            if (participantInBlacklist(identityNumber, rqUuid)) {
                httpStatus = HttpStatus.LOCKED;
                throw BdbExceptionFactory.createExcepcion(httpStatus, identityNumber, "");
            }

            manageCustomer(bankAccountDto, httpHeaders);
            accountResponse = callAccountService(bankAccountDto, httpHeaders, rqUuid, dispatcherDto);

            if (Boolean.FALSE.equals(accountResponse.getReservation()) || accountResponse.getAccountNumber() == null) {
                throw BdbExceptionFactory.createExcepcion(httpStatus, identityNumber, "");
            }

            httpStatus = HttpStatus.CREATED;
            runAsyncTasks(bankAccountDto, accountResponse, bankAccountDto.getUserIp(), rqUuid);

        } catch (Exception e) {
            accountResponse.setMessage("Error creating account");
            log.error("<<< ({}) CREATE ACCOUNT BY DTO. ERROR {} <<<", identityNumber, e.getMessage());
        }

        log.info("<<< ({}) CREATE ACCOUNT BY DTO. SUCCESSFUL END <<<", identityNumber);

        return new ResponseEntity<>(accountResponse, httpStatus);
    }

    private void manageCustomer(BankAccountDto bankAccountDto, HttpHeaders httpHeaders) throws AbsBdbServiceException {
        ConsultCustomerRespDto consultCustomerRespDto = null;
        String authUuid = httpHeaders.getFirst(X_AUTH_UUID);
        try {
            consultCustomerRespDto = customerService.getCustomerInfoFromBackend(bankAccountDto.getIdentityNumber(),
                    authUuid, bankAccountDto.getChannel(), bankAccountDto.getUserIp());
        } catch (AbsBdbServiceException e) {
            if (!e.getCode().equals(HttpStatus.NOT_FOUND)) {
                requestService.saveRequestEvent(bankAccountDto.getRequestId(), EEventType.CHECK_CRM_FALLIDO, bankAccountDto.getIdentityNumber());
                throw e;
            }
        }

        requestService.saveRequestEvent(bankAccountDto.getRequestId(), EEventType.CHECK_CRM_EXITOSO, bankAccountDto.getIdentityNumber());

        if (consultCustomerRespDto == null) {
            customerManagement.createCustomer(bankAccountDto, httpHeaders);
            redisApiService.saveHash(EIdentificationType.CEDULA_CIUDADANIA.getBdbType(), bankAccountDto.getIdentityNumber(), CUSTOMER_IS_NEW,
                    "30", EUnitTime.MINUTES, authUuid, true);
            consultCustomerRespDto = customerService.getCustomerInfoFromBackend(bankAccountDto.getIdentityNumber(),
                    httpHeaders.getFirst(X_AUTH_UUID), bankAccountDto.getChannel(), bankAccountDto.getUserIp());
        }

        try {
            // It must always be updated in order to create the secure data. Refactor when in the facility to create safe data
            customerManagement.updateCustomer(bankAccountDto, consultCustomerRespDto, httpHeaders);
        } catch (Exception e) {
            log.error("({}) ERROR CUSTOMER UPDATE ({})", bankAccountDto.getIdentityNumber(), e.getMessage());
        }
    }

    private boolean participantInBlacklist(String identityNumber, String uuid) throws AbsBdbServiceException {
        ResponseBlacklist responseBlacklist = customerApiService.getBlacklist(identityNumber, "CC", uuid);
        return !responseBlacklist.isCanContinue();
    }

    @Override
    public CreateAccountResponseDto callAccountService(BankAccountDto bankAccountDto, HttpHeaders httpHeaders, String rqUuid, DispatcherDto dispatcherDto) {

        CreateAccountDto createAccountDto = requestMapper.mapCreateAccountDtoRequest(bankAccountDto, rqUuid);
        UriComponentsBuilder urlBuilder =
                UriComponentsBuilder.fromUriString(endpointAccountsAdapter).path(CREATE_ACCOUNT_RESOURCE);

        ResponseEntity<CreateAccountResponseDto> adapterResponse = restExchange.exchange(urlBuilder.toUriString(),
                createAccountDto, HttpMethod.POST, CreateAccountResponseDto.class);

        CreateAccountResponseDto response = Objects.requireNonNull(adapterResponse.getBody());

        CompletableFuture.runAsync(() -> sendEvent(response, bankAccountDto, httpHeaders, rqUuid));

        if (adapterResponse.getStatusCode() == HttpStatus.OK) {
            accountLogProxy.saveAccountLog(createAccountDto, Objects.requireNonNull(response).getAccountNumber(), bankAccountDto.getChannel(), "");
            requestService.saveRequestEvent(bankAccountDto.getRequestId(), EEventType.CHECK_RESERVE_ACCOUNT_EXITOSO,
                    bankAccountDto.getIdentityNumber());
            requestService.saveRequestEvent(bankAccountDto.getRequestId(), EEventType.CHECK_CREAR_CUENTA_EXITOSO,
                    bankAccountDto.getIdentityNumber());

        } else {
            requestService.saveRequestEvent(bankAccountDto.getRequestId(),
                    Boolean.TRUE.equals(Objects.requireNonNull(response).getReservation()) ?
                            EEventType.CHECK_CREAR_CUENTA_FALLIDO :
                            EEventType.CHECK_RESERVE_ACCOUNT_FALLIDO,
                    bankAccountDto.getIdentityNumber());
        }

        return response;
    }

    @Override
    public void runAsyncTasks(BankAccountDto bankAccountDto, CreateAccountResponseDto createAccountResponseDto, String userIp, String rqUid) {
        String accountNumber = createAccountResponseDto.getAccountNumber();

        CompletableFuture.runAsync(() -> {
            try {
                saveNewModel(bankAccountDto, createAccountResponseDto);
            } catch (AbsBdbServiceException e) {
                log.error("Error saving data in DB: {}", e.getMessage());
            }
        });

        CompletableFuture.runAsync(() -> sendNotification(bankAccountDto, accountNumber, rqUid));
        CompletableFuture.runAsync(() -> sendGMF(bankAccountDto, accountNumber));
        CompletableFuture.runAsync(() -> saveCheckVerification(bankAccountDto, accountNumber, rqUid));
        CompletableFuture.runAsync(() -> callAccountLimit(bankAccountDto, accountNumber));
        CompletableFuture.runAsync(() -> sendNewAccountToMonitorPlus(bankAccountDto, accountNumber, userIp, rqUid));
        CompletableFuture.runAsync(() -> saveFatcaInfo(bankAccountDto));
    }

    private void sendGMF(BankAccountDto bankAccountDto, String accountNumber) {
        if (bankAccountDto.isCheckGmf()) {
            String clientName = Utilities.getFullName(bankAccountDto.getFirstName(), bankAccountDto.getMiddleName(),
                    bankAccountDto.getLastName(), bankAccountDto.getSecondLastName());
            gmfService.sendNewAccountToGMFService(accountNumber, bankAccountDto.getOfficeCode(), EIdentificationType.CEDULA_CIUDADANIA.getBdbType(),
                    bankAccountDto.getIdentityNumber(), clientName, bankAccountDto.getCellphone(), bankAccountDto.getRequestId());
        }
    }

    @Override
    public void saveNewModel(BankAccountDto bankAccountDto, CreateAccountResponseDto createAccountResponseDto) throws AbsBdbServiceException {

        SavingTypeDto savingTypeDto = savingTypeRepository.findSavingTypeDtoByCode(bankAccountDto.getProductId());
        SavingConditionDto savingConditionDto = requestMapper.mapSavingCondition(bankAccountDto, savingTypeDto.getId(),
                createAccountResponseDto.getFacialValidate());
        saveSavingCondition(savingConditionDto, createAccountResponseDto.getAccountNumber());

        saveParticipantInfo(bankAccountDto);

        saveDomicileInfo(requestMapper.mapDomicileInfo(bankAccountDto));

        saveRequestOperation(requestMapper.mapRequestOperation(bankAccountDto.getRequestId(), 1));
        saveRequestArrangement(requestMapper.mapRequestArrangement(bankAccountDto));

        if (bankAccountDto.getSellerId() != null) {
            saveRequestSeller(requestMapper.mapRequestSeller(bankAccountDto.getCeoCode(), bankAccountDto.getSellerId(),
                    bankAccountDto.getRequestId()));
        }

        if (Arrays.asList(EAccount.NOMINA.getCode(), EAccount.PENSIONADO.getCode(), EAccount.PENSIONADO_MAS_EXPERIENCIA.getCode())
                .contains(bankAccountDto.getProductId())) {
            saveRequestPayrollAccount(requestMapper.mapRequestPayrollAccount(bankAccountDto.getCodNomina(),
                    bankAccountDto.getEmployeeNit(), bankAccountDto.getRequestId(), bankAccountDto.getNameCompany()));
        }
    }

    private void callAccountLimit(BankAccountDto bankAccountDto, String accountNumber) {
        AccountLimitMapperDto accountLimitMapper = new AccountLimitMapperDto();
        bankAccountDto.setAccountLimit(requestMapper.mapAccountLimits(accountLogRepository.getAccountLimits()));
        callUpdateAccountLimit(accountLimitMapper.createAccountLimitDto(bankAccountDto, accountNumber));
    }

    private void sendNotification(BankAccountDto bankAccountDto, String accountNumber, String rqUid) {

        List<ParameterTypeDto> emailParameters = new ArrayList<>();
        emailParameters.add(new ParameterTypeDto("nombre_cliente", Utilities.getFullName(
                bankAccountDto.getFirstName(), bankAccountDto.getMiddleName(), bankAccountDto.getLastName(), bankAccountDto.getSecondLastName())));
        emailParameters.add(new ParameterTypeDto("ID", bankAccountDto.getIdentityNumber().substring(bankAccountDto.getIdentityNumber().length() - 4)));
        emailParameters.add(new ParameterTypeDto("primer_nombre", bankAccountDto.getFirstName()));
        emailParameters.add(new ParameterTypeDto("num_cuenta", accountNumber));
        emailParameters.add(new ParameterTypeDto("activar_tarjeta", cardActivationEndpoint));

        EEmailTemplate emailTemplate;
        if (!bankAccountDto.isTxInWeb()) {
            emailTemplate = EEmailTemplate.CREACION_OFICINA;
        } else {
            emailTemplate = EDeliveryType.OFFICE.getDescription().equals(bankAccountDto.getDeliverySelected()) ? EEmailTemplate.CREACION_WEB_RECLAMAR : EEmailTemplate.CREACION_WEB_ENVIO;
        }

        String msgTemplate = String.format(ESmsMessage.WELCOME_TO_BDB.getDescription(), bankAccountDto.getAccountType(), accountNumber);

        RequestNotificationMessage requestNotificationMessage = new RequestNotificationMessage(msgTemplate, bankAccountDto.getCellphone());
        notificationApiService.sendSMS(bankAccountDto.getIdentityNumber(), rqUid, requestNotificationMessage);

        RequestNotificationEmail requestNotificationEmail = new RequestNotificationEmail(
                bankAccountDto.getEmail(), emailTemplate, emailParameters);

        notificationApiService.sendEmail(bankAccountDto.getIdentityNumber(), rqUid, requestNotificationEmail);
    }

    private void saveCheckVerification(BankAccountDto accountDto, String accountNumber, String uuid) {
        List<CheckTypeLogItemDto> checkItemList = new ArrayList<>();
        CheckTypeLogListDto checkTypeLogListDto = new CheckTypeLogListDto();

        if (accountDto.isCheckGmf()) {
            mapperCheckTypeLog(ECheckVerify.CHECK_GMF.getIdCheck(), checkItemList, checkTypeLogListDto);
        }

        mapperCheckTypeLog(ECheckVerify.CHECK_TERMINOS.getIdCheck(), checkItemList, checkTypeLogListDto);

        checkLogService.saveCheckLog(EIdentificationType.CEDULA_CIUDADANIA.getBdbType(), accountDto.getIdentityNumber(),
                accountNumber, accountDto.getRequestId(), uuid, checkTypeLogListDto);
    }

    private void mapperCheckTypeLog(int check, List<CheckTypeLogItemDto> checkRedisItemList,
                                    CheckTypeLogListDto checkTypeLogListDto) {
        CheckTypeLogItemDto newItemCheck = new CheckTypeLogItemDto();

        newItemCheck.setDate(TimeUtilities.getCurrentTimestampGMTMinus5());
        newItemCheck.setCheckType(check);

        checkRedisItemList.add(newItemCheck);

        checkTypeLogListDto.setCheckTypeLogList(checkRedisItemList);
    }

    private void sendNewAccountToMonitorPlus(BankAccountDto bankAccountDto, String accountNumber, String userIp, String rqUid) {
        try {

            log.info(">>> SEARCH CHANNEL BANK_ACCOUNT_DTO_REQUEST_ID {}.  >>>", bankAccountDto.getRequestId());
            RequestDto requestDto = requestRepository.findById(bankAccountDto.getRequestId());
            bankAccountDto.setChannelToMonitor(String.valueOf(requestDto.getChannelId()));
            monitorService.sendAccountCreate(bankAccountDto, accountNumber, userIp, rqUid);
            requestService.saveRequestEvent(bankAccountDto.getRequestId(), EEventType.CHECK_MONITOR_PLUS_EXITOSO,
                    bankAccountDto.getIdentityNumber());
            log.info(EEventType.CHECK_MONITOR_PLUS_EXITOSO.getDescription(),
                    JacksonUtilsV2.getPlainJson(bankAccountDto));
        } catch (Exception e) {
            log.error("Error sending message to Business Monitor (invoke service):", e);
            requestService.saveRequestEvent(bankAccountDto.getRequestId(), EEventType.CHECK_MONITOR_PLUS_FALLIDO,
                    bankAccountDto.getIdentityNumber());
            log.info(EEventType.CHECK_MONITOR_PLUS_FALLIDO.getDescription(),
                    JacksonUtilsV2.getPlainJson(bankAccountDto));
        }
    }

    private boolean callUpdateAccountLimit(AccountLimitsDto accountLimitDto) {
        try {
            UriComponentsBuilder urlBuilder =
                    UriComponentsBuilder.fromUriString(endpointAccountsAdapter).path(ACCOUNT_LIMIT_RESOURCE);
            restExchange.exchange(urlBuilder.toUriString(), accountLimitDto, HttpMethod.POST, JsonNode.class);
            return true;
        } catch (Exception e) {
            log.error("({}) Error updating account limits: {}", accountLimitDto.getNumberDocument(), e);
            return false;
        }
    }

    @Override
    public boolean updateAccountLimit(AccountLimitsDto accountLimitDto) {
        log.info(">>> ({}) UPDATE ACCOUNT LIMIT. NEW CALL >>>", accountLimitDto.getNumberDocument());

        accountLimitDto.setListAcctLimitsDesc(requestMapper.mapAccountLimits(accountLogRepository.getAccountLimits()));
        boolean isSuccessful = callUpdateAccountLimit(accountLimitDto);

        log.info("<<< ({}) UPDATE ACCOUNT LIMIT. SUCCESSFUL END <<<", accountLimitDto.getNumberDocument());
        return isSuccessful;
    }

    @Override
    public JsonNode getAccountsByCard(HttpHeaders httpHeaders, String cardNumber) throws AbsBdbServiceException {
        DispatcherDto dispatcherDto = redisApiService.getHash("CC", httpHeaders.getFirst(X_AUTH_UUID),
                DISPATCHER_KEY, httpHeaders.getFirst(X_AUTH_UUID), DispatcherDto.class);

        String rqUid = httpHeaders.getFirst(X_AUTH_UUID);
        String channel = httpHeaders.getFirst(X_CHANNEL);
        String xForwardedFor = httpHeaders.getFirst(X_FORWARDED_FOR);

        String identityNumber = dispatcherDto.getIdentityNumber();

        log.info(">>> GET ACCOUNTS BY CARD ({}). NEW CALL >>>", identityNumber);

        List<AcctBasicInfoDto> accountsList = productsService.getFilteredAccountsList(identityNumber,
                rqUid, channel, xForwardedFor, cardNumber);

        ObjectNode response = objectMapper.createObjectNode();
        ArrayNode accountsNode = objectMapper.valueToTree(accountsList);
        response.putArray("acctBasicInfo").addAll(accountsNode);

        log.info("<<< GET ACCOUNTS BY CARD ({}). SUCCESSFUL END <<<", identityNumber);
        return response;
    }

    @Override
    public ResponseEntity<JsonNode> setAccountHierarchy(AccountHierarchyReqDto accountHierarchyReqDto, HttpHeaders httpHeaders) throws AbsBdbServiceException {

        DispatcherDto dispatcherDto = redisApiService.getHash("CC", httpHeaders.getFirst(X_AUTH_UUID),
                DISPATCHER_KEY, httpHeaders.getFirst(X_AUTH_UUID), DispatcherDto.class);

        String identityNumber = dispatcherDto.getIdentityNumber();
        log.info(">>> ({}) SET ACCOUNT HIERARCHY. NEW CALL >>>", identityNumber);

        accountHierarchyReqDto.setIdentificationType(dispatcherDto.getIdentityType());
        accountHierarchyReqDto.setIdentificationNumber(identityNumber);

        ObjectNode jsonRequest = requestMapper.mapAccountHierarchy(accountHierarchyReqDto);

        UriComponentsBuilder urlBuilder =
                UriComponentsBuilder.fromUriString(endpointAccountsAdapter).path(HIERARCHY_ACCOUNT_RESOURCE);
        ResponseEntity<JsonNode> response = restExchange.exchange(urlBuilder.toUriString(), jsonRequest,
                HttpMethod.POST, JsonNode.class);

        if (response.getStatusCode().is2xxSuccessful()) {
            requestService.saveRequestEvent(accountHierarchyReqDto.getRequestId(),
                    EEventType.CHECK_ACCOUNT_HIERARCHY_EXITOSO, identityNumber);
        } else {
            requestService.saveRequestEvent(accountHierarchyReqDto.getRequestId(),
                    EEventType.CHECK_ACCOUNT_HIERARCHY_FALLIDO, identityNumber);
            throw BdbExceptionFactory.createExcepcion(response.getStatusCode(), identityNumber, "HierarchyAccount",
                    "Error hierarchy/account");
        }

        log.info("<<< ({}) SET ACCOUNT HIERARCHY. SUCCESSFUL END <<<", identityNumber);
        return new ResponseEntity<>(response.getBody(), HttpStatus.OK);
    }

    private int getMediumId(String channel) {
        return switch (channel.toUpperCase()) {
            case "OFICINA" -> 2;
            case WEB, "BM" -> 3;
            default -> 1;
        };
    }

    private void saveRequestOperation(RequestOperationDto requestOperationData) throws AbsBdbServiceException {
        try {
            requestOperationData.setDate(TimeUtilities.getCurrentTimestampGMTMinus5());
            log.info("[{}. SavingRequestOperation] {}", requestOperationData.getRequestId(),
                    JacksonUtilsV2.getPlainJson(requestOperationData));
            requestRepository.saveRequestOperation(requestOperationData.getRequestId(),
                    requestOperationData.getOperationTypeId(), requestOperationData.getDate());
        } catch (Exception e) {
            log.info("ERROR savingRequestOperation {}", JacksonUtilsV2.getPlainJson(requestOperationData));
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR,
                    String.valueOf(requestOperationData.getRequestId()), "Error saving request operation");
        }
    }

    private void saveRequestSeller(RequestSellerDto requestSellerData) throws AbsBdbServiceException {
        try {
            log.info("[{}. SavingRequestSeller] {}", requestSellerData.getRequestId(),
                    JacksonUtilsV2.getPlainJson(requestSellerData));
            requestRepository.saveRequestSeller(requestSellerData.getNode(), requestSellerData.getSeller(), requestSellerData.getRequestId());
        } catch (Exception e) {
            log.info("ERROR savingRequestSeller {} {}", requestSellerData.getSeller(),
                    JacksonUtilsV2.getPlainJson(requestSellerData));
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR,
                    String.valueOf(requestSellerData.getRequestId()), "Error saving request seller");
        }
    }

    private void saveRequestPayrollAccount(RequestPayrollAccountDto requestPayrollAccountDto) throws AbsBdbServiceException {
        try {
            log.info("{}. SavingRequestPayrollAccount {}", requestPayrollAccountDto.getRequestId(),
                    JacksonUtilsV2.getPlainJson(requestPayrollAccountDto));
            requestRepository.saveRequestPayrollAccount(requestPayrollAccountDto.getDispersionCode(),
                    requestPayrollAccountDto.getCompanyNit(), requestPayrollAccountDto.getCompanyName(), requestPayrollAccountDto.getRequestId());
        } catch (Exception e) {
            log.info("ERROR SavingRequestPayrollAccount {} {}", requestPayrollAccountDto.getCompanyNit(),
                    JacksonUtilsV2.getPlainJson(requestPayrollAccountDto));
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR,
                    String.valueOf(requestPayrollAccountDto.getRequestId()), "Error saving request payroll account");
        }
    }

    private void saveRequestArrangement(List<RequestArrangementDto> requestArrangementDtoList) throws AbsBdbServiceException {
        try {
            for (RequestArrangementDto requestArrangementDto : requestArrangementDtoList) {
                requestArrangementDto.setDate(TimeUtilities.getCurrentTimestampGMTMinus5());
                log.info("[{}. SavingRequestArrangement] {}", requestArrangementDto.getRequestId(),
                        JacksonUtilsV2.getPlainJson(requestArrangementDto));
                requestRepository.saveRequestArrangement(requestArrangementDto.getRequestId(),
                        requestArrangementDto.getArrangementTypeId(), requestArrangementDto.getDate());
            }
        } catch (Exception e) {
            log.info("ERROR savingRequestArrangement {}", JacksonUtilsV2.getPlainJson(requestArrangementDtoList));
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR,
                    String.valueOf(requestArrangementDtoList.get(0).getRequestId()), "Error saving request " +
                            "arrangement");
        }
    }

    private void saveSavingCondition(SavingConditionDto savingConditionDto, String accountNumber) throws AbsBdbServiceException {
        try {
            // El requestId viaja como conditionId
            log.info("Saving condition with requestId {}", savingConditionDto.getConditionId());
            ConditionDto conditionDto = new ConditionDto();
            conditionDto.setRequestId(savingConditionDto.getConditionId());
            conditionDto = conditionRepository.save(conditionDto);

            savingConditionDto.setConditionId(conditionDto.getId());
            savingConditionDto.setLogId(accountLogRepository.findByAccountNumber2(accountNumber));
            log.info("[SavingCondition] {}", JacksonUtilsV2.getPlainJson(savingConditionDto));
            savingConditionRepository.save(savingConditionDto);
        } catch (Exception e) {
            log.info("ERROR savingCondition {}", JacksonUtilsV2.getPlainJson(savingConditionDto));
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR,
                    String.valueOf(savingConditionDto.getConditionId()), "Error saving condition");
        }
    }

    private ParticipantDto saveParticipant(ParticipantDto participant) {
        ParticipantDto participantFromDB =
                participantRepository.findByIdentificationNumber(participant.getIdentificationNumber());
        if (participantFromDB == null) participantFromDB = participantRepository.save(participant);
        return participantFromDB;
    }

    private void saveNewParticipantInfo(long participantId, long requestId) {
        ParticipantInfoDto participantInfoDto = new ParticipantInfoDto();

        participantInfoDto.setParticipantId(participantId);
        participantInfoDto.setRequestId(requestId);
        participantInfoDto.setDate(TimeUtilities.getCurrentTimestampGMTMinus5());

        participantInfoRepository.save(participantInfoDto);
    }

    @Override
    public ResponseEntity<String> saveParticipantInfo(BankAccountDto bankAccountDto,
                                                      HttpHeaders httpHeaders) throws AbsBdbServiceException {

        DispatcherDto dispatcherDto = redisApiService.getHash("CC", httpHeaders.getFirst(X_AUTH_UUID),
                DISPATCHER_KEY, httpHeaders.getFirst(X_AUTH_UUID), DispatcherDto.class);
        bankAccountDto.setIdentityNumber(dispatcherDto.getIdentityNumber());

        return saveParticipantInfo(bankAccountDto);
    }

    @Override
    public ResponseEntity<String> saveParticipantInfo(BankAccountDto bankAccountDto) throws AbsBdbServiceException {

        ParticipantInfoDto participantInfoDto = requestMapper.mapParticipantInfo(bankAccountDto);

        try {
            List<ParticipantInfoDto> participantFromDB = participantInfoRepository.findByRequestId(participantInfoDto.getRequestId());

            ParticipantInfoDto participantInfoFromDB = null;
            if (participantFromDB != null) {
                participantInfoFromDB = participantFromDB.get(0);
            }

            if (participantInfoFromDB == null) participantInfoFromDB = participantInfoDto;
            participantInfoFromDB.setFirstName(participantInfoDto.getFirstName());
            participantInfoFromDB.setSecondName(participantInfoDto.getSecondName());
            participantInfoFromDB.setFirstSurname(participantInfoDto.getFirstSurname());
            participantInfoFromDB.setSecondSurname(participantInfoDto.getSecondSurname());
            participantInfoFromDB.setPhone(participantInfoDto.getPhone());
            participantInfoFromDB.setAddress(participantInfoDto.getAddress());
            participantInfoFromDB.setSex(participantInfoDto.getSex());
            participantInfoFromDB.setEmail(participantInfoDto.getEmail());
            participantInfoFromDB.setActivityCode(participantInfoDto.getActivityCode());
            participantInfoFromDB.setOccupation(participantInfoDto.getOccupation());
            participantInfoFromDB.setIncome(participantInfoDto.getIncome());
            participantInfoFromDB.setOutcome(participantInfoDto.getOutcome());
            participantInfoFromDB.setTaxCountry(participantInfoDto.getTaxCountry());
            participantInfoFromDB.setDate(TimeUtilities.getCurrentTimestampGMTMinus5());
            participantInfoFromDB.setCity(participantInfoDto.getCity());
            participantInfoFromDB.setEthnicGroup(participantInfoDto.getEthnicGroup());

            log.info("[SavingParticipantInfo] {}", JacksonUtilsV2.getPlainJson(participantFromDB));
            participantInfoRepository.save(participantInfoFromDB);

            return new ResponseEntity<>(String.valueOf(participantInfoFromDB.getId()), HttpStatus.OK);
        } catch (Exception e) {
            log.error("ERROR savingParticipantInfo", e);
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, "", "Error saving participant" +
                    " info");
        }
    }

    private void saveDomicileInfo(DomicileInfoDto domicileInfoDto) throws AbsBdbServiceException {
        try {
            domicileInfoDto.setDate(TimeUtilities.getCurrentTimestampGMTMinus5());
            log.info("[SavingDomicileInfo] {}", JacksonUtilsV2.getPlainJson(domicileInfoDto));
            domicileInfoRepository.save(domicileInfoDto);
        } catch (Exception e) {
            log.info("ERROR savingDomicileInfo {}", JacksonUtilsV2.getPlainJson(domicileInfoDto));
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR,
                    String.valueOf(domicileInfoDto.getRequestId()), "Error saving domicileInfo");
        }
    }

    private String mapAddress(BankAccountDto bankAccountDto) {
        String address = null;
        try {
            if (bankAccountDto.getAddress1Dto() != null) {
                address = bankAccountDto.getAddress1Dto().getTypeRoad1() + ";"
                        + bankAccountDto.getAddress1Dto().getTypeRoad1Number() + ";"
                        + (bankAccountDto.getAddress1Dto().getTypeRoad2() != null ?
                        bankAccountDto.getAddress1Dto().getTypeRoad2() : "") + ";"
                        + bankAccountDto.getAddress1Dto().getTypeRoad2Number() + ";;;;;;"
                        + (bankAccountDto.getAddress1Dto().getAddressDetail() != null ?
                        bankAccountDto.getAddress1Dto().getAddressDetail() : "") + ";"
                        + "COL;" + (bankAccountDto.getLivingCityId() != null ?
                        bankAccountDto.getLivingCityId().substring(0, 2) : "") + ";"
                        + (bankAccountDto.getLivingCityId() != null ? bankAccountDto.getLivingCityId() : "") + ";;";
            }
        } catch (Exception e) {
            log.error("Error formateando direccion ->", e);
        }
        return address;

    }

    @Override
    public ResponseEntity<JsonNode> getPayloadInfo(String identityNumber, String authUuid) throws AbsBdbServiceException {

        identityNumber = DataUtilities.sanitize(identityNumber);
        log.info(">>> ({}) GET PAYLOAD INFO. NEW CALL >>>", identityNumber);

        JsonNode payload = redisApiService.getHash("CC", identityNumber, KEY_PAYLOAD_ACTIVATE_CARD,
                authUuid, JsonNode.class);

        if (payload == null)
            throw BdbExceptionFactory.createExcepcion(HttpStatus.NOT_FOUND, identityNumber, "Payload info not found");

        log.info("({}) REDIS PAYLOAD: {}", identityNumber, JacksonUtilsV2.getPlainJson(payload));
        log.info("<<< ({}) GET PAYLOAD INFO. SUCCESSFUL END <<<", identityNumber);

        return new ResponseEntity<>(payload, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<JsonNode> saveSessionRedis(JsonNode sessionRedis, HttpHeaders httpHeaders) throws AbsBdbServiceException {

        DispatcherDto dispatcherDto = redisApiService.getHash("CC", httpHeaders.getFirst(X_AUTH_UUID),
                DISPATCHER_KEY, httpHeaders.getFirst(X_AUTH_UUID), DispatcherDto.class);
        Utilities.setDataField(IDENTITY_NUMBER, dispatcherDto.getIdentityNumber(), (ObjectNode) sessionRedis);
        Utilities.setDataField(IDENTITY_TYPE, dispatcherDto.getIdentityType(), (ObjectNode) sessionRedis);

        String timeAlive = httpHeaders.getFirst("time-alive");
        String authUuid = httpHeaders.getFirst(X_AUTH_UUID);

        String identityNumber = sessionRedis.get(IDENTITY_NUMBER).asText();
        String identityType = sessionRedis.get(IDENTITY_TYPE).asText();

        try {
            log.info(">>> saveSessionRedis START >>>");
            redisApiService.saveHash(identityType, identityNumber, SESSION_KEY, StringUtils.isEmpty(timeAlive) ?
                    redisBankAccountDtoAlive : timeAlive, EUnitTime.MINUTES, authUuid, sessionRedis);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (Exception e) {
            log.error("ERROR savingSessionRedis", e);
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, identityNumber, "Error save Session Redis");
        }
    }

    @Override
    public ResponseEntity<JsonNode> getSessionRedis(String identityNumber, String authUuid) throws AbsBdbServiceException {
        try {
            JsonNode sessionRedis = redisApiService.getHash("CC", identityNumber, SESSION_KEY, authUuid, JsonNode.class);
            if (sessionRedis != null) {
                updateAuthenticationRequestAndType(sessionRedis);
            }
            return new ResponseEntity<>(sessionRedis, (sessionRedis == null) ? HttpStatus.NO_CONTENT : HttpStatus.OK);
        } catch (Exception e) {
            log.error("ERROR getSessionRedis", e);
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, "", "Error getSessionRedis");

        }
    }

    private void updateAuthenticationRequestAndType(JsonNode sessionRedis) {

        JsonNode accessType = sessionRedis.get("accessType");

        if (accessType != null && accessType.asText().equals("5")) {
            JsonNode request = sessionRedis.get(REQUEST_ID);
            requestRepository.updateResumeRequest(1, request.asLong());
        }
    }

    @Override
    public ResponseEntity<JsonNode> getAccountLimits() {
        JsonNode accountLimitsJson =
                objectMapper.convertValue(requestMapper.mapAccountLimits(accountLogRepository.getAccountLimits()),
                        JsonNode.class);

        return new ResponseEntity<>(accountLimitsJson, (accountLimitsJson == null) ? HttpStatus.NO_CONTENT :
                HttpStatus.OK);
    }

    private void saveFatcaInfo(BankAccountDto bankAccountDto) {
        if (StringUtils.isNotEmpty(bankAccountDto.getFatca())) {
            FatcaEntity fatcaEntity = new FatcaEntity();

            fatcaEntity.setIdentityType(EIdentificationType.CEDULA_CIUDADANIA.getBdbType());
            fatcaEntity.setIdentityNumber(bankAccountDto.getIdentityNumber());
            fatcaEntity.setClientName(Utilities.getFullName(bankAccountDto.getFirstName(), bankAccountDto.getMiddleName(),
                    bankAccountDto.getLastName(), bankAccountDto.getSecondLastName()));
            fatcaEntity.setBirthPlace(StringUtils.defaultIfEmpty(bankAccountDto.getCodCity(), bankAccountDto.getLivingCityId()));
            fatcaEntity.setNationality("Colombiano");
            fatcaEntity.setFiscalResidence1(bankAccountDto.getFatca());
            fatcaEntity.setTin1(bankAccountDto.getTin1());
            fatcaEntity.setFiscalResidence2(bankAccountDto.getFiscalResidence2());
            fatcaEntity.setTin2(bankAccountDto.getTin2());
            fatcaEntity.setBranchId(bankAccountDto.getOfficeCode());
            fatcaEntity.setProductCreationDate(TimeUtilities.actualDate());

            fatcaService.saveFatcaInfo(fatcaEntity);
        }
    }

    private void sendEvent(CreateAccountResponseDto response, BankAccountDto bankAccountDto, HttpHeaders httpHeaders,
                           String rqUuid) {

        String journey = "FlujoWeb";
        if (!EChannel.findByDescription(bankAccountDto.getChannel()).isWeb()) {
            journey = "FlujoAsistido";
        }

        EventDataDto eventDataDto = new co.com.bancodebogota.dto.pentagon.EventDataDto();
        eventDataDto.setEventName(String.format("Event-CuentaDeAhorros-%s-Contrato-CreacionDelProducto", journey));
        eventDataDto.setMilestone("Contrato");
        eventDataDto.setStep("CreacionDelProducto");
        eventDataDto.setDigRequest(bankAccountDto.getAccountDigitalId());
        eventDataDto.setFront(false);

        if (bankAccountDto.isProspect()) {
            eventDataDto.setIsClient("Lead");
        } else {
            eventDataDto.setIsClient(bankAccountDto.isCustomerExistsInCrm() ? "Active Client" : "No Client");
        }

        eventDataDto.setJourney(journey);

        ObjectNode payload = objectMapper.createObjectNode();
        payload.set("createAccount", objectMapper.convertValue(response, ObjectNode.class));
        payload.put("sourceTeam",
                StringUtils.defaultIfEmpty(httpHeaders.getFirst(X_NAME), "CuentaDeAhorros"));

        eventDataDto.setPayload(JacksonUtilsV2.getPlainJson(payload));

        EventIdentityDto eventIdentityDto = new EventIdentityDto();
        eventIdentityDto.setIdentityType(EIdentificationType.CEDULA_CIUDADANIA.getBdbType());
        eventIdentityDto.setIdentityNumber(bankAccountDto.getIdentityNumber());
        eventIdentityDto.setRqUuid(rqUuid);
        eventIdentityDto.setChannel(bankAccountDto.getChannel());
        eventIdentityDto.setUserIp(httpHeaders.getFirst(X_FORWARDED_FOR));
        eventIdentityDto.setAccessToken(StringUtils.defaultString(httpHeaders.getFirst(ACCESS_TOKEN)));
        eventIdentityDto.setMedium(httpHeaders.getFirst(X_MEDIUM));
        eventIdentityDto.setSourceChannel(httpHeaders.getFirst(X_SOURCE_CHANNEL));

        pentagonService.publish(eventDataDto, eventIdentityDto);
    }

    @Override
    public void saveModel(List<List<String>> requests) {
        log.info("Requests to process: {}", requests.size());
        requests.forEach(request -> {
            try {
                String office = request.get(0);
                String accountNumber = request.get(1);
                String accountType = request.get(2);
                String identityNumber = request.get(3);
                String seller = request.get(4);

                log.info(">>> ({}) SAVE MODEL. NEW CALL >>>", identityNumber);

                Optional<RequestDto> requestDtoOpt = Optional.ofNullable(requestRepository.findRequestDtoByIdentityNumber(identityNumber));
                if (requestDtoOpt.isEmpty()) {
                    throw BdbExceptionFactory.createExcepcion(HttpStatus.NOT_FOUND, identityNumber, "Request Not Found");
                }
                RequestDto requestDto = requestDtoOpt.get();

                AccountLog accountLog = new AccountLog();
                accountLog.setId(MD5Utilities.createId(accountNumber));
                accountLog.setAccountType(accountType);
                accountLog.setAccountNumber(accountNumber);
                accountLog.setEmailCourier(1);
                accountLog.setDate(requestDto.getCreatedAt());
                accountLog.setOffice(office);
                accountLog.setSeller(seller);
                accountLog.setClientType(requestDto.isClient() ? "ACTUAL" : "NUEVO");
                accountLogRepository.save(accountLog);

                Long requestId = requestDto.getId();
                requestService.saveRequestEvent(requestId, EEventType.CHECK_RESERVE_ACCOUNT_EXITOSO, identityNumber);
                requestService.saveRequestEvent(requestId, EEventType.CHECK_CREAR_CUENTA_EXITOSO, identityNumber);

                BankAccountDto bankAccountDto = new BankAccountDto();
                bankAccountDto.setRequestId(requestId);
                bankAccountDto.setChannel("Oficina");
                bankAccountDto.setAccountType(accountType);
                bankAccountDto.setCustomerExistsInCrm(requestDto.isClient());
                bankAccountDto.setIdentityNumber(identityNumber);
                bankAccountDto.setProductId(accountType);
                bankAccountDto.setOfficeCode(office);
                bankAccountDto.setSellerId(seller);

                SavingTypeDto savingTypeDto = savingTypeRepository.findSavingTypeDtoByCode(accountType);
                SavingConditionDto savingConditionDto = requestMapper.mapSavingCondition(bankAccountDto, savingTypeDto.getId(), null);

                saveRequestOperation(requestMapper.mapRequestOperation(bankAccountDto.getRequestId(), 1));
                saveRequestArrangement(requestMapper.mapRequestArrangement(bankAccountDto));
                saveSavingCondition(savingConditionDto, accountNumber);

                log.info("<<< ({}) SAVE MODEL. SUCCESSFUL END <<<", identityNumber);
            } catch (Exception exception) {
                log.error("ERROR SAVE MODEL: {}", exception.getMessage());
            }
        });
    }
}
