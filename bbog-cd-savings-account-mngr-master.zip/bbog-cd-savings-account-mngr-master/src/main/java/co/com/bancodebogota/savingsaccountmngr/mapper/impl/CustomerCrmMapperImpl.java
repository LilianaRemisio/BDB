package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.dto.customer.*;
import co.com.bancodebogota.enums.EIdentificationType;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.savingsaccountmngr.mapper.ICustomerCrmMapper;
import co.com.bancodebogota.utils.DataUtilities;
import co.com.bancodebogota.utils.TimeUtilities;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CustomerCrmMapperImpl implements ICustomerCrmMapper {

    private static final String MVP_NATIONALITY = "COL";
    private static final String COLOMBIAN_PESOS = "COP";
    private static final String MVP_STATE_PROV = "BOG";
    private static final String MVP_ADDR_TYPE = "34";
    private static final String MVP_EDU_LEVEL = "2";
    private static final String PHONE_TYPE_CELL_PHONE = "12";
    private static final String MVP_MARITAL_STATUS = "S";

    @Override
    public RequestCustomerInquiry mapCreateCustomerDto(BankAccountDto bankAccountDto) {

        CustInfo custInfo = generateCustInfo(bankAccountDto);

        RequestCustomerInquiry iRequestCustomerInquiry = new RequestCustomerInquiry();
        CustomerCreateReq customerCreateReq = new CustomerCreateReq();

        customerCreateReq.setCustInfo(custInfo);

        iRequestCustomerInquiry.setCustomerCreateReq(customerCreateReq);
        return iRequestCustomerInquiry;

    }

    @Override
    public JsonNode mapUpdateCustomerDto(BankAccountDto bankAccountDto, ConsultCustomerRespDto consultCustomerRespDto) throws AbsBdbServiceException {

        try {
            if (consultCustomerRespDto != null) {
                updateInfoWithCRM(bankAccountDto, consultCustomerRespDto);
            }

            CustInfo custInfo = generateCustInfo(bankAccountDto);

            RequestCustomerUpdateInquiry requestCustomerUpdateInquiry = new RequestCustomerUpdateInquiry();
            CustomerUpdateReq customerUpdateReq = new CustomerUpdateReq();

            customerUpdateReq.setCustInfo(custInfo);
            customerUpdateReq.setUpdateSafeInfo(bankAccountDto.getProductId().equals("068AH") || !bankAccountDto.isCustomOtpAuth());

            requestCustomerUpdateInquiry.setCustomerUpdateReq(customerUpdateReq);

            ObjectMapper mapper = new ObjectMapper();
            mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

            return mapper.valueToTree(requestCustomerUpdateInquiry);
        } catch (Exception e) {
            throw BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, bankAccountDto.getIdentityNumber(), "ERROR MAPPING mapUpdateCustomerDto: " + e.getMessage());
        }
    }

    private void updateInfoWithCRM(BankAccountDto bankAccountDto, ConsultCustomerRespDto consultCustomerRespDto) {
        bankAccountDto.setCellphone(bankAccountDto.getCellphone());
        bankAccountDto.setBirthDate(StringUtils.defaultIfEmpty(consultCustomerRespDto.getBirthDate(), bankAccountDto.getBirthDate()));
        bankAccountDto.setExpeditionDate(StringUtils.defaultIfEmpty(consultCustomerRespDto.getExpeditionDate(), bankAccountDto.getExpeditionDate()));

        if (bankAccountDto.isProspect() && StringUtils.isNumeric(consultCustomerRespDto.getExpeditionCityId())) {
            bankAccountDto.setExpeditionCityId(Integer.parseInt(consultCustomerRespDto.getExpeditionCityId()));
        }
    }

    private CustInfo getCustInfo(FinancialData financialData, List<Identification> identificationList, PersonInfo personInfo) {
        CustInfo custInfo = new CustInfo();
        custInfo.setCustId(identificationList);
        custInfo.setFinancialData(financialData);
        custInfo.setPersonInfo(personInfo);
        return custInfo;
    }

    private PersonInfo getPersonInfo(BankAccountDto bankAccountDto, PersonName personName, List<ContactInfo> contactInfoList, List<Employment> employmentList) {
        PersonInfo personInfo = new PersonInfo();

        personInfo.setEmployment(employmentList);
        personInfo.setContactInfo(contactInfoList);
        personInfo.setBirthDt(getDateFormat(bankAccountDto.getBirthDate()));
        personInfo.setBirthPlace(String.valueOf(bankAccountDto.getBornCityId()));
        personInfo.setGender(bankAccountDto.getGender());
        personInfo.setNationality(MVP_NATIONALITY);
        personInfo.setFatca(MVP_NATIONALITY);
        personInfo.setPersonName(personName);
        TINInfo tinInfo = new TINInfo();
        tinInfo.setTinType("");
        tinInfo.setTaxId("");
        tinInfo.setCertCode("");
        personInfo.setTinInfo(tinInfo);

        personInfo.setSpouseName("");
        personInfo.setTaxPayerInd(false);
        personInfo.setMaritalStatus(MVP_MARITAL_STATUS);
        personInfo.setDependents(0);
        personInfo.setDriversLicense(getDriversLicense());
        personInfo.setEducationalLevel(MVP_EDU_LEVEL);
        return personInfo;
    }

    private String getDateFormat(String date) {
        String dateFormatted = TimeUtilities.changeFrontToBackFormat(date);
        return StringUtils.isEmpty(dateFormatted) ? date : dateFormatted;
    }

    private DriversLicense getDriversLicense() {
        DriversLicense driversLicense = new DriversLicense();
        driversLicense.setLicenseNum("");
        driversLicense.setStateProv(MVP_STATE_PROV);
        driversLicense.setCountry(MVP_NATIONALITY);

        return driversLicense;
    }

    private List<Identification> getIdentifications(BankAccountDto bankAccountDto, CustIdentType custIdentType, CustIdentNum custIdentNum) {
        Identification identification = new Identification();
        identification.setCustIdentType(custIdentType);
        identification.setCustIdentNum(custIdentNum);
        if (!bankAccountDto.isCustomerExistsInCrm()) {
            identification.setExpeditionPlace(StringUtils.rightPad(String.valueOf(bankAccountDto.getExpeditionCityId()), 8, "0"));
        }
        identification.setIssDt(getDateFormat(bankAccountDto.getExpeditionDate()));
        identification.setIssueLoc("");
        identification.setPassportCountry("");

        List<Identification> identificationList = new ArrayList<>();
        identificationList.add(identification);
        return identificationList;
    }

    private CustIdentNum getCustIdentNum(String identityNumber) {
        CustIdentNum custIdentNum = new CustIdentNum();
        custIdentNum.setValue(identityNumber);
        return custIdentNum;
    }

    private CustIdentType getCustIdentType(String identityType) {
        CustIdentType custIdentType = new CustIdentType();
        custIdentType.setValue(CustIdentType.ValueEnum.valueOf(identityType));
        return custIdentType;
    }

    private FinancialData getFinancialData(BankAccountDto bankAccountDto, TotalLiabilities totalLiabilities, TotalAssests totalAssests) {
        FinancialData financialData = new FinancialData();
        financialData.setExpenses(new BigDecimal(bankAccountDto.getMonthlyOutcome()));
        financialData.setIncome(new BigDecimal(bankAccountDto.getMonthlyIncome()));
        financialData.setTotalLiabilities(totalLiabilities);
        financialData.setTotalAssests(totalAssests);
        financialData.setCostsReport("0");
        financialData.setEconomicActivity("");
        financialData.setEconomicStatus("");
        financialData.setDescEconomicActivity("");
        return financialData;
    }

    private CurAmt getCurAmtAssests(String totalAssets) {
        CurAmt curAmtAssests = new CurAmt();
        curAmtAssests.setAmt(new BigDecimal(totalAssets));
        curAmtAssests.setCurCode(COLOMBIAN_PESOS);
        curAmtAssests.setCurConvertRule("");
        curAmtAssests.setCurRate(new BigDecimal(0));
        return curAmtAssests;
    }

    private TotalLiabilities getTotalLiabilities(CurAmt curAmtLiabilities) {
        TotalLiabilities totalLiabilities = new TotalLiabilities();
        totalLiabilities.setCurAmt(curAmtLiabilities);
        return totalLiabilities;
    }

    private TotalAssests getTotalAssets(CurAmt curAmtAssests) {
        TotalAssests totalAssests = new TotalAssests();
        totalAssests.setCurAmt(curAmtAssests);
        return totalAssests;
    }

    private CurAmt getCurAmt(String totalDebts) {
        CurAmt curAmtLiabilities = new CurAmt();
        curAmtLiabilities.setAmt(new BigDecimal(totalDebts));
        curAmtLiabilities.setCurCode(COLOMBIAN_PESOS);
        curAmtLiabilities.setCurRate(BigDecimal.valueOf(0));
        curAmtLiabilities.setCurConvertRule("");
        return curAmtLiabilities;
    }

    private PersonName mapPersonName(BankAccountDto bankAccountDto) {
        PersonName personName = new PersonName();

        personName.setTitlePrefix("");
        personName.setFirstName(DataUtilities.removeAccents(bankAccountDto.getFirstName()));
        personName.setNameSuffix("");
        personName.setMiddleName(DataUtilities.removeAccents(bankAccountDto.getMiddleName()));
        personName.setNickname("");
        personName.setLastName(DataUtilities.removeAccents(bankAccountDto.getLastName()));
        personName.setLegalName("");
        personName.setSecondLastName(DataUtilities.removeAccents(bankAccountDto.getSecondLastName()));
        personName.setFullName("");
        return personName;
    }

    private PhoneNum mapPhoneNum(String phoneNumber) {

        PhoneNum phoneNum = new PhoneNum();
        phoneNum.setPhone(StringUtils.defaultString(phoneNumber, ""));
        phoneNum.setPhoneType(PHONE_TYPE_CELL_PHONE);
        phoneNum.setAreaDialingCode("");
        phoneNum.setDialingCode("");

        return phoneNum;
    }

    private PostAddr mapPostAddr(BankAccountDto bankAccountDto) {
        String cityId = Optional.ofNullable(bankAccountDto.getLivingCityId()).orElse(bankAccountDto.getCodCity());

        PostAddr postAddr = new PostAddr();
        postAddr.setAddr1(StringUtils.defaultString(bankAccountDto.getCrmAddress(), bankAccountDto.getAddressForCRM()));
        postAddr.setCity("");
        postAddr.setCityId(cityId.substring(2, 5));
        postAddr.setStateProv(cityId.substring(0, 2));
        postAddr.setPostalCode("");
        postAddr.setCountry(MVP_NATIONALITY);
        postAddr.setAddrType(MVP_ADDR_TYPE);

        return postAddr;
    }

    private List<ContactInfo> getContactInfos(BankAccountDto bankAccountDto, PhoneNum phoneNum, PostAddr postAddr) {
        ContactInfo contactInfo = new ContactInfo();

        contactInfo.setContactPref("");
        contactInfo.setPrefTimeStart("");
        contactInfo.setPrefTimeEnd("");
        contactInfo.setPhoneNum(phoneNum);
        contactInfo.setContactName(DataUtilities.removeAccents(bankAccountDto.getFirstName()) + " " +
                DataUtilities.removeAccents(bankAccountDto.getLastName()));

        contactInfo.setEmailAddr(Optional.ofNullable(bankAccountDto.getEmail()).orElse(""));
        contactInfo.setUrl("");
        ActivationPhone activationPhone = new ActivationPhone();
        activationPhone.setPhoneNum(phoneNum);
        contactInfo.setActivationPhone(activationPhone);

        contactInfo.setPostAddr(postAddr);
        contactInfo.setContactStatus("");

        List<ContactInfo> contactInfoList = new ArrayList<>();
        contactInfoList.add(contactInfo);
        return contactInfoList;
    }

    private List<Employment> getEmployments(Integer occupationId, String jobActivityId) {
        Employment employment = new Employment();
        employment.setOccupation("");
        employment.setOccupationCode(occupationId);
        employment.setEmploymentId(jobActivityId);
        List<Employment> employmentList = new ArrayList<>();
        employmentList.add(employment);
        return employmentList;
    }

    private CustInfo generateCustInfo(BankAccountDto bankAccountDto) {

        PersonName personName = mapPersonName(bankAccountDto);

        PhoneNum phoneNum = mapPhoneNum(bankAccountDto.getCellphone());

        PostAddr postAddr = mapPostAddr(bankAccountDto);

        List<ContactInfo> contactInfoList = getContactInfos(bankAccountDto, phoneNum, postAddr);

        List<Employment> employmentList = getEmployments(bankAccountDto.getOccupationId(), bankAccountDto.getJobActivityId());

        CurAmt curAmtLiabilities = getCurAmt(bankAccountDto.getTotalDebts());

        TotalLiabilities totalLiabilities = getTotalLiabilities(curAmtLiabilities);

        CurAmt curAmtAssets = getCurAmtAssests(bankAccountDto.getTotalAssets());

        TotalAssests totalAssests = getTotalAssets(curAmtAssets);

        FinancialData financialData = getFinancialData(bankAccountDto, totalLiabilities, totalAssests);

        CustIdentType custIdentType = getCustIdentType(EIdentificationType.CEDULA_CIUDADANIA.getBdbType());

        CustIdentNum custIdentNum = getCustIdentNum(bankAccountDto.getIdentityNumber());

        List<Identification> identificationList = getIdentifications(bankAccountDto, custIdentType, custIdentNum);

        PersonInfo personInfo = getPersonInfo(bankAccountDto, personName, contactInfoList, employmentList);

        return getCustInfo(financialData, identificationList, personInfo);
    }

}
