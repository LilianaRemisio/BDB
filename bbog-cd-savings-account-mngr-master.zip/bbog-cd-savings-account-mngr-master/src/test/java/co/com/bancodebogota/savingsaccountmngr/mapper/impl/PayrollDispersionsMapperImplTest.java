package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.dto.custcatteredinqrs.CustCatteredInqRsDto;
import co.com.bancodebogota.enums.EPayrollCodes;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class PayrollDispersionsMapperImplTest {

    @InjectMocks
    private PayrollDispersionsMapperImpl payrollDispersionsMapper;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapDispersionCode() {
        CustCatteredInqRsDto custCatteredInqRsDto = payrollDispersionsMapper.mapDispersionCode(EPayrollCodes.ABBVIE_S_A_S);

        Assertions.assertEquals(custCatteredInqRsDto.getEstablishAcctInfo().get(0).getLegalName(), EPayrollCodes.ABBVIE_S_A_S.getLegalName());
        Assertions.assertEquals(custCatteredInqRsDto.getEstablishAcctInfo().get(0).getAcctBasicInfo().getAcctId(), EPayrollCodes.ABBVIE_S_A_S.getAcctId());
    }

}