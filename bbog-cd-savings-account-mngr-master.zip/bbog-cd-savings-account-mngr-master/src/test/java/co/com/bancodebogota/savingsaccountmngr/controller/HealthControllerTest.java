package co.com.bancodebogota.savingsaccountmngr.controller;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class HealthControllerTest {

    private final HealthController healthController = new HealthController();

    @Test
    public void testHealth() {
        String result = healthController.health();
        Assertions.assertEquals("OK", result);
    }
}
