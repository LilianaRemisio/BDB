package co.com.bancodebogota.savingsaccountmngr.controller;

import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.request.*;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.savingsaccountmngr.service.request.IRequestService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Date;
import java.util.Objects;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class RequestControllerTest {

    @Mock
    private IRequestService requestService;
    @InjectMocks
    private RequestController requestController;

    private final CreateRequestDto createRequestDto = new CreateRequestDto();
    private final HttpHeaders httpHeaders = new HttpHeaders();

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        httpHeaders.set("X-Journey", "FlujoWeb");
        httpHeaders.set("X-AuthUuid", "rqUID");
        httpHeaders.set("X-Channel", "Web");
        httpHeaders.set("X-Forwarded-For", "userIp");
    }

    @Test
    public void testCreateRequestOld() throws Exception {
        when(requestService.createRequest(any(), anyString(), any())).thenReturn(new AccountRequestRsDto(null, 123));

        ResponseEntity<String> request = requestController.createRequest("userIp", createRequestDto);
        Assertions.assertEquals("123", request.getBody());
    }

    @Test
    public void testCreateRequestV2() throws Exception {
        AccountRequestV2RsDto accountRequestV2RsDto = new AccountRequestV2RsDto();
        AccountRequestRsDto accountRequestRsDto = new AccountRequestRsDto(12L, 123);
        accountRequestV2RsDto.setAccountRequest(accountRequestRsDto);

        when(requestService.createRequestV2(any())).thenReturn(accountRequestV2RsDto);

        ResponseEntity<AccountRequestV2RsDto> request = requestController.createRequestV2(httpHeaders);
        Assertions.assertEquals(123, Objects.requireNonNull(request.getBody()).getAccountRequest().getRequestId());
    }

    @Test
    public void testCreateRequestV3() throws Exception {
        AccountRequestV3RsDto accountRequestV3RsDto = new AccountRequestV3RsDto();
        AccountRequestRsDto accountRequestRsDto = new AccountRequestRsDto(12L, 123);
        accountRequestV3RsDto.setAccountRequest(accountRequestRsDto);

        when(requestService.createRequestV3(any())).thenReturn(accountRequestV3RsDto);

        ResponseEntity<AccountRequestV3RsDto> request = requestController.createRequestV3(httpHeaders);
        Assertions.assertEquals(123, Objects.requireNonNull(request.getBody()).getAccountRequest().getRequestId());
    }

    @Test
    public void testCreateRequestId() throws Exception {
        AccountRequestRsDto accountRequestRsDto = new AccountRequestRsDto(12L, 123);

        when(requestService.createRequestId(any())).thenReturn(accountRequestRsDto);

        ResponseEntity<AccountRequestRsDto> request = requestController.createRequestId(httpHeaders);
        Assertions.assertEquals(123, Objects.requireNonNull(request.getBody().getRequestId()));
    }

    @Test
    public void testCloseDigitalByDispatcher() {
        DispatcherDto dispatcherDto = new DispatcherDto();
        dispatcherDto.setIdentityNumber("12345678");

        doNothing().when(requestService).closeDigitalBySession(any());
        requestController.closeDigitalByDispatcher(httpHeaders);
        verify(requestService, atLeast(0)).closeDigitalBySession(httpHeaders);
    }

    @Test
    public void testCloseDigitalByDate() {
        Date date = new Date();

        doNothing().when(requestService).closeDigitalByDate(any(Date.class));
        requestController.closeDigitalByDateAsync(date);
        verify(requestService, atLeast(0)).closeDigitalByDate(date);
    }

    @Test
    public void testCloseDigitalById() {
        doNothing().when(requestService).closeDigitalById(anyString(), any());
        requestController.closeDigitalByIdAsync("", null);
        verify(requestService, atLeast(0)).closeDigitalById("", null);
    }

    @Test
    public void testGetFlowType() throws AbsBdbServiceException {
        when(requestService.getFlowType(any())).thenReturn(new FlowTypeDto());
        ResponseEntity<FlowTypeDto> response = requestController.getFlowType(httpHeaders);
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    }
}
