package co.com.bancodebogota.savingsaccountmngr.controller;

import co.com.bancodebogota.db.savings.dto.jpa.DisperserInformationDto;
import co.com.bancodebogota.db.savings.dto.jpa.DisperserRqDto;
import co.com.bancodebogota.dto.payrolldispersions.GetInfoByNitDto;
import co.com.bancodebogota.dto.payrolldispersions.PayrollDispersionsRsDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.savingsaccountmngr.service.accounts.IPayrollService;
import co.com.bancodebogota.savingsaccountmngr.service.dispersioncodes.IDispersionCodesService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import static org.mockito.Mockito.*;

public class PayrollControllerTest {
    @Mock
    private IPayrollService payrollService;
    @Mock
    private IDispersionCodesService dispersionCodesService;
    @InjectMocks
    private PayrollController payrollController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAccountAgreement() {
        when(payrollService.getAccountInformation(any())).thenReturn(new DisperserInformationDto());
        DisperserInformationDto accountAgreement = payrollController.getAccountAgreement(new DisperserRqDto());
        Assertions.assertNotNull(accountAgreement);
    }

    @Test
    public void testGetCompanyNamesByCode() throws AbsBdbServiceException {
        when(dispersionCodesService.getPayrollDispersionsRsDto(
                anyString(),anyString(),anyString(), anyString(), anyString())).thenReturn(new PayrollDispersionsRsDto());

        ResponseEntity<PayrollDispersionsRsDto> custCatteredInqRsDto = payrollController
                .getCompanyNamesByCode("123","N","12", "WEB", "462346362625");
        Assertions.assertNotNull(custCatteredInqRsDto.getBody());
    }

    @Test
    public void testGetNitInfo() throws AbsBdbServiceException {
        when(dispersionCodesService.getNitInfo(any(),anyString())).thenReturn(new GetInfoByNitDto());
        GetInfoByNitDto getInfoByNitDto = payrollController.getNitInfo(any(),anyString());
        Assertions.assertNotNull(getInfoByNitDto);
    }
}
