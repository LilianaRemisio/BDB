package co.com.bancodebogota.savingsaccountmngr.service.accounts;

import co.com.bancodebogota.enums.EAccount;
import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.db.savings.dto.jpa.*;
import co.com.bancodebogota.dto.customer.ConsultCustomerRespDto;
import co.com.bancodebogota.dto.customer.DigitalAccountRsDto;
import co.com.bancodebogota.dto.customer.ResponseBlacklist;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.products.AccountHierarchyReqDto;
import co.com.bancodebogota.dto.products.AcctBasicInfoDto;
import co.com.bancodebogota.dto.request.AccountRequestRsDto;
import co.com.bancodebogota.dto.request.CreateRequestDto;
import co.com.bancodebogota.enums.EChannel;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.model.entities.*;
import co.com.bancodebogota.model.entitiesold.AccountLog;
import co.com.bancodebogota.model.repositories.*;
import co.com.bancodebogota.proxy.AccountLogProxy;
import co.com.bancodebogota.savingsaccountmngr.mapper.RequestMapper;
import co.com.bancodebogota.savingsaccountmngr.mapper.impl.AccountLimitMapperDto;
import co.com.bancodebogota.savingsaccountmngr.service.customer.ICustomerManagement;
import co.com.bancodebogota.savingsaccountmngr.service.customer.ICustomerService;
import co.com.bancodebogota.savingsaccountmngr.service.customer.IParticipantService;
import co.com.bancodebogota.savingsaccountmngr.service.products.IProductsService;
import co.com.bancodebogota.savingsaccountmngr.service.request.IRequestService;
import co.com.bancodebogota.savingsaccountmngr.utils.RequestUtilities;
import co.com.bancodebogota.service.customer.ICustomerApiService;
import co.com.bancodebogota.service.notifications.INotificationApiService;
import co.com.bancodebogota.service.pentagon.IPentagonService;
import co.com.bancodebogota.service.redis.IRedisApiService;
import co.com.bancodebogota.service.request.IRequestApiService;
import co.com.bancodebogota.utils.TimeUtilities;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.util.*;

import static org.mockito.Mockito.*;

public class SavingsAccountServiceImplTest {

    @Mock
    private RequestMapper requestMapper;
    @Mock
    private ObjectMapper objectMapper;
    @Mock
    private RestExchangeV2 restExchange;
    @Mock
    private IRedisApiService redisApiService;
    @Mock
    private AccountLogRepository accountLogRepository;
    @Mock
    private AccountLogProxy accountLogProxy;
    @Mock
    private IParticipantService participantService;
    @Mock
    private ICustomerService customerServiceImpl;
    @Mock
    private IProductsService productsService;
    @Mock
    private AccountLimitMapperDto accountLimitMapper;
    @Mock
    private RequestRepository requestRepository;
    @Mock
    private LocationRepository locationRepository;
    @Mock
    private ParticipantRepository participantRepository;
    @Mock
    private ParticipantInfoRepository participantInfoRepository;
    @Mock
    private ConditionRepository conditionRepository;
    @Mock
    private SavingConditionRepository savingConditionRepository;
    @Mock
    private SavingTypeRepository savingTypeRepository;
    @Mock
    private ICustomerApiService customerApiService;
    @Mock
    private ICustomerManagement customerManagement;
    @Mock
    private INotificationApiService notificationApiService;
    @Mock
    private IRequestService requestService;
    @Mock
    private RequestUtilities requestUtilities;
    @Mock
    private IGMFService gmfService;
    @Mock
    private ChannelRepository channelRepository;
    @Mock
    private IPentagonService pentagonService;
    @Mock
    private IRequestApiService requestApiService;
    @Mock
    private DomicileInfoRepository domicileInfoRepository;
    @InjectMocks
    private SavingsAccountServiceImpl savingsAccountServiceImpl;

    private final BankAccountDto bankAccountDto = new BankAccountDto();
    private BankAccountDto bankAccountDtoOffice = new BankAccountDto();
    private BankAccountDto bankAccountDtoNomina = new BankAccountDto();
    private final RequestSellerDto requestSellerDto = new RequestSellerDto();
    private final RequestPayrollAccountDto requestPayrollAccountDto = new RequestPayrollAccountDto();
    private final CreateAccountResponseDto createAccountResponseDto = new CreateAccountResponseDto();
    private final SavingTypeDto savingTypeDto = new SavingTypeDto();
    private final ChannelDto channelDto = new ChannelDto();
    private final DispatcherDto dispatcherDto = new DispatcherDto();
    private final HttpHeaders httpHeaders = new HttpHeaders();
    private final ResponseBlacklist responseBlacklist = new ResponseBlacklist();

    @BeforeEach
    public void setUp() throws IOException, AbsBdbServiceException {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(savingsAccountServiceImpl, "endpointAccountsAdapter", "http://localhost/a");
        ReflectionTestUtils.setField(savingsAccountServiceImpl, "cardActivationEndpoint", "activatutarjeta.mock");

        bankAccountDto.setLastName("lastName");
        bankAccountDto.setSecondLastName("secondLastName");
        bankAccountDto.setFirstName("firstName");
        bankAccountDto.setMiddleName("middleName");
        bankAccountDto.setGender("M");
        bankAccountDto.setExpeditionDate("12/09/1986");
        bankAccountDto.setIdentityNumber("12345678");
        bankAccountDto.setBirthDate("12/09/1986");
        bankAccountDto.setEmail("email");
        bankAccountDto.setLivingCityId("livingCityId");
        bankAccountDto.setCellphone("cellphone");
        bankAccountDto.setEmployeeName("employeeName");
        bankAccountDto.setEmployeeAddress("employeeAddress");
        bankAccountDto.setEmployeeState("employeeState");
        bankAccountDto.setEmployeePhone("employeePhone");
        bankAccountDto.setMonthlyIncome("10000");
        bankAccountDto.setMonthlyOutcome("20000");
        bankAccountDto.setTotalAssets("30000");
        bankAccountDto.setTotalDebts("40000");
        bankAccountDto.setAccountType("accountType");
        bankAccountDto.setProductId("productId");
        bankAccountDto.setJobActivityId("jobActivityId");
        bankAccountDto.setCodNomina("codNomina");
        bankAccountDto.setEmployeeNit("employeeNit");
        bankAccountDto.setNameCompany("nameCompany");
        bankAccountDto.setOfficeCode("officeCode");
        bankAccountDto.setDeliveryAddress("deliveryAddress");
        bankAccountDto.setLivingCityId("livingCityId");
        bankAccountDto.setAddressForCRM("AV;andres;APTO;prueba;;;;;;;COL;11;11001000;;");

        bankAccountDto.setExpeditionCityId(1231);
        bankAccountDto.setBornCityId(1232);
        bankAccountDto.setCityCompanyId(1234);
        bankAccountDto.setOccupationId(1235);

        bankAccountDto.setHasAuthorizedRiskCheck(true);
        bankAccountDto.setGreenCard(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        bankAccountDto.setAssetsDeclaration(false);
        bankAccountDto.setUsaIncome(true);
        bankAccountDto.setUsaLongTimeVisitor(false);
        bankAccountDto.setCheckGmf(true);
        bankAccountDto.setTxInWeb(true);
        bankAccountDto.setChannel("");
        bankAccountDto.setClientWithDebitCards(true);

        Address1Dto address1Dto = new Address1Dto();
        address1Dto.setAddressDetail("details");
        address1Dto.setTypeRoad1("road1");
        address1Dto.setTypeRoad1Number("number");
        address1Dto.setTypeRoad2("road2");
        address1Dto.setTypeRoad2Number("number");
        bankAccountDto.setAddress1Dto(address1Dto);

        // TODO: Esta copia de objetos esta mal
        bankAccountDtoOffice = bankAccountDto;
        bankAccountDtoOffice.setTxInWeb(false);
        bankAccountDtoOffice.setSellerId("1012101901");

        // TODO: Esta copia de objetos esta mal
        bankAccountDtoNomina = bankAccountDto;
        bankAccountDtoNomina.setProductId("055AH");
        bankAccountDtoNomina.setCodNomina("1A2");
        bankAccountDtoNomina.setEmployeeNit("900123123");

        requestSellerDto.setSeller(bankAccountDtoOffice.getSellerId());
        requestSellerDto.setRequestId(bankAccountDtoOffice.getRequestId());

        requestPayrollAccountDto.setCompanyNit(bankAccountDtoNomina.getEmployeeNit());
        requestPayrollAccountDto.setDispersionCode(bankAccountDtoNomina.getCodNomina());
        requestPayrollAccountDto.setRequestId(bankAccountDto.getRequestId());

        bankAccountDto.setRequestId(123);

        createAccountResponseDto.setAccountNumber("123456789");
        createAccountResponseDto.setMessage("message");
        createAccountResponseDto.setHoliday(false);
        createAccountResponseDto.setReservation(true);

        savingTypeDto.setId(0);
        savingTypeDto.setDescription("desc");
        savingTypeDto.setCode("code");

        httpHeaders.add("X-FORWARDED-FOR", "12.12.12.12");
        httpHeaders.add("User-Agent", "Test");
        httpHeaders.add("access-token", "k5DiyCODpYfiZAem4H9kX");
        httpHeaders.add("X-AuthUuid", "fiZAem4H9kX");

        channelDto.setId(1);
        channelDto.setDescription("Test");

        dispatcherDto.setIdentityType("C");
        dispatcherDto.setIdentityNumber("1234");
        dispatcherDto.setSpecificProductInfoUuid("12345");

        JsonNode data = new ObjectMapper().createObjectNode();
        dispatcherDto.setSpecificProductInfo(data);

        dispatcherDto.setWasteInfo("{\"waste001\":null,\"waste002\":null,\"waste003\":null,\"waste004\":null,\"waste005\":true,\"waste006\":null}");
        when(requestApiService.createDigitalRequest(any())).thenReturn(123456L);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);

        responseBlacklist.setCanContinue(true);
    }

    @Test
    public void testCreateAccountFail() {
        when(participantService.getParticipantInfo(any())).thenReturn(getAccountDto());

        try {
            savingsAccountServiceImpl.createAccountByUuid(null, httpHeaders);
        } catch (AbsBdbServiceException e) {
            Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getCode());
        }
    }

    @Test
    public void testCreateAccount() throws Exception {
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        createAccountDto.setSourceTeamId(1);
        createAccountDto.setGmf(1);
        createAccountDto.setChannel("WEB");
        bankAccountDto.setChannel("WEB");
        bankAccountDto.setFatca("MEX");
        bankAccountDto.setCheckGmf(false);

        DigitalAccountRsDto digitalAccountRsDto = new DigitalAccountRsDto();
        digitalAccountRsDto.setHasAccount(false);

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(channelRepository.findChannelIdByDescription(anyString())).thenReturn(channelDto);
        when(participantService.getParticipantInfo(any())).thenReturn(createAccountDto);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestRepository.save(any(RequestDto.class))).thenReturn(new RequestDto());
        when(participantInfoRepository.save(any(ParticipantInfoDto.class))).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(customerServiceImpl.hasDigitalAccount(anyString(), anyString(), anyString(), anyString())).thenReturn(digitalAccountRsDto);
        when(gmfService.sendNewAccountToGMFService(anyString(), anyString(), anyString(), anyString(), anyString(),
                anyString(), anyLong())).thenReturn(true);
        when(channelRepository.findChannelIdByDescription(anyString())).thenReturn(channelDto);

        String jsonString = "{\"accountNumber\":\"1234\"}";
        String jsonData = "{\"productId\":\"061AH\",\"uuid\":\"xyz\"}";

        ObjectMapper mapper = new ObjectMapper();
        JsonNode string = mapper.readTree(jsonString);
        JsonNode data = mapper.readTree(jsonData);

        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        when(pentagonService.publish(any(), any())).thenReturn(true);

        when(objectMapper.valueToTree(any())).thenReturn(string);
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));

        ResponseEntity<JsonNode> result = savingsAccountServiceImpl.createAccountByUuid(data, httpHeaders);
        Assertions.assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testCreateAccountNoChannel() throws Exception {
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        createAccountDto.setSourceTeamId(1);
        createAccountDto.setGmf(1);
        createAccountDto.setChannel("");
        bankAccountDto.setChannel("");
        bankAccountDto.setFatca("MEX");
        bankAccountDto.setCustomOtpAuth(true);

        DigitalAccountRsDto digitalAccountRsDto = new DigitalAccountRsDto();
        digitalAccountRsDto.setHasAccount(false);

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(channelRepository.findChannelIdByDescription(anyString())).thenReturn(channelDto);
        when(participantService.getParticipantInfo(any())).thenReturn(createAccountDto);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestRepository.save(any(RequestDto.class))).thenReturn(new RequestDto());
        when(participantInfoRepository.save(any(ParticipantInfoDto.class))).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(customerServiceImpl.hasDigitalAccount(anyString(), anyString(), anyString(), anyString())).thenReturn(digitalAccountRsDto);
        when(gmfService.sendNewAccountToGMFService(anyString(), anyString(), anyString(), anyString(), anyString(),
                anyString(), anyLong())).thenReturn(true);
        when(channelRepository.findChannelIdByDescription(anyString())).thenReturn(channelDto);

        String jsonString = "{\"accountNumber\":\"1234\"}";
        String jsonData = "{\"productId\":\"061AH\",\"uuid\":\"xyz\"}";

        ObjectMapper mapper = new ObjectMapper();
        JsonNode string = mapper.readTree(jsonString);
        JsonNode data = mapper.readTree(jsonData);

        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        when(pentagonService.publish(any(), any())).thenReturn(true);

        when(objectMapper.valueToTree(any())).thenReturn(string);
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));

        ResponseEntity<JsonNode> result = savingsAccountServiceImpl.createAccountByUuid(data, httpHeaders);
        Assertions.assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testCreateAccountTeam3() throws Exception {
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        createAccountDto.setGmf(1);
        createAccountDto.setChannel("WEB");
        createAccountDto.setSourceTeamId(3);
        bankAccountDto.setChannel("WEB");
        bankAccountDto.setCustomOtpAuth(true);
        bankAccountDto.setFatca("MEX");

        DigitalAccountRsDto digitalAccountRsDto = new DigitalAccountRsDto();
        digitalAccountRsDto.setHasAccount(false);

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(participantService.getParticipantInfo(anyString())).thenReturn(createAccountDto);
        when(channelRepository.findChannelIdByDescription(anyString())).thenReturn(channelDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestRepository.save(any(RequestDto.class))).thenReturn(new RequestDto());
        when(participantInfoRepository.save(any(ParticipantInfoDto.class))).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(customerServiceImpl.hasDigitalAccount(anyString(), anyString(), anyString(), anyString())).thenReturn(digitalAccountRsDto);
        when(gmfService.sendNewAccountToGMFService(anyString(), anyString(), anyString(), anyString(), anyString(),
                anyString(), anyLong())).thenReturn(true);
        when(requestApiService.createDigitalRequest(any())).thenThrow(BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, "", "Error creating digital request"));
        String jsonString = "{\"accountNumber\":\"1234\"}";
        String jsonData = "{\"productId\":\"061AH\",\"uuid\":\"xyz\",\"requestId\":\"1234\"}";

        ObjectMapper mapper = new ObjectMapper();
        JsonNode string = mapper.readTree(jsonString);
        JsonNode data = mapper.readTree(jsonData);

        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());

        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(false);
        when(pentagonService.publish(any(), any())).thenReturn(true);

        when(objectMapper.valueToTree(any())).thenReturn(string);
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));

        ResponseEntity<JsonNode> result = savingsAccountServiceImpl.createAccountByUuid(data, httpHeaders);
        Assertions.assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testCreateAccountFailProductId() throws Exception {
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        createAccountDto.setSourceTeamId(1);
        createAccountDto.setGmf(1);
        createAccountDto.setChannel("WEB");
        bankAccountDto.setChannel("WEB");
        bankAccountDto.setFatca("MEX");

        String jsonData = "{\"uuid\":\"xyz\"}";

        ObjectMapper mapper = new ObjectMapper();
        JsonNode data = mapper.readTree(jsonData);

        createAccountResponseDto.setAccountNumber(null);
        try {
            savingsAccountServiceImpl.createAccountByUuid(data, httpHeaders);
        } catch (Exception e) {
            Assertions.assertEquals("data.ProductId is null ", e.getMessage());
        }
    }

    @Test
    public void testCreateAccountFailProductId2() throws Exception {
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        createAccountDto.setSourceTeamId(1);
        createAccountDto.setGmf(1);
        createAccountDto.setChannel("WEB");
        bankAccountDto.setChannel("WEB");
        bankAccountDto.setFatca("MEX");

        String jsonData = "{\"productId\":\"\",\"uuid\":\"xyz\"}";

        ObjectMapper mapper = new ObjectMapper();
        JsonNode data = mapper.readTree(jsonData);

        createAccountResponseDto.setAccountNumber(null);
        try {
            savingsAccountServiceImpl.createAccountByUuid(data, httpHeaders);
        } catch (Exception e) {
            Assertions.assertEquals("data.ProductId is null ", e.getMessage());
        }
    }

    @Test
    public void testCreateAccountWithGmfFatcaFail() throws Exception {
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        createAccountDto.setSourceTeamId(3);
        createAccountDto.setChannel("Oficina");

        DigitalAccountRsDto digitalAccountRsDto = new DigitalAccountRsDto();
        digitalAccountRsDto.setHasAccount(false);

        ConsultCustomerRespDto consultCustomerRespDto = new ConsultCustomerRespDto();
        consultCustomerRespDto.setBirthDate("1990-03-21");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(participantService.getParticipantInfo(any())).thenReturn(createAccountDto);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(consultCustomerRespDto);
        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        when(requestRepository.save(any(RequestDto.class))).thenReturn(new RequestDto());
        when(participantInfoRepository.save(any(ParticipantInfoDto.class))).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(customerServiceImpl.hasDigitalAccount(anyString(), anyString(), anyString(), anyString())).thenReturn(digitalAccountRsDto);
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));
        when(pentagonService.publish(any(), any())).thenReturn(true);

        ObjectMapper mapper = new ObjectMapper();

        String jsonString = "{\"accountNumber\":\"1234\"}";
        JsonNode string = mapper.readTree(jsonString);
        when(objectMapper.valueToTree(any())).thenReturn(string);

        String jsonData = "{\"productId\":\"060AH\",\"requestId\":\"123\",\"uuid\":\"xyz\",\"gmf\":\"true\",\"fatca\":\"true\",\"fatcaCountry\":\"PAN\",\"channel\":\"WEB\"}";
        JsonNode data = mapper.readTree(jsonData);

        try {
            savingsAccountServiceImpl.createAccountByUuid(data, httpHeaders);
        } catch (AbsBdbServiceException e) {
            Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getCode());
        }
    }

    @Test
    public void testCreateAccountWithGmfFatca() throws Exception {
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        createAccountDto.setSourceTeamId(1);
        createAccountDto.setChannel("FMV");
        bankAccountDto.setChannel("FMV");

        DigitalAccountRsDto digitalAccountRsDto = new DigitalAccountRsDto();
        digitalAccountRsDto.setHasAccount(false);

        ConsultCustomerRespDto consultCustomerRespDto = new ConsultCustomerRespDto();
        consultCustomerRespDto.setBirthDate("1990-03-21");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(channelRepository.findChannelIdByDescription(anyString())).thenReturn(channelDto);
        when(participantService.getParticipantInfo(any())).thenReturn(createAccountDto);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(consultCustomerRespDto);
        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        when(requestRepository.save(any(RequestDto.class))).thenReturn(new RequestDto());
        when(participantInfoRepository.save(any(ParticipantInfoDto.class))).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(customerServiceImpl.hasDigitalAccount(anyString(), anyString(), anyString(), anyString())).thenReturn(digitalAccountRsDto);
        String jsonString = "{\"accountNumber\":\"1234\"}";
        String jsonData = "{\"productId\":\"060AH\",\"uuid\":\"xyz\",\"gmf\":\"true\",\"fatca\":\"true\",\"fatcaCountry\":\"PAN\"}";

        ObjectMapper mapper = new ObjectMapper();
        JsonNode string = mapper.readTree(jsonString);
        JsonNode data = mapper.readTree(jsonData);

        when(objectMapper.valueToTree(any())).thenReturn(string);

        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));

        ResponseEntity<JsonNode> result = savingsAccountServiceImpl.createAccountByUuid(data, httpHeaders);
        Assertions.assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testCreateAccountHasDigital() throws Exception {
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        createAccountDto.setSourceTeamId(2);
        createAccountDto.setChannel("WEB");
        bankAccountDto.setChannel("WEB");

        RequestDto requestDto = new RequestDto();
        requestDto.setId(1);

        DigitalAccountRsDto digitalAccountRsDto = new DigitalAccountRsDto();
        digitalAccountRsDto.setHasAccount(true);

        ConsultCustomerRespDto consultCustomerRespDto = new ConsultCustomerRespDto();
        consultCustomerRespDto.setBirthDate("1998-03-21");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(participantService.getParticipantInfo(any())).thenReturn(createAccountDto);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(consultCustomerRespDto);
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        when(channelRepository.findChannelIdByDescription(anyString())).thenReturn(channelDto);
        when(requestRepository.save(any(RequestDto.class))).thenReturn(requestDto);
        when(customerServiceImpl.hasDigitalAccount(anyString(), anyString(), anyString(), anyString())).thenReturn(digitalAccountRsDto);

        String jsonData = "{\"productId\":\"060AH\",\"uuid\":\"123\",\"gmf\":\"true\",\"fatca\":\"true\",\"fatcaCountry\":\"PAN\",\"channel\":\"WEB\"}";

        ObjectMapper mapper = new ObjectMapper();
        JsonNode data = mapper.readTree(jsonData);

        try {
            savingsAccountServiceImpl.createAccountByUuid(data, httpHeaders);
        } catch (AbsBdbServiceException e) {
            Assertions.assertEquals(HttpStatus.FORBIDDEN, e.getCode());
        }
    }

    @Test
    public void testCreateAccountByDto() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        bankAccountDto.setChannel("BM");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(true);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(JsonNode.class))).thenReturn(true);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        bankAccountDto.setProspect(true);
        bankAccountDto.setCustomerExistsInCrm(false);
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(notificationApiService.sendSMS(anyString(), anyString(), any())).thenReturn(true);
        when(notificationApiService.sendEmail(anyString(), anyString(), any())).thenReturn(true);
        when(requestRepository.findById(anyLong())).thenReturn(new RequestDto());
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);

        dispatcherDto.setWasteInfo("{\"waste001\":null,\"waste002\":null,\"waste003\":null,\"waste004\":null,\"waste005\":null,\"waste006\":null}");
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);

        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertEquals(HttpStatus.CREATED, result.getStatusCode());

        dispatcherDto.setWasteInfo(null);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);

        ResponseEntity<CreateAccountResponseDto> result2 = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertEquals(HttpStatus.CREATED, result2.getStatusCode());

    }

    @Test
    public void testCreateAccountByDto2() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        bankAccountDto.setChannel("FMV");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(true);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(JsonNode.class))).thenReturn(true);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(notificationApiService.sendSMS(anyString(), anyString(), any())).thenReturn(true);
        when(notificationApiService.sendEmail(anyString(), anyString(), any())).thenReturn(true);
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);

        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        when(pentagonService.publish(any(), any())).thenReturn(true);

        when(requestRepository.findById(anyLong())).thenReturn(new RequestDto());
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));

        bankAccountDto.setCodNomina("");
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertEquals(HttpStatus.CREATED, result.getStatusCode());
    }

    @Test
    public void testCreateAccountByDto3() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        bankAccountDto.setChannel("");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(true);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(JsonNode.class))).thenReturn(true);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(notificationApiService.sendSMS(anyString(), anyString(), any())).thenReturn(true);
        when(notificationApiService.sendEmail(anyString(), anyString(), any())).thenReturn(true);
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);

        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        when(pentagonService.publish(any(), any())).thenReturn(true);

        when(requestRepository.findById(anyLong())).thenReturn(new RequestDto());
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));

        bankAccountDto.setCodNomina("");
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertEquals(HttpStatus.CREATED, result.getStatusCode());
    }

    @Test
    public void testSaveRequestPayrollAccount() throws AbsBdbServiceException {
        bankAccountDto.setSellerId(null);

        bankAccountDto.setProductId(EAccount.NOMINA.getCode());
        ParticipantInfoDto participantInfoDto = new ParticipantInfoDto();
        participantInfoDto.setRequestId(1L);

        List<ParticipantInfoDto> participantInfoDtos = new ArrayList<>();
        participantInfoDtos.add(participantInfoDto);

        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.save(any(ParticipantInfoDto.class))).thenReturn(new ParticipantInfoDto());
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());

        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(domicileInfoRepository.save(any(DomicileInfoDto.class))).thenReturn(new DomicileInfoDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);

        savingsAccountServiceImpl.saveNewModel(bankAccountDto, createAccountResponseDto);

        Assertions.assertEquals(1L, participantInfoDto.getRequestId());
    }

    @Test
    public void testSaveRequestPayrollAccountWithSellerId() throws AbsBdbServiceException {
        bankAccountDto.setSellerId("12345");
        requestSellerDto.setRequestId(1L);

        bankAccountDto.setProductId(EAccount.NOMINA.getCode());
        ParticipantInfoDto participantInfoDto = new ParticipantInfoDto();
        participantInfoDto.setRequestId(1L);

        List<ParticipantInfoDto> participantInfoDtos = new ArrayList<>();
        participantInfoDtos.add(participantInfoDto);

        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.save(any(ParticipantInfoDto.class))).thenReturn(new ParticipantInfoDto());
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());

        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(domicileInfoRepository.save(any(DomicileInfoDto.class))).thenReturn(new DomicileInfoDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);

        when(requestMapper.mapRequestSeller(eq(bankAccountDto.getCeoCode()), eq(bankAccountDto.getSellerId()), eq(bankAccountDto.getRequestId())))
                .thenReturn(new RequestSellerDto());

        savingsAccountServiceImpl.saveNewModel(bankAccountDto, createAccountResponseDto);

        Assertions.assertEquals(1L, participantInfoDto.getRequestId());
    }

    @Test
    public void testSaveRequestPayrollAccountWithSellerIdExperiencia() throws AbsBdbServiceException {
        bankAccountDto.setSellerId("12345");
        requestSellerDto.setRequestId(1L);

        bankAccountDto.setProductId(EAccount.PENSIONADO_MAS_EXPERIENCIA.getCode());
        ParticipantInfoDto participantInfoDto = new ParticipantInfoDto();
        participantInfoDto.setRequestId(1L);

        List<ParticipantInfoDto> participantInfoDtos = new ArrayList<>();
        participantInfoDtos.add(participantInfoDto);

        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.save(any(ParticipantInfoDto.class))).thenReturn(new ParticipantInfoDto());
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());

        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(domicileInfoRepository.save(any(DomicileInfoDto.class))).thenReturn(new DomicileInfoDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);

        when(requestMapper.mapRequestSeller(eq(bankAccountDto.getCeoCode()), eq(bankAccountDto.getSellerId()), eq(bankAccountDto.getRequestId())))
                .thenReturn(new RequestSellerDto());

        savingsAccountServiceImpl.saveNewModel(bankAccountDto, createAccountResponseDto);

        Assertions.assertEquals(1L, participantInfoDto.getRequestId());
    }

    @Test
    public void testSaveRequestPayrollAccountWithSellerIdJoven() throws AbsBdbServiceException {
        bankAccountDto.setSellerId("12345");
        requestSellerDto.setRequestId(1L);

        bankAccountDto.setProductId(EAccount.JOVEN.getCode());
        ParticipantInfoDto participantInfoDto = new ParticipantInfoDto();
        participantInfoDto.setRequestId(1L);

        List<ParticipantInfoDto> participantInfoDtos = new ArrayList<>();
        participantInfoDtos.add(participantInfoDto);

        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.save(any(ParticipantInfoDto.class))).thenReturn(new ParticipantInfoDto());
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());

        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(domicileInfoRepository.save(any(DomicileInfoDto.class))).thenReturn(new DomicileInfoDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);

        when(requestMapper.mapRequestSeller(eq(bankAccountDto.getCeoCode()), eq(bankAccountDto.getSellerId()), eq(bankAccountDto.getRequestId())))
                .thenReturn(new RequestSellerDto());

        savingsAccountServiceImpl.saveNewModel(bankAccountDto, createAccountResponseDto);

        Assertions.assertEquals(1L, participantInfoDto.getRequestId());
    }

    @Test
    public void testCreateAccountByDto4() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        bankAccountDto.setChannel("BM");
        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(false);

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(true);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(JsonNode.class))).thenReturn(true);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(notificationApiService.sendSMS(anyString(), anyString(), any())).thenReturn(true);
        when(notificationApiService.sendEmail(anyString(), anyString(), any())).thenReturn(true);
        when(requestRepository.findById(anyLong())).thenReturn(new RequestDto());
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);

        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertEquals(HttpStatus.CREATED, result.getStatusCode());
    }

    @Test
    public void testCreateAccountByDto5() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        bankAccountDto.setChannel("BM");
        bankAccountDto.setProspect(false);

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(true);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(JsonNode.class))).thenReturn(true);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(notificationApiService.sendSMS(anyString(), anyString(), any())).thenReturn(true);
        when(notificationApiService.sendEmail(anyString(), anyString(), any())).thenReturn(true);
        when(requestRepository.findById(anyLong())).thenReturn(new RequestDto());
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertEquals(HttpStatus.CREATED, result.getStatusCode());
    }

    @Test
    public void testCreateAccountByDto6() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        bankAccountDto.setChannel("BM");
        bankAccountDto.setProspect(false);

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(true);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(JsonNode.class))).thenReturn(true);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(notificationApiService.sendSMS(anyString(), anyString(), any())).thenReturn(true);
        when(notificationApiService.sendEmail(anyString(), anyString(), any())).thenReturn(true);
        when(requestRepository.findById(anyLong())).thenReturn(new RequestDto());
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);

        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertEquals(HttpStatus.CREATED, result.getStatusCode());
    }

    @Test
    public void testCreateAccountByDtoOffice() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        bankAccountDto.setChannel("WEB");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(true);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(JsonNode.class))).thenReturn(true);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDtoOffice);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);
        when(notificationApiService.sendSMS(anyString(), anyString(), any())).thenReturn(true);
        when(notificationApiService.sendEmail(anyString(), anyString(), any())).thenReturn(true);

        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        when(pentagonService.publish(any(), any())).thenReturn(true);


        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));

        bankAccountDtoOffice.setCodNomina("");
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDtoOffice, httpHeaders);
        Assertions.assertEquals(HttpStatus.CREATED, result.getStatusCode());
    }

    @Test
    public void testCreateAccountByDtoNomina() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        bankAccountDto.setChannel("BM");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(true);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(JsonNode.class))).thenReturn(true);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDtoNomina);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);
        when(notificationApiService.sendSMS(anyString(), anyString(), any())).thenReturn(true);
        when(notificationApiService.sendEmail(anyString(), anyString(), any())).thenReturn(true);

        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        when(pentagonService.publish(any(), any())).thenReturn(true);

        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));

        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDtoNomina, httpHeaders);
        Assertions.assertEquals(HttpStatus.CREATED, result.getStatusCode());
    }

    @Test
    public void testCreateAccountByDtoNominaDocTypeCC() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("CC");
        bankAccountDto.setChannel("BM");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(true);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(JsonNode.class))).thenReturn(true);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDtoNomina);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);
        when(notificationApiService.sendSMS(anyString(), anyString(), any())).thenReturn(true);
        when(notificationApiService.sendEmail(anyString(), anyString(), any())).thenReturn(true);

        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        when(pentagonService.publish(any(), any())).thenReturn(true);

        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);

        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDtoNomina, httpHeaders);
        Assertions.assertEquals(HttpStatus.CREATED, result.getStatusCode());
    }

    @Test
    public void testCreateAccountByDtoFail() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setBbtipodoc("C");
        createAccountDto.setAanit("nit");
        createAccountDto.setAacodciiu("1");
        bankAccountDto.setChannel("BM");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(true);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(JsonNode.class))).thenReturn(true);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(notificationApiService.sendSMS(anyString(), anyString(), any())).thenReturn(true);
        when(notificationApiService.sendEmail(anyString(), anyString(), any())).thenReturn(true);
        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);
        createAccountResponseDto.setReservation(false);

        when(objectMapper.readValue(anyString(), eq(CreateAccountResponseDto.class))).thenReturn(createAccountResponseDto);

        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.INTERNAL_SERVER_ERROR));

        bankAccountDto.setCodNomina("");
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
        Assertions.assertFalse(Objects.requireNonNull(result.getBody()).getReservation());

        createAccountResponseDto.setReservation(true);
        createAccountResponseDto.setAccountNumber(null);
        when(objectMapper.readValue(anyString(), eq(CreateAccountResponseDto.class))).thenReturn(createAccountResponseDto);

        result = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
        Assertions.assertEquals("Error creating account", Objects.requireNonNull(result.getBody()).getMessage());
    }

    @Test
    public void testGetAccountsByCard() throws Exception {
        ObjectMapper objectMapperMock = new ObjectMapper();
        AcctBasicInfoDto acctBasicInfoDto = new AcctBasicInfoDto();
        acctBasicInfoDto.setAcctId("id");
        acctBasicInfoDto.setAcctType("type");
        acctBasicInfoDto.setAcctSubType("subtype");

        when(productsService.getFilteredAccountsList(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(Collections.singletonList(acctBasicInfoDto));
        when(objectMapper.createObjectNode()).thenReturn(new ObjectMapper().createObjectNode());
        when(objectMapper.valueToTree(any())).thenReturn(objectMapperMock.valueToTree(Collections.singletonList(acctBasicInfoDto)));

        JsonNode accounts = savingsAccountServiceImpl.getAccountsByCard(httpHeaders, "cardNumber");
        Assertions.assertNotNull(accounts);
    }

    @Test
    public void testSaveParticipantInfo() throws Exception {
        ParticipantInfoDto participantInfoDto = new ParticipantInfoDto();
        participantInfoDto.setRequestId(1);
        participantInfoDto.setDate(TimeUtilities.getCurrentTimestampGMTMinus5());
        participantInfoDto.setParticipantId(1);
        participantInfoDto.setActivityCode("010");
        participantInfoDto.setFirstSurname("firstsurname");
        participantInfoDto.setFirstName("firstname");
        participantInfoDto.setSecondName("secondname");
        participantInfoDto.setSecondSurname("secondsurname");
        participantInfoDto.setAddress("address");
        participantInfoDto.setSex("M");
        participantInfoDto.setEmail("email");
        participantInfoDto.setIncome("4000000");
        participantInfoDto.setOccupation("occupation");
        participantInfoDto.setPhone("3131323232");
        participantInfoDto.setOutcome("1000000");

        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(participantInfoDto));
        when(participantInfoRepository.save(any(ParticipantInfoDto.class))).thenReturn(participantInfoDto);
        when(requestMapper.mapParticipantInfo(any())).thenReturn(participantInfoDto);

        ResponseEntity<String> participant = savingsAccountServiceImpl.saveParticipantInfo(bankAccountDto);
        Assertions.assertNotNull(participant);
    }

    @Test
    public void testSaveParticipantInfoDispatcherApi() throws Exception {
        ParticipantInfoDto participantInfoDto = new ParticipantInfoDto();
        participantInfoDto.setRequestId(1);
        participantInfoDto.setDate(TimeUtilities.getCurrentTimestampGMTMinus5());
        participantInfoDto.setParticipantId(1);
        participantInfoDto.setActivityCode("010");
        participantInfoDto.setFirstSurname("firstsurname");
        participantInfoDto.setFirstName("firstname");
        participantInfoDto.setSecondName("secondname");
        participantInfoDto.setSecondSurname("secondsurname");
        participantInfoDto.setAddress("address");
        participantInfoDto.setSex("M");
        participantInfoDto.setEmail("email");
        participantInfoDto.setIncome("4000000");
        participantInfoDto.setOccupation("occupation");
        participantInfoDto.setPhone("3131323232");
        participantInfoDto.setOutcome("1000000");

        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(participantInfoDto));
        when(participantInfoRepository.save(any(ParticipantInfoDto.class))).thenReturn(participantInfoDto);
        when(requestMapper.mapParticipantInfo(any())).thenReturn(participantInfoDto);

        ResponseEntity<String> participant = savingsAccountServiceImpl.saveParticipantInfo(bankAccountDto, httpHeaders);
        Assertions.assertNotNull(participant);
    }

    @Test
    public void testSaveParticipantInfoFail() throws Exception {
        ParticipantInfoDto participantInfoDto = new ParticipantInfoDto();
        participantInfoDto.setRequestId(1);
        participantInfoDto.setDate(TimeUtilities.getCurrentTimestampGMTMinus5());
        participantInfoDto.setParticipantId(1);
        participantInfoDto.setActivityCode("010");
        participantInfoDto.setFirstSurname("firstsurname");
        participantInfoDto.setFirstName("firstname");
        participantInfoDto.setSecondName("secondname");
        participantInfoDto.setSecondSurname("secondsurname");
        participantInfoDto.setAddress("address");
        participantInfoDto.setSex("M");
        participantInfoDto.setEmail("email");
        participantInfoDto.setIncome("4000000");
        participantInfoDto.setOccupation("occupation");
        participantInfoDto.setPhone("3131323232");
        participantInfoDto.setOutcome("1000000");
        participantInfoDto.setCity("11001");
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(null);
        when(requestMapper.mapParticipantInfo(any())).thenReturn(participantInfoDto);

        ResponseEntity<String> participant = savingsAccountServiceImpl.saveParticipantInfo(bankAccountDto);
        Assertions.assertNotNull(participant);
    }

    private CreateAccountDto getAccountDto() {
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setTxInOffice(false);
        createAccountDto.setBbnumterm(null);
        createAccountDto.setBbtipodoc("C");
        createAccountDto.setAanit("20382332");
        createAccountDto.setLastname("APELLIDOA");
        createAccountDto.setSecondlastname("MINION");
        createAccountDto.setFirstname("NOMBREA");
        createAccountDto.setMiddlename("NOMBREB");
        createAccountDto.setBbtitularidad(null);
        createAccountDto.setBbcodceo(null);
        createAccountDto.setProductid(null);
        createAccountDto.setBbcodctanom("");
        createAccountDto.setBirthdate("1970-06-14");
        createAccountDto.setSex("M");
        createAccountDto.setAacodciiu("0010");
        createAccountDto.setBbtiporetencion(null);
        createAccountDto.setBbenvioextracto(null);
        createAccountDto.setBbcodoficinahs(null);
        createAccountDto.setBbcodvendedor("");
        createAccountDto.setBbcodofi("0000");
        createAccountDto.setCourier(null);
        createAccountDto.setDeliveryAddress("Calle 36 # 7 - 47");
        createAccountDto.setFatca("");
        createAccountDto.setNewClient(false);
        createAccountDto.setNewCard(0);
        createAccountDto.setGmf(1);
        createAccountDto.setPostalAddress("11001");
        createAccountDto.setEmail("alope24@bancodebogota.com.co");
        createAccountDto.setCellphone("3133703370");
        createAccountDto.setMonthlyIncome("");
        createAccountDto.setCityCode("11001000");
        createAccountDto.setPreferentialCustomer(false);
        createAccountDto.setNeighborhood("Chapinero");

        AddressDto addressDto = new AddressDto();
        addressDto.setAddress1("Calle 36 7 47");
        addressDto.setAddress11("piso 2");
        createAccountDto.setA1(addressDto);

        return createAccountDto;
    }

    @Test
    public void testSaveSessionRedis() throws Exception {
        String jsonData = """
                {
                \t"productId":1,
                \t"client":0,
                \t"channelId":"OFICINA",
                \t"identityNumber":"1234",
                \t\t"officeCode":"0000",
                \t\t"identityType":"C",
                \t\t"accessType":"5",
                \t"mediumType":"1",
                \t"authTypeId":2,
                \t"participant": {
                \t\t"identificationType":"C",
                \t\t"identificationNumber":"1023455455"
                \t},
                \t"locationInfo": {
                \t\t"officeCode":"0000",
                \t\t"latitude":-74.343434,
                \t\t"longitude":43.33444,
                \t\t"ip":"192.168.5.46"
                \t},
                \t"sourceTeamId":2,
                \t"utmInfo": {
                \t\t"source":"source",
                \t\t"medium":"medium",
                \t\t"campaign":"campaign"
                \t},
                \t"customOtp":1
                }""";
        ObjectMapper mapper = new ObjectMapper();
        JsonNode data = mapper.readTree(jsonData);

        ParticipantDto participantDto = new ParticipantDto();
        participantDto.setId(1);
        participantDto.setIdentificationType("C");
        participantDto.setIdentificationNumber("1032455455");

        RequestDto requestDto = new RequestDto();
        requestDto.setId(1);

        LocationDto locationDto = new LocationDto();
        locationDto.setId(1);
        locationDto.setOfficeCode("0000");
        locationDto.setLatitude(-74.121212);
        locationDto.setLongitude(43.454545);
        locationDto.setIp("192.168.5.43");

        RequestUtmDto requestUtmDto = new RequestUtmDto();
        requestUtmDto.setId(1);
        requestUtmDto.setRequestId(1);
        requestUtmDto.setSource("source");
        requestUtmDto.setMedium("medium");
        requestUtmDto.setCampaign("campaign");
        requestUtmDto.setRefer("refer");

        CreateRequestDto createRequestDto = new CreateRequestDto();
        createRequestDto.setParticipant(participantDto);
        createRequestDto.setLocationInfo(new LocationDto());
        createRequestDto.setChannelId("WEB");
        createRequestDto.setAuthTypeId("1");

        when(objectMapper.convertValue(any(), eq(ParticipantDto.class))).thenReturn(participantDto);
        when(objectMapper.convertValue(any(), eq(CreateRequestDto.class))).thenReturn(createRequestDto);
        when(objectMapper.createObjectNode()).thenReturn(new ObjectMapper().createObjectNode());
        when(requestRepository.save(any(RequestDto.class))).thenReturn(requestDto);
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(participantDto);
        when(participantInfoRepository.save(any(ParticipantInfoDto.class))).thenReturn(null);
        when(objectMapper.convertValue(any(), eq(LocationDto.class))).thenReturn(locationDto);
        when(locationRepository.save(any(LocationDto.class))).thenReturn(locationDto);
        when(requestRepository.saveRequestLocation(any(Long.class), any(Integer.class), any(Date.class))).thenReturn(1);
        when(objectMapper.convertValue(any(), eq(RequestUtmDto.class))).thenReturn(requestUtmDto);
        when(requestRepository.saveRequestUtm(any(Long.class), any(String.class), any(String.class), any(String.class), any(String.class), any(String.class), any(String.class))).thenReturn(1);

        when(requestService.createRequest(any(), anyString(), any())).thenReturn(new AccountRequestRsDto());
        httpHeaders.set("time-alive", "1");
        ResponseEntity<JsonNode> result = savingsAccountServiceImpl.saveSessionRedis(data, httpHeaders);

        Assertions.assertEquals(new ResponseEntity<>(HttpStatus.OK), result);
    }

    @Test
    public void testSaveSessionRedisNoTimeAlive() throws Exception {
        String jsonData = """
                {
                \t"productId":1,
                \t"client":0,
                \t"channelId":"OFICINA",
                \t"identityNumber":"1234",
                \t\t"officeCode":"0000",
                \t\t"identityType":"C",
                \t\t"accessType":"5",
                \t"mediumType":"1",
                \t"authTypeId":2,
                \t"participant": {
                \t\t"identificationType":"C",
                \t\t"identificationNumber":"1023455455"
                \t},
                \t"locationInfo": {
                \t\t"officeCode":"0000",
                \t\t"latitude":-74.343434,
                \t\t"longitude":43.33444,
                \t\t"ip":"192.168.5.46"
                \t},
                \t"sourceTeamId":2,
                \t"utmInfo": {
                \t\t"source":"source",
                \t\t"medium":"medium",
                \t\t"campaign":"campaign"
                \t},
                \t"customOtp":1
                }""";

        String jsonDataAccesToken = """
                {
                \t"productId":1,
                \t"client":0,
                \t\t"accessToken":"accessToken",
                \t"channelId":"OFICINA",
                \t"identityNumber":"1234",
                \t\t"officeCode":"0000",
                \t\t"identityType":"C",
                \t\t"accessType":"5",
                \t"mediumType":"1",
                \t"authTypeId":2,
                \t"participant": {
                \t\t"identificationType":"C",
                \t\t"identificationNumber":"1023455455"
                \t},
                \t"locationInfo": {
                \t\t"officeCode":"0000",
                \t\t"latitude":-74.343434,
                \t\t"longitude":43.33444,
                \t\t"ip":"192.168.5.46"
                \t},
                \t"sourceTeamId":2,
                \t"utmInfo": {
                \t\t"source":"source",
                \t\t"medium":"medium",
                \t\t"campaign":"campaign"
                \t},
                \t"customOtp":1
                }""";
        ObjectMapper mapper = new ObjectMapper();
        JsonNode data = mapper.readTree(jsonData);

        ParticipantDto participantDto = new ParticipantDto();
        participantDto.setId(1);
        participantDto.setIdentificationType("C");
        participantDto.setIdentificationNumber("1032455455");

        RequestDto requestDto = new RequestDto();
        requestDto.setId(1);

        LocationDto locationDto = new LocationDto();
        locationDto.setId(1);
        locationDto.setOfficeCode("0000");
        locationDto.setLatitude(-74.121212);
        locationDto.setLongitude(43.454545);
        locationDto.setIp("192.168.5.43");

        RequestUtmDto requestUtmDto = new RequestUtmDto();
        requestUtmDto.setId(1);
        requestUtmDto.setRequestId(1);
        requestUtmDto.setSource("source");
        requestUtmDto.setMedium("medium");
        requestUtmDto.setCampaign("campaign");
        requestUtmDto.setRefer("refer");

        CreateRequestDto createRequestDto = new CreateRequestDto();
        createRequestDto.setParticipant(participantDto);
        createRequestDto.setLocationInfo(new LocationDto());
        createRequestDto.setChannelId("WEB");
        createRequestDto.setAuthTypeId("1");

        when(objectMapper.convertValue(any(), eq(ParticipantDto.class))).thenReturn(participantDto);
        when(objectMapper.convertValue(any(), eq(CreateRequestDto.class))).thenReturn(createRequestDto);
        when(objectMapper.createObjectNode()).thenReturn(new ObjectMapper().createObjectNode());
        when(requestRepository.save(any(RequestDto.class))).thenReturn(requestDto);
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(participantDto);
        when(participantInfoRepository.save(any(ParticipantInfoDto.class))).thenReturn(null);
        when(objectMapper.convertValue(any(), eq(LocationDto.class))).thenReturn(locationDto);
        when(locationRepository.save(any(LocationDto.class))).thenReturn(locationDto);
        when(requestRepository.saveRequestLocation(any(Long.class), any(Integer.class), any(Date.class))).thenReturn(1);
        when(objectMapper.convertValue(any(), eq(RequestUtmDto.class))).thenReturn(requestUtmDto);
        when(requestRepository.saveRequestUtm(any(Long.class), any(String.class), any(String.class), any(String.class), any(String.class), any(String.class), any(String.class))).thenReturn(1);

        when(requestService.createRequest(any(), anyString(), any())).thenReturn(new AccountRequestRsDto());

        httpHeaders.set("time-alive", "");
        ResponseEntity<JsonNode> result = savingsAccountServiceImpl.saveSessionRedis(data, httpHeaders);

        Assertions.assertEquals(new ResponseEntity<>(HttpStatus.OK), result);
    }

    @Test
    public void testGetSessionRedis() throws Exception {
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), any())).thenReturn(null);

        ResponseEntity<JsonNode> result = savingsAccountServiceImpl.getSessionRedis("1023455455", "authUuid");
        Assertions.assertEquals(HttpStatus.NO_CONTENT, result.getStatusCode());
    }

    @Test
    public void testGetSessionRedis2() throws Exception {
        String jsonData = """
                {
                \t"productId":1,
                \t"client":0,
                \t"channelId":"WEB",
                \t"accessType":5,
                \t"identityType":"C",
                \t\t"requestId":"120",
                \t"identityNumber":"1023455455",
                \t"locationInfo": {
                \t\t"officeCode":"0000",
                \t\t"latitude":-74.343434,
                \t\t"longitude":43.33444,
                \t\t"ip":"192.168.5.46"
                \t},
                \t"sourceTeamId":2,
                \t"utmInfo": {
                \t\t"source":"source",
                \t\t"medium":"medium",
                \t\t"campaign":"campaign"
                \t}
                }""";

        ObjectMapper mapper = new ObjectMapper();
        JsonNode sessionRedis = mapper.readTree(jsonData);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), any())).thenReturn(sessionRedis);
        doNothing().when(requestRepository).updateResumeRequest(anyLong(), anyLong());
        ResponseEntity<JsonNode> result = savingsAccountServiceImpl.getSessionRedis("1234567890", "authUuid");
        Assertions.assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testGetSessionRedisException() throws Exception {

        when(redisApiService.getHash(any(), any(), any(), any(), eq(JsonNode.class)))
                .thenThrow(BdbExceptionFactory.createExcepcion(HttpStatus.NOT_FOUND, "1234567", "Error data not found in RedisAPI"));

        try {
            savingsAccountServiceImpl.getSessionRedis(null, "authUudi");
        } catch (Exception e) {
            Assertions.assertEquals("Error getSessionRedis", e.getMessage());
        }
    }

    @Test
    public void testGetSessionRedisFail() throws Exception {

        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), any())).thenReturn(null);
        when(objectMapper.readValue(anyString(), eq(JsonNode.class))).thenThrow(new ArrayIndexOutOfBoundsException());

        ResponseEntity<JsonNode> result = savingsAccountServiceImpl.getSessionRedis("1234567890", "authUuid");
        Assertions.assertEquals(HttpStatus.NO_CONTENT, result.getStatusCode());
    }

    @Test
    public void testGetAccountLimits() {

        List<AcctLimitsDescDto> acctLimitsDescDtoList = new ArrayList<>();
        acctLimitsDescDtoList.add(new AcctLimitsDescDto("type1", 1, 100f, "networkOwner1"));
        acctLimitsDescDtoList.add(new AcctLimitsDescDto("type2", 2, 100f, "networkOwner2"));
        acctLimitsDescDtoList.add(new AcctLimitsDescDto("type3", 3, 100f, "networkOwner3"));

        ObjectMapper mapper = new ObjectMapper();
        JsonNode acctLimitsDescDtoListJson = mapper.valueToTree(acctLimitsDescDtoList);

        when(objectMapper.convertValue(any(), eq(JsonNode.class))).thenReturn(acctLimitsDescDtoListJson);

        ResponseEntity<JsonNode> result = savingsAccountServiceImpl.getAccountLimits();
        Assertions.assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testCatchManageCustomer() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        bankAccountDto.setChannel("BM");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(any(), any(), any(), any()))
                .thenThrow(BdbExceptionFactory.createExcepcion(HttpStatus.NOT_FOUND, "1234567", "Error getCustomerInfoCustomerOpenApi"));

        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        try {
            savingsAccountServiceImpl.createAccountByDto(bankAccountDtoNomina, httpHeaders);
        } catch (Exception e) {
            Assertions.assertEquals("djdjf", e.getMessage());
        }

    }

    @Test
    public void testCreateAccountByDtoNominaCustomOtp() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        bankAccountDto.setChannel("BM");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(true);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(JsonNode.class))).thenReturn(true);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDtoNomina);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        bankAccountDtoNomina.setCustomOtpAuth(true);
        bankAccountDtoNomina.setTxInWeb(true);
        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDtoNomina, httpHeaders);
        Assertions.assertEquals(HttpStatus.CREATED, result.getStatusCode());
    }

    @Test
    public void testSetAccountHierarchy() throws Exception {
        when(requestMapper.mapAccountHierarchy(any())).thenReturn(null);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(String.class))).thenReturn(true);
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        doNothing().when(requestService).saveRequestEvent(anyLong(), any(), anyString());

        ResponseEntity<JsonNode> accountHierarchy = savingsAccountServiceImpl.setAccountHierarchy(new AccountHierarchyReqDto(), httpHeaders);
        Assertions.assertNotNull(accountHierarchy);
    }

    @Test
    public void testSetAccountHierarchyFail() {
        when(requestMapper.mapAccountHierarchy(any())).thenReturn(null);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(String.class))).thenReturn(true);
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
        doNothing().when(requestService).saveRequestEvent(anyLong(), any(), anyString());

        try {
            savingsAccountServiceImpl.setAccountHierarchy(new AccountHierarchyReqDto(), httpHeaders);
        } catch (AbsBdbServiceException e) {
            Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getCode());
        }
    }

    @Test
    public void testGetPayloadInfo() throws Exception {
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), any())).thenReturn(new ObjectMapper().createObjectNode());

        ResponseEntity<JsonNode> payloadInfo = savingsAccountServiceImpl.getPayloadInfo("identityNumber", "authUuid");
        Assertions.assertNotNull(payloadInfo);
    }

    @Test
    public void testGetPayloadInfoNotFound() throws Exception {
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), any())).thenReturn(null);

        try {
            savingsAccountServiceImpl.getPayloadInfo("identityNumber", "authUuid");
        } catch (AbsBdbServiceException e) {
            Assertions.assertEquals("Payload info not found", e.getMessage());
        }
    }

    @Test
    public void testCreateAccountFailData() throws Exception {

        String jsonData = "{\"requestId\":\"123\",\"officeCode\":\"0449\",\"appVersion\":\"0.0.38\",\"userIp\":\"192.168.4.175\",\"successCreateAccount\":\"false\",\"identityType\":\"C\",\"officeCodeSeller\":null,\"identityNumber\":\"29326111\",\"accessType\":\"5\",\"customerValidToUpdateInfoSafe\":false,\"channel\":\"WEB\",\"prospect\":false,\"currentFlow\":\"accountOpening\",\"accountType\":\"Libreahorro\",\"codNomina\":null,\"authMethod\":\"validateCustomOtp\",\"customOtpAuth\":true,\"controlFlag\":false,\"channelFromLauncher\":false,\"utmCampaign\":null,\"allyUuid\":null,\"customerExistsInCrm\":false,\"clientWithDebitCards\":false,\"segcomercial\":\"620\",\"apiCity\":\"Bogotá\",\"redirectRegulation\":\"/account-summary\",\"txInOffice\":false,\"firstName\":\"Andres\",\"middleName\":\"David\",\"lastName\":\"Guzman\",\"secondLastName\":\"Soto\",\"birthDate\":\"10/10/1990\",\"bornCity\":\"BOGOTA, D.C. - BOGOTA D.C.- CUND.\",\"bornCityId\":\"11001000\",\"expeditionDate\":\"10/10/2008\",\"expeditionCity\":\"BOGOTA, D.C. - BOGOTA D.C.- CUND.\",\"expeditionCityId\":\"11001000\",\"gender\":\"M\",\"cellphone\":\"3008214021\",\"email\":\"correo@correo.com\",\"address1Dto\":{\"typeRoad1\":\"AU\",\"typeRoad1Number\":\"12\",\"typeRoad2\":\"\",\"typeRoad2Number\":\"12-12\",\"addressDetail\":\"12 12\"},\"livingCity\":\"BOGOTA, D.C. - BOGOTA D.C.- CUND.\",\"neighborhood\":\"\",\"crmAddress\":\"AU;12;;12-12;12 12;;;;;;COL;11;11001000;12;\",\"livingCityId\":\"11001000\",\"officeAddress\":\"CARRERA 7 CALLE 67 \",\"officeAccountName\":\"CARRERA 7 CALLE 67\",\"setOffice\":true,\"occupation\":\"Otra\",\"occupationId\":7,\"jobActivityId\":\"0010\",\"checkPensioner\":false,\"monthlyIncome\":\"12\",\"monthlyOutcome\":\"12\",\"totalAssets\":\"13\",\"totalDebts\":\"13\",\"productId\":\"068AH\",\"accountType\":\"Econocuenta\",\"deliveryAddress\":\"BOGOTA, D.C. - BOGOTA D.C.- CUND. - Autopista 12 #  12-1212 12\",\"address\":\"Autopista 12 #  12-12-12 12\",\"cityCodeDelivery\":\"11001000\",\"deliverySelected\":\"home\",\"deliveryMethod\":\"home\",\"ageInsurance\":28,\"hasToDeclareForeignTaxes\":false}";
        JsonNode data = objectMapper.readTree(jsonData);

        try {
            savingsAccountServiceImpl.createAccountByUuid(data, httpHeaders);
        } catch (AbsBdbServiceException e) {
            Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getCode());
        }
    }

    @Test
    public void testCreateAccountByDtonotTxtInWeb() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        bankAccountDto.setTxInWeb(false);
        bankAccountDto.setChannel("BM");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(true);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(JsonNode.class))).thenReturn(true);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(notificationApiService.sendSMS(anyString(), anyString(), any())).thenReturn(true);
        when(notificationApiService.sendEmail(anyString(), anyString(), any())).thenReturn(true);
        when(requestRepository.findById(anyLong())).thenReturn(new RequestDto());
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertEquals(HttpStatus.CREATED, result.getStatusCode());
    }

    @Test
    public void testCreateAccountByDtoTxtInWebElse() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        bankAccountDto.setTxInWeb(true);
        bankAccountDto.setDeliveryMethod("office");
        bankAccountDto.setChannel("MFZ");
        ((ObjectNode) dispatcherDto.getSpecificProductInfo()).put("ceoCode", "1234");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(true);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(JsonNode.class))).thenReturn(true);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(notificationApiService.sendSMS(anyString(), anyString(), any())).thenReturn(true);
        when(notificationApiService.sendEmail(anyString(), anyString(), any())).thenReturn(true);
        RequestDto requestDto = new RequestDto();
        requestDto.setChannelId(101);
        when(requestRepository.findById(anyLong())).thenReturn(requestDto);
        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertEquals(HttpStatus.CREATED, result.getStatusCode());
    }

    @Test
    public void testCreateAccountByDtoTxtInWebElseWithCeoCode() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        bankAccountDto.setTxInWeb(true);
        bankAccountDto.setDeliveryMethod("office");
        bankAccountDto.setChannel("MFZ");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(true);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(JsonNode.class))).thenReturn(true);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(notificationApiService.sendSMS(anyString(), anyString(), any())).thenReturn(true);
        when(notificationApiService.sendEmail(anyString(), anyString(), any())).thenReturn(true);
        RequestDto requestDto = new RequestDto();
        requestDto.setChannelId(101);
        ((ObjectNode) dispatcherDto.getSpecificProductInfo()).put("ceoCode", "1234");
        when(requestRepository.findById(anyLong())).thenReturn(requestDto);
        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertEquals(HttpStatus.CREATED, result.getStatusCode());
    }

    @Test
    public void testCreateAccountByDtonotTxtInWebElseNotOffice() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        bankAccountDto.setChannel("BM");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        bankAccountDto.setTxInWeb(true);
        bankAccountDto.setDeliveryMethod("home");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(true);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(JsonNode.class))).thenReturn(true);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(notificationApiService.sendSMS(anyString(), anyString(), any())).thenReturn(true);
        when(notificationApiService.sendEmail(anyString(), anyString(), any())).thenReturn(true);
        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(requestRepository.findById(anyLong())).thenReturn(new RequestDto());
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertEquals(HttpStatus.CREATED, result.getStatusCode());
    }

    @Test
    public void testParticipantInfoError() throws Exception {
        String jsonString = "{\"accountNumber\":\"1234\"}";
        String jsonData = "{\"requestId\":\"123\",\"uuid\":\"123\",\"officeCode\":\"0449\",\"appVersion\":\"0.0.38\",\"userIp\":\"192.168.4.175\",\"successCreateAccount\":\"false\",\"identityType\":\"C\",\"officeCodeSeller\":null,\"identityNumber\":\"29326111\",\"accessType\":\"5\",\"customerValidToUpdateInfoSafe\":false,\"channel\":\"WEB\",\"prospect\":false,\"currentFlow\":\"accountOpening\",\"accountType\":\"Libreahorro\",\"productId\":\"061AH\",\"codNomina\":null,\"authMethod\":\"validateCustomOtp\",\"customOtpAuth\":true,\"controlFlag\":false,\"channelFromLauncher\":false,\"utmCampaign\":null,\"allyUuid\":null,\"customerExistsInCrm\":false,\"clientWithDebitCards\":false,\"segcomercial\":\"620\",\"apiCity\":\"Bogotá\",\"redirectRegulation\":\"/account-summary\",\"txInOffice\":false,\"firstName\":\"Andres\",\"middleName\":\"David\",\"lastName\":\"Guzman\",\"secondLastName\":\"Soto\",\"birthDate\":\"10/10/1990\",\"bornCity\":\"BOGOTA, D.C. - BOGOTA D.C.- CUND.\",\"bornCityId\":\"11001000\",\"expeditionDate\":\"10/10/2008\",\"expeditionCity\":\"BOGOTA, D.C. - BOGOTA D.C.- CUND.\",\"expeditionCityId\":\"11001000\",\"gender\":\"M\",\"cellphone\":\"3008214021\",\"email\":\"correo@correo.com\",\"address1Dto\":{\"typeRoad1\":\"AU\",\"typeRoad1Number\":\"12\",\"typeRoad2\":\"\",\"typeRoad2Number\":\"12-12\",\"addressDetail\":\"12 12\"},\"livingCity\":\"BOGOTA, D.C. - BOGOTA D.C.- CUND.\",\"neighborhood\":\"\",\"crmAddress\":\"AU;12;;12-12;12 12;;;;;;COL;11;11001000;12;\",\"livingCityId\":\"11001000\",\"officeAddress\":\"CARRERA 7 CALLE 67 \",\"officeAccountName\":\"CARRERA 7 CALLE 67\",\"setOffice\":true,\"occupation\":\"Otra\",\"occupationId\":7,\"jobActivityId\":\"0010\",\"checkPensioner\":false,\"monthlyIncome\":\"12\",\"monthlyOutcome\":\"12\",\"totalAssets\":\"13\",\"totalDebts\":\"13\",\"productId\":\"\",\"accountType\":\"Econocuenta\",\"deliveryAddress\":\"BOGOTA, D.C. - BOGOTA D.C.- CUND. - Autopista 12 #  12-1212 12\",\"address\":\"Autopista 12 #  12-12-12 12\",\"cityCodeDelivery\":\"11001000\",\"deliverySelected\":\"home\",\"deliveryMethod\":\"home\",\"ageInsurance\":28,\"hasToDeclareForeignTaxes\":false}";

        ObjectMapper mapper = new ObjectMapper();
        JsonNode string = mapper.readTree(jsonString);
        JsonNode data = mapper.readTree(jsonData);

        when(objectMapper.valueToTree(any())).thenReturn(string);
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));

        try {
            savingsAccountServiceImpl.createAccountByUuid(data, httpHeaders);
        } catch (AbsBdbServiceException e) {
            Assertions.assertEquals("data.ProductId is null ", e.getMessage());
        }
    }

    @Test
    public void testGetParticipantInfoNull() throws Exception {
        String jsonString = "{\"accountNumber\":\"1234\"}";
        String jsonData = "{\"requestId\":\"123\",\"uuid\":\"123\",\"officeCode\":\"0449\",\"appVersion\":\"0.0.38\",\"userIp\":\"192.168.4.175\",\"successCreateAccount\":\"false\",\"identityType\":\"C\",\"officeCodeSeller\":null,\"identityNumber\":\"29326111\",\"accessType\":\"5\",\"customerValidToUpdateInfoSafe\":false,\"channel\":\"WEB\",\"prospect\":false,\"currentFlow\":\"accountOpening\",\"accountType\":\"Libreahorro\",\"productId\":\"null\",\"codNomina\":null,\"authMethod\":\"validateCustomOtp\",\"customOtpAuth\":true,\"controlFlag\":false,\"channelFromLauncher\":false,\"utmCampaign\":null,\"allyUuid\":null,\"customerExistsInCrm\":false,\"clientWithDebitCards\":false,\"segcomercial\":\"620\",\"apiCity\":\"Bogotá\",\"redirectRegulation\":\"/account-summary\",\"txInOffice\":false,\"firstName\":\"Andres\",\"middleName\":\"David\",\"lastName\":\"Guzman\",\"secondLastName\":\"Soto\",\"birthDate\":\"10/10/1990\",\"bornCity\":\"BOGOTA, D.C. - BOGOTA D.C.- CUND.\",\"bornCityId\":\"11001000\",\"expeditionDate\":\"10/10/2008\",\"expeditionCity\":\"BOGOTA, D.C. - BOGOTA D.C.- CUND.\",\"expeditionCityId\":\"11001000\",\"gender\":\"M\",\"cellphone\":\"3008214021\",\"email\":\"correo@correo.com\",\"address1Dto\":{\"typeRoad1\":\"AU\",\"typeRoad1Number\":\"12\",\"typeRoad2\":\"\",\"typeRoad2Number\":\"12-12\",\"addressDetail\":\"12 12\"},\"livingCity\":\"BOGOTA, D.C. - BOGOTA D.C.- CUND.\",\"neighborhood\":\"\",\"crmAddress\":\"AU;12;;12-12;12 12;;;;;;COL;11;11001000;12;\",\"livingCityId\":\"11001000\",\"officeAddress\":\"CARRERA 7 CALLE 67 \",\"officeAccountName\":\"CARRERA 7 CALLE 67\",\"setOffice\":true,\"occupation\":\"Otra\",\"occupationId\":7,\"jobActivityId\":\"0010\",\"checkPensioner\":false,\"monthlyIncome\":\"12\",\"monthlyOutcome\":\"12\",\"totalAssets\":\"13\",\"totalDebts\":\"13\",\"accountType\":\"Econocuenta\",\"deliveryAddress\":\"BOGOTA, D.C. - BOGOTA D.C.- CUND. - Autopista 12 #  12-1212 12\",\"address\":\"Autopista 12 #  12-12-12 12\",\"cityCodeDelivery\":\"11001000\",\"deliverySelected\":\"home\",\"deliveryMethod\":\"home\",\"ageInsurance\":28,\"hasToDeclareForeignTaxes\":false}";

        ObjectMapper mapper = new ObjectMapper();
        JsonNode string = mapper.readTree(jsonString);
        JsonNode data = mapper.readTree(jsonData);

        when(objectMapper.valueToTree(any())).thenReturn(string);
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));

        try {
            savingsAccountServiceImpl.createAccountByUuid(data, httpHeaders);
        } catch (AbsBdbServiceException e) {
            Assertions.assertEquals("Error consumiendo el servicio getParticipantInfo", e.getMessage());
        }
    }

    @Test
    public void testGetCustomerInfoNull() throws Exception {
        String jsonString = "{\"accountNumber\":\"1234\"}";
        String jsonData = "{\"requestId\":\"123\",\"uuid\":\"123\",\"officeCode\":\"0449\",\"appVersion\":\"0.0.38\",\"userIp\":\"192.168.4.175\",\"successCreateAccount\":\"false\",\"identityType\":\"C\",\"officeCodeSeller\":null,\"identityNumber\":\"29326111\",\"accessType\":\"5\",\"customerValidToUpdateInfoSafe\":false,\"channel\":\"WEB\",\"prospect\":false,\"currentFlow\":\"accountOpening\",\"accountType\":\"Libreahorro\",\"productId\":\"null\",\"codNomina\":null,\"authMethod\":\"validateCustomOtp\",\"customOtpAuth\":true,\"controlFlag\":false,\"channelFromLauncher\":false,\"utmCampaign\":null,\"allyUuid\":null,\"customerExistsInCrm\":false,\"clientWithDebitCards\":false,\"segcomercial\":\"620\",\"apiCity\":\"Bogotá\",\"redirectRegulation\":\"/account-summary\",\"txInOffice\":false,\"firstName\":\"Andres\",\"middleName\":\"David\",\"lastName\":\"Guzman\",\"secondLastName\":\"Soto\",\"birthDate\":\"10/10/1990\",\"bornCity\":\"BOGOTA, D.C. - BOGOTA D.C.- CUND.\",\"bornCityId\":\"11001000\",\"expeditionDate\":\"10/10/2008\",\"expeditionCity\":\"BOGOTA, D.C. - BOGOTA D.C.- CUND.\",\"expeditionCityId\":\"11001000\",\"gender\":\"M\",\"cellphone\":\"3008214021\",\"email\":\"correo@correo.com\",\"address1Dto\":{\"typeRoad1\":\"AU\",\"typeRoad1Number\":\"12\",\"typeRoad2\":\"\",\"typeRoad2Number\":\"12-12\",\"addressDetail\":\"12 12\"},\"livingCity\":\"BOGOTA, D.C. - BOGOTA D.C.- CUND.\",\"neighborhood\":\"\",\"crmAddress\":\"AU;12;;12-12;12 12;;;;;;COL;11;11001000;12;\",\"livingCityId\":\"11001000\",\"officeAddress\":\"CARRERA 7 CALLE 67 \",\"officeAccountName\":\"CARRERA 7 CALLE 67\",\"setOffice\":true,\"occupation\":\"Otra\",\"occupationId\":7,\"jobActivityId\":\"0010\",\"checkPensioner\":false,\"monthlyIncome\":\"12\",\"monthlyOutcome\":\"12\",\"totalAssets\":\"13\",\"totalDebts\":\"13\",\"accountType\":\"Econocuenta\",\"deliveryAddress\":\"BOGOTA, D.C. - BOGOTA D.C.- CUND. - Autopista 12 #  12-1212 12\",\"address\":\"Autopista 12 #  12-12-12 12\",\"cityCodeDelivery\":\"11001000\",\"deliverySelected\":\"home\",\"deliveryMethod\":\"home\",\"ageInsurance\":28,\"hasToDeclareForeignTaxes\":false}";

        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        createAccountDto.setSourceTeamId(1);

        ObjectMapper mapper = new ObjectMapper();
        JsonNode string = mapper.readTree(jsonString);
        JsonNode data = mapper.readTree(jsonData);

        when(participantService.getParticipantInfo(any())).thenReturn(createAccountDto);
        when(channelRepository.findChannelIdByDescription(anyString())).thenReturn(channelDto);
        when(requestRepository.save(any(RequestDto.class))).thenReturn(new RequestDto());

        when(objectMapper.valueToTree(any())).thenReturn(string);
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));
        try {
            savingsAccountServiceImpl.createAccountByUuid(data, httpHeaders);
        } catch (AbsBdbServiceException e) {
            Assertions.assertEquals("Error consumiendo el servicio getCustomerInfo CRM", e.getMessage());
        }
    }

    @Test
    public void testCustomerExistInCRM() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");
        bankAccountDto.setChannel("WEB");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(true);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(JsonNode.class))).thenReturn(true);
        when(requestMapper.mapCreateAccountDtoRequest(any(), anyString())).thenReturn(createAccountDto);

        when(requestMapper.mapParticipantInfo(any())).thenReturn(new ParticipantInfoDto());
        when(requestMapper.mapDomicileInfo(any())).thenReturn(new DomicileInfoDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(savingTypeDto);
        when(requestMapper.mapSavingCondition(any(), anyInt(), any())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(any(Long.class), any(Integer.class))).thenReturn(new RequestOperationDto());
        when(requestMapper.mapRequestSeller(any(String.class), any(String.class), any(Long.class))).thenReturn(requestSellerDto);
        when(requestMapper.mapRequestPayrollAccount(any(String.class), any(String.class), any(Long.class), any(String.class))).thenReturn(requestPayrollAccountDto);
        when(requestMapper.mapRequestArrangement(any())).thenReturn(Collections.singletonList(new RequestArrangementDto()));
        when(participantRepository.findByIdentificationNumber(any())).thenReturn(null);
        when(participantInfoRepository.findByRequestId(any(Long.class))).thenReturn(Collections.singletonList(new ParticipantInfoDto()));
        when(participantRepository.save(any(ParticipantDto.class))).thenReturn(new ParticipantDto());
        when(conditionRepository.save(any(ConditionDto.class))).thenReturn(new ConditionDto());
        when(accountLogRepository.findByAccountNumber(any(String.class))).thenReturn(accountLog);
        when(savingConditionRepository.save(any(SavingConditionDto.class))).thenReturn(new SavingConditionDto());
        when(requestMapper.mapCreateBankAccountDto(any(), any(), any())).thenReturn(bankAccountDto);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(accountLimitMapper.createAccountLimitDto(any(), any())).thenReturn(null);
        when(notificationApiService.sendSMS(anyString(), anyString(), any())).thenReturn(true);
        when(notificationApiService.sendEmail(anyString(), anyString(), any())).thenReturn(true);
        when(requestRepository.findById(anyLong())).thenReturn(new RequestDto());
        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK));
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertEquals(HttpStatus.CREATED, result.getStatusCode());
    }

    @Test
    public void testCustomerInBlackList() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        responseBlacklist.setCanContinue(false);
        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        bankAccountDto.setProspect(false);
        bankAccountDto.setCustomerExistsInCrm(false);
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertEquals(HttpStatus.LOCKED, result.getStatusCode());
    }

    @Test
    public void testCustomerCreated() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        CreateAccountDto createAccountDto = new CreateAccountDto();
        createAccountDto.setAacodciiu("1");
        createAccountDto.setAanit("nit");
        createAccountDto.setBbtipodoc("C");

        AccountLog accountLog = new AccountLog();
        accountLog.setId("1234");

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(customerServiceImpl.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        when(customerManagement.createCustomer(any(), any(HttpHeaders.class))).thenReturn(false);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);

        ResponseEntity<CreateAccountResponseDto> result = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, result.getStatusCode());
    }

    @Test
    public void testCreateAccountByDtoFailBlacklist() throws Exception {
        httpHeaders.add("X-RqUID", "123456");
        bankAccountDto.setProductId("068AH");
        responseBlacklist.setCanContinue(false);

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);

        ResponseEntity<CreateAccountResponseDto> response = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertTrue(response.getStatusCode().isError());
    }

    @Test
    public void testCreateAccountWithoutCeoCodeByMFZ() throws AbsBdbServiceException {
        bankAccountDto.setChannel(EChannel.MFZ.getDescription());
        ((ObjectNode) dispatcherDto.getSpecificProductInfo()).put("ceoCode", "");
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);

        ResponseEntity<CreateAccountResponseDto> response = savingsAccountServiceImpl.createAccountByDto(bankAccountDto, httpHeaders);
        Assertions.assertTrue(response.getStatusCode().isError());
    }

    @Test
    public void testSaveModel() {
        List<String> request = new ArrayList<>();
        request.add(0, "0123");
        request.add(1, "09876543");
        request.add(2, "061AH");
        request.add(3, "123456789");
        request.add(4, "987654321");
        List<List<String>> requests = new ArrayList<>();
        requests.add(request);

        when(requestRepository.findRequestDtoByIdentityNumber(anyString())).thenReturn(new RequestDto());
        when(savingTypeRepository.findSavingTypeDtoByCode(anyString())).thenReturn(new SavingTypeDto());
        when(requestMapper.mapSavingCondition(any(BankAccountDto.class), anyInt(), anyBoolean())).thenReturn(new SavingConditionDto());
        when(requestMapper.mapRequestOperation(anyLong(), anyInt())).thenReturn(new RequestOperationDto());

        savingsAccountServiceImpl.saveModel(requests);
        Assertions.assertFalse(requests.isEmpty());
    }
}
