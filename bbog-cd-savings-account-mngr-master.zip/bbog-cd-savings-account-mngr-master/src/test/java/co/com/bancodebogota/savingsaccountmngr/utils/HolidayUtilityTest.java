package co.com.bancodebogota.savingsaccountmngr.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class HolidayUtilityTest {

    @Test
    public void testGetHolidays() {
        HolidayUtility holidayUtility = new HolidayUtility(2025);
        HolidayUtility holidayUtilityCurrent = new HolidayUtility();
        System.out.println(holidayUtility.getHolidays());
        Assertions.assertEquals(19, holidayUtility.getHolidays().size());
        Assertions.assertEquals(19, holidayUtilityCurrent.getHolidays().size());
    }
}
