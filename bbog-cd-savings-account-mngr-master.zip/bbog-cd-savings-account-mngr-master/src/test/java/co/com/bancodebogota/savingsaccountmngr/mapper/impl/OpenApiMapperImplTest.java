package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.dto.account.AccountData;
import co.com.bancodebogota.dto.account.BankInfoType;
import co.com.bancodebogota.dto.customer.CustomerManagementRs;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.openapi.AccountDto;
import co.com.bancodebogota.dto.openapi.FatcaDto;
import co.com.bancodebogota.enums.EAccount;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.model.entities.SourceTeamDto;
import co.com.bancodebogota.model.repositories.SourceTeamRepository;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;

import java.io.InputStream;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

public class OpenApiMapperImplTest {

    @Mock
    private SourceTeamRepository sourceTeamRepository;
    @InjectMocks
    private OpenApiMapperImpl openApiMapper;

    private final ObjectMapper testMapper = new ObjectMapper();
    private final AccountDto account = new AccountDto();
    private final HttpHeaders headers = new HttpHeaders();
    private CustomerManagementRs customerManagementRs = new CustomerManagementRs();
    private final FatcaDto fatcaDto = new FatcaDto();

    @BeforeEach
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);

        headers.set("x-ipaddr", "0.0.0.1");
        headers.set("x-custtype", "ACTIVE");
        headers.set("x-channel", "Web");
        headers.set("x-custidenttype", "CC");
        headers.set("x-custidentnum", "123456789");
        headers.set("x-officecode", "0000");
        headers.set("x-name", "Seguros");
        headers.set("x-digrequest", "12345");
        headers.set("x-rquid", "12345");

        account.setSeller("seller");
        account.setCeoCode("ceoCode");
        account.setDispersionCode("dispersionCode");
        account.setProductCode("010AH");
        account.setOfficeCode("0000");

        fatcaDto.setCountry("USA");
        fatcaDto.setTin("123456");

        testMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        InputStream inputStream = getClass().getResourceAsStream("/customerOpenApi.json");
        customerManagementRs = testMapper.readValue(inputStream, CustomerManagementRs.class);
    }

    @Test
    public void mapDispatcher() throws AbsBdbServiceException {
        DispatcherDto dispatcherDto = openApiMapper.mapDispatcher(headers, account.getOfficeCode());
        Assertions.assertNotNull(dispatcherDto);
    }

    @Test
    public void mapDispatcherFail() {
        headers.remove("x-ipaddr");

        try {
            openApiMapper.mapDispatcher(headers, account.getOfficeCode());
        } catch (AbsBdbServiceException exception) {
            Assertions.assertEquals(HttpStatus.BAD_REQUEST, exception.getCode());
        }
    }

    @Test
    public void getSourceTeam() throws AbsBdbServiceException {
        when(sourceTeamRepository.findByApiName(anyString())).thenReturn(new SourceTeamDto());

        Integer response = openApiMapper.getSourceTeam("Libranzas");
        Assertions.assertNotNull(response);
    }

    @Test
    public void getSourceTeamFail() {
        when(sourceTeamRepository.findByDescription(anyString())).thenReturn(null);

        try {
            openApiMapper.getSourceTeam("");
        } catch (AbsBdbServiceException exception) {
            Assertions.assertEquals(HttpStatus.NOT_FOUND, exception.getCode());
        }
    }

    @Test
    public void testMapAccountDataWithoutFatca() {
        AccountData response = openApiMapper.mapAccountData(123L, account, customerManagementRs, headers);
        Assertions.assertEquals("test@bancodebogota.com.co", response.getOpeningAccount().getEmailAddr());
        Assertions.assertEquals("0010", response.getOpeningAccount().getEconomicActivity());
    }

    @Test
    public void testMapAccountDataWithOneFatca() {
        account.setFatca(List.of(fatcaDto));

        AccountData response = openApiMapper.mapAccountData(123L, account, customerManagementRs, headers);
        Assertions.assertNotNull(response.getFatca().getFiscalResidence1());
    }

    @Test
    public void testMapAccountDataWithTwoFatca() {
        account.setFatca(List.of(fatcaDto, fatcaDto));

        AccountData response = openApiMapper.mapAccountData(123L, account, customerManagementRs, headers);
        Assertions.assertNotNull(response.getFatca().getFiscalResidence2());
    }

    @Test
    public void testMapAccountDataWhenProductIdIsCurrentCoba() {
        BankInfoType bankInfoType = new BankInfoType();
        bankInfoType.setCobaOfficeCode("10");
        account.setProductCode(EAccount.CORRIENTE_COBA.getCode());
        account.setBankInfo(bankInfoType);
        account.setOverdraftDays(10);
        AccountData response = openApiMapper.mapAccountData(123L, account, customerManagementRs, headers);
        Assertions.assertEquals(response.getOpeningAccount().getOverdraftDays(), 10);
    }
}
