package co.com.bancodebogota.savingsaccountmngr.service.monitorplus;

import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.dto.monitorplus.MonitorAccountCreateDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.io.InputStream;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

public class MonitorServiceImplTest {

    @Mock
    private RestExchangeV2 restExchange;
    @InjectMocks
    private MonitorServiceImpl monitorServiceImpl;

    private final BankAccountDto bankAccountDto = new BankAccountDto();

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        ReflectionTestUtils.setField(monitorServiceImpl, "securityMonitoringApiEndpoint", "localhost");
        ReflectionTestUtils.setField(monitorServiceImpl, "tvsApiKey", "apiKey");

        bankAccountDto.setGender("M");
        bankAccountDto.setAddressForCRM("2");
        bankAccountDto.setLivingCityId("3");
        bankAccountDto.setOriginIp("4");
        bankAccountDto.setAccountType("5");
        bankAccountDto.setAssetsDeclaration(true);
        bankAccountDto.setBirthDate("7");
        bankAccountDto.setBornCityId(8);
        bankAccountDto.setCellphone("9");
        bankAccountDto.setCheckGmf(true);
        bankAccountDto.setCityCompanyId(11);
        bankAccountDto.setClientWithDebitCards(true);
        bankAccountDto.setCodNomina("13");
        bankAccountDto.setCustomerExistsInCrm(true);
        bankAccountDto.setDeliveryAddress("15");
        bankAccountDto.setEmail("16");
        bankAccountDto.setEmployeeAddress("17");
        bankAccountDto.setEmployeeName("18");
        bankAccountDto.setEmployeeNit("19");
        bankAccountDto.setEmployeePhone("20");
        bankAccountDto.setEmployeeState("21");
        bankAccountDto.setExpeditionCityId(21);
        bankAccountDto.setExpeditionDate("22");
        bankAccountDto.setFirstName("23");
        bankAccountDto.setFatca("24");
        bankAccountDto.setGreenCard(true);
        bankAccountDto.setHasAuthorizedRiskCheck(true);
        bankAccountDto.setIdentityNumber("27");
        bankAccountDto.setJobActivityId("28");
        bankAccountDto.setLastName("29");
        bankAccountDto.setMiddleName("30");
        bankAccountDto.setMonthlyIncome("31");
        bankAccountDto.setMonthlyOutcome("32");
        bankAccountDto.setNameCompany("33");
        bankAccountDto.setOccupationId(34);
        bankAccountDto.setOfficeCode("35");
        bankAccountDto.setOfficeCodeSeller("36");
        bankAccountDto.setProductId("37");
        bankAccountDto.setProductId("38");
        bankAccountDto.setPostalAddress("39");
        bankAccountDto.setSecondLastName("40");
        bankAccountDto.setTotalAssets("41");
        bankAccountDto.setTotalDebts("42");
        bankAccountDto.setTxInWeb(true);
        bankAccountDto.setUsaIncome(true);
        bankAccountDto.setUsaLongTimeVisitor(true);
        bankAccountDto.setUserAgent("Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:47.0) Gecko/20100101 Firefox/47.0");
        bankAccountDto.setValidAddressToCRM(true);
        bankAccountDto.setChannelToMonitor("");
        bankAccountDto.setChannel("");
    }

    @Test
    public void testSendAccountCreateFail() {
        try {
            monitorServiceImpl.sendAccountCreate(bankAccountDto, "1234567", "1.1.11", "uuid");
        } catch (AbsBdbServiceException e) {
            Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getCode());
        }
    }

    @Test
    public void testSendAccountCreate() throws Exception {

        when(restExchange.exchange(anyString(), any(), any(), eq(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        monitorServiceImpl.sendAccountCreate(bankAccountDto, "1234567", "1.1.11", "uuid");
        Assertions.assertNotNull(bankAccountDto);

    }

    @Test
    public void testSendAccountCreateOficina() throws Exception {

        bankAccountDto.setChannel("OFICINA");
        when(restExchange.exchange(anyString(), any(), any(), eq(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        monitorServiceImpl.sendAccountCreate(bankAccountDto, "1234567", "1.1.11", "uuid");
        Assertions.assertNotNull(bankAccountDto);
    }


    @Test
    public void testSendAccountCreateOffice() throws Exception {

        when(restExchange.exchange(anyString(), any(), any(), eq(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        bankAccountDto.setChannelToMonitor("1");
        monitorServiceImpl.sendAccountCreate(bankAccountDto, "1234567", "1.1.11", "uuid");
        Assertions.assertNotNull(bankAccountDto);
    }

    @Test
    public void testSendAccountCreateBM() throws Exception {

        when(restExchange.exchange(anyString(), any(), any(), eq(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        bankAccountDto.setChannel("BM");
        monitorServiceImpl.sendAccountCreate(bankAccountDto, "1234567", "1.1.11", "uuid");
        Assertions.assertNotNull(bankAccountDto);
    }

    @Test
    public void testSendAccountCreateFuerzaMovil() throws Exception {

        when(restExchange.exchange(anyString(), any(), any(), eq(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        bankAccountDto.setChannel("FMV");
        monitorServiceImpl.sendAccountCreate(bankAccountDto, "1234567", "1.1.11", "uuid");
        Assertions.assertNotNull(bankAccountDto);
    }

    @Test
    public void testTramaOficna() throws Exception {

        ObjectMapper testMapper = new ObjectMapper();
        InputStream inputStream = getClass().getResourceAsStream("/bankAccountDto.json");
        BankAccountDto bankAccountDto = testMapper.readValue(inputStream, BankAccountDto.class);
        bankAccountDto.setUserAgent("Mozilla/5.0 (Macintosh; Intel Mac OS X x.y; rv:42.0) Gecko/20100101 Firefox/42.0\n");
        when(restExchange.exchange(anyString(), any(), any(), eq(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        monitorServiceImpl.sendAccountCreate(bankAccountDto, "1234567", "1.1.11", "uuid");
        Assertions.assertNotNull(bankAccountDto);
    }

    @Test
    public void testTramaWeb() throws Exception {

        ObjectMapper testMapper = new ObjectMapper();
        InputStream inputStream = getClass().getResourceAsStream("/bankAccountDto.json");
        BankAccountDto bankAccountDto = testMapper.readValue(inputStream, BankAccountDto.class);
        bankAccountDto.setChannelToMonitor("2");
        bankAccountDto.setUserAgent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51" +
                ".0.2704.103 Safari/537.36\n");
        when(restExchange.exchange(anyString(), any(), any(), eq(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        monitorServiceImpl.sendAccountCreate(bankAccountDto, "1234567", "1.1.11", "uuid");
        Assertions.assertNotNull(bankAccountDto);
    }

    @Test
    public void testTramaBancaMovil() throws Exception {

        ObjectMapper testMapper = new ObjectMapper();
        InputStream inputStream = getClass().getResourceAsStream("/bankAccountDto.json");
        BankAccountDto bankAccountDto = testMapper.readValue(inputStream, BankAccountDto.class);
        bankAccountDto.setChannelToMonitor("3");
        bankAccountDto.setUserAgent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51" +
                ".0.2704.106 Safari/537.36 OPR/38.0.2220.41\n");
        when(restExchange.exchange(anyString(), any(), any(), eq(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));

        monitorServiceImpl.sendAccountCreate(bankAccountDto, "1234567", "1.1.11", "uuid");
        Assertions.assertNotNull(testMapper);
    }

    @Test
    public void testTramaFuerzaMovil() throws Exception {

        ObjectMapper testMapper = new ObjectMapper();
        InputStream inputStream = getClass().getResourceAsStream("/bankAccountDto.json");
        BankAccountDto bankAccountDto = testMapper.readValue(inputStream, BankAccountDto.class);
        bankAccountDto.setChannelToMonitor("4");
        bankAccountDto.setUserAgent("Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 " +
                "(KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1\n");

        monitorServiceImpl.sendAccountCreate(bankAccountDto, "1234567", "1.1.11", "uuid");
        Assertions.assertNotNull(testMapper);
    }

    @Test
    public void testSendAccountToMonitorPlus() throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-FORWARDED-FOR", "1.1.1.1");
        headers.set("User-Agent", "Test");
        headers.set("X-RqUuid", "7a5b83ba-9002-4986-9e87-f55ec41d634f");

        bankAccountDto.setUserAgent("Googlebot/2.1 (+https://www.google.com/bot.html)\n");
        when(restExchange.exchange(anyString(), any(), any(), eq(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        ObjectMapper mapper = new ObjectMapper();
        InputStream inputStream = getClass().getResourceAsStream("/MonitorPlus.json");
        MonitorAccountCreateDto monitorAccountCreateDto = mapper.readValue(inputStream, MonitorAccountCreateDto.class);

        when(restExchange.exchange(anyString(), any(), any(), eq(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));

        monitorServiceImpl.sendAccountToMonitorPlus(headers, monitorAccountCreateDto);
        Assertions.assertNotNull(monitorAccountCreateDto);
    }

    @Test
    public void testSendAccountToMonitorPlusError() throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-FORWARDED-FOR", "1.1.1.1");
        headers.set("User-Agent", "Test");
        headers.set("X-AuthUuid", "7a5b83ba-9002-4986-9e87-f55ec41d634f");

        ObjectMapper mapper = new ObjectMapper();
        InputStream inputStream = getClass().getResourceAsStream("/MonitorPlus.json");
        MonitorAccountCreateDto monitorAccountCreateDto = mapper.readValue(inputStream, MonitorAccountCreateDto.class);
        monitorAccountCreateDto.setOfficeCode(null);

        when(restExchange.exchange(anyString(), any(), any(), eq(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));

        monitorServiceImpl.sendAccountToMonitorPlus(headers, monitorAccountCreateDto);
        Assertions.assertNotNull(monitorAccountCreateDto);
    }

    @Test
    public void testSendAccountCreateUpCoverage() throws Exception {
        bankAccountDto.setSellerId("12345678");
        bankAccountDto.setMiddleName(null);
        bankAccountDto.setSecondLastName(null);
        bankAccountDto.setGender(null);
        bankAccountDto.setCellphone(null);
        bankAccountDto.setUserAgent("Mozilla/5.0 (compatible; MSIE 9.0; Windows Phone OS 7.5; Trident/5.0; IEMobile/9" +
                ".0)\n");

        when(restExchange.exchange(anyString(), any(), any(), eq(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        monitorServiceImpl.sendAccountCreate(bankAccountDto, "1234567", "1.1.11", "uuid");
        Assertions.assertNotNull(bankAccountDto);
    }

    @Test
    public void testSendAccountCreateUpCoverage2() throws Exception {
        bankAccountDto.setGender("F");
        bankAccountDto.setUserAgent("UserAgent");

        when(restExchange.exchange(anyString(), any(), any(), eq(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        monitorServiceImpl.sendAccountCreate(bankAccountDto, "1234567", "1.1.11", "uuid");
        Assertions.assertNotNull(bankAccountDto);
    }
}
