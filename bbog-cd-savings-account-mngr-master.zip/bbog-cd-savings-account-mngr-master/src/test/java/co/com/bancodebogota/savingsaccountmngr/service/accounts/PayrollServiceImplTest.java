package co.com.bancodebogota.savingsaccountmngr.service.accounts;

import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.db.savings.dto.jpa.DisperserInformationDto;
import co.com.bancodebogota.db.savings.dto.jpa.DisperserRqDto;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

public class PayrollServiceImplTest {

    @Mock
    private RestExchangeV2 restExchange;
    @InjectMocks
    private PayrollServiceImpl payrollService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        ReflectionTestUtils.setField(payrollService, "endpointAccountsAdapter", "http://localhost/b");
    }

    @Test
    public void testGetAccountInformation() {
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(new DisperserInformationDto(), HttpStatus.OK));
        DisperserInformationDto accountInformation = payrollService.getAccountInformation(new DisperserRqDto());
        Assertions.assertNotNull(accountInformation);
    }
}
