package co.com.bancodebogota.savingsaccountmngr.service.request;

import co.com.bancodebogota.db.savings.dto.jpa.CheckTypeLogListDto;
import co.com.bancodebogota.dto.request.RequestCheckDto;
import co.com.bancodebogota.model.entities.RequestCheckEntity;
import co.com.bancodebogota.model.entitiesold.CheckType;
import co.com.bancodebogota.model.repositories.CheckTypeRepository;
import co.com.bancodebogota.model.repositories.RequestCheckRepository;
import co.com.bancodebogota.proxy.CheckLogsProxy;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Optional;

import static org.mockito.Mockito.*;

public class CheckLogServiceImplTest {
    @Mock
    private CheckTypeRepository checkTypeRepository;
    @Mock
    private CheckLogsProxy checkLogsProxy;
    @Mock
    private IRequestService requestService;
    @Mock
    private RequestCheckRepository requestCheckRepository;
    @InjectMocks
    private CheckLogServiceImpl checkLogServiceImpl;

    private RequestCheckDto requestCheckDto;
    private RequestCheckEntity requestCheckEntity;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        requestCheckDto = new RequestCheckDto();
        requestCheckDto.setRequestId(1234L);
        requestCheckDto.setChecks("{\"product-contract\":true,\"legal-resources\":true,\"gmf\":true,\"fatca\":true}");

        requestCheckEntity = new RequestCheckEntity();
        requestCheckEntity.setId(123L);
        requestCheckEntity.setRequestId(1234L);
        requestCheckEntity.setChecks("{\"product-contract\":true,\"legal-resources\":true,\"gmf\":false,\"fatca\":false}");
    }

    @Test
    public void testSaveCheckLog() throws Exception {
        CheckTypeLogListDto checkTypeLogListDto = new CheckTypeLogListDto();
        checkTypeLogListDto.setIdentityNumber("1234");
        checkTypeLogListDto.setCheckTypeLogList(new ArrayList<>());

        when(checkLogsProxy.saveCheckType(any())).thenReturn(true);
        when(checkLogsProxy.saveCheckAccountType(any())).thenReturn(true);

        boolean checklog = checkLogServiceImpl.saveCheckLog("documentType", "123",
                "accountNumber", 0L, "uuid", checkTypeLogListDto);
        Assertions.assertTrue(checklog);
    }

    @Test
    public void testGetCheckTypeById() throws Exception {
        CheckType checkTypeEntity = new CheckType();
        checkTypeEntity.setId(1);
        when(checkTypeRepository.findById(anyInt())).thenReturn(Optional.of(checkTypeEntity));
        CheckType result = checkLogServiceImpl.getCheckTypeById(0);
        Assertions.assertEquals(checkTypeEntity.getId(), result.getId());
    }

    @Test
    public void testSaveRequestCheckLogSaveNewChecksTrue() {
        when(requestCheckRepository.findByRequestId(anyLong())).thenReturn(null);
        when(requestCheckRepository.save(any(RequestCheckEntity.class))).thenReturn(new RequestCheckEntity());

        boolean result = checkLogServiceImpl.saveRequestCheckLog(requestCheckDto);
        Assertions.assertTrue(result);
    }

    @Test
    public void testSaveRequestCheckLogSaveNewChecksFalse() {
        when(requestCheckRepository.findByRequestId(anyLong())).thenReturn(null);
        when(requestCheckRepository.save(any(RequestCheckEntity.class))).thenThrow(new IllegalArgumentException());

        boolean result = checkLogServiceImpl.saveRequestCheckLog(requestCheckDto);
        Assertions.assertFalse(result);
    }

    @Test
    public void testSaveRequestCheckLogUpdateChecksTrue() {
        when(requestCheckRepository.findByRequestId(anyLong())).thenReturn(requestCheckEntity);
        when(requestCheckRepository.save(any(RequestCheckEntity.class))).thenReturn(new RequestCheckEntity());

        boolean result = checkLogServiceImpl.saveRequestCheckLog(requestCheckDto);
        Assertions.assertTrue(result);
    }

    @Test
    public void testSaveRequestCheckLogUpdateChecksFalsae() {
        when(requestCheckRepository.findByRequestId(anyLong())).thenReturn(requestCheckEntity);
        when(requestCheckRepository.save(any(RequestCheckEntity.class))).thenThrow(new IllegalArgumentException());

        boolean result = checkLogServiceImpl.saveRequestCheckLog(requestCheckDto);
        Assertions.assertFalse(result);
    }
}

