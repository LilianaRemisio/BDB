package co.com.bancodebogota.savingsaccountmngr.service.fatca;

import co.com.bancodebogota.model.entities.FatcaEntity;
import co.com.bancodebogota.model.repositories.FatcaRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

public class FatcaServiceImplTest {

    @Mock
    private FatcaRepository fatcaRepository;
    @InjectMocks
    private FatcaServiceImpl fatcaServiceImpl;

    private final FatcaEntity fatcaEntity = new FatcaEntity();

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        fatcaEntity.setIdentityNumber("1");
    }

    @Test
    public void testSaveFatcaInfo() {
        when(fatcaRepository.save(any())).thenReturn(new FatcaEntity());
        fatcaServiceImpl.saveFatcaInfo(fatcaEntity);
        Assertions.assertEquals("1", fatcaEntity.getIdentityNumber());
    }

    @Test
    public void testSaveFatcaInfoError() {
        when(fatcaRepository.save(any())).thenThrow(new IllegalArgumentException());
        fatcaServiceImpl.saveFatcaInfo(fatcaEntity);
        Assertions.assertEquals("1", fatcaEntity.getIdentityNumber());
    }
}
