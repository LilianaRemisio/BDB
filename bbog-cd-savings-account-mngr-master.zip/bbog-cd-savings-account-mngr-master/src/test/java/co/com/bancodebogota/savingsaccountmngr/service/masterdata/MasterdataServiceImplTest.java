package co.com.bancodebogota.savingsaccountmngr.service.masterdata;

import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.dto.masterdata.TutorOfficeDef;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

public class MasterdataServiceImplTest {

    @Mock
    private RestExchangeV2 restExchange;
    @InjectMocks
    private MasterdataServiceImpl masterdataServiceImpl;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(masterdataServiceImpl, "masterdataPublicApiEndpoint", "http://localhost:8080");
    }

    @Test
    public void testGetDomicilesByPremiumOffice() {
        TutorOfficeDef tutorOfficeDef = new TutorOfficeDef();
        tutorOfficeDef.setId(1);
        tutorOfficeDef.setPremiumCode("premium");
        tutorOfficeDef.setCode("code");
        tutorOfficeDef.setDomicileCode("domicile");

        TutorOfficeDef[] docs = new TutorOfficeDef[1];
        docs[0] = tutorOfficeDef;

        when(restExchange.exchange(anyString(), any(), any(), any(HttpHeaders.class), eq(TutorOfficeDef[].class))).thenReturn(new ResponseEntity<>(docs, HttpStatus.OK));
        List<TutorOfficeDef> result = masterdataServiceImpl.getDomicilesByPremiumOffice("premiumCode");
        Assertions.assertEquals(1, result.size());
    }
}
