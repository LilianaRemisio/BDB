package co.com.bancodebogota.savingsaccountmngr.service.customer;

import co.com.bancodebogota.debitcards.CardInfoDto;
import co.com.bancodebogota.dto.account.OpeningAccountDto;
import co.com.bancodebogota.dto.customer.CustomerStatusDto;
import co.com.bancodebogota.dto.products.ProductAccountDto;
import co.com.bancodebogota.dto.products.ProductDto;
import co.com.bancodebogota.dto.products.ProductsHandledDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.model.entitiesold.AccountLog;
import co.com.bancodebogota.model.repositories.AccountLogRepository;
import co.com.bancodebogota.savingsaccountmngr.service.products.IProductsService;
import co.com.bancodebogota.service.notifications.INotificationApiService;
import co.com.bancodebogota.service.pentagon.IPentagonService;
import co.com.bancodebogota.service.product.IProductService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

public class CustomerServiceV2ImplTest {

    @Mock
    private IProductsService productsService;
    @Mock
    private IProductService productService;
    @Mock
    private AccountLogRepository accountLogRepository;
    @Mock
    private INotificationApiService notificationApiService;
    @Mock
    private IPentagonService pentagonService;
    @InjectMocks
    private CustomerServiceV2Impl customerServiceV2Impl;

    private final OpeningAccountDto openingAccountDto = new OpeningAccountDto();
    private final HttpHeaders httpHeaders = new HttpHeaders();
    private final String accountType = "055AH";

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        ReflectionTestUtils.setField(customerServiceV2Impl, "cardActivationLink", "link");

        when(notificationApiService.sendSMS(anyString(), anyString(), any())).thenReturn(true);
        when(notificationApiService.sendEmail(anyString(), anyString(), any())).thenReturn(true);
        when(pentagonService.publish(any(), any())).thenReturn(true);

        httpHeaders.add("identification-number", "MTIzNDU2Nzg5Qw==");
        httpHeaders.add("X-RqUID", "rqUID");
        httpHeaders.add("X-Channel", "Oficina");
        httpHeaders.add("X-Forwarded-For", "xForwardedFor");
    }

    @Test
    public void getCustomerStatusErrorProducts() throws AbsBdbServiceException {

        when(productService.getProducts(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenThrow(BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, "", ""));

        try {
            customerServiceV2Impl.getProductsStatus(httpHeaders, accountType);
        } catch (AbsBdbServiceException e) {
            Assertions.assertEquals(500, e.getStatus());
        }
    }

    @Test
    public void getCustomerStatusV2WithCeroAccountsInDB() throws AbsBdbServiceException {
        httpHeaders.add("X-Journey", "FlujoWeb");

        AccountLog accountLog = new AccountLog();
        accountLog.setAccountNumber("accountNumber");

        ProductDto productDto = new ProductDto();
        productDto.setProductStatusCode("A");
        productDto.setProductId("02312312670013458485");

        List<ProductDto> productDtoList = new ArrayList<>();
        productDtoList.add(productDto);

        ProductAccountDto productAccountDto = new ProductAccountDto();
        productAccountDto.setProductAccount(productDtoList);

        when(accountLogRepository.findByAccountNumber("02312312670013458485")).thenReturn(accountLog);
        when(productsService.getFilteredCards(any())).thenReturn(new ProductsHandledDto());
        when(productService.getProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);

        CustomerStatusDto res = customerServiceV2Impl.getProductsStatus(httpHeaders, accountType);
        Assertions.assertFalse(res.isHasDebitCards());
    }

    @Test
    public void getCustomerStatusV2WithAccounts() throws AbsBdbServiceException {

        httpHeaders.add("X-Journey", "FlujoAsistido");

        AccountLog accountLog = new AccountLog();
        accountLog.setAccountNumber("accountNumber");
        accountLog.setAccountType("010AH");

        ProductsHandledDto productsHandledDto = new ProductsHandledDto();
        productsHandledDto.getActiveCards().add(new CardInfoDto());
        productsHandledDto.getTempCards().add(new CardInfoDto());

        ProductDto productDto = new ProductDto();
        productDto.setProductStatusCode("A");
        productDto.setProductId("7777670013458485");
        productDto.setAcctSubType("061AH");

        ProductDto productDto1 = new ProductDto();
        productDto1.setProductStatusCode("A");
        productDto1.setProductId("77776700134585000");
        productDto1.setAcctSubType("063AH");

        List<ProductDto> productDtoList = new ArrayList<>();
        productDtoList.add(productDto);
        productDtoList.add(productDto1);

        ProductAccountDto productAccountDto = new ProductAccountDto();
        productAccountDto.setProductAccount(productDtoList);

        when(accountLogRepository.findByAccountNumber("7777670013458485")).thenReturn(accountLog);
        when(productsService.getFilteredCards(any())).thenReturn(productsHandledDto);
        when(productService.getProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);

        CustomerStatusDto res = customerServiceV2Impl.getProductsStatus(httpHeaders, accountType);
        Assertions.assertTrue(res.isHasDebitCards());
        Assertions.assertFalse(res.isHasDigitalAccount());
    }

    @Test
    public void getCustomerStatusV2WithAccountsNotApprove() throws AbsBdbServiceException {

        httpHeaders.add("X-Journey", "FlujoAsistido");

        AccountLog accountLog = new AccountLog();
        accountLog.setAccountNumber("accountNumber");
        accountLog.setAccountType("010AH");

        ProductsHandledDto productsHandledDto = new ProductsHandledDto();
        productsHandledDto.getActiveCards().add(new CardInfoDto());
        productsHandledDto.getTempCards().add(new CardInfoDto());

        ProductDto productDto = new ProductDto();
        productDto.setProductStatusCode("A");
        productDto.setProductId("7777670013458485");
        productDto.setAcctSubType("061AH");

        ProductDto productDto1 = new ProductDto();
        productDto1.setProductStatusCode("E");
        productDto1.setProductId("77776700134585000");
        productDto1.setAcctSubType("063AH");

        List<ProductDto> productDtoList = new ArrayList<>();
        productDtoList.add(productDto);
        productDtoList.add(productDto1);

        ProductAccountDto productAccountDto = new ProductAccountDto();
        productAccountDto.setProductAccount(productDtoList);

        when(accountLogRepository.findByAccountNumber("7777670013458485")).thenReturn(accountLog);
        when(productsService.getFilteredCards(any())).thenReturn(productsHandledDto);
        when(productService.getProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);

        CustomerStatusDto res = customerServiceV2Impl.getProductsStatus(httpHeaders, accountType);
        Assertions.assertTrue(res.isHasDebitCards());
        Assertions.assertFalse(res.isHasDigitalAccount());
    }

    @Test
    public void getCustomerStatusV2WithThreeAccountsHasDigitalAccounts() throws AbsBdbServiceException {

        httpHeaders.add("X-Journey", "FlujoAsistido");

        String accountTypee = "010AH";

        AccountLog accountLog = new AccountLog();
        accountLog.setAccountNumber("accountNumber");
        accountLog.setAccountType("010AH");

        ProductsHandledDto productsHandledDto = new ProductsHandledDto();
        productsHandledDto.getActiveCards().add(new CardInfoDto());
        productsHandledDto.getTempCards().add(new CardInfoDto());

        ProductDto productDto = new ProductDto();
        productDto.setProductStatusCode("A");
        productDto.setProductId("7777670013458485");
        productDto.setAcctSubType("061AH");

        ProductDto productDto1 = new ProductDto();
        productDto1.setProductStatusCode("A");
        productDto1.setProductId("77776700134585000");
        productDto1.setAcctSubType("010AH");

        ProductDto productDto2 = new ProductDto();
        productDto2.setProductStatusCode("A");
        productDto2.setProductId("77776700134585000");
        productDto2.setAcctSubType("010AH");

        ProductDto productDto3 = new ProductDto();
        productDto3.setProductStatusCode("A");
        productDto3.setProductId("77776700134585000");
        productDto3.setAcctSubType("010AH");

        List<ProductDto> productDtoList = new ArrayList<>();
        productDtoList.add(productDto);
        productDtoList.add(productDto1);
        productDtoList.add(productDto2);
        productDtoList.add(productDto3);

        ProductAccountDto productAccountDto = new ProductAccountDto();
        productAccountDto.setProductAccount(productDtoList);

        when(accountLogRepository.findByAccountNumber("77776700134585000")).thenReturn(accountLog);
        when(productsService.getFilteredCards(any())).thenReturn(productsHandledDto);
        when(productService.getProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);

        CustomerStatusDto res = customerServiceV2Impl.getProductsStatus(httpHeaders, accountTypee);
        Assertions.assertTrue(res.isHasDigitalAccount());
    }

    @Test
    public void getCustomerStatusV2WithTwoAccountsHasDigitalAccounts() throws AbsBdbServiceException {

        httpHeaders.add("X-Journey", "FlujoAsistido");

        String accountTypee = "010AH";

        AccountLog accountLog = new AccountLog();
        accountLog.setAccountNumber("accountNumber");
        accountLog.setAccountType("010AH");

        ProductsHandledDto productsHandledDto = new ProductsHandledDto();
        productsHandledDto.getActiveCards().add(new CardInfoDto());
        productsHandledDto.getTempCards().add(new CardInfoDto());

        ProductDto productDto = new ProductDto();
        productDto.setProductStatusCode("A");
        productDto.setProductId("7777670013458485");
        productDto.setAcctSubType("061AH");

        ProductDto productDto1 = new ProductDto();
        productDto1.setProductStatusCode("A");
        productDto1.setProductId("77776700134585001");
        productDto1.setAcctSubType("063AH");

        ProductDto productDto2 = new ProductDto();
        productDto2.setProductStatusCode("A");
        productDto2.setProductId("77776700134585000");
        productDto2.setAcctSubType("010AH");

        ProductDto productDto3 = new ProductDto();
        productDto3.setProductStatusCode("A");
        productDto3.setProductId("77776700134585000");
        productDto3.setAcctSubType("010AH");

        List<ProductDto> productDtoList = new ArrayList<>();
        productDtoList.add(productDto);
        productDtoList.add(productDto1);
        productDtoList.add(productDto2);
        productDtoList.add(productDto3);

        ProductAccountDto productAccountDto = new ProductAccountDto();
        productAccountDto.setProductAccount(productDtoList);

        when(accountLogRepository.findByAccountNumber("77776700134585000")).thenReturn(accountLog);
        when(productsService.getFilteredCards(any())).thenReturn(productsHandledDto);
        when(productService.getProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);

        CustomerStatusDto res = customerServiceV2Impl.getProductsStatus(httpHeaders, accountTypee);
        Assertions.assertTrue(res.isHasDigitalAccount());
    }

    @Test
    public void getCustomerStatusV2WithTOneAccountsHasDigitalAccounts() throws AbsBdbServiceException {

        httpHeaders.add("X-Journey", "FlujoAsistido");

        String accountTypee = "010AH";

        AccountLog accountLog = new AccountLog();
        accountLog.setAccountNumber("accountNumber");
        accountLog.setAccountType("010AH");

        ProductsHandledDto productsHandledDto = new ProductsHandledDto();
        productsHandledDto.getActiveCards().add(new CardInfoDto());
        productsHandledDto.getTempCards().add(new CardInfoDto());

        ProductDto productDto = new ProductDto();
        productDto.setProductStatusCode("A");
        productDto.setProductId("7777670013458485");
        productDto.setAcctSubType("061AH");

        ProductDto productDto1 = new ProductDto();
        productDto1.setProductStatusCode("A");
        productDto1.setProductId("77776700134585001");
        productDto1.setAcctSubType("063AH");

        ProductDto productDto2 = new ProductDto();
        productDto2.setProductStatusCode("A");
        productDto2.setProductId("77776700134585000");
        productDto2.setAcctSubType("010AH");

        List<ProductDto> productDtoList = new ArrayList<>();
        productDtoList.add(productDto);
        productDtoList.add(productDto1);
        productDtoList.add(productDto2);

        ProductAccountDto productAccountDto = new ProductAccountDto();
        productAccountDto.setProductAccount(productDtoList);

        when(accountLogRepository.findByAccountNumber("77776700134585000")).thenReturn(accountLog);
        when(productsService.getFilteredCards(any())).thenReturn(productsHandledDto);
        when(productService.getProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);

        CustomerStatusDto res = customerServiceV2Impl.getProductsStatus(httpHeaders, accountTypee);
        Assertions.assertFalse(res.isHasDigitalAccount());
    }

    @Test
    public void getCustomerStatusV2WithTOneAccountsHasDigital055() throws AbsBdbServiceException {
        httpHeaders.add("X-Journey", "FlujoAsistido");

        AccountLog accountLog = new AccountLog();
        accountLog.setAccountNumber("accountNumber");
        accountLog.setAccountType("055AH");

        ProductsHandledDto productsHandledDto = new ProductsHandledDto();
        productsHandledDto.getActiveCards().add(new CardInfoDto());
        productsHandledDto.getTempCards().add(new CardInfoDto());

        ProductDto productDto = new ProductDto();
        productDto.setProductStatusCode("A");
        productDto.setProductId("7777670013458485");
        productDto.setAcctSubType("061AH");

        ProductDto productDto1 = new ProductDto();
        productDto1.setProductStatusCode("A");
        productDto1.setProductId("77776700134585001");
        productDto1.setAcctSubType("063AH");

        ProductDto productDto2 = new ProductDto();
        productDto2.setProductStatusCode("A");
        productDto2.setProductId("77776700134585000");
        productDto2.setAcctSubType("055AH");

        List<ProductDto> productDtoList = new ArrayList<>();
        productDtoList.add(productDto);
        productDtoList.add(productDto1);
        productDtoList.add(productDto2);

        ProductAccountDto productAccountDto = new ProductAccountDto();
        productAccountDto.setProductAccount(productDtoList);

        when(accountLogRepository.findByAccountNumber("77776700134585000")).thenReturn(accountLog);
        when(productsService.getFilteredCards(any())).thenReturn(productsHandledDto);
        when(productService.getProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);

        CustomerStatusDto res = customerServiceV2Impl.getProductsStatus(httpHeaders, accountType);
        Assertions.assertTrue(res.isHasDigitalAccount());
    }

    @Test
    public void getCustomerStatusV2WithTempBlocks() throws AbsBdbServiceException {

        httpHeaders.add("X-Journey", "FlujoAsistido");

        AccountLog accountLog = new AccountLog();
        accountLog.setAccountNumber("accountNumber");
        accountLog.setAccountType("010AH");

        CardInfoDto cardInfoDto = new CardInfoDto();
        cardInfoDto.setNumber("213123123");
        cardInfoDto.setStatusCode("A");

        ProductsHandledDto productsHandledDto = new ProductsHandledDto();
        productsHandledDto.getTempCards().add(cardInfoDto);

        ProductDto productDto = new ProductDto();
        productDto.setProductStatusCode("A");
        productDto.setProductId("07777670013458485");
        productDto.setAcctSubType("055AH");

        List<ProductDto> productDtoList = new ArrayList<>();
        productDtoList.add(productDto);

        ProductAccountDto productAccountDto = new ProductAccountDto();
        productAccountDto.setProductAccount(productDtoList);

        when(pentagonService.publish(any(), any())).thenThrow(new IllegalArgumentException(""));
        when(accountLogRepository.findByAccountNumber("7777670013458485")).thenReturn(accountLog);
        when(productsService.getFilteredCards(any())).thenReturn(productsHandledDto);
        when(productService.getProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);

        CustomerStatusDto res = new CustomerStatusDto();
        try {
            res = customerServiceV2Impl.getProductsStatus(httpHeaders, accountType);
        } catch (Exception e) {
            Assertions.assertFalse(res.isHasDigitalAccount());
        }
    }

    @Test
    public void testSendNotificationForCreatedAccountWebDelivery() {
        openingAccountDto.setCardDelivery(true);

        customerServiceV2Impl.sendNotificationForCreatedAccount("identityNumber", "rqUid", true,
                "accountNumber", openingAccountDto, "fullName", "Web");

        Assertions.assertTrue(openingAccountDto.isCardDelivery());
    }

    @Test
    public void testSendNotificationForCreatedAccountWebNotDelivery() {
        customerServiceV2Impl.sendNotificationForCreatedAccount("identityNumber", "rqUid", true,
                "accountNumber", openingAccountDto, "fullName", "Web");

        Assertions.assertFalse(openingAccountDto.isCardDelivery());
    }

    @Test
    public void testSendNotificationForCreatedAccountOffice() {
        customerServiceV2Impl.sendNotificationForCreatedAccount("identityNumber", "rqUid", true,
                "accountNumber", openingAccountDto, "fullName", "Oficina");

        Assertions.assertFalse(openingAccountDto.isCardDelivery());
    }

    @Test
    public void testSendNotificationForCreatedAccountOAS() {
        customerServiceV2Impl.sendNotificationForCreatedAccount("identityNumber", "rqUid", false,
                "accountNumber", openingAccountDto, "fullName", "Oficina");

        verify(notificationApiService, never()).sendEmail(anyString(), anyString(), any());
    }

    @Test
    public void testSendNotificationForCreatedAccountOASDDA() {
        openingAccountDto.setAcctType("DDA");

        customerServiceV2Impl.sendNotificationForCreatedAccount("identityNumber", "rqUid", true,
                "accountNumber", openingAccountDto, "fullName", "Oficina");

        verify(notificationApiService, never()).sendEmail(anyString(), anyString(), any());
    }
}