package co.com.bancodebogota.savingsaccountmngr.service.accounts;

import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.savingsaccountmngr.mapper.IGMFMapper;
import co.com.bancodebogota.savingsaccountmngr.service.request.IRequestService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.Mockito.*;

public class GMFServiceImplTest {

    @Mock
    private RestExchangeV2 restExchange;
    @Mock
    private IGMFMapper gmfMapper;
    @Mock
    private IRequestService requestService;
    @InjectMocks
    private GMFServiceImpl gMFServiceImpl;

    @BeforeEach
    public void setUp() {

        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(gMFServiceImpl, "endpointAccountsAdapter", "http://localhost/");
    }

    @Test
    public void testSendNewAccountToGMFService() {
        when(gmfMapper.mapGmfRequestDto(anyString(), anyString(), anyString(), anyString(), anyString(),
                anyString(), anyString())).thenReturn(null);
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        doNothing().when(requestService).saveRequestEvent(anyLong(), any(), anyString());
        boolean result = gMFServiceImpl.sendNewAccountToGMFService("accountNumber", "officeCode",
                "identityType", "identityNumber", "clientName", "cellphone",
                123L);
        Assertions.assertTrue(result);
    }

    @Test
    public void testSendNewAccountToGMFServiceFail() {
        when(gmfMapper.mapGmfRequestDto(anyString(), anyString(), anyString(), anyString(), anyString(),
                anyString(), anyString())).thenReturn(null);
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.BAD_REQUEST));
        doNothing().when(requestService).saveRequestEvent(anyLong(), any(), anyString());
        boolean result = gMFServiceImpl.sendNewAccountToGMFService("accountNumber", "officeCode",
                "identityType", "identityNumber", "clientName", "cellphone",
                123L);
        Assertions.assertFalse(result);
    }
}
