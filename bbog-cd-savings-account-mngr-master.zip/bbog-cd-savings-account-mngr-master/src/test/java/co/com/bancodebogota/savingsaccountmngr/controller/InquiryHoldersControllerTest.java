package co.com.bancodebogota.savingsaccountmngr.controller;

import co.com.bancodebogota.dto.customer.Customer;
import co.com.bancodebogota.dto.products.Account;
import co.com.bancodebogota.dto.products.LimitsAccountRq;
import co.com.bancodebogota.savingsaccountmngr.service.inquiryholders.IInquiryHolders;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.mockito.Mockito.when;

public class InquiryHoldersControllerTest {

    @Mock
    private IInquiryHolders inquiryHoldersService;
    
    @InjectMocks
    private InquiryHoldersController inquiryHoldersController;

    LimitsAccountRq accountInfo = new LimitsAccountRq();

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        Customer customer = new Customer();
        Account account = new Account();

        customer.setIdentificationNumber("123456");
        customer.setIdentificationType("C");
        account.setAccountNumber("123456");
        account.setAccountType("SDA");
        account.setAccountSubType("SDAT");
        accountInfo.setAccount(account);
        accountInfo.setCustomer(customer);
    }

    @Test
    public void testGetOwnership() throws Exception {
        String rqUID = "test-rqUID";

        when(inquiryHoldersService.getOwnership(accountInfo, rqUID)).thenReturn("01");

        ResponseEntity<String> ownership = inquiryHoldersController.getOwnership(accountInfo, rqUID);

        Assertions.assertEquals(HttpStatus.OK, ownership == null ? HttpStatus.INTERNAL_SERVER_ERROR : HttpStatus.OK);
        Assertions.assertEquals("01", ownership.getBody());
}

    @Test
    public void testGetOwnershipFail() throws Exception {
        String rqUID = "test-rqUID";

        when(inquiryHoldersService.getOwnership(accountInfo, rqUID)).thenReturn(null);

        ResponseEntity<String> ownership = inquiryHoldersController.getOwnership(accountInfo, rqUID);

        Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, ownership.getStatusCode());
        Assertions.assertNull(ownership.getBody());    }
}