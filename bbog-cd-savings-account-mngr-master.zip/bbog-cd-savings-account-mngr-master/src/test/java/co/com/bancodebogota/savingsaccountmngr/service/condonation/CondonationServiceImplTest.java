package co.com.bancodebogota.savingsaccountmngr.service.condonation;

import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.dto.products.ProductAccountDto;
import co.com.bancodebogota.dto.products.ProductDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.model.entitiesold.AccountLog;
import co.com.bancodebogota.service.product.IProductService;
import com.bancodebogota.ifx.base.v1.AcctBalListType;
import com.bancodebogota.ifx.base.v1.AcctBalType;
import com.bancodebogota.ifx.base.v1.CurrencyAmountType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

public class CondonationServiceImplTest {

    @Mock
    private RestExchangeV2 restExchange;
    @Mock
    private IProductService productService;
    @InjectMocks
    private CondonationServiceImpl condonationService;

    @BeforeEach
    public void setUp() throws AbsBdbServiceException {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(condonationService, "endpointAccountsAdapter", "endpoint");

        AccountLog accountLog = new AccountLog();
        accountLog.setAccountNumber("accountNumber");

        ProductDto productDto = new ProductDto();
        productDto.setProductStatusCode("A");
        productDto.setProductId("02312312670013458485");
        productDto.setProductType("SDA");

        ProductDto productDto1 = new ProductDto();
        productDto1.setProductStatusCode("N");
        productDto1.setProductId("4915000000040629");
        productDto1.setProductType("DEB");

        ProductDto productDto2 = new ProductDto();
        productDto2.setProductStatusCode("A");
        productDto2.setProductId("02312312670013458486");
        productDto2.setProductType("DDA");

        ProductDto productDto3 = new ProductDto();
        productDto3.setProductStatusCode("N");
        productDto3.setProductId("4915110100040628");
        productDto3.setProductType("DEB");

        ProductDto productDto4 = new ProductDto();
        productDto4.setProductStatusCode("N");
        productDto4.setProductId("4915000000040629");
        productDto4.setProductType("DEB");

        ProductDto productDto5 = new ProductDto();
        productDto5.setProductStatusCode("A");
        productDto5.setProductId("02312312670013458487");
        productDto5.setProductType("DDA");

        List<ProductDto> productDtoList = new ArrayList<>();
        productDtoList.add(productDto);
        productDtoList.add(productDto1);
        productDtoList.add(productDto2);
        productDtoList.add(productDto3);
        productDtoList.add(productDto4);
        productDtoList.add(productDto5);

        ProductAccountDto productAccountDto = new ProductAccountDto();
        productAccountDto.setProductAccount(productDtoList);
        when(productService.getProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);
    }

    @Test
    public void condonationProcessTestJson() throws IOException {
        String json = "{\"timestamp\":\"10-02-2022 02:07:49.875\",\"message\":\"get Savings Info\",\"correlId\":\"20571535\",\"status\":500}";

        ObjectMapper objectMapper = new ObjectMapper();

        JsonNode acctBalListTypeFail = objectMapper.readTree(json);

        CurrencyAmountType currencyAmountType = new CurrencyAmountType();
        currencyAmountType.setAmt(new BigDecimal(200));

        AcctBalType acctBalType = new AcctBalType();
        acctBalType.getCurAmt().add(currencyAmountType);

        AcctBalType[] acctBalListType = new AcctBalType[]{acctBalType, acctBalType, acctBalType, acctBalType};
        JsonNode acctBalListTypeJson = objectMapper.convertValue(acctBalListType, JsonNode.class);

        when(restExchange.exchange(anyString(), any(), any(), eq(JsonNode.class)))
                .thenReturn(new ResponseEntity<>(acctBalListTypeJson, HttpStatus.OK))
                .thenReturn(new ResponseEntity<>(acctBalListTypeFail, HttpStatus.INTERNAL_SERVER_ERROR))
                .thenReturn(new ResponseEntity<>(null, HttpStatus.OK));
        when(restExchange.exchange(anyString(), any(), any(), eq(Void.class))).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        when(restExchange.exchange(anyString(), any(), any(), eq(Void.class))).thenReturn(new ResponseEntity<>(HttpStatus.OK));

        Boolean response = condonationService.condonationProcess("1030789123", "C", "rquid",
                "0000", true, "WEB", "ip");

        Assertions.assertTrue(response);
    }

    @Test
    public void condonationProcessExceptionTest() {

        when(restExchange.exchange(anyString(), any(), any(), eq(AcctBalListType.class))).thenThrow(new IllegalArgumentException());
        when(restExchange.exchange(anyString(), any(), eq(HttpMethod.POST), eq(Void.class))).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        when(restExchange.exchange(anyString(), any(), eq(HttpMethod.PUT), eq(Void.class))).thenReturn(new ResponseEntity<>(HttpStatus.OK));

        Boolean response = condonationService.condonationProcess("1030789123", "C", "rquid", "0000", true, "WEB", "");
        Assertions.assertFalse(response);
    }

    @Test
    public void condonationProcessFail() throws AbsBdbServiceException {

        when(productService.getProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenThrow(new IllegalArgumentException());

        Boolean response = condonationService.condonationProcess("1030789123", "C", "rquid", "0000", true, "WEB", "ip");

        Assertions.assertFalse(response);
    }

    @Test
    public void condonationProcessTestFailDebitOrder() throws IOException {
        String json = "{\"timestamp\":\"10-02-2022 04:19:41.798\",\"message\":\"error send debit order\",\"correlId\":\"b1494f32-3f6b-4f59-a854-7019852b6469\",\"status\":500}";

        ObjectMapper objectMapper = new ObjectMapper();

        JsonNode setbitOrderFailJson = objectMapper.readTree(json);

        CurrencyAmountType currencyAmountType = new CurrencyAmountType();
        currencyAmountType.setAmt(new BigDecimal(200));

        AcctBalType acctBalType = new AcctBalType();
        acctBalType.getCurAmt().add(currencyAmountType);

        AcctBalType[] acctBalListType = new AcctBalType[]{acctBalType, acctBalType, acctBalType, acctBalType};
        JsonNode acctBalListTypeJson = objectMapper.convertValue(acctBalListType, JsonNode.class);

        when(restExchange.exchange(anyString(), any(), eq(HttpMethod.POST), eq(JsonNode.class))).thenReturn(new ResponseEntity<>(acctBalListTypeJson, HttpStatus.OK))
                .thenReturn(new ResponseEntity<>(setbitOrderFailJson, HttpStatus.INTERNAL_SERVER_ERROR));
        when(restExchange.exchange(anyString(), any(), any(), eq(Void.class))).thenReturn(new ResponseEntity<>(HttpStatus.OK));

        Boolean response = condonationService.condonationProcess("1030789123", "C", "rquid",
                "0000", true, "WEB", "ip");

        Assertions.assertFalse(response);
    }
}