package co.com.bancodebogota.savingsaccountmngr.service.accounts;
import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountDto;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountResponseDto;
import co.com.bancodebogota.dto.account.AccountData;
import co.com.bancodebogota.dto.account.OpeningAccountDto;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.fatca.FatcaDto;
import co.com.bancodebogota.dto.gmf.GmfDto;
import co.com.bancodebogota.dto.monitorplus.MonitorAccountCreateDto;
import co.com.bancodebogota.enums.EAccount;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.proxy.AccountLogProxy;
import co.com.bancodebogota.savingsaccountmngr.mapper.IAccountMapper;
import co.com.bancodebogota.savingsaccountmngr.service.customer.ICustomerServiceV2;
import co.com.bancodebogota.savingsaccountmngr.service.fatca.IFatcaService;
import co.com.bancodebogota.savingsaccountmngr.service.monitorplus.IMonitorService;
import co.com.bancodebogota.service.pentagon.IPentagonService;
import co.com.bancodebogota.service.redis.IRedisApiService;
import co.com.bancodebogota.rest.RestExchangeV2;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import java.io.IOException;
import java.io.InputStream;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

public class AccountServiceImplTest {

    @Mock
    private RestExchangeV2 restExchange;
    @Mock
    private IAccountMapper accountMapper;
    @Mock
    private ISavingsAccountService savingsAccountService;
    @Mock
    private IPentagonService pentagonService;
    @Mock
    private IMonitorService monitorService;
    @Mock
    private IFatcaService fatcaService;
    @Mock
    private IGMFService gmfService;
    @Mock
    private AccountLogProxy accountLogProxy;
    @Mock
    private ICustomerServiceV2 customerServiceV2;
    @Mock
    private IRedisApiService redisApiService;
    @InjectMocks
    private AccountServiceImpl accountService;

    private final HttpHeaders headers = new HttpHeaders();
    private final AccountData accountData = new AccountData();
    private final FatcaDto fatca = new FatcaDto();

    @BeforeEach
    public void setUp() throws AbsBdbServiceException, IOException {
        MockitoAnnotations.openMocks(this);

        ReflectionTestUtils.setField(accountService, "endpointAccountsAdapter", "endpoint");

        headers.set("x-ipaddr", "0.0.0.1");
        headers.set("x-clienttype", "ACTIVE");
        headers.set("x-channel", "Web");
        headers.set("x-custidenttype", "CC");
        headers.set("x-custidentnum", "123456789");
        headers.set("x-officecode", "0000");
        headers.set("x-name", "Seguros");
        headers.set("x-digrequest", "12345");
        headers.set("x-rquid", "12345");
        headers.set("X-AuthUuid", "12345");

        OpeningAccountDto openingAccount = new OpeningAccountDto();
        openingAccount.setFirstName("Juan");
        openingAccount.setFirstLastName("Perea");
        openingAccount.setAcctSubType(EAccount.FLEXIAHORRO.getCode());
        accountData.setOpeningAccount(openingAccount);

        fatca.setFiscalResidence1("Col");
        accountData.setFatca(fatca);

        GmfDto gmf = new GmfDto();
        gmf.setCheckGmf(true);
        gmf.setCellphone("3452345235");
        gmf.setRequestId(123L);
        accountData.setGmf(gmf);

        accountData.setClientWithDebitCards(false);
        accountData.setPostalAddress("address");

        when(fatcaService.saveFatcaInfo(any())).thenReturn(true);
        doNothing().when(accountLogProxy).saveAccountLog(any(), any(), anyString(), any());
        when(gmfService.sendNewAccountToGMFService(anyString(), anyString(), anyString(), anyString(), anyString(),
                anyString(), anyLong())).thenReturn(true);
        when(accountMapper.mapBankAccountForDB(any(), any())).thenReturn(new BankAccountDto());
        doNothing().when(customerServiceV2).sendNotificationForCreatedAccount(anyString(), anyString(), anyBoolean(),
                anyString(), any(), anyString(), anyString());

        InputStream inputStream = getClass().getResourceAsStream("/dispatcher.json");
        ObjectMapper mapper = new ObjectMapper();
        DispatcherDto dispatcherDtoUtmInfo = mapper.readValue(inputStream, DispatcherDto.class);

        DispatcherDto dispatcherDto = new DispatcherDto();
        dispatcherDto.setIdentityType("C");
        dispatcherDto.setIdentityNumber("1030687432");
        dispatcherDto.setChannel("FMV");
        dispatcherDto.setCustomerState("NOT_CLIENT");
        dispatcherDto.setUtmInfo(dispatcherDtoUtmInfo.getUtmInfo());
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
    }

    @Test
    public void testAccountOpening() throws Exception {

        CreateAccountResponseDto createAccountResponseDto = new CreateAccountResponseDto();
        createAccountResponseDto.setAccountNumber("89127398312");

        when(restExchange.exchange(anyString(), any(), any(), any()))
                .thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK))
                .thenReturn(new ResponseEntity<>(null, HttpStatus.OK));
        when(accountMapper.mapOpeningAccountDto(any(), anyString(), anyString(), anyString(), anyString())).thenReturn(new CreateAccountDto());
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(savingsAccountService.updateAccountLimit(any())).thenReturn(true);
        when(accountMapper.mapMonitorAccountCreate(any(), anyString(), anyString())).thenReturn(new MonitorAccountCreateDto());
        when(monitorService.sendAccountToMonitorPlus(any(), any())).thenReturn(true);

        CreateAccountResponseDto response = accountService.accountOpening(headers, accountData);
        Assertions.assertEquals("89127398312", response.getAccountNumber());
    }

    @Test
    public void testAccountOpeningDDAAndNoFatca() throws Exception {

        accountData.getOpeningAccount().setAcctSubType(EAccount.CORRIENTE_COMERCIAL.getCode());
        fatca.setFiscalResidence1(null);
        accountData.setFatca(fatca);

        CreateAccountResponseDto createAccountResponseDto = new CreateAccountResponseDto();
        createAccountResponseDto.setAccountNumber("89127398312");

        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK))
                .thenReturn(new ResponseEntity<>(null, HttpStatus.OK));
        when(accountMapper.mapOpeningAccountDto(any(), anyString(), anyString(), anyString(), anyString())).thenReturn(new CreateAccountDto());
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(savingsAccountService.updateAccountLimit(any())).thenReturn(true);
        when(accountMapper.mapMonitorAccountCreate(any(), anyString(), anyString())).thenReturn(new MonitorAccountCreateDto());
        when(monitorService.sendAccountToMonitorPlus(any(), any())).thenReturn(true);

        CreateAccountResponseDto response = accountService.accountOpening(headers, accountData);
        Assertions.assertEquals("89127398312", response.getAccountNumber());
    }

    @Test
    public void testAccountOpeningError() {
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(null,
                HttpStatus.INTERNAL_SERVER_ERROR));
        when(accountMapper.mapOpeningAccountDto(any(), anyString(), anyString(), anyString(), anyString())).thenReturn(new CreateAccountDto());
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(savingsAccountService.updateAccountLimit(any())).thenReturn(true);
        when(accountMapper.mapMonitorAccountCreate(any(), anyString(), anyString())).thenReturn(new MonitorAccountCreateDto());
        when(monitorService.sendAccountToMonitorPlus(any(), any())).thenReturn(true);

        try {
            accountService.accountOpening(headers, accountData);
        } catch (Exception e) {
            Assertions.assertEquals("Error accountOpeningAdd", e.getMessage());
        }
    }

    @Test
    public void testAccountOpeningV4() throws Exception {

        CreateAccountResponseDto createAccountResponseDto = new CreateAccountResponseDto();
        createAccountResponseDto.setAccountNumber("89127398312");

        when(restExchange.exchange(anyString(), any(), any(), any()))
                .thenReturn(new ResponseEntity<>(createAccountResponseDto, HttpStatus.OK))
                .thenReturn(new ResponseEntity<>(null, HttpStatus.OK));
        when(accountMapper.mapOpeningAccountDto(any(), anyString(), anyString(), anyString(), anyString())).thenReturn(new CreateAccountDto());
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(savingsAccountService.updateAccountLimit(any())).thenReturn(true);
        when(accountMapper.mapMonitorAccountCreate(any(), anyString(), anyString())).thenReturn(new MonitorAccountCreateDto());
        when(monitorService.sendAccountToMonitorPlus(any(), any())).thenReturn(true);

        CreateAccountResponseDto response = accountService.accountOpeningV4(headers, accountData, null);
        Assertions.assertEquals("89127398312", response.getAccountNumber());
    }

    @Test
    public void testAccountOpeningV4Error() {
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(null,
                HttpStatus.INTERNAL_SERVER_ERROR));
        when(accountMapper.mapOpeningAccountDto(any(), anyString(), anyString(), anyString(), anyString())).thenReturn(new CreateAccountDto());
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(savingsAccountService.updateAccountLimit(any())).thenReturn(true);
        when(accountMapper.mapMonitorAccountCreate(any(), anyString(), anyString())).thenReturn(new MonitorAccountCreateDto());
        when(monitorService.sendAccountToMonitorPlus(any(), any())).thenReturn(true);

        try {
            accountService.accountOpeningV4(headers, accountData, null);
        } catch (Exception e) {
            Assertions.assertEquals("Error accountOpeningAdd", e.getMessage());
        }
    }

    @Test
    public void testAccountOpeningV4NullBody() {
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(null, HttpStatus.OK));
        when(accountMapper.mapOpeningAccountDto(any(), anyString(), anyString(), anyString(), anyString())).thenReturn(new CreateAccountDto());
        when(pentagonService.publish(any(), any())).thenReturn(true);
        when(savingsAccountService.updateAccountLimit(any())).thenReturn(true);
        when(accountMapper.mapMonitorAccountCreate(any(), anyString(), anyString())).thenReturn(new MonitorAccountCreateDto());
        when(monitorService.sendAccountToMonitorPlus(any(), any())).thenReturn(true);

        try {
            accountService.accountOpeningV4(headers, accountData, null);
        } catch (Exception e) {
            Assertions.assertEquals("Error accountOpeningAdd", e.getMessage());
        }
    }
}
