package co.com.bancodebogota.savingsaccountmngr.service.pentagon;

import co.com.bancodebogota.dto.pentagon.EventDataDto;
import co.com.bancodebogota.service.pentagon.PentagonServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class EventPentagonServiceImplTest {

    @Mock
    private PentagonServiceImpl pentagonServiceImpl;
    @InjectMocks
    private EventPentagonServiceImpl eventPentagonService;

    private final HttpHeaders httpHeaders = new HttpHeaders();
    private final EventDataDto eventDataDto = new EventDataDto();

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        ReflectionTestUtils.setField(pentagonServiceImpl, "endPointPentagonApi", "http://localhost:8089/");
        httpHeaders.add("X-Channel", "X-Channel");
        httpHeaders.add("X-Journey", "X-Journey");
        httpHeaders.add("X-Forwarded-For", "168.25.23.12, 0.0.0.0");
        httpHeaders.add("Identification-Number", "MTAzMDY4NTQxNUM=");
        httpHeaders.add("X-RqUID", "9b4e461b-32b8-4bd0-9ba5-f967d7b9a4f1");

        eventDataDto.setEventName("eventName-test");
        eventDataDto.setMilestone("milestone");
        eventDataDto.setJourney("journey");
        eventDataDto.setStep("step");
        eventDataDto.setIsClient("LEAD");
        eventDataDto.setFront(false);
        eventDataDto.setDigRequest("123123");
        eventDataDto.setPayload("payload");
    }

    @Test
    public void sendEvent() {
        when(pentagonServiceImpl.publish(any(), any()))
                .thenReturn(true);
        boolean result = eventPentagonService.sendEvent(httpHeaders, eventDataDto);
        Assertions.assertTrue(result);
    }

    @Test
    public void sendEventError() {
        when(pentagonServiceImpl.publish(any(), any()))
                .thenThrow(new IllegalArgumentException());
        boolean result = eventPentagonService.sendEvent(httpHeaders, eventDataDto);
        Assertions.assertFalse(result);
    }
}

