package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.db.savings.dto.jpa.AccountLimitsDto;
import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class AccountLimitMapperDtoTest {

    private final AccountLimitMapperDto accountLimitMapperDto = new AccountLimitMapperDto();

    @Test
    public void testCreateAccountLimitDto() {
        BankAccountDto obj = new BankAccountDto();
        obj.setLastName("lastName");
        obj.setSecondLastName("secondLastName");
        obj.setFirstName("firstName");
        obj.setMiddleName("middleName");
        obj.setGender("M");
        obj.setExpeditionDate("12/09/1986");
        obj.setIdentityNumber("identityNumber");
        obj.setBirthDate("12/09/1986");
        obj.setEmail("email");
        obj.setLivingCityId("livingCityId");
        obj.setCellphone("cellphone");
        obj.setEmployeeName("employeeName");
        obj.setEmployeeAddress("employeeAddress");
        obj.setEmployeeState("employeeState");
        obj.setEmployeePhone("employeePhone");
        obj.setMonthlyIncome("10000");
        obj.setMonthlyOutcome("20000");
        obj.setTotalAssets("30000");
        obj.setTotalDebts("40000");
        obj.setAccountType("accountType");
        obj.setProductId("productId");
        obj.setJobActivityId("jobActivityId");
        obj.setCodNomina("codNomina");
        obj.setEmployeeNit("employeeNit");
        obj.setNameCompany("nameCompany");
        obj.setOfficeCode("officeCode");
        obj.setDeliveryAddress("deliveryAddress");
        obj.setLivingCityId("livingCityId");
        obj.setAddressForCRM("AV;andres;APTO;prueba;;;;;;;COL;11;11001000;;");

        obj.setExpeditionCityId(1231);
        obj.setBornCityId(1232);
        obj.setCityCompanyId(1234);
        obj.setOccupationId(1235);

        obj.setHasAuthorizedRiskCheck(true);
        obj.setGreenCard(false);
        obj.setCustomerExistsInCrm(true);
        obj.setAssetsDeclaration(false);
        obj.setUsaIncome(true);
        obj.setUsaLongTimeVisitor(false);
        obj.setCheckGmf(true);
        obj.setTxInWeb(false);
        obj.setClientWithDebitCards(true);
        AccountLimitsDto result = accountLimitMapperDto.createAccountLimitDto(obj, "accountNumber");
        Assertions.assertEquals(obj.getIdentityNumber(), result.getNumberDocument());
    }
}

