package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.db.savings.dto.jpa.AcctLimitsDescDto;
import co.com.bancodebogota.db.savings.dto.jpa.AddressDto;
import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountDto;
import co.com.bancodebogota.dto.customer.ConsultCustomerRespDto;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.masterdata.TutorOfficeDef;
import co.com.bancodebogota.dto.products.AccountHierarchyReqDto;
import co.com.bancodebogota.dto.products.AcctBasicInfoDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.model.entities.*;
import co.com.bancodebogota.savingsaccountmngr.service.masterdata.IMasterdataService;
import co.com.bancodebogota.savingsaccountmngr.utils.RequestUtilities;
import co.com.bancodebogota.service.redis.IRedisApiService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.io.DataInput;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.BooleanSupplier;

import static org.mockito.Mockito.*;

public class RequestMapperImplTest {
    @Mock
    private IMasterdataService masterdataService;
    @Mock
    private RequestUtilities requestUtilities;
    @Mock
    private IRedisApiService redisApiService;
    @InjectMocks
    private RequestMapperImpl requestMapperImpl;

    private final BankAccountDto bankAccountDto = new BankAccountDto();
    private BankAccountDto bankAccountOfficeDto = new BankAccountDto();
    private final CreateAccountDto createAccountDto = new CreateAccountDto();
    private final ConsultCustomerRespDto consultCustomerRespDto = new ConsultCustomerRespDto();
    private final TutorOfficeDef tutorOfficeDef = new TutorOfficeDef();

    private ObjectMapper objectMapper = new ObjectMapper();
    private DispatcherDto dispatcherDto;


    @BeforeEach
    public void setup() {
        dispatcherDto = new DispatcherDto();
        objectMapper = new ObjectMapper();
        bankAccountDto.setLastName("lastName");
        bankAccountDto.setSecondLastName("secondLastName");
        bankAccountDto.setFirstName("firstName");
        bankAccountDto.setMiddleName("middleName");
        bankAccountDto.setGender("M");
        bankAccountDto.setExpeditionDate("12/09/1986");
        bankAccountDto.setIdentityNumber("identityNumber");
        bankAccountDto.setBirthDate("12/09/1986");
        bankAccountDto.setEmail("email");
        bankAccountDto.setLivingCityId("livingCityId");
        bankAccountDto.setCellphone("cellphone");
        bankAccountDto.setEmployeeName("employeeName");
        bankAccountDto.setEmployeeAddress("employeeAddress");
        bankAccountDto.setEmployeeState("employeeState");
        bankAccountDto.setEmployeePhone("employeePhone");
        bankAccountDto.setMonthlyIncome("10000");
        bankAccountDto.setMonthlyOutcome("20000");
        bankAccountDto.setTotalAssets("30000");
        bankAccountDto.setTotalDebts("40000");
        bankAccountDto.setAccountType("accountType");
        bankAccountDto.setProductId("010AH");
        bankAccountDto.setJobActivityId("jobActivityId");
        bankAccountDto.setCodNomina(null);
        bankAccountDto.setEmployeeNit("employeeNit");
        bankAccountDto.setNameCompany("nameCompany");
        bankAccountDto.setOfficeCode("officeCode");
        bankAccountDto.setDeliveryAddress("deliveryAddress");
        bankAccountDto.setAddressForCRM("AV;andres;APTO;prueba;;;;;;;COL;11;11001000;;");
        bankAccountDto.setCrmAddress("crmAddress");
        bankAccountDto.setSegcomercial("1578");

        bankAccountDto.setExpeditionCityId(1231);
        bankAccountDto.setBornCityId(1232);
        bankAccountDto.setCityCompanyId(1234);
        bankAccountDto.setOccupationId(1235);

        bankAccountDto.setHasAuthorizedRiskCheck(true);
        bankAccountDto.setGreenCard(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        bankAccountDto.setAssetsDeclaration(false);
        bankAccountDto.setUsaIncome(true);
        bankAccountDto.setUsaLongTimeVisitor(false);
        bankAccountDto.setCheckGmf(true);
        bankAccountDto.setCheckPensioner(true);
        bankAccountDto.setTxInWeb(false);
        bankAccountDto.setClientWithDebitCards(true);

        bankAccountOfficeDto = bankAccountDto;
        bankAccountOfficeDto.setTxInWeb(false);
        bankAccountOfficeDto.setSellerId("1012101901");

        consultCustomerRespDto.setAddress1("1");
        consultCustomerRespDto.setBirthDate("2");
        consultCustomerRespDto.setCellphone("3");
        consultCustomerRespDto.setCodCity("4");
        consultCustomerRespDto.setCodCiuu("5");
        consultCustomerRespDto.setCodOcupation(6);
        consultCustomerRespDto.setEffdt("7");
        consultCustomerRespDto.setEmail("8");
        consultCustomerRespDto.setExpeditionCityId("9");
        consultCustomerRespDto.setExpeditionDate("10");
        consultCustomerRespDto.setFirstName("11");
        consultCustomerRespDto.setLastName("12");
        consultCustomerRespDto.setMiddleName("13");
        consultCustomerRespDto.setNationality("14");
        consultCustomerRespDto.setPurposeAddress1("15");
        consultCustomerRespDto.setRepCostos("16");
        consultCustomerRespDto.setSecondLastName("17");
        consultCustomerRespDto.setSegComercial("18");
        consultCustomerRespDto.setSex("19");
        consultCustomerRespDto.setValActivos("20");
        consultCustomerRespDto.setValEgresos("21");
        consultCustomerRespDto.setValIngresos("22");
        consultCustomerRespDto.setValOtrosActivos("23");
        consultCustomerRespDto.setValPasivos("24");

        AddressDto addressDto = new AddressDto();
        addressDto.setCity("11001000");

        createAccountDto.setLastname("lastname");
        createAccountDto.setSecondlastname("second");
        createAccountDto.setFirstname("first");
        createAccountDto.setMiddlename("middle");
        createAccountDto.setSex("sex");
        createAccountDto.setAanit("nit");
        createAccountDto.setBirthdate("1990-02-21");
        createAccountDto.setNewClient(true);
        createAccountDto.setBbcodofi("codofi");
        createAccountDto.setBbcodvendedor("codvendedor");
        createAccountDto.setGmf(1);
        createAccountDto.setDeliveryAddress("delivery");
        createAccountDto.setTxInOffice(true);
        createAccountDto.setFatca("fatca");
        createAccountDto.setNewCard(1);
        createAccountDto.setPostalAddress("postal");
        createAccountDto.setProductid("product");
        createAccountDto.setBbcodctanom("codnom");
        createAccountDto.setCityCode("11001");
        createAccountDto.setA1(addressDto);

        tutorOfficeDef.setId(1);
        tutorOfficeDef.setPremiumCode("premiumCode");
        tutorOfficeDef.setCode("code");
        tutorOfficeDef.setDomicileCode("DomicileCode");

        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapCreateAccountDtoRequest() throws AbsBdbServiceException {
        bankAccountDto.setSegcomercial("620");
        consultCustomerRespDto.setAddress1(";;;;;;;;;;;;;;");
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(ConsultCustomerRespDto.class)))
                .thenReturn(consultCustomerRespDto);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(String.class))).thenReturn("keyAuthenticated");
        when(masterdataService.getDomicilesByPremiumOffice(any())).thenReturn(new ArrayList<>());
        bankAccountDto.setChannel("WEB");
        CreateAccountDto result = requestMapperImpl.mapCreateAccountDtoRequest(bankAccountDto, "authUuid");
        Assertions.assertEquals("0000", result.getBbcodceo());
        Assertions.assertEquals("officeCode", result.getBbcodofi());

    }

    @Test
    public void testMapCreateAccountDtoRequestMFZ() throws AbsBdbServiceException {
        bankAccountDto.setCustomerExistsInCrm(false);
        bankAccountDto.setSegcomercial("1578");
        bankAccountDto.setCodNomina("");

        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(ConsultCustomerRespDto.class)))
                .thenReturn(consultCustomerRespDto);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(String.class))).thenReturn("keyAuthenticated");
        when(masterdataService.getDomicilesByPremiumOffice(any())).thenReturn(new ArrayList<>());

        CreateAccountDto result = requestMapperImpl.mapCreateAccountDtoRequest(bankAccountDto, "authUuid");
        Assertions.assertEquals("0000", result.getBbcodceo());
        Assertions.assertEquals("officeCode", result.getBbcodofi());

    }

    @Test
    public void testMapCreateAccountDtoRequestMFZ2() throws AbsBdbServiceException {
        bankAccountDto.setCustomerExistsInCrm(false);
        bankAccountDto.setSegcomercial("1578");
        bankAccountDto.setCodNomina("");

        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(ConsultCustomerRespDto.class)))
                .thenReturn(consultCustomerRespDto);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(String.class))).thenReturn("keyAuthenticated");
        when(masterdataService.getDomicilesByPremiumOffice(any())).thenReturn(new ArrayList<>());

        CreateAccountDto result = requestMapperImpl.mapCreateAccountDtoRequest(bankAccountDto, "authUuid");
        Assertions.assertEquals("0000", result.getBbcodceo());
        Assertions.assertEquals("officeCode", result.getBbcodofi());

    }

    @Test
    public void testMapCreateAccountDtoRequestMFZWithCeoCode() throws AbsBdbServiceException {
        bankAccountDto.setSegcomercial("620");

        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(ConsultCustomerRespDto.class)))
                .thenReturn(consultCustomerRespDto);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(String.class))).thenReturn("keyAuthenticated");
        when(masterdataService.getDomicilesByPremiumOffice(any())).thenReturn(new ArrayList<>());
        bankAccountDto.setChannel("MFZ");
        bankAccountDto.setCeoCode("1413");
        CreateAccountDto result = requestMapperImpl.mapCreateAccountDtoRequest(bankAccountDto, "authUuid");
        Assertions.assertEquals("1413", result.getBbcodceo());
        Assertions.assertEquals("officeCode", result.getBbcodofi());

    }

    @Test
    public void testMapCreateAccountDtoRequestWebWithCeoCode() throws AbsBdbServiceException {
        bankAccountDto.setSegcomercial("620");
        bankAccountDto.setChannel("Web");
        bankAccountDto.setCeoCode("1413");

        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(ConsultCustomerRespDto.class)))
                .thenReturn(consultCustomerRespDto);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(String.class))).thenReturn("keyAuthenticated");
        when(masterdataService.getDomicilesByPremiumOffice(any())).thenReturn(new ArrayList<>());

        CreateAccountDto result = requestMapperImpl.mapCreateAccountDtoRequest(bankAccountDto, "authUuid");
        Assertions.assertEquals("1413", result.getBbcodceo());
        Assertions.assertEquals("officeCode", result.getBbcodofi());
    }

    @Test
    public void testMapCreateAccountDtoRequestAssistedWithCeoCode() throws AbsBdbServiceException {
        bankAccountDto.setSegcomercial("620");
        bankAccountDto.setChannel("Oficina");
        bankAccountDto.setCeoCode("1413");

        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(ConsultCustomerRespDto.class)))
                .thenReturn(consultCustomerRespDto);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(String.class))).thenReturn("keyAuthenticated");
        when(masterdataService.getDomicilesByPremiumOffice(any())).thenReturn(new ArrayList<>());

        CreateAccountDto result = requestMapperImpl.mapCreateAccountDtoRequest(bankAccountDto, "authUuid");
        Assertions.assertEquals("1413", result.getBbcodceo());
        Assertions.assertEquals("officeCode", result.getBbcodofi());
    }


    @Test
    public void testMapCreateAccountDtoRequestPremium() throws AbsBdbServiceException {
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(ConsultCustomerRespDto.class)))
                .thenReturn(consultCustomerRespDto);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(String.class))).thenReturn("keyAuthenticated");
        when(masterdataService.getDomicilesByPremiumOffice(any())).thenReturn(Collections.singletonList(tutorOfficeDef));
        when(requestUtilities.getNextCeoCode(any())).thenReturn("1010");
        bankAccountDto.setChannel("WEB");
        CreateAccountDto result = requestMapperImpl.mapCreateAccountDtoRequest(bankAccountDto, "authUuid");
        Assertions.assertEquals("0000", result.getBbcodceo());
        Assertions.assertEquals("code", result.getBbcodofi());
    }

    @Test
    public void testMapCreateAccountDtoRequestPremiumNormalOffice() throws AbsBdbServiceException {
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(String.class))).thenReturn(null);
        when(masterdataService.getDomicilesByPremiumOffice(any())).thenReturn(new ArrayList<>());
        when(requestUtilities.getNextCeoCode(any())).thenReturn("0000");
        bankAccountDto.setChannel("WEB");
        CreateAccountDto result = requestMapperImpl.mapCreateAccountDtoRequest(bankAccountDto, "authUuid");
        Assertions.assertEquals("0000", result.getBbcodceo());
        Assertions.assertEquals("officeCode", result.getBbcodofi());
    }

    @Test
    public void testCreateRequesthierarchyAccount() {
        AccountHierarchyReqDto accountHierarchyReqDto = new AccountHierarchyReqDto();
        AcctBasicInfoDto acctBasicInfoDto = new AcctBasicInfoDto();
        acctBasicInfoDto.setAcctId("acctId");
        acctBasicInfoDto.setAcctType("acctType");
        acctBasicInfoDto.setAcctSubType("acctSubType");
        accountHierarchyReqDto.setAcctBasicInfo(Collections.singletonList(acctBasicInfoDto));
        accountHierarchyReqDto.setClientDt("cliente");
        accountHierarchyReqDto.setFiDebitTrnNum("FiDebit");
        accountHierarchyReqDto.setIdentificationNumber("1234");
        accountHierarchyReqDto.setIdentificationType("C");
        accountHierarchyReqDto.setProductId("1");
        accountHierarchyReqDto.setTrnCount("2");
        ObjectNode result = requestMapperImpl.mapAccountHierarchy(accountHierarchyReqDto);
        Assertions.assertNotNull(result);
    }

    @Test
    public void testMapCreateBankAccountDto() {
        createAccountDto.setSourceTeamId(5);
        BankAccountDto result = requestMapperImpl.mapCreateBankAccountDto(createAccountDto, consultCustomerRespDto, "061AH");
        Assertions.assertEquals("nit", result.getIdentityNumber());
        Assertions.assertEquals("11001", result.getLivingCityId());
    }

    @Test
    public void testMapSavingCondition() {
        SavingConditionDto savingConditionDto = requestMapperImpl.mapSavingCondition(bankAccountDto, 1, true);

        Assertions.assertEquals(bankAccountDto.getRequestId(), savingConditionDto.getConditionId());
        Assertions.assertEquals(1, savingConditionDto.getSavingTypeId());
        Assertions.assertEquals(bankAccountDto.getOfficeCode(), savingConditionDto.getOfficeCode());
        Assertions.assertEquals(bankAccountDto.isCheckGmf(), savingConditionDto.isGmf());
    }

    @Test
    public void testMapSavingConditionOfficeCodeUndefined() {
        bankAccountDto.setOfficeCode("undefined");
        SavingConditionDto savingConditionDto = requestMapperImpl.mapSavingCondition(bankAccountDto, 1, true);

        Assertions.assertEquals(bankAccountDto.getRequestId(), savingConditionDto.getConditionId());
        Assertions.assertEquals(1, savingConditionDto.getSavingTypeId());
        Assertions.assertEquals("WEB", savingConditionDto.getOfficeCode());
        Assertions.assertEquals(bankAccountDto.isCheckGmf(), savingConditionDto.isGmf());
    }

    @Test
    public void testMapRequestOperation() {
        RequestOperationDto requestOperationDto = requestMapperImpl.mapRequestOperation(bankAccountDto.getRequestId(), 1);

        Assertions.assertEquals(bankAccountDto.getRequestId(), requestOperationDto.getRequestId());
        Assertions.assertEquals(1, requestOperationDto.getOperationTypeId());
    }

    @Test
    public void testMapRequestSellerId() {
        RequestSellerDto requestSellerDto = requestMapperImpl.mapRequestSeller("", bankAccountOfficeDto.getSellerId(), bankAccountOfficeDto.getRequestId());

        Assertions.assertEquals(bankAccountOfficeDto.getRequestId(), requestSellerDto.getRequestId());
        Assertions.assertEquals(bankAccountOfficeDto.getSellerId(), requestSellerDto.getSeller());
    }

    @Test
    public void testMapRequestPayrollAccount() {
        RequestPayrollAccountDto requestPayrollAccountDto = requestMapperImpl.mapRequestPayrollAccount(bankAccountOfficeDto.getCodNomina(), bankAccountOfficeDto.getEmployeeNit(), bankAccountOfficeDto.getRequestId(), bankAccountDto.getNameCompany());

        Assertions.assertEquals(bankAccountOfficeDto.getRequestId(), requestPayrollAccountDto.getRequestId());
        Assertions.assertEquals(bankAccountOfficeDto.getEmployeeNit(), requestPayrollAccountDto.getCompanyNit());
        Assertions.assertEquals(bankAccountOfficeDto.getCodNomina(), requestPayrollAccountDto.getDispersionCode());
    }

    @Test
    public void testMapParticipantInfo() {
        ParticipantInfoDto participantInfoDto = requestMapperImpl.mapParticipantInfo(bankAccountDto);

        Assertions.assertEquals(bankAccountDto.getRequestId(), participantInfoDto.getRequestId());
        Assertions.assertEquals(bankAccountDto.getFirstName(), participantInfoDto.getFirstName());
        Assertions.assertEquals(bankAccountDto.getMiddleName(), participantInfoDto.getSecondName());
        Assertions.assertEquals(bankAccountDto.getLastName(), participantInfoDto.getFirstSurname());
        Assertions.assertEquals(bankAccountDto.getSecondLastName(), participantInfoDto.getSecondSurname());
        Assertions.assertEquals(bankAccountDto.getCellphone(), participantInfoDto.getPhone());
        Assertions.assertEquals(bankAccountDto.getCrmAddress(), participantInfoDto.getAddress());
        Assertions.assertEquals(bankAccountDto.getJobActivityId(), participantInfoDto.getActivityCode());
        Assertions.assertEquals(bankAccountDto.getOccupationId().toString(), participantInfoDto.getOccupation());
        Assertions.assertEquals(bankAccountDto.getMonthlyIncome(), participantInfoDto.getIncome());
        Assertions.assertEquals(bankAccountDto.getMonthlyOutcome(), participantInfoDto.getOutcome());
    }

    @Test
    public void testMapParticipantInfoOccupationIdNull() {
        bankAccountDto.setOccupationId(null);
        ParticipantInfoDto participantInfoDto = requestMapperImpl.mapParticipantInfo(bankAccountDto);

        Assertions.assertEquals(bankAccountDto.getRequestId(), participantInfoDto.getRequestId());
        Assertions.assertEquals(bankAccountDto.getFirstName(), participantInfoDto.getFirstName());
        Assertions.assertEquals(bankAccountDto.getMiddleName(), participantInfoDto.getSecondName());
        Assertions.assertEquals(bankAccountDto.getLastName(), participantInfoDto.getFirstSurname());
        Assertions.assertEquals(bankAccountDto.getSecondLastName(), participantInfoDto.getSecondSurname());
        Assertions.assertEquals(bankAccountDto.getCellphone(), participantInfoDto.getPhone());
        Assertions.assertEquals(bankAccountDto.getCrmAddress(), participantInfoDto.getAddress());
        Assertions.assertEquals(bankAccountDto.getJobActivityId(), participantInfoDto.getActivityCode());
        Assertions.assertNull(bankAccountDto.getOccupationId());
        Assertions.assertEquals(bankAccountDto.getMonthlyIncome(), participantInfoDto.getIncome());
        Assertions.assertEquals(bankAccountDto.getMonthlyOutcome(), participantInfoDto.getOutcome());
    }

    @Test
    public void testMapDomicileInfo() {
        DomicileInfoDto domicileInfoDto = requestMapperImpl.mapDomicileInfo(bankAccountDto);

        Assertions.assertEquals(bankAccountDto.getRequestId(), domicileInfoDto.getRequestId());
        Assertions.assertEquals(bankAccountDto.getDeliveryAddress(), domicileInfoDto.getAddress());
        Assertions.assertEquals(bankAccountDto.getLivingCityId(), domicileInfoDto.getCity());
    }

    @Test
    public void testMapRequestArrangement() {
        List<RequestArrangementDto> requestArrangementDtoList = requestMapperImpl.mapRequestArrangement(bankAccountDto);

        Assertions.assertEquals(bankAccountDto.getRequestId(), requestArrangementDtoList.get(0).getRequestId());
        Assertions.assertEquals(2, requestArrangementDtoList.get(0).getArrangementTypeId());
        Assertions.assertEquals(5, requestArrangementDtoList.get(1).getArrangementTypeId());
        Assertions.assertEquals(3, requestArrangementDtoList.get(2).getArrangementTypeId());
    }

    @Test
    public void testMapRequestArrangement2() {
        bankAccountDto.setCheckGmf(false);
        bankAccountDto.setCheckPensioner(false);
        List<RequestArrangementDto> requestArrangementDtoList = requestMapperImpl.mapRequestArrangement(bankAccountDto);

        Assertions.assertEquals(bankAccountDto.getRequestId(), requestArrangementDtoList.get(0).getRequestId());
        Assertions.assertEquals(3, requestArrangementDtoList.get(0).getArrangementTypeId());
    }

    @Test
    public void testGetAccountLimits() {

        List<Object[]> list = new ArrayList<>();
        Object[] object = new Object[]{123, "test", 5, 100f, "test"};
        list.add(object);

        List<AcctLimitsDescDto> result = requestMapperImpl.mapAccountLimits(list);
        Assertions.assertEquals("test", result.get(0).getNetworkOwner());
    }

    @Test
    public void testMapCreateBankValidationTxInOffice1() {

        createAccountDto.setTxInOffice(true);
        createAccountDto.setChannel(null);
        createAccountDto.setSourceTeamId(5);

        BankAccountDto result3 = requestMapperImpl.mapCreateBankAccountDto(createAccountDto, consultCustomerRespDto, "061AH");
        Assertions.assertFalse(result3.isTxInWeb());
    }

    @Test
    public void testMapCreateBankValidationTxInOffice2() {

        createAccountDto.setTxInOffice(true);
        createAccountDto.setChannel("");
        createAccountDto.setSourceTeamId(5);
        createAccountDto.setNewClient(false);
        createAccountDto.setNewCard(0);

        BankAccountDto result3 = requestMapperImpl.mapCreateBankAccountDto(createAccountDto, consultCustomerRespDto, "061AH");
        Assertions.assertFalse(result3.isTxInWeb());
    }

    @Test
    public void testMapCreateBankValidationTxInOffice3() {

        createAccountDto.setTxInOffice(true);
        createAccountDto.setChannel("OFICINA");
        createAccountDto.setSourceTeamId(5);

        BankAccountDto result2 = requestMapperImpl.mapCreateBankAccountDto(createAccountDto, consultCustomerRespDto, "061AH");
        Assertions.assertFalse(result2.isTxInWeb());
    }

    @Test
    public void testMapCreateBankValidationTxInOffice4() {

        createAccountDto.setTxInOffice(true);
        createAccountDto.setChannel("FMV");
        createAccountDto.setSourceTeamId(5);

        BankAccountDto result3 = requestMapperImpl.mapCreateBankAccountDto(createAccountDto, consultCustomerRespDto, "061AH");
        Assertions.assertFalse(result3.isTxInWeb());
    }

    @Test
    public void testMapCreateBankValidationTxInOffice5() {

        createAccountDto.setTxInOffice(true);
        createAccountDto.setChannel("OFICINA");
        createAccountDto.setSourceTeamId(3);

        BankAccountDto result3 = requestMapperImpl.mapCreateBankAccountDto(createAccountDto, consultCustomerRespDto, "061AH");
        Assertions.assertFalse(result3.isTxInWeb());
    }

    @Test
    public void testMapCreateBankValidationTxInOffice6() {

        createAccountDto.setTxInOffice(true);
        createAccountDto.setChannel("");
        createAccountDto.setSourceTeamId(3);

        BankAccountDto result = requestMapperImpl.mapCreateBankAccountDto(createAccountDto, consultCustomerRespDto, "061AH");
        Assertions.assertFalse(result.isTxInWeb());
    }

    @Test
    public void testMapCreateBankValidationTxInOffice7() {

        createAccountDto.setTxInOffice(false);
        createAccountDto.setChannel("FMV");
        createAccountDto.setSourceTeamId(5);

        BankAccountDto result3 = requestMapperImpl.mapCreateBankAccountDto(createAccountDto, consultCustomerRespDto, "061AH");
        Assertions.assertFalse(result3.isTxInWeb());
    }

    @Test
    public void testMapCreateBankValidationTxInOffice8() {

        createAccountDto.setTxInOffice(false);
        createAccountDto.setChannel(null);
        createAccountDto.setSourceTeamId(5);

        BankAccountDto result3 = requestMapperImpl.mapCreateBankAccountDto(createAccountDto, consultCustomerRespDto, "061AH");
        Assertions.assertTrue(result3.isTxInWeb());
    }

    @Test
    public void testMapCreateBankValidationTxInOffice9() {

        createAccountDto.setTxInOffice(false);
        createAccountDto.setChannel("");
        createAccountDto.setSourceTeamId(5);

        BankAccountDto result3 = requestMapperImpl.mapCreateBankAccountDto(createAccountDto, consultCustomerRespDto, "061AH");
        Assertions.assertTrue(result3.isTxInWeb());
    }

    @Test
    public void testMapCreateBankValidationTxInOffice10() {

        createAccountDto.setTxInOffice(false);
        createAccountDto.setChannel("OFICINA");
        createAccountDto.setSourceTeamId(3);

        BankAccountDto result3 = requestMapperImpl.mapCreateBankAccountDto(createAccountDto, consultCustomerRespDto, "061AH");
        Assertions.assertTrue(result3.isTxInWeb());
    }

    @Test
    public void testMapCreateBankValidationTxInOffice11() {

        createAccountDto.setTxInOffice(false);
        createAccountDto.setChannel("");
        createAccountDto.setSourceTeamId(3);

        BankAccountDto result3 = requestMapperImpl.mapCreateBankAccountDto(createAccountDto, consultCustomerRespDto, "061AH");
        Assertions.assertTrue(result3.isTxInWeb());
    }

    @Test
    public void testMapCreateBankValidationTxInOffice12() {

        createAccountDto.setTxInOffice(false);
        createAccountDto.setChannel("WEB");
        createAccountDto.setSourceTeamId(3);

        BankAccountDto result3 = requestMapperImpl.mapCreateBankAccountDto(createAccountDto, consultCustomerRespDto, "061AH");
        Assertions.assertTrue(result3.isTxInWeb());
    }

    @Test
    public void testMapDispatcherByRequestAuth() throws IOException {
        Path jsonFilePath = Paths.get("src/test/resources/dispatcherData.json");
        String jsonContent = new String(Files.readAllBytes(jsonFilePath));

        DispatcherDto result = requestMapperImpl.mapDispatcherByRequestAuth(jsonContent);
        Assertions.assertNotEquals(result, null);
    }
}
