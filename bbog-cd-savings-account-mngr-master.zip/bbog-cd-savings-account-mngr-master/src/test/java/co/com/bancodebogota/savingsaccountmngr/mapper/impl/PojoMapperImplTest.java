package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.dto.customer.*;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.io.IOException;
import java.io.InputStream;

public class PojoMapperImplTest {

    @InjectMocks
    private PojoMapperImpl pojoMapperImpl;

    private final BankAccountDto bankAccountDto = new BankAccountDto();

    private CustomerManagementRs response;

    @BeforeEach
    public void setup() throws IOException {
        MockitoAnnotations.openMocks(this);


        bankAccountDto.setLastName("lastName");
        bankAccountDto.setSecondLastName("secondLastName");
        bankAccountDto.setFirstName("firstName");
        bankAccountDto.setMiddleName("middleName");
        bankAccountDto.setGender("M");
        bankAccountDto.setExpeditionDate("12/09/1986");
        bankAccountDto.setIdentityNumber("identityNumber");
        bankAccountDto.setBirthDate("12/09/1986");
        bankAccountDto.setEmail("email");
        bankAccountDto.setLivingCityId("livingCityId");
        bankAccountDto.setCellphone("cellphone");
        bankAccountDto.setEmployeeName("employeeName");
        bankAccountDto.setEmployeeAddress("employeeAddress");
        bankAccountDto.setEmployeeState("employeeState");
        bankAccountDto.setEmployeePhone("employeePhone");
        bankAccountDto.setMonthlyIncome("10000");
        bankAccountDto.setMonthlyOutcome("20000");
        bankAccountDto.setTotalAssets("30000");
        bankAccountDto.setTotalDebts("40000");
        bankAccountDto.setAccountType("accountType");
        bankAccountDto.setProductId("010AH");
        bankAccountDto.setJobActivityId("jobActivityId");
        bankAccountDto.setCodNomina(null);
        bankAccountDto.setEmployeeNit("employeeNit");
        bankAccountDto.setNameCompany("nameCompany");
        bankAccountDto.setOfficeCode("officeCode");
        bankAccountDto.setDeliveryAddress("deliveryAddress");
        bankAccountDto.setAddressForCRM("AV;andres;APTO;prueba;;;;;;;COL;11;11001000;;");
        bankAccountDto.setCrmAddress("crmAddress");
        bankAccountDto.setSegcomercial("1578");

        bankAccountDto.setCityCompanyId(1234);
        bankAccountDto.setOccupationId(1235);

        bankAccountDto.setHasAuthorizedRiskCheck(true);
        bankAccountDto.setGreenCard(false);
        bankAccountDto.setCustomerExistsInCrm(true);
        bankAccountDto.setAssetsDeclaration(false);
        bankAccountDto.setUsaIncome(true);
        bankAccountDto.setUsaLongTimeVisitor(false);
        bankAccountDto.setCheckGmf(true);
        bankAccountDto.setCheckPensioner(true);
        bankAccountDto.setTxInWeb(false);
        bankAccountDto.setClientWithDebitCards(true);

        ObjectMapper testMapper = new ObjectMapper();
        testMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        InputStream inputStream = getClass().getResourceAsStream("/customerOpenApi.json");
        response = testMapper.readValue(inputStream, CustomerManagementRs.class);
    }

    @Test
    public void testMapConsultCustomerRespDto() {
        ConsultCustomerRespDto result = pojoMapperImpl.mapConsultCustomerRespDto(response);
        Assertions.assertEquals("ANDREST", result.getFirstName());
        Assertions.assertEquals("test@bancodebogota.com.co", result.getEmail());
    }

    @Test
    public void testMapConsultCustomerRespDtoIssDateNull() {
        response.getCustInfo().getCustId().get(0).setIssDt(null);
        ConsultCustomerRespDto result = pojoMapperImpl.mapConsultCustomerRespDto(response);
        Assertions.assertEquals("ANDREST", result.getFirstName());
        Assertions.assertEquals("test@bancodebogota.com.co", result.getEmail());
    }

    @Test
    public void testMapConsultCustomerRespDtoInfoNull() {
        CustInfo custInfo = response.getCustInfo();
        Identification custId = custInfo.getCustId().get(0);

        PersonInfo personInfo = custInfo.getPersonInfo();
        PersonName personName = personInfo.getPersonName();
        FinancialData financialData = custInfo.getFinancialData();
        ContactInfo contactInfo = personInfo.getContactInfo().get(0);
        PostAddr postAddr = contactInfo.getPostAddr();
        Employment employment = personInfo.getEmployment().get(0);

        personName.setFirstName(null);
        personName.setMiddleName(null);
        personName.setLastName(null);
        personName.setSecondLastName(null);
        personInfo.setBirthDt(null);
        custId.setExpeditionPlace(null);
        contactInfo.setEmailAddr(null);
        contactInfo.getPhoneNum().setPhone(null);
        personInfo.setGender(null);
        personInfo.setNationality(null);
        employment.setOccupationCode(null);
        employment.setEmploymentId(null);
        financialData.getTotalAssests().getCurAmt().setAmt(null);
        financialData.setExpenses(null);
        financialData.setIncome(null);
        financialData.getTotalLiabilities().getCurAmt().setAmt(null);
        postAddr.setCityId(null);
        financialData.setCostsReport(null);
        postAddr.setAddr1(null);
        postAddr.setAddrType(null);


        ConsultCustomerRespDto result = pojoMapperImpl.mapConsultCustomerRespDto(response);
        Assertions.assertEquals("", result.getFirstName());
        Assertions.assertEquals("", result.getEmail());
        Assertions.assertEquals(0, result.getCodOcupation());
        Assertions.assertEquals("", result.getValIngresos());
        Assertions.assertEquals("", result.getValEgresos());
        Assertions.assertEquals("", result.getValPasivos());
        Assertions.assertEquals("", result.getValActivos());
        Assertions.assertEquals("", result.getSex());
        Assertions.assertEquals("", result.getMiddleName());
        Assertions.assertEquals("", result.getLastName());
        Assertions.assertEquals("", result.getSecondLastName());
        Assertions.assertEquals("", result.getBirthDate());
        Assertions.assertEquals("", result.getExpeditionCityId());
        Assertions.assertEquals("", result.getCellphone());
        Assertions.assertEquals("", result.getNationality());
        Assertions.assertEquals("", result.getCodCiuu());
        Assertions.assertEquals("", result.getCodCity());
        Assertions.assertEquals("", result.getRepCostos());
        Assertions.assertEquals("", result.getAddress1());
        Assertions.assertEquals("", result.getPurposeAddress1());
    }

    @Test
    public void testMapCreateCustomerRequest() throws Exception {
        ObjectNode customer = pojoMapperImpl.mapCustInfoPojo(bankAccountDto, "authUuid");
        Assertions.assertNotNull(customer);
    }

    @Test
    public void testMapCreateCustomerRequestCatch() {
        bankAccountDto.setLivingCityId("1");
        bankAccountDto.setCodCity("2");
        bankAccountDto.setBornCityId(1232);

        try {
            pojoMapperImpl.mapCustInfoPojo(bankAccountDto, "authUuid");
        } catch (Exception e) {
            Assertions.assertEquals("Error mapping custInfo from bankAccountDto", e.getMessage());
        }
    }

    @Test
    public void testMapCreateCustomerRequestV2() throws Exception {
        bankAccountDto.setEmail(null);
        bankAccountDto.setExpeditionCityId(1231);

        ObjectNode customer = pojoMapperImpl.mapCustInfoPojo(bankAccountDto, "authUuid");
        Assertions.assertNotNull(customer);
    }

    @Test
    public void testMapCreateCustomerRequestV3() throws Exception {
        bankAccountDto.setEmail("");

        ObjectNode customer = pojoMapperImpl.mapCustInfoPojo(bankAccountDto, "authUuid");
        Assertions.assertNotNull(customer);
    }

    @Test
    public void testMapCreateCustomerRequestRedisNull() throws Exception {
        bankAccountDto.setEmail(null);

        ObjectNode customer = pojoMapperImpl.mapCustInfoPojo(bankAccountDto, "authUuid");
        Assertions.assertNotNull(customer);
    }
}
