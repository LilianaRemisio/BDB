package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.dto.customer.ConsultCustomerRespDto;
import co.com.bancodebogota.dto.customer.RequestCustomerInquiry;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.io.InputStream;

public class CustomerCrmMapperImplTest {

    @InjectMocks
    private CustomerCrmMapperImpl customerCrmMapperImpl;

    private BankAccountDto bankAccountDto = new BankAccountDto();
    private final Resource resource = new ClassPathResource("MappCustomerDto.json");

    @BeforeEach
    public void setUp() throws IOException {
        MockitoAnnotations.openMocks(this);

        ObjectMapper objectMapper = new ObjectMapper();
        InputStream inputStreamCustomerAPI = resource.getInputStream();

        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        bankAccountDto = objectMapper.readValue(inputStreamCustomerAPI, BankAccountDto.class);
    }

    @Test
    public void testMapCreateCustomerDto() {
        RequestCustomerInquiry result = customerCrmMapperImpl.mapCreateCustomerDto(bankAccountDto);
        Assertions.assertNotNull(result);
    }

    @Test
    public void testMapCreateCustomerDto2() {
        RequestCustomerInquiry result = customerCrmMapperImpl.mapCreateCustomerDto(bankAccountDto);
        Assertions.assertNotNull(result);
    }


    @Test
    public void testMapCreateCustomerDto3() throws Exception {
        JsonNode result = customerCrmMapperImpl.mapUpdateCustomerDto(bankAccountDto, new ConsultCustomerRespDto());
        Assertions.assertNotNull(result);
    }

    @Test
    public void testMapCreateCustomerDto4() throws Exception {
        ConsultCustomerRespDto consultCustomerRespDto = new ConsultCustomerRespDto();
        consultCustomerRespDto.setCellphone("1234");
        consultCustomerRespDto.setBirthDate("23");
        consultCustomerRespDto.setExpeditionCityId("345658");
        consultCustomerRespDto.setExpeditionDate("2345");

        JsonNode result = customerCrmMapperImpl.mapUpdateCustomerDto(bankAccountDto, consultCustomerRespDto);
        Assertions.assertNotNull(result);
    }

    @Test
    public void testMapCreateCustomerDto5() throws Exception {
        JsonNode result = customerCrmMapperImpl.mapUpdateCustomerDto(bankAccountDto, null);
        Assertions.assertNotNull(result);
    }


    @Test
    public void testMapCreateCustomerDto6() throws Exception {
        ConsultCustomerRespDto consultCustomerRespDto = new ConsultCustomerRespDto();
        consultCustomerRespDto.setCellphone("1234");
        consultCustomerRespDto.setBirthDate("23");
        consultCustomerRespDto.setExpeditionCityId("BOG");
        consultCustomerRespDto.setExpeditionDate("2345");

        JsonNode result = customerCrmMapperImpl.mapUpdateCustomerDto(bankAccountDto, consultCustomerRespDto);
        Assertions.assertNotNull(result);
    }

    @Test
    public void testMapCreateCustomerDto7() throws Exception {
        ConsultCustomerRespDto consultCustomerRespDto = new ConsultCustomerRespDto();
        consultCustomerRespDto.setCellphone("1234");
        consultCustomerRespDto.setBirthDate("23");
        consultCustomerRespDto.setExpeditionCityId("BOG");
        consultCustomerRespDto.setExpeditionDate("2345");
        JsonNode result = customerCrmMapperImpl.mapUpdateCustomerDto(bankAccountDto, consultCustomerRespDto);
        Assertions.assertNotNull(result);
    }
}
