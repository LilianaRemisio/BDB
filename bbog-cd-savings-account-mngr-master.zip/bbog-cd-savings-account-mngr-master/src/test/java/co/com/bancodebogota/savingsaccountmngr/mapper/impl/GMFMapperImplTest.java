package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.dto.gmf.GMFTaxExemptionMarkAddRqDTO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class GMFMapperImplTest {

    @InjectMocks
    private GMFMapperImpl gMFTaxMapperImpl;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapRequestDto() {
        GMFTaxExemptionMarkAddRqDTO result = gMFTaxMapperImpl.mapGmfRequestDto("accountNumber",
                "officeCode", "identityType", "identityNumber", "clientName",
                "cellphone", "SDA");

        Assertions.assertEquals(GMFTaxExemptionMarkAddRqDTO.class, result.getClass());
        Assertions.assertEquals("accountNumber", result.getAcctBasicInfo().getAcctId());
        Assertions.assertEquals("officeCode", result.getAcctBasicInfo().getBankInfo().getBranchId());
        Assertions.assertEquals("identityType", result.getOtherIdentDoc().getTypeId());
        Assertions.assertEquals("identityNumber", result.getOtherIdentDoc().getParticipantId());
        Assertions.assertEquals("clientName", result.getFullName());
        Assertions.assertEquals("cellphone", result.getPhoneNum().getPhone());
    }
}