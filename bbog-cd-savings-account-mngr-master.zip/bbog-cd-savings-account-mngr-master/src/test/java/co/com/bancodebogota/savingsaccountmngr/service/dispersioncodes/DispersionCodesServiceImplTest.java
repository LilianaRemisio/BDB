package co.com.bancodebogota.savingsaccountmngr.service.dispersioncodes;

import co.com.bancodebogota.dto.custcatteredinqrs.CustCatteredInqRsDto;
import co.com.bancodebogota.dto.custcatteredinqrs.establishacctinfo.EstablishAcctInfoDto;
import co.com.bancodebogota.dto.payrolldispersions.GetInfoByNitDto;
import co.com.bancodebogota.dto.payrolldispersions.PayrollDispersionsRsDto;
import co.com.bancodebogota.dto.products.AcctBasicInfoDto;
import co.com.bancodebogota.enums.EPayrollCodes;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.savingsaccountmngr.mapper.PayrollDispersionsMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

public class DispersionCodesServiceImplTest {

    @Mock
    private RestExchangeV2 restExchange;
    @Mock
    private PayrollDispersionsMapper payrollDispersionsMapper;
    @InjectMocks
    private DispersionCodesServiceImpl dispersionCodesServiceImpl;

    private final HttpHeaders headers = new HttpHeaders();

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(dispersionCodesServiceImpl, "endpointAccountsAdapter", "localhost");

        headers.set("X-RqUID", null);
        headers.set("X-Channel", "DIG482");
    }

    @Test
    public void testGetCompaniesByCode() throws AbsBdbServiceException {
        AcctBasicInfoDto acctBasicInfoDto = new AcctBasicInfoDto();
        acctBasicInfoDto.setAcctId("AcctId");
        EstablishAcctInfoDto establishAcctInfoDto = new EstablishAcctInfoDto();
        establishAcctInfoDto.setAcctBasicInfo(acctBasicInfoDto);

        List<EstablishAcctInfoDto> listEstablishAcctInfoDto = new ArrayList<>();
        listEstablishAcctInfoDto.add(establishAcctInfoDto);

        CustCatteredInqRsDto custCatteredInqRsDto = new CustCatteredInqRsDto();
        custCatteredInqRsDto.setEstablishAcctInfo(listEstablishAcctInfoDto);

        PayrollDispersionsRsDto payrollDispersionsRsDto = new PayrollDispersionsRsDto();
        payrollDispersionsRsDto.setEstablishAcctInfoDtoList(listEstablishAcctInfoDto);

        when(restExchange.exchange(anyString(), any(), any(), any(), eq(CustCatteredInqRsDto.class)))
                .thenReturn(new ResponseEntity<>(custCatteredInqRsDto, HttpStatus.OK));

        PayrollDispersionsRsDto result = dispersionCodesServiceImpl.getPayrollDispersionsRsDto(
                "dispersionCode", null, null, "channel", "rqUID");
        Assertions.assertEquals("AcctId", result.getEstablishAcctInfoDtoList().get(0).getAcctBasicInfo().getAcctId());
    }

    @Test
    public void testGetCompaniesByCodeWithEmptyBody() {
        when(restExchange.exchange(anyString(), any(), any(), any(), eq(CustCatteredInqRsDto.class)))
                .thenReturn(new ResponseEntity<>(null, HttpStatus.OK));

        try {
            dispersionCodesServiceImpl.getCompaniesByCode(
                    "dispersionCode", null, null, "channel", "rqUID");
        } catch (AbsBdbServiceException e) {
            Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getCode());
        }
    }

    @Test
    public void testGetCompaniesByCodeError() {
        when(restExchange.exchange(anyString(), any(), any(), any(), eq(CustCatteredInqRsDto.class)))
                .thenReturn(new ResponseEntity<>(null, HttpStatus.NOT_FOUND));

        try {
            dispersionCodesServiceImpl.getCompaniesByCode(
                    "dispersionCode", null, null, "channel", "rqUID");
        } catch (AbsBdbServiceException e) {
            Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getCode());
        }
    }

    @Test
    public void testGetPayrollDispersionsRsDtoWithNullEstablishAcctInfoDtoList() throws AbsBdbServiceException {
        when(restExchange.exchange(anyString(), any(), any(), any(), eq(CustCatteredInqRsDto.class)))
                .thenReturn(new ResponseEntity<>(null, HttpStatus.OK));

        AcctBasicInfoDto acctBasicInfoDto = new AcctBasicInfoDto();
        acctBasicInfoDto.setAcctId("AcctId");
        EstablishAcctInfoDto establishAcctInfoDto = new EstablishAcctInfoDto();
        establishAcctInfoDto.setAcctBasicInfo(acctBasicInfoDto);

        CustCatteredInqRsDto custCatteredInqRsDto = new CustCatteredInqRsDto();
        custCatteredInqRsDto.setEstablishAcctInfo(null);

        when(restExchange.exchange(anyString(), any(), any(), any(), eq(CustCatteredInqRsDto.class)))
                .thenReturn(new ResponseEntity<>(custCatteredInqRsDto, HttpStatus.OK));

        PayrollDispersionsRsDto result = dispersionCodesServiceImpl.getPayrollDispersionsRsDto(
                "dispersionCode", "N", "123", "channel", "rqUID");
        Assertions.assertTrue(result.getEstablishAcctInfoDtoList().isEmpty());
    }

    @Test
    public void testGetEPayrollCodes() throws AbsBdbServiceException {
        AcctBasicInfoDto acctBasicInfoDto = new AcctBasicInfoDto();
        EstablishAcctInfoDto establishAcctInfoDto = new EstablishAcctInfoDto();
        List<EstablishAcctInfoDto> establishAcctInfoDtoList = new ArrayList<>();

        acctBasicInfoDto.setAcctType("N");
        acctBasicInfoDto.setAcctId("8001413975");
        establishAcctInfoDto.setAcctBasicInfo(acctBasicInfoDto);
        establishAcctInfoDto.setLegalName("DTN POLI NAL TES GRAL");
        establishAcctInfoDtoList.add(establishAcctInfoDto);

        CustCatteredInqRsDto custCatteredInqRsDto = new CustCatteredInqRsDto();

        custCatteredInqRsDto.setEstablishAcctInfo(establishAcctInfoDtoList);

        when(payrollDispersionsMapper.mapDispersionCode(any())).thenReturn(custCatteredInqRsDto);
        PayrollDispersionsRsDto payrollDispersionsRsDto = dispersionCodesServiceImpl.getPayrollDispersionsRsDto(
                "SUFR", "N", "123", "channel", "rqUID");
        Assertions.assertEquals(EPayrollCodes.DTN_POLI_NAL_TES_GRAL.getLegalName(), payrollDispersionsRsDto.getEstablishAcctInfoDtoList().get(0).getLegalName());
    }

    @Test
    public void testGetNitInfoWithoutDV() throws AbsBdbServiceException {
        GetInfoByNitDto getInfoByNitDto = new GetInfoByNitDto();
        getInfoByNitDto.setCompanyName("EMPRESA PRUEBAS");

        when(restExchange.exchange(anyString(), any(), any(), any(), eq(GetInfoByNitDto.class)))
                .thenReturn(new ResponseEntity<>(getInfoByNitDto, HttpStatus.OK));

        GetInfoByNitDto result = dispersionCodesServiceImpl.getNitInfo(headers, "123456789");
        Assertions.assertEquals("EMPRESA PRUEBAS", result.getCompanyName());
    }

    @Test
    public void testGetNitInfo() throws AbsBdbServiceException {
        GetInfoByNitDto getInfoByNitDto = new GetInfoByNitDto();
        getInfoByNitDto.setCompanyName("EMPRESA PRUEBAS");

        when(restExchange.exchange(anyString(), any(), any(), any(), eq(GetInfoByNitDto.class)))
                .thenReturn(new ResponseEntity<>(getInfoByNitDto, HttpStatus.OK));

        GetInfoByNitDto result = dispersionCodesServiceImpl.getNitInfo(headers, "1111111111");
        Assertions.assertEquals("EMPRESA PRUEBAS", result.getCompanyName());
    }

    @Test
    public void testGetNitInfoWithEmptyBody() {
        when(restExchange.exchange(anyString(), any(), any(), any(), eq(GetInfoByNitDto.class)))
                .thenReturn(new ResponseEntity<>(null, HttpStatus.OK));

        try {
            dispersionCodesServiceImpl.getNitInfo(headers, "1111111111");
        } catch (AbsBdbServiceException e) {
            Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getCode());
        }
    }

    @Test
    public void testGetNitInfoError() {
        when(restExchange.exchange(anyString(), any(), any(), any(), eq(GetInfoByNitDto.class)))
                .thenReturn(new ResponseEntity<>(null, HttpStatus.NOT_FOUND));

        try {
            dispersionCodesServiceImpl.getNitInfo(headers, "1111111111");
        } catch (AbsBdbServiceException e) {
            Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, e.getCode());
        }
    }

    @Test
    public void testCalculateVerifyDigit() {
        String digitVerify1 = dispersionCodesServiceImpl.calculateVerifyDigit("123456789");
        String digitVerify2 = dispersionCodesServiceImpl.calculateVerifyDigit("123456780");

        Assertions.assertEquals("6", digitVerify1);
        Assertions.assertEquals("0", digitVerify2);
    }
}
