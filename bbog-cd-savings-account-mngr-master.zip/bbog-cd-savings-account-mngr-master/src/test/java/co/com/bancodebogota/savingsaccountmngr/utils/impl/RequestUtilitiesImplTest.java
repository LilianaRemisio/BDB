package co.com.bancodebogota.savingsaccountmngr.utils.impl;

import co.com.bancodebogota.dto.masterdata.TutorOfficeDef;
import co.com.bancodebogota.enums.EChannel;
import co.com.bancodebogota.model.entities.ChannelDto;
import co.com.bancodebogota.model.entitiesold.AccountLog;
import co.com.bancodebogota.model.repositories.AccountLogRepository;
import co.com.bancodebogota.model.repositories.ChannelRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

public class RequestUtilitiesImplTest {

    @Mock
    private AccountLogRepository accountLogRepository;
    @Mock
    private ChannelRepository channelRepository;
    @InjectMocks
    private RequestUtilitiesImpl requestUtilities;

    private final ChannelDto channelDto = new ChannelDto();

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        channelDto.setId(5);
        channelDto.setDescription("MFZ");
    }

    @Test
    public void getNextCeoCode() {
        List<TutorOfficeDef> tutorOfficeDefList = getList();

        AccountLog accountLog = new AccountLog();
        accountLog.setCeoCode("0978");

        when(accountLogRepository.findLastCeoCode(any())).thenReturn("0000");
        String result = requestUtilities.getNextCeoCode(tutorOfficeDefList);
        Assertions.assertNull(result);
    }

    @Test
    public void getNextCeoCodeNull() {
        List<TutorOfficeDef> tutorOfficeDefList = getList();

        AccountLog accountLog = new AccountLog();
        accountLog.setCeoCode("0978");

        when(accountLogRepository.findLastCeoCode(any())).thenReturn(null);
        String result = requestUtilities.getNextCeoCode(tutorOfficeDefList);
        Assertions.assertEquals("0978", result);
    }

    private List<TutorOfficeDef> getList() {
        TutorOfficeDef tutorOfficeDef = new TutorOfficeDef();
        tutorOfficeDef.setPremiumCode("premium");
        tutorOfficeDef.setCode("code");
        tutorOfficeDef.setDomicileCode("0978");

        TutorOfficeDef tutorOfficeDef2 = new TutorOfficeDef();
        tutorOfficeDef2.setPremiumCode("premium");
        tutorOfficeDef2.setCode("code");
        tutorOfficeDef2.setDomicileCode("0979");

        List<TutorOfficeDef> tutorOfficeDefList = new ArrayList<>();

        tutorOfficeDefList.add(tutorOfficeDef);
        tutorOfficeDefList.add(tutorOfficeDef2);

        return tutorOfficeDefList;
    }

    @Test
    public void testGetChannelFromLauncher() {
        when(channelRepository.findChannelIdByDescription(anyString())).thenReturn(channelDto);

        int result = requestUtilities.getChannelFromLauncher("6", "MFZ");
        Assertions.assertEquals(5, result);
    }

    @Test
    public void testGetChannelFromLauncherNull() {
        when(channelRepository.findChannelIdByDescription(anyString())).thenReturn(channelDto);

        int result = requestUtilities.getChannelFromLauncher("2", "channel");
        Assertions.assertEquals(1, result);
    }

    @Test
    public void testGetChannelFromLauncherBV() {

        this.channelDto.setDescription("BancaVirtual");
        this.channelDto.setId(6);
        when(channelRepository.findChannelIdByDescription(anyString())).thenReturn(channelDto);

        int result = requestUtilities.getChannelFromLauncher("6", "BancaVirtual");
        Assertions.assertEquals(6, result);
    }

    @Test
    public void testGetChannelFromLauncherBM() {

        this.channelDto.setDescription("BM");
        this.channelDto.setId(3);
        when(channelRepository.findChannelIdByDescription(anyString())).thenReturn(channelDto);

        int result = requestUtilities.getChannelFromLauncher("3", "BM");
        Assertions.assertEquals(3, result);
    }

    @Test
    public void testGetChannelFromLauncherWEB() {
        when(channelRepository.findChannelIdByDescription(anyString())).thenReturn(channelDto);

        int result = requestUtilities.getChannelFromLauncher("6", "WEB");
        Assertions.assertEquals(5, result);
    }

    @Test
    public void testGetChannelFromLauncherOPB001() {
        when(channelRepository.findChannelIdByDescription(anyString())).thenReturn(channelDto);

        int result = requestUtilities.getChannelFromLauncher("6", "OPB001");
        Assertions.assertEquals(5, result);
    }

    @Test
    public void testGetChannelFromLauncherMediumTypeNull() {
        when(channelRepository.findChannelIdByDescription(anyString())).thenReturn(channelDto);

        int result = requestUtilities.getChannelFromLauncher(null, "test");
        Assertions.assertEquals(5, result);
    }

    @Test
    public void testGetChannelFromLauncherMedium3() {
        when(channelRepository.findChannelIdByDescription(anyString())).thenReturn(channelDto);

        int result = requestUtilities.getChannelFromLauncher("3", "test");
        Assertions.assertEquals(4, result);
    }

    @Test
    public void testValidateOpbChannel() {

        String result = requestUtilities.validateOpbChannel("OPB001", EChannel.OPB001);
        Assertions.assertEquals("OPB001", result);
    }

    @Test
    public void testValidateOpbChannelWEB() {

        String result = requestUtilities.validateOpbChannel("WEB", EChannel.WEB);
        Assertions.assertEquals("WEB", result);
    }
}

