package co.com.bancodebogota.savingsaccountmngr.controller;

import co.com.bancodebogota.dto.balanceinquiry.AccInfoDto;
import co.com.bancodebogota.dto.customer.CustomerStatusDto;
import co.com.bancodebogota.dto.customer.DigitalAccountRsDto;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.products.AcctBasicInfoType;
import co.com.bancodebogota.dto.products.ProductDto;
import co.com.bancodebogota.dto.responsereactivation.ReactivationRsDto;
import co.com.bancodebogota.dto.responsereactivation.ReactivationRspDto;
import co.com.bancodebogota.savingsaccountmngr.service.customer.ICustomerService;
import co.com.bancodebogota.savingsaccountmngr.service.customer.ICustomerServiceV2;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.when;

public class CustomerControllerTest {

    @Mock
    private ICustomerService customerService;
    @Mock
    private ICustomerServiceV2 customerServiceV2;
    @InjectMocks
    private CustomerController customerController;
    @InjectMocks
    private AccInfoDto accInfoDto = new AccInfoDto();
    @InjectMocks
    private ReactivationRsDto responseReactivationDto = new ReactivationRsDto();
    @InjectMocks
    private ReactivationRspDto acctBasicInfoDTO = new ReactivationRspDto();
    @InjectMocks
    private AcctBasicInfoType acctBasicInfoType = new AcctBasicInfoType();

    private final DispatcherDto dispatcherDto = new DispatcherDto();
    private final HttpHeaders httpHeaders = new HttpHeaders();
    private final ObjectMapper testMapper = new ObjectMapper();

    @BeforeEach
    public void setUp() throws IOException {
        MockitoAnnotations.openMocks(this);

        dispatcherDto.setIdentityType("C");
        dispatcherDto.setIdentityNumber("1234");

        testMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        InputStream inputBalanceInquiry = getClass().getResourceAsStream("/balanceInquiry.json");
        accInfoDto = testMapper.readValue(inputBalanceInquiry, AccInfoDto.class);

        InputStream inputaccBasicInfoType = getClass().getResourceAsStream("/accBasicInfoType.json");
        acctBasicInfoType = testMapper.readValue(inputaccBasicInfoType, AcctBasicInfoType.class);
    }

    @Test
    public void testCustomerInfo() throws Exception {
        when(customerService.getCustomerInfo(any())).thenReturn(null);

        ResponseEntity<JsonNode> customerInfo = customerController.customerInfo(httpHeaders);
        Assertions.assertEquals(HttpStatus.OK, customerInfo.getStatusCode());
    }

    @Test
    public void testCustomerInfoV2() throws Exception {
        when(customerServiceV2.getProductsStatus(any(), anyString())).thenReturn(null);

        ResponseEntity<CustomerStatusDto> customerInfo = customerController.productsStatus(new HttpHeaders(), "055AH");
        Assertions.assertEquals(HttpStatus.OK, customerInfo.getStatusCode());
    }

    @Test
    public void testHasDigitalAccount() throws Exception {
        when(customerService.hasDigitalAccount(anyString(), anyString(), anyString(), anyString())).thenReturn(new DigitalAccountRsDto());

        ResponseEntity<DigitalAccountRsDto> digitalAccount = customerController.customerHasDigitalAccount(httpHeaders);
        Assertions.assertNotNull(digitalAccount);
    }

    @Test
    public void testGetProduct() throws Exception {
        when(customerService.getProducts(any())).thenReturn(any());

        ResponseEntity<List<ProductDto>> digitalAccount = customerController.getProduct(httpHeaders);
        Assertions.assertNotNull(digitalAccount);
    }

    @Test
    public void testGetProductsInactives() throws Exception {
        when(customerService.getInactiveProducts(any())).thenReturn(any());

        ResponseEntity<List<ProductDto>> productsInactive = customerController.getProductsInactive(httpHeaders);
        Assertions.assertNotNull(productsInactive);
    }

    @Test
    public void testGetBalanceInquiry() throws Exception {
        when(customerService.getBalanceInquiry(any(), any())).thenReturn(accInfoDto);

        ResponseEntity<AccInfoDto> accInfoDtoResponseEntity = customerController.getBalanceInquiry(httpHeaders, acctBasicInfoType);
        Assertions.assertNotNull(accInfoDtoResponseEntity);
    }

    @Test
    public void testPutreactivationAccount() throws Exception {
        when(customerService.reactivateAccount(any(), any())).thenReturn(responseReactivationDto);

        ResponseEntity<ReactivationRsDto> accInfoDtoResponseEntity = customerController.productReactivateAccount(httpHeaders, acctBasicInfoDTO);
        Assertions.assertNotNull(accInfoDtoResponseEntity);
    }
}
