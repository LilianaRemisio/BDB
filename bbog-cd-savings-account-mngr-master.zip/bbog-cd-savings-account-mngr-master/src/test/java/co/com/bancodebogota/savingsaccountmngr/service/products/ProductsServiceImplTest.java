package co.com.bancodebogota.savingsaccountmngr.service.products;

import co.com.bancodebogota.dto.products.AcctBasicInfoDto;
import co.com.bancodebogota.dto.products.ProductAccountDto;
import co.com.bancodebogota.dto.products.ProductDto;
import co.com.bancodebogota.dto.products.ProductsHandledDto;
import co.com.bancodebogota.service.product.IProductService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

public class ProductsServiceImplTest {

    @Mock
    private IProductService productService;
    @InjectMocks
    private ProductsServiceImpl productsService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetClientProducts() throws Exception {
        when(productService.getProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(new ProductAccountDto());

        ProductAccountDto products = productsService.getClientProducts("identityType", "identityNumber",
                "rqUid", "WEB", "userIp");
        Assertions.assertNotNull(products);
    }

    @Test
    public void testGetFilteredAccountList() throws Exception {
        ObjectMapper testMapper = new ObjectMapper();
        InputStream inputStream = getClass().getResourceAsStream("/ProductAccountDto.json");
        ProductAccountDto productAccountDto = testMapper.readValue(inputStream, ProductAccountDto.class);

        when(productService.getProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);

        List<AcctBasicInfoDto> response = productsService.getFilteredAccountsList("identityNumber", "rqUid",
                "FMV", "userIp", "4915110200109679");

        Assertions.assertEquals("885021741", response.get(0).getAcctId());
        Assertions.assertEquals("622024917", response.get(1).getAcctId());
    }

    @Test
    public void testGetFilteredAccountListEmptyCards() throws Exception {
        ObjectMapper testMapper = new ObjectMapper();
        InputStream inputStream = getClass().getResourceAsStream("/ProductAccountDto.json");
        ProductAccountDto productAccountDto = testMapper.readValue(inputStream, ProductAccountDto.class);
        productAccountDto.setProductAccount(new ArrayList<>());

        when(productService.getProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);

        List<AcctBasicInfoDto> response = productsService.getFilteredAccountsList("identityNumber", "rqUid",
                "FMV", "userIp", "4915110200109679");

        Assertions.assertTrue(response.isEmpty());
    }

    @Test
    public void testGetFilteredCards() {
        ProductDto productDto = new ProductDto();
        productDto.setProductStatusCode("A");
        productDto.setProductId("4915110205541124");
        productDto.setProductType("DEB");

        ProductDto productDto1 = new ProductDto();
        productDto1.setProductStatusCode("N");
        productDto1.setProductId("4915110205541124");
        productDto1.setProductType("DEB");

        ProductDto productDto2 = new ProductDto();
        productDto2.setProductStatusCode("P");
        productDto2.setProductId("4915110205541124");
        productDto2.setProductType("DEB");

        ProductDto productDto3 = new ProductDto();
        productDto3.setProductStatusCode("R");
        productDto3.setProductId("4915110205541124");
        productDto3.setProductType("DEB");

        List<ProductDto> productDtoList = new ArrayList<>();
        productDtoList.add(productDto);
        productDtoList.add(productDto1);
        productDtoList.add(productDto2);
        productDtoList.add(productDto3);

        ProductAccountDto productAccountDto = new ProductAccountDto();
        productAccountDto.setProductAccount(productDtoList);

        ProductsHandledDto productsHandledDto = productsService.getFilteredCards(productAccountDto);
        Assertions.assertNotNull(productsHandledDto);
    }
}

