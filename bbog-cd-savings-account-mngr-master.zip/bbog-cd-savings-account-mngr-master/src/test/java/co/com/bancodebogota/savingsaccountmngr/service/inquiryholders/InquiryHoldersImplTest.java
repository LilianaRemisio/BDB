package co.com.bancodebogota.savingsaccountmngr.service.inquiryholders;

import co.com.bancodebogota.dto.customer.Customer;
import co.com.bancodebogota.dto.products.Account;
import co.com.bancodebogota.dto.products.LimitsAccountRq;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.rest.RestExchangeV2;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

public class InquiryHoldersImplTest {

    @Mock
    private RestExchangeV2 restExchange;

    @InjectMocks
    private InquiryHoldersImpl inquiryHoldersService;

    private LimitsAccountRq accountInfo;
    private String rqUID;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        Customer customer = new Customer();
        Account account = new Account();

        customer.setIdentificationNumber("123456");
        customer.setIdentificationType("C");
        account.setAccountNumber("123456");
        account.setAccountType("SDA");
        account.setAccountSubType("SDAT");

        accountInfo = new LimitsAccountRq();
        accountInfo.setAccount(account);
        accountInfo.setCustomer(customer);

        rqUID = "test-rqUID";

        ReflectionTestUtils.setField(inquiryHoldersService, "endpointAccountsAdapter", "http://localhost:8080");

    }

    @Test
    public void testGetOwnershipSuccess() throws AbsBdbServiceException {
        JsonNode responseBody = new ObjectMapper().createObjectNode().put("ownership", "01");
        ResponseEntity<JsonNode> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.OK);

        when(restExchange.exchange(any(String.class), eq(accountInfo), eq(HttpMethod.POST), any(HttpHeaders.class), eq(JsonNode.class)))
                .thenReturn(responseEntity);

        String ownership = inquiryHoldersService.getOwnership(accountInfo, rqUID);

        assertEquals("01", ownership);
    }

    @Test
    public void testGetOwnershipFail() {
        ResponseEntity<JsonNode> responseEntity = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);

        when(restExchange.exchange(any(String.class), eq(accountInfo), eq(HttpMethod.POST), any(HttpHeaders.class), eq(JsonNode.class)))
                .thenReturn(responseEntity);

        assertThrows(AbsBdbServiceException.class, () -> {
            inquiryHoldersService.getOwnership(accountInfo, rqUID);
        });
    }
}