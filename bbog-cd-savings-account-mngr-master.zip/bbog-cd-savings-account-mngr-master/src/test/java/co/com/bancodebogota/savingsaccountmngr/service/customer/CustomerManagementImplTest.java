package co.com.bancodebogota.savingsaccountmngr.service.customer;

import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.db.savings.dto.jpa.Address1Dto;
import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.dto.customer.ConsultCustomerRespDto;
import co.com.bancodebogota.dto.customer.RequestCustomerInquiry;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.savingsaccountmngr.mapper.CustomerUpdateMapper;
import co.com.bancodebogota.savingsaccountmngr.mapper.ICustomerCrmMapper;
import co.com.bancodebogota.savingsaccountmngr.service.request.IRequestService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

public class CustomerManagementImplTest {

    @Mock
    private IRequestService requestService;
    @Mock
    private ICustomerCrmMapper customerCrmMapper;
    @Mock
    private CustomerUpdateMapper customerUpdateMapper;
    @Mock
    private RestExchangeV2 restExchange;
    @Mock
    private ICustomerService customerService;
    @InjectMocks
    private CustomerManagementImpl customerManagementImpl;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(customerManagementImpl, "customerApiEndpoint", "http://localhost:8081");
        ReflectionTestUtils.setField(customerManagementImpl, "tvsApiKey", "abc123");
    }

    @Test
    public void testCreateCustomerOpenApi() throws AbsBdbServiceException {
        when(restExchange.exchange(anyString(), any(), any(), any(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        when(customerUpdateMapper.mapCreateCustomerRequestByCreate(any(), anyString())).thenReturn(null);
        doNothing().when(requestService).saveRequestEvent(anyLong(), any(), anyString());
        BankAccountDto b = new BankAccountDto();
        b.setIdentityNumber("123");
        b.setRequestId(47);
        b.setChannel("channel");
        b.setUserIp("190.98.98.188");
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-FORWARDED-FOR", "12.34.56");
        boolean createdCustomer = customerManagementImpl.createCustomer(b, headers);
        Assertions.assertTrue(createdCustomer);
    }

    @Test
    public void testCreateCustomerOpenApiFailDobleCheckTrue() throws AbsBdbServiceException {
        when(restExchange.exchange(anyString(), any(), any(), any(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
        when(customerUpdateMapper.mapCreateCustomerRequestByCreate(any(), anyString())).thenReturn(null);
        when(customerService.getCustomerInfoFromBackend(anyString(), anyString(), anyString(), anyString())).thenReturn(new ConsultCustomerRespDto());
        doNothing().when(requestService).saveRequestEvent(anyLong(), any(), anyString());
        BankAccountDto b = new BankAccountDto();
        b.setIdentityNumber("123");
        b.setRequestId(47);
        b.setChannel("channel");
        b.setUserIp("190.98.98.188");
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-FORWARDED-FOR", "12.34.56");
        headers.add("X-AuthUuid", "sjdfhsdjbfi");
        boolean createdCustomer = customerManagementImpl.createCustomer(b, headers);
        Assertions.assertTrue(createdCustomer);
    }

    @Test
    public void testCreateCustomerOpenApiFailDobleCheckFalse() throws AbsBdbServiceException {
        when(restExchange.exchange(anyString(), any(), any(), any(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR));
        when(customerUpdateMapper.mapCreateCustomerRequestByCreate(any(), anyString())).thenReturn(null);
        when(customerCrmMapper.mapCreateCustomerDto(any())).thenReturn(new RequestCustomerInquiry());
        doNothing().when(requestService).saveRequestEvent(anyLong(), any(), anyString());
        BankAccountDto b = new BankAccountDto();
        b.setIdentityNumber("123");
        b.setRequestId(47);
        b.setChannel("channel");
        b.setUserIp("190.98.98.188");
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-FORWARDED-FOR", "12.34.56");
        try {
            customerManagementImpl.createCustomer(b, headers);
        } catch (Exception e) {
            Assertions.assertEquals("Error creating customer in CRM", e.getMessage());
        }
    }

    @Test
    public void testUpdateCustomerOpenApi() throws AbsBdbServiceException, IOException {
        when(restExchange.exchange(anyString(), any(), any(), any(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));

        String object= "{\"customerUpdateReq\":{\"custInfo\":{\"custId\":[{\"expeditionPlace\":null,\"custIdentNum\":{\"value\":\"1101752603\"},\"issueLoc\":\"\",\"issDt\":\"2004-01-01\",\"custIdentType\":{\"value\":\"C\"},\"passportCountry\":\"\"}],\"personInfo\":{\"birthDt\":\"1986-01-01\",\"contactInfo\":[{\"contactStatus\":\"\",\"prefTimeStart\":\"\",\"contactName\":\"BIBIANA MORENO\",\"emailAddr\":\"Dulce.melcocha@gmail.com\",\"postAddr\":{\"stateProv\":\"25\",\"country\":\"COL\",\"addr1\":\"TV;21;;7-225;;;;;;;COL;25;25513000;Nari\u00f1o ;\",\"city\":\"\",\"postalCode\":\"\",\"cityId\":\"513\",\"addrType\":\"34\"},\"activationPhone\":{\"phoneNum\":{\"areaDialingCode\":\"\",\"phoneType\":\"12\",\"phone\":\"3004352098\",\"dialingCode\":\"\"}},\"prefTimeEnd\":\"\",\"phoneNum\":{\"areaDialingCode\":\"\",\"phoneType\":\"12\",\"phone\":\"3004352098\",\"dialingCode\":\"\"},\"contactPref\":\"\",\"url\":\"\"}],\"gender\":\"F\",\"tiNInfo\":{\"tiNType\":\"\",\"certCode\":\"\",\"taxId\":\"\"},\"employment\":[{\"occupation\":\"\",\"occupationCode\":7,\"employmentId\":\"0010\"}],\"personName\":{\"legalName\":\"\",\"firstName\":\"BIBIANA\",\"lastName\":\"MORENO\",\"secondLastName\":\"GARCIA\",\"nickname\":\"\",\"nameSuffix\":\"\",\"fullName\":\"\",\"middleName\":\"LUCIA\",\"titlePrefix\":\"\"},\"driversLicense\":{\"stateProv\":\"BOG\",\"country\":\"COL\",\"licenseNum\":\"\"},\"birthPlace\":\"25513000\",\"taxPayerInd\":null,\"nationality\":\"COL\",\"dependents\":0,\"spouseName\":\"\",\"fatca\":\"COL\",\"maritalStatus\":\"S\",\"educationalLevel\":\"2\"},\"financialData\":{\"income\":200000,\"economicActivity\":\"\",\"costsReport\":\"0\",\"totalLiabilities\":{\"curAmt\":{\"curConvertRule\":\"\",\"amt\":2000000,\"curCode\":\"COP\",\"curRate\":0}},\"totalAssests\":{\"curAmt\":{\"curConvertRule\":\"\",\"amt\":6000000,\"curCode\":\"COP\",\"curRate\":0}},\"descEconomicActivity\":\"\",\"economicStatus\":\"\",\"expenses\":100000}},\"updateSafeInfo\":true}}";
        ObjectMapper mapper = new ObjectMapper();

        JsonNode jsonNode = mapper.readTree(object);

        when(customerCrmMapper.mapUpdateCustomerDto(any(BankAccountDto.class), any(ConsultCustomerRespDto.class)))
                .thenReturn(jsonNode);
        BankAccountDto bankAccountDto = new BankAccountDto();
        bankAccountDto.setAddress1Dto(new Address1Dto());
        bankAccountDto.setIdentityNumber("1234");

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("X-AuthUuid", "sjdfhsdjbfi");

        Assertions.assertTrue(customerManagementImpl.updateCustomer(bankAccountDto, new ConsultCustomerRespDto(), httpHeaders));
    }
}
