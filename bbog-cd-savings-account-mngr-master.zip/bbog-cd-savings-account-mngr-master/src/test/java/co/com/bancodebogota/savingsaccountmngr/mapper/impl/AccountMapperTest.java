package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountDto;
import co.com.bancodebogota.dto.account.AccountData;
import co.com.bancodebogota.dto.account.OpeningAccountDto;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.dispatcher.SellerDto;
import co.com.bancodebogota.dto.dispatcher.SpecificProductInfoDto;
import co.com.bancodebogota.dto.fatca.FatcaDto;
import co.com.bancodebogota.dto.gmf.GmfDto;
import co.com.bancodebogota.dto.masterdata.TutorOfficeDef;
import co.com.bancodebogota.dto.monitorplus.MonitorAccountCreateDto;
import co.com.bancodebogota.model.entities.FatcaEntity;
import co.com.bancodebogota.savingsaccountmngr.service.masterdata.IMasterdataService;
import co.com.bancodebogota.savingsaccountmngr.utils.RequestUtilities;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class AccountMapperTest {

    @Mock
    private IMasterdataService masterdataService;
    @Mock
    private RequestUtilities requestUtilities;
    @InjectMocks
    private AccountMapperImpl accountMapper;

    private final OpeningAccountDto openingAccountDto = new OpeningAccountDto();
    private final TutorOfficeDef tutorOfficeDef = new TutorOfficeDef();
    private final ObjectMapper testMapper = new ObjectMapper();

    @BeforeEach
    public void setUp() {
        openingAccountDto.setOfficeCode("2131");
        openingAccountDto.setPhoneNumber("3058791234");
        openingAccountDto.setEmailAddr("test@gmail.com");
        openingAccountDto.setFirstName("julian");
        openingAccountDto.setSecondName("david");
        openingAccountDto.setFirstLastName("carrazco");
        openingAccountDto.setSecondLastName("mesa");
        openingAccountDto.setGender("M");
        openingAccountDto.setAcctSubType("061AH");
        openingAccountDto.setBirthDt("1970-06-15");
        openingAccountDto.setOccupationId("1");
        openingAccountDto.setSegCommercial("0000");
        openingAccountDto.setCeoCode("1234");

        tutorOfficeDef.setId(1);
        tutorOfficeDef.setPremiumCode("premiumCode");
        tutorOfficeDef.setCode("code");
        tutorOfficeDef.setDomicileCode("DomicileCode");

        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapperOpeningAccountDto() {
        CreateAccountDto response = accountMapper.mapOpeningAccountDto(openingAccountDto, "1030685411", "C", "rquid", "Oficina");
        Assertions.assertEquals("C", response.getBbtipodoc());
        Assertions.assertEquals("1970-06-15", response.getBirthdate());
        Assertions.assertTrue(response.isTxInOffice());
    }

    @Test
    public void testMapperOpeningAccountDtoWeb() {
        CreateAccountDto response = accountMapper.mapOpeningAccountDto(openingAccountDto, "1030685411", "C", "rquid", "Web");
        Assertions.assertEquals("1234", response.getBbcodceo());
        Assertions.assertFalse(response.isTxInOffice());
    }

    @Test
    public void testMapperOpeningAccountDtoWebNotCodeCeo() {
        openingAccountDto.setCeoCode("");
        CreateAccountDto response = accountMapper.mapOpeningAccountDto(openingAccountDto, "1030685411", "C", "rquid", "Web");
        Assertions.assertEquals("0000", response.getBbcodceo());
        Assertions.assertFalse(response.isTxInOffice());
    }

    @Test
    public void testMapperOpeningAccountDtoAssited() {
        CreateAccountDto response = accountMapper.mapOpeningAccountDto(openingAccountDto, "1030685411", "C", "rquid", "Oficina");
        Assertions.assertEquals("1234", response.getBbcodceo());
        Assertions.assertTrue(response.isTxInOffice());
    }

    @Test
    public void testMapperOpeningAccountDtoAssistedNotCodeCeo() {
        openingAccountDto.setCeoCode("");
        CreateAccountDto response = accountMapper.mapOpeningAccountDto(openingAccountDto, "1030685411", "C", "rquid", "Oficina");
        Assertions.assertEquals("0000", response.getBbcodceo());
        Assertions.assertTrue(response.isTxInOffice());
    }


    @Test
    public void testMapperOpeningAccountDtoRequestPremium() {
        openingAccountDto.setSegCommercial("1578");
        when(masterdataService.getDomicilesByPremiumOffice(any())).thenReturn(Collections.singletonList(tutorOfficeDef));
        when(requestUtilities.getNextCeoCode(any())).thenReturn("1010");
        CreateAccountDto response = accountMapper.mapOpeningAccountDto(openingAccountDto, "1030685411", "C", "rquid", "MFZ");
        Assertions.assertEquals("C", response.getBbtipodoc());
        Assertions.assertEquals("1970-06-15", response.getBirthdate());
        Assertions.assertTrue(response.isTxInOffice());
    }

    @Test
    public void testMapperOpeningAccountDtoBirtDateFormat() {
        openingAccountDto.setBirthDt("1970-06-15T05:00:00.000Z");

        CreateAccountDto response = accountMapper.mapOpeningAccountDto(openingAccountDto, "1030685411", "C", "rquid", "Oficina");
        Assertions.assertEquals("1970-06-15", response.getBirthdate());
    }

    @Test
    public void testMapMonitorAccountCreate() {
        MonitorAccountCreateDto response = accountMapper.mapMonitorAccountCreate(openingAccountDto, "123456789", "Web");
        Assertions.assertEquals("Web", response.getChannel());
    }

    @Test
    public void testMapFatcaEntity() {

        FatcaDto fatca = new FatcaDto();
        fatca.setFiscalResidence1("Col");
        fatca.setBirthPlace("Bogota");
        fatca.setTin1("123");
        fatca.setFiscalResidence2("Fra");
        fatca.setTin2("456");
        FatcaEntity response = accountMapper.mapFatcaEntity(fatca, "C", "123456789", "Juan Perea", "0123");
        Assertions.assertEquals(fatca.getBirthPlace(), response.getBirthPlace());
        Assertions.assertEquals(fatca.getFiscalResidence1(), response.getFiscalResidence1());
        Assertions.assertEquals(fatca.getTin1(), response.getTin1());
        Assertions.assertEquals(fatca.getFiscalResidence2(), response.getFiscalResidence2());
        Assertions.assertEquals(fatca.getTin2(), response.getTin2());
        Assertions.assertEquals("123456789", response.getIdentityNumber());
        Assertions.assertEquals("C", response.getIdentityType());
        Assertions.assertEquals("Juan Perea", response.getClientName());
        Assertions.assertEquals("0123", response.getBranchId());
    }

    @Test
    public void mapBankAccountForDBWeb() {
        AccountData accountData = new AccountData();

        GmfDto gmfDto = new GmfDto();
        gmfDto.setRequestId(123L);
        accountData.setGmf(gmfDto);

        accountData.setOpeningAccount(openingAccountDto);
        accountData.setFatca(new FatcaDto());

        SpecificProductInfoDto specificProductInfo = new SpecificProductInfoDto();
        specificProductInfo.setCompanyNitPayroll("123456");

        DispatcherDto dispatcherDto = new DispatcherDto();
        dispatcherDto.setSpecificProductInfo(testMapper.valueToTree(specificProductInfo));

        BankAccountDto response = accountMapper.mapBankAccountForDB(accountData, dispatcherDto);
        Assertions.assertEquals("julian", response.getFirstName());
    }

    @Test
    public void mapBankAccountForDBOffice() {
        AccountData accountData = new AccountData();

        GmfDto gmfDto = new GmfDto();
        gmfDto.setRequestId(123L);
        accountData.setGmf(gmfDto);

        accountData.setOpeningAccount(openingAccountDto);
        accountData.setFatca(new FatcaDto());

        SpecificProductInfoDto specificProductInfo = new SpecificProductInfoDto();
        specificProductInfo.setCompanyNitPayroll("123456");

        DispatcherDto dispatcherDto = new DispatcherDto();
        dispatcherDto.setSpecificProductInfo(testMapper.valueToTree(specificProductInfo));
        dispatcherDto.setChannel("Oficina");

        SellerDto sellerDto = new SellerDto();
        sellerDto.setSellerIdentityNumber("987654321");
        dispatcherDto.setSeller(sellerDto);

        BankAccountDto response = accountMapper.mapBankAccountForDB(accountData, dispatcherDto);
        Assertions.assertEquals("987654321", response.getSellerId());
    }

    @Test
    public void mapBankAccountForDBOfficeWithNullSellerDto() {
        AccountData accountData = new AccountData();

        GmfDto gmfDto = new GmfDto();
        gmfDto.setRequestId(123L);
        accountData.setGmf(gmfDto);

        accountData.setOpeningAccount(openingAccountDto);
        accountData.setFatca(new FatcaDto());

        SpecificProductInfoDto specificProductInfo = new SpecificProductInfoDto();
        specificProductInfo.setCompanyNitPayroll("123456");

        openingAccountDto.setOfficeCodeSeller("987654321");

        DispatcherDto dispatcherDto = new DispatcherDto();
        dispatcherDto.setSpecificProductInfo(testMapper.valueToTree(specificProductInfo));
        dispatcherDto.setChannel("FMV");

        BankAccountDto response = accountMapper.mapBankAccountForDB(accountData, dispatcherDto);
        Assertions.assertEquals("987654321", response.getSellerId());
    }
}
