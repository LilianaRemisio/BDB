package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.dto.pentagon.EventDataDto;
import co.com.bancodebogota.dto.products.ProductDto;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

public class PentagonMapperTest {
    @InjectMocks
    private PentagonMapperImpl pentagonMapper;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testMapInactiveProducts() {
        List<ProductDto> productDtoList = new ArrayList<>();

        ProductDto productDto1 = new ProductDto();
        productDto1.setProductId("123456789");
        productDto1.setProductType("010AH");

        ProductDto productDto2 = new ProductDto();
        productDto2.setProductId("23456789");
        productDto2.setProductType("064AH");

        productDtoList.add(productDto1);
        productDtoList.add(productDto2);

        EventDataDto result = pentagonMapper.mapInactiveProducts(productDtoList);

        Assertions.assertNotNull(result.getPayload());
    }

    @Test
    public void testMapCreateDigitalRequest() {
        EventDataDto result = pentagonMapper.mapCreateDigitalRequest(12L, 200, "SUCCESS");

        Assertions.assertNotNull(result.getPayload());
    }

    @Test
    public void testMapReactivateAccount() {
        EventDataDto result = pentagonMapper.mapReactivateAccount(true);

        Assertions.assertNotNull(result.getPayload());
    }
}
