package co.com.bancodebogota.savingsaccountmngr.service.customer;

import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountDto;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

public class ParticipantServiceImplTest {

    @Mock
    private RestExchangeV2 restExchange;
    @InjectMocks
    private ParticipantServiceImpl participantServiceImpl;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(participantServiceImpl, "customerMngrEndpoint", "localhost/");
    }

    @Test
    public void testGetParticipantInfo() throws Exception {
        String jsonString = "{\"statusCode\":\"OK\",\"participantDispatcherDto\":{\"aanit\":\"nit\"}}";
        ObjectMapper mapper = new ObjectMapper();
        JsonNode response = mapper.readTree(jsonString);

        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(response, HttpStatus.OK));
        CreateAccountDto result = participantServiceImpl.getParticipantInfo("uuid");
        Assertions.assertEquals("nit", result.getAanit());
    }

    @Test
    public void testGetParticipantInfoNull() {
        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(null, HttpStatus.OK));
        CreateAccountDto result = participantServiceImpl.getParticipantInfo("uuid");
        Assertions.assertNull(result);
    }

    @Test
    public void testGetParticipantInfoNotFound() throws Exception {
        String jsonString = "{\"statusCode\":\"NOT_FOUND\",\"participantDispatcherDto\":{\"aanit\":\"nit\"}}";
        ObjectMapper mapper = new ObjectMapper();
        JsonNode response = mapper.readTree(jsonString);

        when(restExchange.exchange(anyString(), any(), any(), any())).thenReturn(new ResponseEntity<>(response, HttpStatus.OK));
        CreateAccountDto result = participantServiceImpl.getParticipantInfo("uuid");
        Assertions.assertNull(result);
    }
}
