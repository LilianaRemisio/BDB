package co.com.bancodebogota.savingsaccountmngr.service.facebookconvertions;

import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.dto.account.AccountData;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.io.InputStream;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

public class ReportMarketingServiceImplTest {

    @Mock
    private RestExchangeV2 restExchange;
    @InjectMocks
    private ReportMarketingServiceImpl reportMarketingServiceImpl;

    private AccountData accountData;
    private DispatcherDto dispatcherDto;
    private final HttpHeaders httpHeaders = new HttpHeaders();

    @BeforeEach
    public void setUp() throws IOException {
        MockitoAnnotations.openMocks(this);

        ReflectionTestUtils.setField(reportMarketingServiceImpl, "reportMarketingApiEndpoint",
                "http://localhost/");

        ObjectMapper mapper = new ObjectMapper();
        InputStream inputStream = getClass().getResourceAsStream("/dispatcher.json");
        InputStream inputStreamAccount = getClass().getResourceAsStream("/accoundData.json");

        dispatcherDto = mapper.readValue(inputStream, DispatcherDto.class);
        accountData = mapper.readValue(inputStreamAccount, AccountData.class);

        httpHeaders.set("X-FORWARDED-FOR", "10.10.10.10");
        httpHeaders.set("X-AuthUuid", "xxxyywww");
        httpHeaders.set("X-DigRequest", "12345");
    }

    @Test
    public void testSendNewAccountToFacebookServiceFai() {
        when(restExchange.exchange(anyString(),
                any(), any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.BAD_REQUEST));

        Boolean result = reportMarketingServiceImpl.sendNewAccountCreateFacebook(accountData,
                dispatcherDto, httpHeaders);
        Assertions.assertFalse(result);
    }

    @Test
    public void testSendNewAccountToFacebookServiceSuccess() {
        when(restExchange.exchange(anyString(),
                any(), any(), any(HttpHeaders.class), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));

        Boolean result = reportMarketingServiceImpl.sendNewAccountCreateFacebook(accountData,
                dispatcherDto, httpHeaders);
        Assertions.assertTrue(result);

    }
}
