package co.com.bancodebogota.savingsaccountmngr.interceptors;

import co.com.bancodebogota.TokenException;
import co.com.bancodebogota.dto.interceptor.AuthenticationExceptionResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class ControllerAdviceTest {

    @InjectMocks
    private ControllerAdvice controllerAdvice;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testHandleTokenException() {
        TokenException tokenException = new TokenException("documentNumber", "serviceName");
        AuthenticationExceptionResponse response = controllerAdvice.handleTokenException(tokenException);
        Assertions.assertNotNull(response);
    }
}
