package co.com.bancodebogota.savingsaccountmngr.service.customer;

import co.com.bancodebogota.debitcards.CardInfoDto;
import co.com.bancodebogota.dto.balanceinquiry.AccInfoDto;
import co.com.bancodebogota.dto.customer.*;
import co.com.bancodebogota.dto.debitcards.debitcarddelivery.Status;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.pentagon.EventDataDto;
import co.com.bancodebogota.dto.products.ProductAccountDto;
import co.com.bancodebogota.dto.products.ProductDto;
import co.com.bancodebogota.dto.products.ProductsHandledDto;
import co.com.bancodebogota.dto.responsereactivation.ReactivationRsDto;
import co.com.bancodebogota.dto.responsereactivation.ReactivationRspDto;
import co.com.bancodebogota.enums.EChannel;
import co.com.bancodebogota.enums.EIdentificationType;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.model.entitiesold.AccountLog;
import co.com.bancodebogota.model.repositories.AccountLogRepository;
import co.com.bancodebogota.rest.RestExchangeV2;
import co.com.bancodebogota.savingsaccountmngr.mapper.IPentagonMapper;
import co.com.bancodebogota.savingsaccountmngr.mapper.IPojoMapper;
import co.com.bancodebogota.savingsaccountmngr.service.products.IProductsService;
import co.com.bancodebogota.service.customer.ICustomerApiService;
import co.com.bancodebogota.service.customerv3.ICustomerApiV3Service;
import co.com.bancodebogota.service.pentagon.IPentagonService;
import co.com.bancodebogota.service.product.IProductService;
import co.com.bancodebogota.service.redis.IRedisApiService;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.InputStream;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

public class CustomerServiceImplTest {

    @Mock
    private ICustomerApiService customerApiService;
    @Mock
    private ICustomerApiV3Service iCustomerApiV3Service;

    @Mock
    private IProductsService productsService;
    @Mock
    private IProductService productServiceProd;
    @Mock
    private AccountLogRepository accountLogRepository;
    @Mock
    private ObjectMapper objectMapper;
    @Mock
    private IPojoMapper custInfoPojoMapper;
    @Mock
    private IRedisApiService redisApiService;
    @Mock
    private RestExchangeV2 restExchange;
    @Mock
    private IPentagonMapper pentagonMapper;
    @Mock
    private IPentagonService pentagonService;

    @InjectMocks
    private AccInfoDto accInfoDto = new AccInfoDto();

    @InjectMocks
    private CustomerServiceImpl customerServiceImpl;

    private final ConsultCustomerRespDto consultCustomerRespDto = new ConsultCustomerRespDto();
    private final AccountLog accountLog = new AccountLog();
    private CustomerManagementRs response;
    private final ResponseBlacklist responseBlacklist = new ResponseBlacklist();
    private final DispatcherDto dispatcherDto = new DispatcherDto();
    private ProductAccountDto productAccountDto = new ProductAccountDto();
    private final ObjectMapper testMapper = new ObjectMapper();
    private final HttpHeaders httpHeaders = new HttpHeaders();

    @BeforeEach
    public void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);

        ReflectionTestUtils.setField(customerServiceImpl, "balanceManagementApiKey", "balanceManagementApiKey");
        ReflectionTestUtils.setField(customerServiceImpl, "balanceInquiryApiEndpoint", "http://localhost");
        ReflectionTestUtils.setField(customerServiceImpl, "reactivationApiEndPoint", "http://localhost");

        consultCustomerRespDto.setFirstName("Test");

        testMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        InputStream inputStream = getClass().getResourceAsStream("/customerOpenApi.json");
        response = testMapper.readValue(inputStream, CustomerManagementRs.class);

        InputStream inputBalanceInquiry = getClass().getResourceAsStream("/balanceInquiry.json");
        accInfoDto = testMapper.readValue(inputBalanceInquiry, AccInfoDto.class);

        accountLog.setAccountNumber("0131002725");

        responseBlacklist.setCanContinue(true);

        dispatcherDto.setIdentityType("C");
        dispatcherDto.setIdentityNumber("1234567890");
        dispatcherDto.setChannel("Web");

        InputStream inputStream2 = getClass().getResourceAsStream("/ProductAccountDto.json");
        productAccountDto = testMapper.readValue(inputStream2, ProductAccountDto.class);

        httpHeaders.set("X-AuthUuid", "rqUID");
        httpHeaders.set("X-Channel", "Web");
        httpHeaders.set("X-Forwarded-For", "10.0.0.0");
        httpHeaders.set("Identification-Number", "MTIzNDU2Qw==");
        httpHeaders.set("X-RqUID", "rqUID");


        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        when(pentagonMapper.mapInactiveProducts(any())).thenReturn(new EventDataDto());
        when(pentagonMapper.mapCreateDigitalRequest(anyLong(), anyInt(), anyString())).thenReturn(new EventDataDto());
        when(pentagonService.publishSns(any(), any(), anyString())).thenReturn(true);
    }

    @Test
    public void testGetCustomerInfoFromBackendCustomer() throws Exception {

        when(customerApiService.getInfo(anyString(), anyString(), anyString(), anyString())).thenReturn(response);
        when(custInfoPojoMapper.mapConsultCustomerRespDto(any())).thenReturn(consultCustomerRespDto);

        ConsultCustomerRespDto result = customerServiceImpl.getCustomerInfoFromBackend("identityNumber", "1234", "channel", "userIp");
        Assertions.assertEquals("Test", result.getFirstName());
    }

    @Test
    public void testGetCustomerInfoFromBackendCustomerNull() throws Exception {
        when(customerApiService.getInfo(anyString(), anyString(), anyString(), anyString())).thenReturn(null);
        when(custInfoPojoMapper.mapConsultCustomerRespDto(any())).thenReturn(null);

        try {
            customerServiceImpl.getCustomerInfoFromBackend("identityNumber", "1234", "channel", "userIp");
        } catch (Exception e) {
            Assertions.assertEquals("Error getCustomerInfoCustomerOpenApi", e.getMessage());
        }
    }

    @Test
    public void testGetCustomerInfo() throws Exception {
        AccountLog accountLog = new AccountLog();
        accountLog.setAccountNumber("accountNumber");
        AccountLog accountLog2 = new AccountLog();
        accountLog2.setAccountNumber("accountNumber2");

        ProductsHandledDto productsHandledDto = new ProductsHandledDto();
        productsHandledDto.getActiveCards().add(new CardInfoDto());
        productsHandledDto.getTempCards().add(new CardInfoDto());

        when(customerApiService.getInfo(anyString(), anyString(), anyString(), anyString())).thenReturn(response);
        when(custInfoPojoMapper.mapConsultCustomerRespDto(any())).thenReturn(consultCustomerRespDto);

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(Boolean.class))).thenReturn(true);
        when(productsService.getClientProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);
        when(iCustomerApiV3Service.getSafeData(anyString(), anyString(), anyString(), anyString())).thenReturn(new SafeInfoDef());
        when(objectMapper.createObjectNode()).thenReturn(testMapper.createObjectNode());
        when(objectMapper.valueToTree(any())).thenReturn(testMapper.createArrayNode());
        when(productsService.getFilteredCards(any())).thenReturn(productsHandledDto);
        when(accountLogRepository.findByAccountNumber("0131002725")).thenReturn(accountLog);
        when(accountLogRepository.findByAccountNumber("0231002725")).thenReturn(accountLog2);
        when(accountLogRepository.findByAccountNumber("0331002725")).thenReturn(null);

        JsonNode response = customerServiceImpl.getCustomerInfo(httpHeaders);
        Assertions.assertNotNull(response);
    }

    @Test
    public void testGetCustomerInfoResponseNull() throws Exception {
        AccountLog accountLog = new AccountLog();
        accountLog.setAccountNumber("accountNumber");
        AccountLog accountLog2 = new AccountLog();
        accountLog2.setAccountNumber("accountNumber2");

        ProductsHandledDto productsHandledDto = new ProductsHandledDto();
        productsHandledDto.getActiveCards().add(new CardInfoDto());
        productsHandledDto.getTempCards().add(new CardInfoDto());

        when(customerApiService.getInfo(anyString(), anyString(), anyString(), anyString())).thenReturn(null);
        when(custInfoPojoMapper.mapConsultCustomerRespDto(any())).thenReturn(consultCustomerRespDto);

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(Boolean.class))).thenReturn(true);
        when(productsService.getClientProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);
        when(iCustomerApiV3Service.getSafeData(anyString(), anyString(), anyString(), anyString())).thenReturn(new SafeInfoDef());
        when(objectMapper.createObjectNode()).thenReturn(testMapper.createObjectNode());
        when(objectMapper.valueToTree(any())).thenReturn(testMapper.createArrayNode());
        when(productsService.getFilteredCards(any())).thenReturn(productsHandledDto);
        when(accountLogRepository.findByAccountNumber("0131002725")).thenReturn(accountLog);
        when(accountLogRepository.findByAccountNumber("0231002725")).thenReturn(accountLog2);
        when(accountLogRepository.findByAccountNumber("0331002725")).thenReturn(null);

        try {
            customerServiceImpl.getCustomerInfo(httpHeaders);
        } catch (Exception e) {
            Assertions.assertEquals("Error getCustomerInfoCustomerOpenApi", e.getMessage());
        }
    }

    @Test
    public void testGetCustomerInfoResponseNull2() throws Exception {
        AccountLog accountLog = new AccountLog();
        accountLog.setAccountNumber("accountNumber");
        AccountLog accountLog2 = new AccountLog();
        accountLog2.setAccountNumber("accountNumber2");

        ProductsHandledDto productsHandledDto = new ProductsHandledDto();
        productsHandledDto.getActiveCards().add(new CardInfoDto());
        productsHandledDto.getTempCards().add(new CardInfoDto());

        when(customerApiService.getInfo(anyString(), anyString(), anyString(), anyString())).thenReturn(response);
        when(custInfoPojoMapper.mapConsultCustomerRespDto(any())).thenReturn(null);

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(Boolean.class))).thenReturn(true);
        when(productsService.getClientProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);
        when(iCustomerApiV3Service.getSafeData(anyString(), anyString(), anyString(), anyString())).thenReturn(new SafeInfoDef());
        when(objectMapper.createObjectNode()).thenReturn(testMapper.createObjectNode());
        when(objectMapper.valueToTree(any())).thenReturn(testMapper.createArrayNode());
        when(productsService.getFilteredCards(any())).thenReturn(productsHandledDto);
        when(accountLogRepository.findByAccountNumber("0131002725")).thenReturn(accountLog);
        when(accountLogRepository.findByAccountNumber("0231002725")).thenReturn(accountLog2);
        when(accountLogRepository.findByAccountNumber("0331002725")).thenReturn(null);

        try {
            customerServiceImpl.getCustomerInfo(httpHeaders);
        } catch (Exception e) {
            Assertions.assertEquals("Customer info not found", e.getMessage());
        }
    }

    @Test
    public void testGetCustomerInfoRequestIdNull() throws Exception {
        AccountLog accountLog = new AccountLog();
        accountLog.setAccountNumber("accountNumber");
        AccountLog accountLog2 = new AccountLog();
        accountLog2.setAccountNumber("accountNumber2");

        ProductsHandledDto productsHandledDto = new ProductsHandledDto();
        productsHandledDto.getActiveCards().add(new CardInfoDto());
        productsHandledDto.getTempCards().add(new CardInfoDto());

        responseBlacklist.setCanContinue(false);

        when(customerApiService.getInfo(anyString(), anyString(), anyString(), anyString())).thenReturn(response);
        when(custInfoPojoMapper.mapConsultCustomerRespDto(any())).thenReturn(consultCustomerRespDto);

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(Boolean.class))).thenReturn(true);
        when(productsService.getClientProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);
        when(iCustomerApiV3Service.getSafeData(anyString(), anyString(), anyString(), anyString())).thenReturn(new SafeInfoDef());
        when(objectMapper.createObjectNode()).thenReturn(testMapper.createObjectNode());
        when(objectMapper.valueToTree(any())).thenReturn(testMapper.createArrayNode());
        when(productsService.getFilteredCards(any())).thenReturn(productsHandledDto);
        when(accountLogRepository.findByAccountNumber("0131002725")).thenReturn(accountLog);
        when(accountLogRepository.findByAccountNumber("0231002725")).thenReturn(accountLog2);
        when(accountLogRepository.findByAccountNumber("0331002725")).thenReturn(null);

        try {
            customerServiceImpl.getCustomerInfo(httpHeaders);
        } catch (Exception e) {
            Assertions.assertEquals("Client in blacklist", e.getMessage());
        }
    }

    @Test
    public void testGetCustomerInfoBlacklist() throws Exception {
        responseBlacklist.setCanContinue(false);

        when(customerApiService.getInfo(anyString(), anyString(), anyString(), anyString())).thenReturn(response);
        when(custInfoPojoMapper.mapConsultCustomerRespDto(any())).thenReturn(consultCustomerRespDto);

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);

        try {
            customerServiceImpl.getCustomerInfo(httpHeaders);
        } catch (Exception e) {
            Assertions.assertNotNull(e);
        }

    }

    @Test
    public void testGetCustomerInfoNotFound() throws Exception {
        when(customerApiService.getInfo(anyString(), anyString(), anyString(), anyString())).thenReturn(null);
        when(custInfoPojoMapper.mapConsultCustomerRespDto(any())).thenReturn(null);

        try {
            customerServiceImpl.getCustomerInfo(httpHeaders);
        } catch (Exception e) {
            Assertions.assertNotNull(e);
        }
    }

    @Test
    public void testHasDigitalAccount() throws Exception {
        setAccountLogDate();

        when(productsService.getClientProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);
        when(accountLogRepository.findByAccountNumber(any())).thenReturn(accountLog);

        DigitalAccountRsDto response = customerServiceImpl
                .hasDigitalAccount("1234567", "authUuid", "channel", "xForwardedFor");

        Assertions.assertEquals("0131002725", response.getAccountNumber());
        Assertions.assertTrue(response.isHasAccount());
    }

    @Test
    public void testHasDigitalAccountDispatcherService() throws Exception {
        setAccountLogDate();

        when(productsService.getClientProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);
        when(accountLogRepository.findByAccountNumber(any())).thenReturn(accountLog);

        DigitalAccountRsDto response = customerServiceImpl.hasDigitalAccount(httpHeaders);

        Assertions.assertEquals("0131002725", response.getAccountNumber());
        Assertions.assertTrue(response.isHasAccount());
    }

    @Test
    public void testHasDigitalAccountNoCustInfoUnivAccessInqRs() throws Exception {
        setAccountLogDate();

        when(productsService.getClientProducts(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenThrow(BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, "", ""));
        when(accountLogRepository.findByAccountNumber(any())).thenReturn(accountLog);

        DigitalAccountRsDto response = customerServiceImpl
                .hasDigitalAccount("1234567", "authUuid", "channel", "xForwardedFor");
        Assertions.assertNull(response.getAccountNumber());
    }

    @Test
    public void testHasDigitalAccountServiceRunning() throws Exception {
        setAccountLogDate();

        when(productsService.getClientProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);
        when(accountLogRepository.findByAccountNumber(any())).thenReturn(accountLog);
        when(redisApiService.getKey(anyString(), anyString(), eq(Boolean.class))).thenReturn(true);

        try {
            customerServiceImpl.hasDigitalAccount("1234567", "authUuid", "channel", "xForwardedFor");
        } catch (Exception e) {
            Assertions.assertEquals("Service already running", e.getMessage());
        }
    }

    @Test
    public void testHasDigitalAccountNoProducts() throws Exception {
        setAccountLogDate();

        when(accountLogRepository.getAccountLogByIdentityNumber(anyString())).thenReturn(Collections.singletonList(accountLog));
        when(productsService.getClientProducts(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenThrow(BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, "", ""));

        DigitalAccountRsDto response = customerServiceImpl
                .hasDigitalAccount("1234567", "authUuid", "channel", "xForwardedFor");
        Assertions.assertEquals("0131002725", response.getAccountNumber());
    }

    @Test
    public void testHasDigitalAccountFail() throws Exception {
        AccountLog accountLog = new AccountLog();
        accountLog.setAccountNumber("accountNumber");

        when(productsService.getClientProducts(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenThrow(BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, "", ""));

        Assertions.assertNotNull(customerServiceImpl.hasDigitalAccount("1234567", "authUuid", "channel", "xForwardedFor"));
    }

    private void setAccountLogDate() throws Exception {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        java.util.Date date = formatter.parse("2018-11-07 12:39:12");
        Timestamp accountDate = new Timestamp(date.getTime());

        accountLog.setDate(accountDate);
        Assertions.assertNotNull(accountDate);
    }


    @Test
    public void testGetCustomerInfoBlackList() throws Exception {
        AccountLog accountLog = new AccountLog();
        accountLog.setAccountNumber("accountNumber");
        AccountLog accountLog2 = new AccountLog();
        accountLog2.setAccountNumber("accountNumber2");

        ProductsHandledDto productsHandledDto = new ProductsHandledDto();
        productsHandledDto.getActiveCards().add(new CardInfoDto());
        productsHandledDto.getTempCards().add(new CardInfoDto());

        responseBlacklist.setCanContinue(false);

        when(customerApiService.getInfo(anyString(), anyString(), anyString(), anyString())).thenReturn(response);
        when(custInfoPojoMapper.mapConsultCustomerRespDto(any())).thenReturn(consultCustomerRespDto);

        when(customerApiService.getBlacklist(anyString(), anyString(), anyString())).thenReturn(responseBlacklist);
        when(redisApiService.saveHash(anyString(), anyString(), any(), anyString(), any(), anyString(), eq(Boolean.class))).thenReturn(true);
        when(productsService.getClientProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);
        when(objectMapper.createObjectNode()).thenReturn(testMapper.createObjectNode());
        when(objectMapper.valueToTree(any())).thenReturn(testMapper.createArrayNode());
        when(productsService.getFilteredCards(any())).thenReturn(productsHandledDto);
        when(accountLogRepository.findByAccountNumber("0131002725")).thenReturn(accountLog);
        when(accountLogRepository.findByAccountNumber("0231002725")).thenReturn(accountLog2);
        when(accountLogRepository.findByAccountNumber("0331002725")).thenReturn(null);

        try {
            customerServiceImpl.getCustomerInfo(httpHeaders);
        } catch (Exception e) {
            Assertions.assertNotNull(e);
        }
    }

    @Test
    public void testGetProduct() throws Exception {
        when(productServiceProd.getProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);
        List<ProductDto> produ =  customerServiceImpl.getProducts(httpHeaders);
        Assertions.assertEquals(5, produ.size());
    }

    @Test
    public void testGetInactiveProducts() throws Exception {
        when(productServiceProd.getProducts(anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(productAccountDto);
        List<ProductDto> produ =  customerServiceImpl.getInactiveProducts(httpHeaders);
        Assertions.assertEquals(1, produ.size());
    }

    @Test
    public void testGetBalanceInquiry() throws AbsBdbServiceException {

        httpHeaders.set("X-CustIdentType","CC");
        httpHeaders.set("X-CustIdentNum", "MTIzNDU2Qw==");
        httpHeaders.set("X-IPAddr", "1.1.1.1");
        httpHeaders.set("X-Name", "CuentaDeAhorros");
        httpHeaders.set("X-CompanyId", "860002964");
        httpHeaders.set("Content-Type", "");

        when(restExchange.exchange(anyString(), any(), any(), any(), eq(AccInfoDto.class)))
                .thenReturn(new ResponseEntity<>(accInfoDto, HttpStatus.OK));

       ObjectMapper mapper = new ObjectMapper();
        ObjectNode rootNode = mapper.createObjectNode();
        rootNode.put("acctId", "0000000000930602");
        JsonNode jsonNode = rootNode;

        byte[] decodedBytes = Base64.getDecoder().decode(httpHeaders.getFirst("X-CustIdentNum"));
        String identityNum = new String(decodedBytes).replaceAll("[^\\d]", "");
        httpHeaders.set("X-CustIdentNum", identityNum);

        AccInfoDto res = customerServiceImpl.getBalanceInquiry(httpHeaders, accInfoDto.getAccInfo().get(0).getAcctBasicInfo().getAcctId());
        Assertions.assertNotNull(res);
    }

    @Test
    public void testGetBalanceInquiryFail() {
        httpHeaders.set("X-CustIdentType","CC");
        httpHeaders.set("X-CustIdentNum", "MTIzNDU2Qw==");
        httpHeaders.set("X-IPAddr", "1.1.1.1");
        httpHeaders.set("X-Name", "CuentaDeAhorros");
        httpHeaders.set("X-CompanyId", "860002964");
        httpHeaders.set("Content-Type", "");

        when(restExchange.exchange(anyString(), any(), any(), any(), eq(AccInfoDto.class)))
                .thenReturn(new ResponseEntity<>(accInfoDto, HttpStatus.INTERNAL_SERVER_ERROR));

        try {
            ObjectMapper mapper = new ObjectMapper();
            ObjectNode rootNode = mapper.createObjectNode();
            rootNode.put("acctId", "0000000000930602");
            JsonNode jsonNode = rootNode;

            byte[] decodedBytes = Base64.getDecoder().decode(httpHeaders.getFirst("X-CustIdentNum"));
            String identityNum = new String(decodedBytes).replaceAll("[^\\d]", "");
            httpHeaders.set("X-CustIdentNum", identityNum);

            AccInfoDto res = customerServiceImpl.getBalanceInquiry(httpHeaders, accInfoDto.getAccInfo().get(0).getAcctBasicInfo().getAcctId());
        } catch (Exception e) {
            Assertions.assertEquals("Error get balance inquiry", e.getMessage());
        }

    }

    @Test
    public void testReactiveAccount() throws AbsBdbServiceException {

        httpHeaders.set("X-CompanyId", "860002964");
        httpHeaders.set("X-Name", "CuentaDeAhorros");
        httpHeaders.add("X-Channel", EChannel.WEB.getNotSpaced());
        httpHeaders.set("X-IPAddr", "1.1.1.1");
        httpHeaders.add("X-GovIssueIdentType", EIdentificationType.CEDULA_CIUDADANIA.getApiType());
        httpHeaders.add("X-IdentSerialNum", "123456");
        httpHeaders.add("Content-Type", "application/json");

        ReactivationRsDto responseReactivationDto = new ReactivationRsDto();
        Status status = new Status();
        status.setServerStatusCode("OK");
        responseReactivationDto.setStatus(status);
        ReactivationRspDto acctBasicInfoDTO = new ReactivationRspDto();

        when(restExchange.exchange(anyString(), any(), any(), any(), eq(ReactivationRsDto.class)))
                .thenReturn(new ResponseEntity<>(responseReactivationDto, HttpStatus.OK));

        httpHeaders.set("X-CustIdentNum", httpHeaders.getFirst("X-IdentSerialNum"));

        ReactivationRsDto res = customerServiceImpl.reactivateAccount(httpHeaders, acctBasicInfoDTO);
        Assertions.assertNotNull(res);
    }

    @Test
    public void testReactiveAccountFail() {
        httpHeaders.set("X-CompanyId", "860002964");
        httpHeaders.set("X-Name", "CuentaDeAhorros");
        httpHeaders.add("X-Channel", EChannel.WEB.getNotSpaced());
        httpHeaders.set("X-IPAddr", "1.1.1.1");
        httpHeaders.add("X-GovIssueIdentType", EIdentificationType.CEDULA_CIUDADANIA.getApiType());
        httpHeaders.add("X-IdentSerialNum", "123456");
        httpHeaders.add("Content-Type", "application/json");

        ReactivationRsDto responseReactivationDto = new ReactivationRsDto();
        ReactivationRspDto acctBasicInfoDTO = new ReactivationRspDto();

        when(restExchange.exchange(anyString(), any(), any(), any(), eq(ReactivationRsDto.class)))
                .thenReturn(new ResponseEntity<>(responseReactivationDto, HttpStatus.INTERNAL_SERVER_ERROR));

        try {
            ReactivationRsDto res = customerServiceImpl.reactivateAccount(httpHeaders, acctBasicInfoDTO);
        } catch (Exception e) {
            Assertions.assertEquals("Error put reactivation account", e.getMessage());
        }

    }
}
