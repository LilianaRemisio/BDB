package co.com.bancodebogota.savingsaccountmngr.controller;

import co.com.bancodebogota.db.savings.dto.jpa.AccountLimitsDto;
import co.com.bancodebogota.db.savings.dto.jpa.BankAccountDto;
import co.com.bancodebogota.db.savings.dto.jpa.CheckTypeLogListDto;
import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountResponseDto;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.monitorplus.MonitorAccountCreateDto;
import co.com.bancodebogota.dto.pentagon.EventDataDto;
import co.com.bancodebogota.dto.products.AccountHierarchyReqDto;
import co.com.bancodebogota.dto.request.RequestCheckDto;
import co.com.bancodebogota.proxy.CheckLogsProxy;
import co.com.bancodebogota.savingsaccountmngr.service.accounts.ISavingsAccountService;
import co.com.bancodebogota.savingsaccountmngr.service.monitorplus.IMonitorService;
import co.com.bancodebogota.savingsaccountmngr.service.pentagon.IEventPentagonService;
import co.com.bancodebogota.savingsaccountmngr.service.request.ICheckLogService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

public class SavingsAccountControllerTest {
    private static final String ERROR_LANZANDO = "java.lang.Exception";
    @Mock
    private CheckLogsProxy checkLogsProxy;
    @Mock
    private ISavingsAccountService savingsAccountService;
    @Mock
    private IMonitorService monitorService;
    @Mock
    private ICheckLogService checkLogService;

    @Mock
    private IEventPentagonService eventPentagonService;

    private final HttpHeaders httpHeaders = new HttpHeaders();
    private final DispatcherDto dispatcherDto = new DispatcherDto();

    @InjectMocks
    private SavingsAccountController savingsAccountController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        httpHeaders.add("X-FORWARDED-FOR", "12.12.12.12");
        httpHeaders.add("User-Agent", "Test");
        httpHeaders.add("access-tokent", "k5DiyCODpYfiZAem4H9kX");

        dispatcherDto.setIdentityType("C");
        dispatcherDto.setIdentityNumber("1234");
        dispatcherDto.setSpecificProductInfoUuid("12345");
        JsonNode data = new ObjectMapper().createObjectNode();
        dispatcherDto.setSpecificProductInfo(data);
    }

    @Test
    public void testCreateAccount() throws Exception {

        BindingResult resultValid = mock(BindingResult.class);
        when(resultValid.hasErrors()).thenReturn(false);
        when(savingsAccountService.createAccountByUuid(any(), any(HttpHeaders.class))).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        ResponseEntity<JsonNode> account = savingsAccountController.createAccountByUuid(httpHeaders, null);
        Assertions.assertNotNull(account);
    }

    @Test
    public void testCreateAccountByDto() throws Exception {
        BindingResult resultValid = mock(BindingResult.class);
        when(resultValid.hasErrors()).thenReturn(false);
        when(savingsAccountService.createAccountByDto(any(), any(HttpHeaders.class))).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        ResponseEntity<CreateAccountResponseDto> account = savingsAccountController.createAccountByDto(httpHeaders, new BankAccountDto());
        Assertions.assertNotNull(account);
    }

    @Test
    public void testCreateAccountByDtoWithCeoCode() throws Exception {
        JsonNode specificProductInfo = dispatcherDto.getSpecificProductInfo();
        ((ObjectNode) specificProductInfo).put("ceoCode", "1413");
        BindingResult resultValid = mock(BindingResult.class);
        when(resultValid.hasErrors()).thenReturn(false);
        when(savingsAccountService.createAccountByDto(any(), any(HttpHeaders.class))).thenReturn(new ResponseEntity<>(HttpStatus.OK));
        ResponseEntity<CreateAccountResponseDto> account = savingsAccountController.createAccountByDto(httpHeaders, new BankAccountDto());
        Assertions.assertNotNull(account);
    }

    @Test
    public void testCreateAccountFail() {
        BindingResult resultValid = mock(BindingResult.class);
        when(resultValid.hasErrors()).thenReturn(true);
        try {
            ResponseEntity<JsonNode> account = savingsAccountController.createAccountByUuid(httpHeaders, null);
            Assertions.assertNull(account);
        } catch (Exception e) {
            Assertions.assertTrue(e.toString().contains("Body"));
        }
    }

    @Test
    public void testSaveCheckTypeLog() {
        BindingResult resutlValid = mock(BindingResult.class);
        when(resutlValid.hasErrors()).thenReturn(false);
        when(checkLogsProxy.saveCheckType(any())).thenReturn(true);

        boolean result = savingsAccountController.saveCheckTypeLog(new CheckTypeLogListDto());
        Assertions.assertTrue(result);
    }

    @Test
    public void testSaveCheckTypeLogFail01() {
        BindingResult resutlValid = mock(BindingResult.class);
        when(resutlValid.hasErrors()).thenReturn(true);
        try {
            boolean check = savingsAccountController.saveCheckTypeLog(new CheckTypeLogListDto());
            Assertions.assertFalse(check);
        } catch (Exception e) {
            Assertions.assertTrue(e.toString().contains("Body"));
        }
    }

    @Test
    public void testSaveCheckTypeLogFail02() {

        try {
            BindingResult resutlValid = mock(BindingResult.class);
            when(resutlValid.hasErrors()).thenReturn(false);
            when(checkLogsProxy.saveCheckType(any())).thenThrow(Exception.class);

            boolean check = savingsAccountController.saveCheckTypeLog(new CheckTypeLogListDto());
            Assertions.assertTrue(check);

        } catch (Exception e) {
            Assertions.assertTrue(e.toString().contains(ERROR_LANZANDO));
        }
    }

    @Test
    public void testGetAccountsByCard() throws Exception {
        when(savingsAccountService.getAccountsByCard(any(), anyString())).thenReturn(null);

        ResponseEntity<JsonNode> response = savingsAccountController.getAccountsByCard(httpHeaders, "cardNumber");
        Assertions.assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void testSetAccountHierarchy() throws Exception {
        when(savingsAccountService.setAccountHierarchy(any(), any())).thenReturn(null);

        ResponseEntity<JsonNode> response = savingsAccountController.setAccountHierarchy(httpHeaders, new AccountHierarchyReqDto());
        Assertions.assertNull(response);
    }

    @Test
    public void testSaveParticipantInfo() throws Exception {
        when(savingsAccountService.saveParticipantInfo(any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));

        ResponseEntity<String> responseEntity = savingsAccountController.saveParticipantInfo(new BankAccountDto(), httpHeaders);
        Assertions.assertNotNull(responseEntity);
    }

    @Test
    public void testGetPayloadInfo() throws Exception {
        when(savingsAccountService.getPayloadInfo(anyString(), anyString())).thenReturn(new ResponseEntity<>(HttpStatus.OK));

        ResponseEntity<JsonNode> result = savingsAccountController.getPayloadInfo("identityNumber", "authUuid");
        Assertions.assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testSaveSessionRedis() throws Exception {
        when(savingsAccountService.saveSessionRedis(any(), any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));

        ResponseEntity<JsonNode> result = savingsAccountController.saveSessionRedis(httpHeaders, null);
        Assertions.assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testGetSessionRedis() throws Exception {
        when(savingsAccountService.getSessionRedis(anyString(), anyString())).thenReturn(new ResponseEntity<>(HttpStatus.OK));

        ResponseEntity<JsonNode> result = savingsAccountController.getSessionRedis("identityNumber", "authUuid");
        Assertions.assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testGetAccountLimits() throws Exception {
        when(savingsAccountService.getAccountLimits()).thenReturn(new ResponseEntity<>(HttpStatus.OK));

        ResponseEntity<JsonNode> result = savingsAccountController.getAccountLimits();
        Assertions.assertEquals(HttpStatus.OK, result.getStatusCode());
    }

    @Test
    public void testSendAccountToMonitorPlusAsync() throws IOException {
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-FORWARDED-FOR", "1.1.1.1");
        headers.set("User-Agent", "Test");
        headers.set("X-RqUuid", "7a5b83ba-9002-4986-9e87-f55ec41d634f");

        ObjectMapper mapper = new ObjectMapper();
        InputStream inputStream = getClass().getResourceAsStream("/MonitorPlus.json");
        MonitorAccountCreateDto monitorAccountCreateDto = mapper.readValue(inputStream, MonitorAccountCreateDto.class);

        when(monitorService.sendAccountToMonitorPlus(any(), any())).thenReturn(true);
        savingsAccountController.sendAccountToMonitorPlusAsync(headers, monitorAccountCreateDto);

        verify(monitorService, atLeast(0)).sendAccountToMonitorPlus(any(), any());
    }

    @Test
    public void testUpdateAccountLimitAsync() {
        AccountLimitsDto accountLimitsDto = new AccountLimitsDto();
        accountLimitsDto.setAcctId("id");

        when(savingsAccountService.updateAccountLimit(any())).thenReturn(true);
        savingsAccountController.updateAccountLimitAsync(accountLimitsDto);
        verify(savingsAccountService, atLeast(0)).updateAccountLimit(accountLimitsDto);
    }

    @Test
    public void testgetAccountLimits() {
        when(eventPentagonService.sendEvent(any(), any())).thenReturn(true);

        ResponseEntity<Boolean> result = savingsAccountController.sendPentagonEvent(new HttpHeaders(), new EventDataDto());
        Assertions.assertEquals(200, result.getStatusCodeValue());
    }

    @Test
    public void testgetAccountLimitsError() {
        when(eventPentagonService.sendEvent(any(), any())).thenReturn(false);

        ResponseEntity<Boolean> result = savingsAccountController.sendPentagonEvent(new HttpHeaders(), new EventDataDto());
        Assertions.assertEquals(500, result.getStatusCodeValue());
    }

    @Test
    public void testSaveCheckOK() {
        when(checkLogService.saveRequestCheckLog(any())).thenReturn(true);
        RequestCheckDto requestCheckDto = new RequestCheckDto();
        requestCheckDto.setRequestId(1234L);
        requestCheckDto.setChecks("{\"product-contract\":true,\"legal-resources\":true,\"gmf\":false,\"fatca\":false}");

        ResponseEntity<Boolean> result = savingsAccountController.saveCheck(requestCheckDto);
        Assertions.assertEquals(200, result.getStatusCodeValue());
    }

    @Test
    public void testSaveCheckError() {
        when(checkLogService.saveRequestCheckLog(any())).thenReturn(false);
        RequestCheckDto requestCheckDto = new RequestCheckDto();
        requestCheckDto.setRequestId(1234L);
        requestCheckDto.setChecks("{\"product-contract\":true,\"legal-resources\":true,\"gmf\":false,\"fatca\":false}");

        ResponseEntity<Boolean> result = savingsAccountController.saveCheck(requestCheckDto);
        Assertions.assertEquals(500, result.getStatusCodeValue());
    }

    @Test
    public void testSaveModel() {
        doNothing().when(savingsAccountService).saveModel(any());

        List<String> request = new ArrayList<>();
        request.add(0, "");
        List<List<String>> requests = new ArrayList<>();
        requests.add(request);

        savingsAccountController.saveModel(requests);
        verify(savingsAccountService, atLeast(0)).saveModel(requests);
    }
}
