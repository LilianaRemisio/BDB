package co.com.bancodebogota.savingsaccountmngr.service.request;

import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.dispatcher.SpecificProductInfoDto;
import co.com.bancodebogota.dto.pentagon.EventDataDto;
import co.com.bancodebogota.dto.request.*;
import co.com.bancodebogota.enums.EChannel;
import co.com.bancodebogota.enums.EEventType;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.model.entities.ParticipantDto;
import co.com.bancodebogota.model.entities.*;
import co.com.bancodebogota.model.repositories.*;
import co.com.bancodebogota.savingsaccountmngr.mapper.IDispatcherMapper;
import co.com.bancodebogota.savingsaccountmngr.mapper.IPentagonMapper;
import co.com.bancodebogota.savingsaccountmngr.mapper.RequestMapper;
import co.com.bancodebogota.savingsaccountmngr.utils.RequestUtilities;
import co.com.bancodebogota.service.pentagon.IPentagonService;
import co.com.bancodebogota.service.redis.IRedisApiService;
import co.com.bancodebogota.service.request.IRequestApiService;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

public class RequestServiceImplTest {

    @Mock
    private IRequestApiService requestApiService;
    @Mock
    private ObjectMapper objectMapper;
    @Mock
    private RequestRepository requestRepository;
    @Mock
    private ParticipantRepository participantRepository;
    @Mock
    private ParticipantInfoRepository participantInfoRepository;
    @Mock
    private LocationRepository locationRepository;
    @Mock
    private RequestEventRepository requestEventRepository;
    @Mock
    private RequestAuthenticationRepository requestAuthenticationRepository;
    @Mock
    private RequestUtilities requestUtilities;
    @Mock
    private IDispatcherMapper dispatcherMapper;
    @Mock
    private IPentagonService eventsService;
    @Mock
    private RequestMapper requestMapper;
    @Mock
    private IRedisApiService redisApiService;
    @Mock
    private IPentagonMapper pentagonMapper;

    @InjectMocks
    private RequestServiceImpl requestServiceImpl;

    private final CreateRequestDto createRequestDto = new CreateRequestDto();
    private InputStream inputStream;
    private final HttpHeaders httpHeaders = new HttpHeaders();
    private final DispatcherDto dispatcherDto = new DispatcherDto();
    private final ObjectMapper testMapper = new ObjectMapper();


    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        LocationDto locationDto = new LocationDto();
        locationDto.setLatitude(0d);
        locationDto.setLongitude(0d);
        locationDto.setIp("ip");
        locationDto.setOfficeCode("001");

        RequestUtmDto requestUtmDto = new RequestUtmDto();
        requestUtmDto.setSource("source");
        requestUtmDto.setMedium("medium");
        requestUtmDto.setCampaign("campaign");
        requestUtmDto.setRefer("refer");

        createRequestDto.setParticipant(new ParticipantDto("C", "12345678"));
        createRequestDto.setLocationInfo(locationDto);
        createRequestDto.setCustomOtp(0);
        createRequestDto.setSourceTeamId(1);
        createRequestDto.setAuthTypeId("1");
        createRequestDto.setMediumType("1");
        createRequestDto.setChannelId("WEB");
        createRequestDto.setClient(true);
        createRequestDto.setProductId(1);
        createRequestDto.setUtmInfo(requestUtmDto);
        createRequestDto.setCreateDigitalRequest(true);

        inputStream = getClass().getResourceAsStream("/dispatcher.json");

        httpHeaders.set("X-AuthUuid", "rqUID");
        httpHeaders.set("X-Channel", "Web");
        httpHeaders.set("X-Forwarded-For", "userIp");
        httpHeaders.set("X-Journey", "journey");
        httpHeaders.set("Identification-Number", "123456");
        httpHeaders.set("X-spiUuid", "spiUuid");
        httpHeaders.set("X-IdentityNumber", "123456");

        dispatcherDto.setChannel("Web");
        dispatcherDto.setIdentityType("C");
        dispatcherDto.setIdentityNumber("123456");

        when(pentagonMapper.mapCreateDigitalRequest(anyLong(), anyInt(), anyString())).thenReturn(new EventDataDto());
        when(eventsService.publishSns(any(), any(), anyString())).thenReturn(true);
    }

    @Test
    public void testCreateRequestV2() throws Exception {
        DispatcherDto dispatcherDto = new DispatcherDto();
        dispatcherDto.setIdentityNumber("123456789");
        dispatcherDto.setAccessType("1");
        dispatcherDto.setCustomerState("NOT_CLIENT");
        dispatcherDto.setChannel("OPB001");
        dispatcherDto.setOfficeCode("0000");

        createRequestDto.setChannelId("OPB001");

        SpecificProductInfoDto specificProductInfoDto = new SpecificProductInfoDto();
        specificProductInfoDto.setRedirectToCardActivation("false");
        dispatcherDto.setSpecificProductInfo(testMapper.valueToTree(specificProductInfoDto));

        when(requestUtilities.validateOpbChannel(eq("OPB001"), eq(EChannel.WEB))).thenReturn("WEB");
        when(requestApiService.createDigitalRequest(any())).thenReturn(Long.valueOf(123));

        when(dispatcherMapper.mapCreateRequest(any(), any())).thenReturn(createRequestDto);
        when(dispatcherMapper.handleFlags(any(), anyBoolean(), anyBoolean(), anyString())).thenReturn(new AuthFlagsDto());

        when(requestRepository.findOfficesEnabledForSarlaft(anyString())).thenReturn(Collections.emptyList());
        when(requestRepository.save(any())).thenReturn(new RequestDto());
        when(participantRepository.findByIdentificationNumber(anyString())).thenReturn(null);
        when(participantRepository.save(any())).thenReturn(new ParticipantDto());
        when(participantInfoRepository.save(any())).thenReturn(new ParticipantInfoDto());
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");
        when(requestAuthenticationRepository.save(any())).thenReturn(new RequestAuthenticationDto());
        when(locationRepository.save(any())).thenReturn(new LocationDto());
        when(requestRepository.saveRequestLocation(anyLong(), anyInt(), any())).thenReturn(0);
        when(requestRepository.saveRequestUtm(anyLong(), anyString(), anyString(), anyString(), anyString(),
                anyString(),
                anyString())).thenReturn(0);
        when(requestRepository.saveRequestEvent(anyLong(), anyLong(), any())).thenReturn(0);
        when(eventsService.publish(any(), any())).thenReturn(true);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);

        AccountRequestV2RsDto resultV2 = requestServiceImpl.createRequestV2(httpHeaders);
        assertEquals(0, resultV2.getAccountRequest().getRequestId());
        AccountRequestV3RsDto resultV3 = requestServiceImpl.createRequestV3(httpHeaders);
        assertEquals(0, resultV3.getAccountRequest().getRequestId());
    }

    @Test
    public void testCreateRequestV2AccesTypeNullCustomerStateClient() throws Exception {
        DispatcherDto dispatcherDto = new DispatcherDto();
        dispatcherDto.setIdentityNumber("123456789");
        dispatcherDto.setCustomerState("ACTIVE");
        dispatcherDto.setChannel("WEB");
        dispatcherDto.setSpecificProductInfo(new ObjectMapper().createObjectNode());

        when(requestUtilities.validateOpbChannel(eq("WEB"), eq(EChannel.WEB))).thenReturn("WEB");
        when(requestApiService.createDigitalRequest(any())).thenReturn(Long.valueOf(123));
        when(dispatcherMapper.mapCreateRequest(any(), any())).thenReturn(createRequestDto);
        when(dispatcherMapper.handleFlags(any(), anyBoolean(), anyBoolean(), anyString())).thenReturn(new AuthFlagsDto());

        when(requestRepository.findOfficesEnabledForSarlaft(anyString())).thenReturn(Collections.emptyList());
        when(requestRepository.save(any())).thenReturn(new RequestDto());
        when(participantRepository.findByIdentificationNumber(anyString())).thenReturn(null);
        when(participantRepository.save(any())).thenReturn(new ParticipantDto());
        when(participantInfoRepository.save(any())).thenReturn(new ParticipantInfoDto());
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");
        when(requestAuthenticationRepository.save(any())).thenReturn(new RequestAuthenticationDto());
        when(locationRepository.save(any())).thenReturn(new LocationDto());
        when(requestRepository.saveRequestLocation(anyLong(), anyInt(), any())).thenReturn(0);
        when(requestRepository.saveRequestUtm(anyLong(), anyString(), anyString(), anyString(), anyString(),
                anyString(),
                anyString())).thenReturn(0);
        when(requestRepository.saveRequestEvent(anyLong(), anyLong(), any())).thenReturn(0);
        when(eventsService.publish(any(), any())).thenReturn(true);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);

        AccountRequestV2RsDto resultV2 = requestServiceImpl.createRequestV2(httpHeaders);
        assertEquals(0, resultV2.getAccountRequest().getRequestId());
        AccountRequestV3RsDto resultV3 = requestServiceImpl.createRequestV3(httpHeaders);
        assertEquals(0, resultV3.getAccountRequest().getRequestId());
    }

    @Test
    public void testCreateRequestV2SpecificProductInfoNull() throws Exception {
        DispatcherDto dispatcherDto = new DispatcherDto();
        dispatcherDto.setIdentityNumber("123456789");
        dispatcherDto.setChannel("WEB");
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);

        try {
            requestServiceImpl.createRequestV3(httpHeaders);
        } catch (Exception e) {
            assertEquals("Error specific product info null", e.getMessage());
        }
    }

    @Test
    public void testCreateRequestWeb() throws Exception {
        SpecificProductInfoDto specificProductInfoDto = new SpecificProductInfoDto();
        specificProductInfoDto.setRedirectToCardActivation("false");
        dispatcherDto.setSpecificProductInfo(testMapper.valueToTree(specificProductInfoDto));

        when(requestUtilities.validateOpbChannel(eq("OPB001"), eq(EChannel.WEB))).thenReturn("WEB");
        when(requestRepository.findOfficesEnabledForSarlaft(anyString())).thenReturn(Collections.emptyList());
        when(requestRepository.save(any())).thenReturn(new RequestDto());
        when(participantRepository.findByIdentificationNumber(anyString())).thenReturn(null);
        when(participantRepository.save(any())).thenReturn(new ParticipantDto());
        when(participantInfoRepository.save(any())).thenReturn(new ParticipantInfoDto());
        when(requestAuthenticationRepository.save(any())).thenReturn(new RequestAuthenticationDto());
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");
        when(locationRepository.save(any())).thenReturn(new LocationDto());
        when(requestRepository.saveRequestLocation(anyLong(), anyInt(), any())).thenReturn(0);
        when(requestRepository.saveRequestUtm(anyLong(), anyString(), anyString(), anyString(), anyString(),
                anyString(),
                anyString())).thenReturn(0);
        when(requestRepository.saveRequestEvent(anyLong(), anyLong(), any())).thenReturn(0);

        AccountRequestRsDto result = requestServiceImpl.createRequest(createRequestDto, "userIp", dispatcherDto);
        assertEquals(0, result.getRequestId());
    }

    @Test
    public void testCreateRequestWithDigital() throws Exception {
        createRequestDto.setCreateDigitalRequest(true);
        createRequestDto.setSpiUuid("spiUuid");

        SpecificProductInfoDto specificProductInfoDto = new SpecificProductInfoDto();
        specificProductInfoDto.setRedirectToCardActivation("true");
        dispatcherDto.setSpecificProductInfo(testMapper.valueToTree(specificProductInfoDto));

        when(requestUtilities.validateOpbChannel(eq("OPB001"), eq(EChannel.WEB))).thenReturn("WEB");
        when(requestRepository.findOfficesEnabledForSarlaft(anyString())).thenReturn(Collections.emptyList());
        when(requestRepository.save(any())).thenReturn(new RequestDto());
        when(participantRepository.findByIdentificationNumber(anyString())).thenReturn(null);
        when(participantRepository.save(any())).thenReturn(new ParticipantDto());
        when(participantInfoRepository.save(any())).thenReturn(new ParticipantInfoDto());
        when(requestAuthenticationRepository.save(any())).thenReturn(new RequestAuthenticationDto());
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");
        when(locationRepository.save(any())).thenReturn(new LocationDto());
        when(requestRepository.saveRequestLocation(anyLong(), anyInt(), any())).thenReturn(0);
        when(requestRepository.saveRequestUtm(anyLong(), anyString(), anyString(), anyString(), anyString(),
                anyString(),
                anyString())).thenReturn(0);
        when(requestApiService.createDigitalRequest(any())).thenReturn(123L);
        when(requestRepository.saveRequestEvent(anyLong(), anyLong(), any())).thenReturn(0);

        AccountRequestRsDto result = requestServiceImpl.createRequest(createRequestDto, "userIp", dispatcherDto);
        assertEquals(0, result.getRequestId());
        assertEquals(123, result.getDigitalId().longValue());
    }

    @Test
    public void testCreateRequestBMErrorDigital() throws Exception {
        createRequestDto.setCreateDigitalRequest(true);
        createRequestDto.setSpiUuid("spiUuid");
        createRequestDto.setChannelId("BM");

        when(requestUtilities.validateOpbChannel(eq("OPB001"), eq(EChannel.WEB))).thenReturn("WEB");
        when(requestRepository.save(any())).thenReturn(new RequestDto());
        when(participantRepository.findByIdentificationNumber(anyString())).thenReturn(null);
        when(participantRepository.save(any())).thenReturn(new ParticipantDto());
        when(participantInfoRepository.save(any())).thenReturn(new ParticipantInfoDto());
        when(requestAuthenticationRepository.save(any())).thenReturn(new RequestAuthenticationDto());
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");
        when(locationRepository.save(any())).thenReturn(new LocationDto());
        when(requestRepository.saveRequestLocation(anyLong(), anyInt(), any())).thenReturn(0);
        when(requestRepository.saveRequestUtm(anyLong(), anyString(), anyString(), anyString(), anyString(),
                anyString(),
                anyString())).thenReturn(0);
        when(requestUtilities.getChannelFromLauncher(anyString(), anyString())).thenReturn(4);
        when(requestApiService.createDigitalRequest(any())).thenThrow(BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, "", "Error creating digital request"));

        try {
            requestServiceImpl.createRequest(createRequestDto, "userIp", dispatcherDto);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            assertEquals("Error al crear la solicitud", e.getMessage());
        }
    }

    @Test
    public void testUpdateRequestEvent() throws Exception {

        RequestEventDto requestEventDto = new RequestEventDto();
        when(requestEventRepository.findByRequestIdAndEventId(anyLong(), anyInt())).thenReturn(new RequestEventDto());
        when(requestEventRepository.save(any())).thenReturn(requestEventDto);

        requestServiceImpl.updateRequestEvent(0L, EEventType.CHECK_CRM_FALLIDO, EEventType.CHECK_CRM_EXITOSO);
        assertNotNull(requestEventDto);
    }

    @Test
    public void testSaveFailedRequest() {

        RequestDto requestDto = new RequestDto();
        requestDto.setId(1);

        when(requestRepository.save(any())).thenReturn(requestDto);
        when(requestAuthenticationRepository.save(any())).thenReturn(new RequestAuthenticationDto());

        requestServiceImpl.saveFailedRequest("authUuid");
        assertNotNull(requestDto);
    }

    @Test
    public void testSaveFailedRequestError() {

        RequestDto requestDto = new RequestDto();
        requestDto.setId(1);

        when(requestRepository.save(any())).thenThrow(new IllegalArgumentException(""));

        requestServiceImpl.saveFailedRequest("authUuid");
        assertNotNull(requestDto);
    }

    @Test
    public void testCreateRequestOpen() throws Exception {
        createRequestDto.setChannelId(EChannel.MFZ.getDescription());
        createRequestDto.setAuthTypeId("5");
        createRequestDto.setLocationInfo(new LocationDto());
        createRequestDto.setUtmInfo(null);

        SpecificProductInfoDto specificProductInfoDto = new SpecificProductInfoDto();
        specificProductInfoDto.setRedirectToCardActivation("false");
        dispatcherDto.setSpecificProductInfo(testMapper.valueToTree(specificProductInfoDto));

        when(requestUtilities.validateOpbChannel(eq("OPB001"), eq(EChannel.WEB))).thenReturn("WEB");
        when(requestRepository.findOfficesEnabledForSarlaft(anyString())).thenReturn(Collections.singletonList("0000"));
        when(requestRepository.save(any())).thenReturn(new RequestDto());
        when(participantRepository.findByIdentificationNumber(anyString())).thenReturn(null);
        when(participantRepository.save(any())).thenReturn(new ParticipantDto());
        when(participantInfoRepository.save(any())).thenReturn(new ParticipantInfoDto());
        when(requestAuthenticationRepository.save(any())).thenReturn(new RequestAuthenticationDto());
        when(objectMapper.writeValueAsString(any())).thenReturn("{}");
        when(locationRepository.save(any())).thenReturn(new LocationDto());
        when(requestRepository.saveRequestLocation(anyLong(), anyInt(), any())).thenReturn(0);
        when(requestRepository.saveRequestUtm(anyLong(), anyString(), anyString(), anyString(), anyString(),
                anyString(),
                anyString())).thenReturn(0);
        when(requestApiService.createDigitalRequest(any())).thenReturn(123L);
        doNothing().when(requestApiService).closeDigitalRequest(any());
        when(requestRepository.saveRequestEvent(anyLong(), anyLong(), any())).thenReturn(0);

        AccountRequestRsDto result = requestServiceImpl.createRequest(createRequestDto, "userIp", dispatcherDto);
        assertEquals(0, result.getRequestId());
        assertEquals(123, result.getDigitalId().longValue());
    }

    @Test
    public void testCloseDigitalByDispatcher() throws IOException, AbsBdbServiceException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        DispatcherDto dispatcherDto = mapper.readValue(inputStream, DispatcherDto.class);

        when(requestRepository.findByIdentityNumberAndRqUuid(anyString(), anyString())).thenReturn(new RequestDto());
        doNothing().when(requestApiService).closeDigitalRequest(any(CloseDigitalRequestDto.class));
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);

        requestServiceImpl.closeDigitalBySession(httpHeaders);
        verify(requestApiService, atLeastOnce()).closeDigitalRequest(any());
    }

    @Test
    public void whenCloseDigital_thenRequestRepositoryIsNull() throws AbsBdbServiceException {
        when(requestRepository.findByIdentityNumberAndRqUuid(anyString(), anyString())).thenReturn(null);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);

        try {
            requestServiceImpl.closeDigitalBySession(httpHeaders);
        } catch (Exception e) {
            assertTrue(e.toString().contains("NullPointerException"));
        }
    }

    @Test
    public void whenCloseDigital_thenDispatcherIsNull() throws AbsBdbServiceException {
        httpHeaders.set("X-AuthUuid", null);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(null);

        try {
            requestServiceImpl.closeDigitalBySession(httpHeaders);
        } catch (Exception e) {
            assertTrue(e.toString().contains("NullPointerException"));
        }
    }

    @Test
    public void whenCloseDigital_thenIdentificationIsNull() throws AbsBdbServiceException {
        dispatcherDto.setIdentityNumber(null);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);

        try {
            requestServiceImpl.closeDigitalBySession(httpHeaders);
        } catch (Exception e) {
            assertTrue(e.toString().contains("NullPointerException"));
        }
    }

    @Test
    public void whenCloseDigital_thenSpecificProductInfoIsNull() throws AbsBdbServiceException {
        dispatcherDto.setSpecificProductInfo(null);
        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);

        try {
            requestServiceImpl.closeDigitalBySession(httpHeaders);
        } catch (Exception e) {
            assertTrue(e.toString().contains("NullPointerException"));
        }
    }

    @Test
    public void testCloseDigitalByDate() throws IOException, AbsBdbServiceException {
        InputStream inputStreamMFZ = getClass().getResourceAsStream("/dispatcher.json");

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        DispatcherDto dispatcherDto = mapper.readValue(inputStream, DispatcherDto.class);
        DispatcherDto dispatcherDtoMFZ = mapper.readValue(inputStreamMFZ, DispatcherDto.class);
        dispatcherDtoMFZ.setChannel("MFZ");

        List<Object[]> requestList = new ArrayList<>();
        requestList.add(new Object[]{123L, dispatcherDto.toString()});
        requestList.add(new Object[]{124L, dispatcherDtoMFZ.toString()});

        when(requestRepository.findAllOpenRequestsByDate(anyString())).thenReturn(requestList);
        when(requestMapper.mapDispatcherByRequestAuth(anyString()))
                .thenReturn(dispatcherDto).thenReturn(dispatcherDtoMFZ);
        doNothing().when(requestApiService).closeDigitalRequest(any(CloseDigitalRequestDto.class));

        requestServiceImpl.closeDigitalByDate(new Date());
        assertEquals("2864409", dispatcherDto.getIdentityNumber());
    }

    @Test
    public void testCloseDigitalByDateFail() {
        List<Object[]> requestList = new ArrayList<>();
        requestList.add(new Object[]{123L, ""});

        when(requestRepository.findAllOpenRequestsByDate(anyString())).thenReturn(requestList);
        when(requestMapper.mapDispatcherByRequestAuth(anyString())).thenReturn(null);

        try {
            requestServiceImpl.closeDigitalByDate(new Date());
        } catch (Exception e) {
            assertTrue(e.toString().contains("NullPointerException"));
        }
    }

    @Test
    public void testCloseDigitalById() throws Exception {
        CloseDigitalRequestDto closeDigitalRequestDto = new CloseDigitalRequestDto();
        closeDigitalRequestDto.setDigRequestId(123L);

        doNothing().when(requestApiService).closeDigitalRequest(any(CloseDigitalRequestDto.class));

        requestServiceImpl.closeDigitalById("", closeDigitalRequestDto);
        assertNotNull(closeDigitalRequestDto.getDigRequestId());
    }

    @Test
    public void testGetFlowTypeIsCardActivation() throws AbsBdbServiceException {
        DispatcherDto dispatcherDto = new DispatcherDto();
        dispatcherDto.setOfficeCode("0000");
        dispatcherDto.setChannel("Web");
        SpecificProductInfoDto data = new SpecificProductInfoDto();
        data.setRedirectToCardActivation("true");
        dispatcherDto.setSpecificProductInfo(testMapper.valueToTree(data));


        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        when(requestRepository.findOfficesEnabledForSarlaft(any())).thenReturn(Collections.singletonList("0000"));
        FlowTypeDto result = requestServiceImpl.getFlowType(httpHeaders);
        assertTrue(result.isCardActivation());
    }

    @Test
    public void testGetFlowTypeIsAssistedSarlaft() throws AbsBdbServiceException {
        DispatcherDto dispatcherDto = new DispatcherDto();
        dispatcherDto.setOfficeCode("0000");
        dispatcherDto.setChannel("Web");
        SpecificProductInfoDto data = new SpecificProductInfoDto();
        data.setRedirectToCardActivation("false");
        dispatcherDto.setSpecificProductInfo(testMapper.valueToTree(data));

        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        when(requestRepository.findOfficesEnabledForSarlaft(any())).thenReturn(Collections.singletonList("0000"));
        FlowTypeDto result = requestServiceImpl.getFlowType(httpHeaders);
        assertTrue(result.isAssistedSarlaft());
    }

    @Test
    public void testGetFlowTypeIsAccountOpening() throws AbsBdbServiceException {
        DispatcherDto dispatcherDto = new DispatcherDto();
        dispatcherDto.setOfficeCode("0101");
        dispatcherDto.setChannel("Web");
        dispatcherDto.setSpecificProductInfo(new ObjectMapper().createObjectNode());

        when(redisApiService.getHash(anyString(), anyString(), anyString(), anyString(), eq(DispatcherDto.class)))
                .thenReturn(dispatcherDto);
        when(requestRepository.findOfficesEnabledForSarlaft(any())).thenReturn(Collections.singletonList("0000"));
        FlowTypeDto result = requestServiceImpl.getFlowType(httpHeaders);
        assertFalse(result.isCardActivation());
        assertFalse(result.isAssistedSarlaft());
    }

    @Test
    public void testCreateDigitalRequestId() throws Exception {
        when(requestApiService.createDigitalRequest(any())).thenReturn(Long.valueOf(123));

        AccountRequestRsDto accountRequestRsDto = requestServiceImpl.createRequestId(httpHeaders);
        assertEquals(123, accountRequestRsDto.getDigitalId());
    }

    @Test
    public void testCreateDigitalRequestIdFail() throws Exception {
        when(requestApiService.createDigitalRequest(any(CreateDigitalRequestDto.class)))
                .thenThrow(BdbExceptionFactory.createExcepcion(HttpStatus.BAD_REQUEST, "", ""));
        AccountRequestRsDto accountRequestRsDto = requestServiceImpl.createRequestId(httpHeaders);
        assertNull(accountRequestRsDto.getDigitalId());
    }
}
