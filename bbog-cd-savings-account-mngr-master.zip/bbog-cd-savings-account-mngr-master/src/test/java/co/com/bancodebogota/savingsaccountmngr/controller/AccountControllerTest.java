package co.com.bancodebogota.savingsaccountmngr.controller;

import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountResponseDto;
import co.com.bancodebogota.dto.account.AccountData;
import co.com.bancodebogota.dto.openapi.AccountDto;
import co.com.bancodebogota.dto.openapi.ProductDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.savingsaccountmngr.service.accounts.IAccountService;
import co.com.bancodebogota.savingsaccountmngr.service.openapi.IOpenApiService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.concurrent.ExecutionException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class AccountControllerTest {

    @Mock
    private IOpenApiService openApiService;
    @Mock
    private IAccountService accountService;
    @InjectMocks
    private AccountController accountController;

    private final HttpHeaders headers = new HttpHeaders();
    private final AccountDto accountDto = new AccountDto();

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        headers.set("key1", "value1");

        accountDto.setSeller("seller");
        accountDto.setGmf(true);
        accountDto.setCeoCode("ceoCode");
        accountDto.setDispersionCode("dispersionCode");
        accountDto.setProductCode("010AH");
    }

    @Test
    public void createAccountByOpenApi() throws AbsBdbServiceException {
        ProductDto productDto = new ProductDto();
        productDto.setNumber("012345678");
        productDto.setRequestId(9299);

        when(openApiService.create(any(), any())).thenReturn(productDto);

        ResponseEntity<ProductDto> response = accountController.createAccountByOpenApi(headers, accountDto);

        Assertions.assertNotNull(response.getBody());
        Assertions.assertEquals("012345678", response.getBody().getNumber());
        Assertions.assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Test
    public void createAccountByOpenApiFail() throws AbsBdbServiceException {
        when(openApiService.create(any(), any(AccountDto.class))).thenReturn(new ProductDto());

        ResponseEntity<ProductDto> response = accountController.createAccountByOpenApi(headers, accountDto);

        Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    public void testAccountOpening() throws AbsBdbServiceException, ExecutionException, InterruptedException {

        CreateAccountResponseDto createAccountResponseDto = new CreateAccountResponseDto();
        createAccountResponseDto.setAccountNumber("89127398312");
        when(accountService.accountOpening(any(), any())).thenReturn(createAccountResponseDto);

        ResponseEntity<CreateAccountResponseDto> response = accountController.accountOpening(headers, new AccountData());

        Assertions.assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Test
    public void createAccountV3() throws AbsBdbServiceException {
        ProductDto productDto = new ProductDto();
        productDto.setNumber("012345678");

        when(openApiService.create(any(), any())).thenReturn(productDto);

        ResponseEntity<ProductDto> response = accountController.createAccountV3(headers, accountDto);

        Assertions.assertNotNull(response.getBody());
        Assertions.assertEquals("012345678", response.getBody().getNumber());
        Assertions.assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }

    @Test
    public void testAccountOpeningV4() throws AbsBdbServiceException, ExecutionException, InterruptedException {

        CreateAccountResponseDto createAccountResponseDto = new CreateAccountResponseDto();
        createAccountResponseDto.setAccountNumber("89127398312");
        when(accountService.accountOpeningV4(any(), any(), any())).thenReturn(createAccountResponseDto);

        ResponseEntity<CreateAccountResponseDto> response = accountController.createAccountV4(headers, new AccountData());

        Assertions.assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }
}
