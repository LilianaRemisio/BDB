package co.com.bancodebogota.savingsaccountmngr.mapper.impl;

import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.request.AuthFlagsDto;
import co.com.bancodebogota.dto.request.CreateRequestDto;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;

import java.io.InputStream;

public class DispatcherMapperImplTest {

    private final DispatcherMapperImpl dispatcherMapperImpl = new DispatcherMapperImpl();

    private final DispatcherDto dispatcherDto = new DispatcherDto();
    private final ObjectMapper testMapper = new ObjectMapper();

    private final ObjectNode specificProductInfo = testMapper.createObjectNode();
    private final ObjectNode utmInfo = testMapper.createObjectNode();

    private final HttpHeaders headers = new HttpHeaders();

    @BeforeEach
    public void setUp() throws Exception {
        dispatcherDto.setIdentityType("C");
        dispatcherDto.setIdentityNumber("123456789");
        dispatcherDto.setCustomerState("ACTIVE");
        dispatcherDto.setChannel("WEB");
        dispatcherDto.setAccessType("1");
        dispatcherDto.setOfficeCode("0000");

        headers.set("X-Journey", "CorrienteAsistido");


        String specificProductInfoString = """
                {
                    "accountType": "CUENTA NOMINA",
                    "productId": "010AH",
                    "Journey": "Digital",
                    "AppName": "CuentaDeAhorros",
                    "authMethod": "cifin",
                    "customOtpAuthMethod": "false"
                  }""";

        ObjectMapper mapper = new ObjectMapper();
        JsonNode specificProductInfo = mapper.readTree(specificProductInfoString);

        dispatcherDto.setSpecificProductInfo(specificProductInfo);

        utmInfo.put("utm_source", "banca_movil");
        utmInfo.put("utm_medium", "utm_medium");
        utmInfo.put("utm_campaign", "utm_campaign");
        utmInfo.put("utm_refer", "utm_refer");

        dispatcherDto.setSpecificProductInfo(testMapper.valueToTree(specificProductInfo));
        dispatcherDto.setUtmInfo(utmInfo);
        dispatcherDto.setBranch(null);

        dispatcherDto.setWasteInfo("{\"waste001\":null,\"waste002\":null,\"waste003\":null,\"waste004\":null,\"waste005\":null,\"waste006\":null}");
    }

    @Test
    public void testMapCreateRequestBM() {
        headers.set("X-Journey", "CorrienteAsistido");
        dispatcherDto.setChannel("BM");
        CreateRequestDto result = dispatcherMapperImpl.mapCreateRequest(headers, dispatcherDto);

        Assertions.assertEquals("BM", result.getChannelId());
        Assertions.assertEquals(0, result.getCustomOtp());
        Assertions.assertNull(result.getMediumType());
    }

    @Test
    public void testMapCreateRequestBMUtmInfoNull() {
        headers.set("X-Journey", "FlujoAsistido");

        utmInfo.put("utm_source", "");
        utmInfo.put("utm_medium", "");
        utmInfo.put("utm_campaign", "");
        utmInfo.put("utm_term", "");
        utmInfo.put("utm_content", "");
        utmInfo.put("utm_refer", "");
        utmInfo.remove("utm_refer");

        dispatcherDto.setSpecificProductInfo(testMapper.valueToTree(specificProductInfo));
        dispatcherDto.setUtmInfo(utmInfo);
        CreateRequestDto result = dispatcherMapperImpl.mapCreateRequest(headers, dispatcherDto);

        Assertions.assertEquals("WEB", result.getChannelId());
        Assertions.assertEquals(0, result.getCustomOtp());
        Assertions.assertNull(result.getMediumType());
    }

    @Test
    public void testMapCreateRequestWithUtmInfoNull() {
        headers.set("X-Journey", "CorrienteAsistido");

        dispatcherDto.setUtmInfo(null);
        CreateRequestDto result = dispatcherMapperImpl.mapCreateRequest(headers, dispatcherDto);

        Assertions.assertNull(result.getUtmInfo());
    }

    @Test
    public void testMapCreateRequestWithEmptyUtmInfo() {
        headers.set("X-Journey", "CorrienteAsistido");

        dispatcherDto.setUtmInfo(testMapper.createObjectNode());
        CreateRequestDto result = dispatcherMapperImpl.mapCreateRequest(headers, dispatcherDto);

        Assertions.assertNull(result.getUtmInfo());
    }

    @Test
    public void testMapCreateRequestWEBAndCustomOtp() throws Exception {
        headers.set("X-Journey", "CorrienteAsistido");

        utmInfo.put("utm_source", "");
        utmInfo.put("fbclid", "fbclid");

        String specificProductInfoString = """
                {
                    "accountType": "CUENTA NOMINA",
                    "productId": "010AH",
                    "Journey": "Digital",
                    "AppName": "CuentaDeAhorros",
                    "authMethod": "validateCustomOtp",
                    "customOtpAuthMethod": "false"
                  }""";

        ObjectMapper mapper = new ObjectMapper();
        JsonNode specificProductInfo = mapper.readTree(specificProductInfoString);

        dispatcherDto.setSpecificProductInfo(specificProductInfo);

        CreateRequestDto result = dispatcherMapperImpl.mapCreateRequest(headers, dispatcherDto);

        Assertions.assertEquals("WEB", result.getChannelId());
        Assertions.assertEquals(1, result.getCustomOtp());
        Assertions.assertNull(result.getMediumType());
    }

    @Test
    public void testHandleFlagsNullWaste() throws Exception {
        AuthFlagsDto result = dispatcherMapperImpl.handleFlags(dispatcherDto, true, false, "identityNumber");
        Assertions.assertTrue(result.isEnableFullFlow());
    }

    @Test
    public void testHandleFlagsUnsafeSim() throws Exception {

        dispatcherDto.setWasteInfo("{\"waste001\":true,\"waste002\":null,\"waste003\":null,\"waste004\":null,\"waste005\":null,\"waste006\":null}");

        try {
            dispatcherMapperImpl.handleFlags(dispatcherDto, true, true, "identityNumber");
        } catch (AbsBdbServiceException e) {
            Assertions.assertNotNull(e);
        }
    }

    @Test
    public void testHandleFlagsCustomOtp() throws Exception {
        dispatcherDto.setWasteInfo("{\"waste001\":null,\"waste002\":true,\"waste003\":null,\"waste004\":null,\"waste005\":null,\"waste006\":null}");

        AuthFlagsDto result = dispatcherMapperImpl.handleFlags(dispatcherDto, true, true, "identityNumber");
        Assertions.assertFalse(result.isEnableFullFlow());
    }

    @Test
    public void testHandleFlagsFailQuestions() {
        dispatcherDto.setWasteInfo("{\"waste001\":null,\"waste002\":null,\"waste003\":true,\"waste004\":null,\"waste005\":null,\"waste006\":null}");

        try {
            dispatcherMapperImpl.handleFlags(dispatcherDto, true, true, "identityNumber");
        } catch (AbsBdbServiceException e) {
            Assertions.assertNotNull(e);
        }
    }

    @Test
    public void testHandleFlagsPotentialRiskPayroll() throws Exception {
        dispatcherDto.setWasteInfo("{\"waste001\":null,\"waste002\":null,\"waste003\":null,\"waste004\":true,\"waste005\":null,\"waste006\":null}");

        AuthFlagsDto result = dispatcherMapperImpl.handleFlags(dispatcherDto, true, true, "identityNumber");
        Assertions.assertFalse(result.isEnableFullFlow());
    }

    @Test
    public void testHandleFlagsPotentialRiskNotPayroll() throws Exception {
        dispatcherDto.setWasteInfo("{\"waste001\":null,\"waste002\":null,\"waste003\":null,\"waste004\":true,\"waste005\":null,\"waste006\":null}");

        try {
            dispatcherMapperImpl.handleFlags(dispatcherDto, false, true, "identityNumber");
        } catch (AbsBdbServiceException e) {
            Assertions.assertNotNull(e);
        }
    }

    @Test
    public void testHandleFlagsUnsafeSimAndCustomOtp() throws Exception {
        dispatcherDto.setWasteInfo("{\"waste001\":true,\"waste002\":true,\"waste003\":null,\"waste004\":null,\"waste005\":null,\"waste006\":null}");

        try {
            dispatcherMapperImpl.handleFlags(dispatcherDto, true, true, "identityNumber");
        } catch (AbsBdbServiceException e) {
            Assertions.assertNotNull(e);
        }
    }

    @Test
    public void testHandleFlagsCustomOtpAndPotentialRiskPayroll() throws Exception {
        dispatcherDto.setWasteInfo("{\"waste001\":null,\"waste002\":true,\"waste003\":null,\"waste004\":true,\"waste005\":null,\"waste006\":null}");

        AuthFlagsDto result = dispatcherMapperImpl.handleFlags(dispatcherDto, true, true, "identityNumber");
        Assertions.assertFalse(result.isEnableFullFlow());
    }

    @Test
    public void testHandleFlagsThreeFlags() throws Exception {
        dispatcherDto.setWasteInfo("{\"waste001\":true,\"waste002\":true,\"waste003\":null,\"waste004\":true,\"waste005\":null,\"waste006\":null}");

        try {
            dispatcherMapperImpl.handleFlags(dispatcherDto, false, true, "identityNumber");
            Assertions.fail();
        } catch (AbsBdbServiceException e) {
            Assertions.assertNotNull(e);
        }
    }

    @Test
    public void testHandleFlagsNullWaste003() throws Exception {
        AuthFlagsDto result = dispatcherMapperImpl.handleFlags(dispatcherDto, true, false, "identityNumber");
        Assertions.assertTrue(result.isEnableFullFlow());
    }

    @Test
    public void testHandleFlagsNotNullWaste003() throws Exception {
        dispatcherDto.setWasteInfo("{\"waste001\":null,\"waste002\":null,\"waste003\":true,\"waste004\":null,\"waste005\":null,\"waste006\":null}");

        AuthFlagsDto result = dispatcherMapperImpl.handleFlags(dispatcherDto, true, false, "identityNumber");
        Assertions.assertTrue(result.isEnableFullFlow());
    }

    @Test
    public void testHandleFlagsBranch() throws Exception {
        dispatcherDto.setBranch(3);

        AuthFlagsDto result = dispatcherMapperImpl.handleFlags(dispatcherDto, true, false, "identityNumber");
        Assertions.assertTrue(result.isEnableFullFlow());
    }

    @Test
    public void testHandleFlagsBranchNot3() throws Exception {
        dispatcherDto.setBranch(2);

        AuthFlagsDto result = dispatcherMapperImpl.handleFlags(dispatcherDto, true, false, "identityNumber");
        Assertions.assertTrue(result.isEnableFullFlow());
    }

    @Test
    public void testHandleFlagsBranchNull() throws Exception {
        AuthFlagsDto result = dispatcherMapperImpl.handleFlags(dispatcherDto, true, false, "identityNumber");
        Assertions.assertTrue(result.isEnableFullFlow());
    }

    @Test
    public void testHandleFlagsEnableWasteFlow() throws Exception {

        InputStream inputStream = getClass().getResourceAsStream("/dispatcher.json");

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        DispatcherDto dispatcherDto = mapper.readValue(inputStream, DispatcherDto.class);
        AuthFlagsDto result = dispatcherMapperImpl.handleFlags(dispatcherDto, true, true, "identityNumber");
        Assertions.assertFalse(result.isEnableFullFlow());
    }

    @Test
    public void testHandleFlagsPaySheet() throws Exception {
        AuthFlagsDto result = dispatcherMapperImpl.handleFlags(dispatcherDto, true, true, "identityNumber");
        Assertions.assertTrue(result.isEnableFullFlow());
    }

    @Test
    public void testHandleFlagsNoPaySheet() throws Exception {
        AuthFlagsDto result = dispatcherMapperImpl.handleFlags(dispatcherDto, false, true, "identityNumber");
        Assertions.assertTrue(result.isEnableFullFlow());
    }

}
