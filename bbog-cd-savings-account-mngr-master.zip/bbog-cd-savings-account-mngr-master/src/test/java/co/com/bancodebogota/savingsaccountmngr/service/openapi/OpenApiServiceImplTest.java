package co.com.bancodebogota.savingsaccountmngr.service.openapi;

import co.com.bancodebogota.db.savings.dto.jpa.CreateAccountResponseDto;
import co.com.bancodebogota.dto.customer.CustomerManagementRs;
import co.com.bancodebogota.dto.dispatcher.DispatcherDto;
import co.com.bancodebogota.dto.openapi.AccountDto;
import co.com.bancodebogota.dto.openapi.ProductDto;
import co.com.bancodebogota.dto.request.AccountRequestRsDto;
import co.com.bancodebogota.dto.request.CreateRequestDto;
import co.com.bancodebogota.enums.EChannel;
import co.com.bancodebogota.exception.AbsBdbServiceException;
import co.com.bancodebogota.exception.impl.BdbExceptionFactory;
import co.com.bancodebogota.savingsaccountmngr.mapper.IDispatcherMapper;
import co.com.bancodebogota.savingsaccountmngr.mapper.IOpenApiMapper;
import co.com.bancodebogota.savingsaccountmngr.service.accounts.IAccountService;
import co.com.bancodebogota.savingsaccountmngr.service.request.IRequestService;
import co.com.bancodebogota.savingsaccountmngr.utils.RequestUtilities;
import co.com.bancodebogota.service.customer.ICustomerApiService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;

import java.io.IOException;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

public class OpenApiServiceImplTest {

    @Mock
    private IOpenApiMapper openApiMapper;
    @Mock
    private IDispatcherMapper dispatcherMapper;
    @Mock
    private ICustomerApiService customerApiService;
    @Mock
    private IAccountService accountService;
    @Mock
    private IRequestService requestService;
    @Mock
    private RequestUtilities requestUtilities;
    @InjectMocks
    private OpenApiServiceImpl openApiService;

    private final AccountDto account = new AccountDto();
    private final HttpHeaders headers = new HttpHeaders();
    private final CreateAccountResponseDto createAccountResponseDto = new CreateAccountResponseDto();

    @BeforeEach
    public void setUp() throws AbsBdbServiceException, IOException {
        MockitoAnnotations.openMocks(this);

        headers.set("x-ipaddr", "0.0.0.1");
        headers.set("x-clienttype", "ACTIVE");
        headers.set("x-channel", "Web");
        headers.set("x-custidenttype", "CC");
        headers.set("x-custidentnum", "123456789");
        headers.set("x-officecode", "0000");
        headers.set("x-name", "Seguros");
        headers.set("x-digrequest", "12345");
        headers.set("x-rquid", "12345");
        headers.set("X-AuthUuid", "12345");
        headers.set("x-custtype", "ACTIVE");

        account.setSeller("seller");
        account.setGmf(true);
        account.setCeoCode("ceoCode");
        account.setDispersionCode("dispersionCode");
        account.setProductCode("010AH");
        account.setOfficeCode("0000");
    }

    @Test
    public void create() throws AbsBdbServiceException {

        headers.set("x-channel", "OPB001");
        createAccountResponseDto.setAccountNumber("012345678");

        when(requestUtilities.validateOpbChannel(eq("OPB001"), eq(EChannel.OPB001))).thenReturn("OPB001");
        when(customerApiService.getInfo(anyString(), anyString(), anyString(), anyString()))
                .thenReturn(new CustomerManagementRs());
        when(openApiMapper.mapDispatcher(any(HttpHeaders.class), anyString())).thenReturn(new DispatcherDto());
        when(dispatcherMapper.mapCreateRequest(any(), any())).thenReturn(new CreateRequestDto());
        when(requestService.createRequest(any(), anyString(), any())).thenReturn(new AccountRequestRsDto());
        when(accountService.accountOpeningV4(any(), any(), any())).thenReturn(new CreateAccountResponseDto());

        ProductDto response = openApiService.create(headers, account);
        Assertions.assertNotNull(response);
    }

    @Test
    public void createWithoutDigReq() throws AbsBdbServiceException {

        headers.remove("x-digrequest");
        createAccountResponseDto.setAccountNumber("012345678");

        when(requestUtilities.validateOpbChannel(eq("OPB001"), eq(EChannel.WEB))).thenReturn("WEB");
        when(customerApiService.getInfo(anyString(), anyString(), anyString(), anyString()))
                .thenReturn(new CustomerManagementRs());
        when(openApiMapper.mapDispatcher(any(), anyString())).thenReturn(new DispatcherDto());
        when(dispatcherMapper.mapCreateRequest(any(),any())).thenReturn(new CreateRequestDto());
        when(requestService.createRequest(any(), anyString(), any())).thenReturn(new AccountRequestRsDto());
        when(accountService.accountOpeningV4(any(), any(), any())).thenReturn(new CreateAccountResponseDto());

        ProductDto response = openApiService.create(headers, account);
        Assertions.assertNotNull(response);
    }

    @Test
    public void getCustomerFromCrmFail() throws AbsBdbServiceException {
        headers.set("x-channel", "WEB");

        when(requestUtilities.validateOpbChannel(eq("WEB"), eq(EChannel.WEB))).thenReturn("WEB");
        when(customerApiService.getInfo(anyString(), anyString(), anyString(), anyString()))
                .thenThrow(BdbExceptionFactory.createExcepcion(HttpStatus.NOT_FOUND, "", "FAILED GETTING CUSTOMER"));

        try {
            openApiService.create(headers, account);
        } catch (Exception exception) {
            Assertions.assertTrue(exception.getMessage().contains("FAILED"));
        }
    }

    @Test
    public void createRequestFail() throws AbsBdbServiceException {

        when(requestUtilities.validateOpbChannel(anyString(), eq(EChannel.WEB))).thenReturn("WEB");
        when(customerApiService.getInfo(anyString(), anyString(), anyString(), anyString()))
                .thenReturn(new CustomerManagementRs());
        when(openApiMapper.mapDispatcher(any(), anyString())).thenReturn(new DispatcherDto());
        when(dispatcherMapper.mapCreateRequest(any(), any())).thenReturn(new CreateRequestDto());
        when(requestService.createRequest(any(), anyString(), any())).thenThrow(BdbExceptionFactory.createExcepcion(HttpStatus.INTERNAL_SERVER_ERROR, "", "FAILED SAVE REQUEST"));
        try {
            openApiService.create(headers, account);
        } catch (Exception exception) {
            Assertions.assertTrue(exception.getMessage().contains("FAILED"));
        }
    }

    @Test
    public void createAccountFail() throws AbsBdbServiceException {

        when(requestUtilities.validateOpbChannel(anyString(), eq(EChannel.WEB))).thenReturn("WEB");
        when(customerApiService.getInfo(anyString(), anyString(), anyString(), anyString()))
                .thenReturn(new CustomerManagementRs());
        when(openApiMapper.mapDispatcher(any(), anyString())).thenReturn(new DispatcherDto());
        when(dispatcherMapper.mapCreateRequest(any(), any())).thenReturn(new CreateRequestDto());
        when(requestService.createRequest(any(), anyString(), any())).thenReturn(new AccountRequestRsDto());
        when(accountService.accountOpening(any(), any(), any())).thenReturn(new CreateAccountResponseDto());

        try {
            openApiService.create(headers, account);
        } catch (Exception exception) {
            Assertions.assertNotNull(exception);
        }
    }
}
